# -*- coding: utf-8 -*-
"""patch_v10: v9（くわしく）を「シンプルに」方式に反転。
   既定は全表示、ボタンで基本ブロックだけに絞る。
   あわせて 5-2 の③④を入れ替える。"""
import re, sys, importlib
sys.path.insert(0, '/home/claude/build')
v9 = importlib.import_module('patch_v9')

CSS = """
  /* ===== v10: シンプルに（基本ブロックだけ表示） ===== */
  .mbtn{font-family:"Zen Maru Gothic",sans-serif;font-weight:700;font-size:9.5pt;
    border:2px solid var(--key);border-radius:999px;padding:2px 15px 3px;cursor:pointer;
    background:#fff;color:var(--key);margin-right:auto;display:inline-flex;
    align-items:center;gap:5px;line-height:1.5;}
  .mbtn:active{transform:translateY(1px);}
  .mbtn.on{background:var(--key);color:#fff;}
  .mbtn .cv{font-family:"Lexend",sans-serif;font-size:8pt;transition:transform .15s;}
  .mbtn.on .cv{transform:rotate(180deg);}
  .blk-sec.more{display:block;}
  .simple .blk-sec.more{display:none;}
  .morehint{display:none;align-items:center;gap:8px;margin:0 0 9px;
    border:1.5px dashed #B9C4D2;border-radius:8px;padding:5px 12px;
    background:#F6F9FD;color:var(--mut);font-size:9.5pt;}
  .morehint b{color:var(--key);}
  .simple .morehint{display:flex;}
  @media print{ .mbtn,.morehint{display:none;} .blk-sec.more{display:block;} }
"""

JS = """
function toggleMore(btn){
  const s = btn.closest('.sheet');
  const on = s.classList.toggle('simple');
  btn.firstChild.nodeValue = on ? 'ぜんぶ表示 ' : 'シンプルに ';
  btn.classList.toggle('on', on);
  s.scrollIntoView({behavior:'smooth', block:'start'});
}
"""

MBTN_OLD = v9.MBTN
MBTN_NEW = MBTN_OLD.replace('くわしく ', 'シンプルに ')

HINT_NEW = ('  <div class="morehint"><svg style="width:15px;height:15px;flex:none;color:#1F4E9C">'
            '<use href="#i-pen"/></svg><div>かくれている説明を読みたいときは、上の '
            '<b>「ぜんぶ表示」</b> を押そう。</div></div>\n')


def swap_blocks(sheet1, a, b):
    """1ページ目の blk-sec を 1-origin の a 番目と b 番目で中身だけ入れ替え、
       番号を位置に合わせて振り直す。ラッパー（.more の有無）は動かさない。"""
    parts = re.split(r'(<div class="blk-sec(?: more)?">)', sheet1)
    # parts = [前, open1, body1, open2, body2, ...]
    opens = parts[1::2]
    bodies = parts[2::2]
    assert len(opens) >= max(a, b), ('ブロック数が足りません', len(opens))
    # 最後の body には quiz 以降も入っているので、</div> までで切る
    tails = []
    for i, bd in enumerate(bodies):
        bodies[i] = bd
    bodies[a-1], bodies[b-1] = bodies[b-1], bodies[a-1]
    # 番号を振り直す
    for i in range(len(bodies)):
        bodies[i] = re.sub(r'<span class="stepnum">\d+</span>',
                           '<span class="stepnum">%d</span>' % (i+1), bodies[i], count=1)
    out = [parts[0]]
    for o, bd in zip(opens, bodies):
        out.append(o); out.append(bd)
    return ''.join(out)


def patch(path, swap=None):
    s = open(path, encoding='utf-8').read()
    assert 'v9: くわしく' in s, 'patch_v9 を先に当ててください'
    if 'v10: シンプルに' in s:
        print('already v10:', path); return

    s = s.replace(v9.CSS, CSS)
    s = s.replace(v9.JS, JS)
    s = s.replace(MBTN_OLD, MBTN_NEW)
    s = s.replace(v9.HINT, HINT_NEW)
    assert 'v10: シンプルに' in s and MBTN_NEW in s and 'ぜんぶ表示' in s, '置換もれ'

    if swap:
        head, rest = s.split('<section class="sheet">', 1)
        sheet1, tail = rest.split('</section>', 1)
        sheet1 = swap_blocks(sheet1, *swap)
        s = head + '<section class="sheet">' + sheet1 + '</section>' + tail

    open(path, 'w', encoding='utf-8').write(s)
    order = re.findall(r'<span class="stepnum">(\d+)</span>([^<]*)',
                       s.split('<section class="sheet">')[1].split('</section>')[0])
    print('patched v10:', path.split('/')[-1])
    for n, t in order:
        print('   %s %s' % (n, t[:36]))


if __name__ == '__main__':
    patch('/home/claude/u5-2.html', swap=(3, 4))
