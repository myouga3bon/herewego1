# -*- coding: utf-8 -*-
"""patch_v9: 1ページ目を「きほんの3ブロック」だけにして、
   左上の『くわしく』ボタンで④以降を開く"""
import re, sys

KEEP = 3   # ①〜③はいつも表示

CSS = """
  /* ===== v9: くわしく（④以降の折りたたみ） ===== */
  .mbtn{font-family:"Zen Maru Gothic",sans-serif;font-weight:700;font-size:9.5pt;
    border:2px solid var(--key);border-radius:999px;padding:2px 15px 3px;cursor:pointer;
    background:#fff;color:var(--key);margin-right:auto;display:inline-flex;
    align-items:center;gap:5px;line-height:1.5;}
  .mbtn:active{transform:translateY(1px);}
  .mbtn.on{background:var(--key);color:#fff;}
  .mbtn .cv{font-family:"Lexend",sans-serif;font-size:8pt;transition:transform .15s;}
  .mbtn.on .cv{transform:rotate(180deg);}
  .blk-sec.more{display:none;}
  .showmore .blk-sec.more{display:block;}
  .morehint{display:flex;align-items:center;gap:8px;margin:0 0 9px;
    border:1.5px dashed #B9C4D2;border-radius:8px;padding:5px 12px;
    background:#F6F9FD;color:var(--mut);font-size:9.5pt;}
  .morehint b{color:var(--key);}
  .showmore .morehint{display:none;}
  @media print{ .mbtn,.morehint{display:none;} .blk-sec.more{display:block;} }
"""

JS = """
function toggleMore(btn){
  const s = btn.closest('.sheet');
  const on = s.classList.toggle('showmore');
  btn.firstChild.nodeValue = on ? 'かんたんに ' : 'くわしく ';
  btn.classList.toggle('on', on);
  if(!on) s.scrollIntoView({behavior:'smooth', block:'start'});
}
"""

MBTN = ('<button class="mbtn" onclick="toggleMore(this)">くわしく '
        '<span class="cv">▼</span></button>')

HINT = ('  <div class="morehint"><svg style="width:15px;height:15px;flex:none;color:#1F4E9C">'
        '<use href="#i-pen"/></svg><div>もっと知りたい人は、上の <b>「くわしく」</b> を押すと'
        'つづきが出ます。</div></div>\n')


def patch(path):
    s = open(path, encoding='utf-8').read()
    if 'v9: くわしく' in s:
        print('already v9:', path); return

    # 1) CSS
    anchor = '  @media print{ .ansbar,.toolbar{display:none;} .sheet{box-shadow:none;margin:0;} }'
    assert s.count(anchor) == 1, 'css anchor'
    s = s.replace(anchor, CSS + '\n' + anchor)

    # 2) 1ページ目を切り出す
    head, rest = s.split('<section class="sheet">', 1)
    sheet1, tail = rest.split('</section>', 1)

    # 3) ④以降の blk-sec に .more を付ける
    idx = [m.start() for m in re.finditer(r'<div class="blk-sec">', sheet1)]
    assert len(idx) > KEEP, ('blk-sec が足りません', len(idx))
    for p in reversed(idx[KEEP:]):
        sheet1 = (sheet1[:p] + '<div class="blk-sec more">'
                  + sheet1[p + len('<div class="blk-sec">'):])
    n_more = len(idx) - KEEP

    # 4) クイズの直前に案内を置く
    q = sheet1.index('  <div class="quiz">')
    sheet1 = sheet1[:q] + HINT + sheet1[q:]

    # 5) ツールバーの先頭に「くわしく」ボタン
    t = sheet1.index('<div class="toolbar">') + len('<div class="toolbar">')
    sheet1 = sheet1[:t] + MBTN + sheet1[t:]

    s = head + '<section class="sheet">' + sheet1 + '</section>' + tail

    # 6) JS
    jt = '\nfunction toggleHint(btn){'
    assert s.count(jt) == 1, 'js anchor'
    s = s.replace(jt, JS + jt)

    open(path, 'w', encoding='utf-8').write(s)
    print('patched v9: %s  表示=%d  たたむ=%d' % (path.split('/')[-1], KEEP, n_more))


if __name__ == '__main__':
    for p in sys.argv[1:]:
        patch(p)
