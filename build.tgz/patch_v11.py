# -*- coding: utf-8 -*-
"""patch_v11: 「シンプルに」ボタン。
   既定はぜんぶ表示。押すと ①②③ だけになる。
   「必須のことば」ブロックを③に繰り上げてから切る。
   u5-2 / u5-3 はすでに③が必須語ブロックなので並べ替えなし。"""
import re, sys, os

KEEP = 3   # シンプル時に残すブロック数

# 「必須のことば」にあたるブロックの見出し（③へ繰り上げる対象）
KEY_TITLES = ('テストによく出ることば', 'つづりが変わることば',
              '場所を表すことば', '時を表すことば')

CSS = """
  /* ===== v11: シンプルに（基本ブロックだけ表示） ===== */
  .mbtn{font-family:"Zen Maru Gothic",sans-serif;font-weight:700;font-size:9.5pt;
    border:2px solid var(--key);border-radius:999px;padding:2px 15px 3px;cursor:pointer;
    background:#fff;color:var(--key);margin-right:auto;display:inline-flex;
    align-items:center;gap:5px;line-height:1.5;}
  .mbtn:active{transform:translateY(1px);}
  .mbtn.on{background:var(--key);color:#fff;}
  .mbtn .cv{font-family:"Lexend",sans-serif;font-size:8pt;transition:transform .15s;}
  .mbtn.on .cv{transform:rotate(180deg);}
  .blk-sec.more{display:block;}
  .simple .blk-sec.more{display:none;}
  .morehint{display:none;align-items:center;gap:8px;margin:0 0 9px;
    border:1.5px dashed #B9C4D2;border-radius:8px;padding:5px 12px;
    background:#F6F9FD;color:var(--mut);font-size:9.5pt;}
  .morehint b{color:var(--key);}
  .simple .morehint{display:flex;}
  @media print{ .mbtn,.morehint{display:none;} .blk-sec.more{display:block;} }
"""

JS = """
function toggleMore(btn){
  const s = btn.closest('.sheet');
  const on = s.classList.toggle('simple');
  btn.firstChild.nodeValue = on ? 'ぜんぶ表示 ' : 'シンプルに ';
  btn.classList.toggle('on', on);
  s.scrollIntoView({behavior:'smooth', block:'start'});
}
"""

MBTN = ('<button class="mbtn" onclick="toggleMore(this)">シンプルに '
        '<span class="cv">▼</span></button>')

HINT = ('  <div class="morehint"><svg style="width:15px;height:15px;flex:none;color:#1F4E9C">'
        '<use href="#i-pen"/></svg><div>かくれている説明を読みたいときは、上の '
        '<b>「ぜんぶ表示」</b> を押そう。</div></div>\n')


def title_of(body):
    m = re.search(r'<span class="stepnum">\d+</span>(.*?)<button', body, re.S)
    return re.sub(r'<[^>]+>', '', m.group(1)).strip() if m else ''


def patch(path):
    name = os.path.basename(path)
    s = open(path, encoding='utf-8').read()
    if 'v11: シンプルに' in s or 'v10: シンプルに' in s:
        print('already simple:', name); return

    anchor = '  @media print{ .ansbar,.toolbar{display:none;} .sheet{box-shadow:none;margin:0;} }'
    assert s.count(anchor) == 1, ('css anchor', name)
    s = s.replace(anchor, CSS + '\n' + anchor)

    head, rest = s.split('<section class="sheet">', 1)
    sheet1, tail = rest.split('</section>', 1)

    # ブロックを分解
    parts = re.split(r'(<div class="blk-sec">)', sheet1)
    pre, bodies = parts[0], parts[2::2]
    assert len(bodies) > KEEP, ('ブロック数が足りません', name, len(bodies))

    # 必須語ブロックを探して③へ
    k = next((i for i, b in enumerate(bodies) if title_of(b) in KEY_TITLES), None)
    assert k is not None, ('必須語ブロックが見つかりません', name)
    moved = (k != KEEP - 1)
    if moved:
        b = bodies.pop(k)
        bodies.insert(KEEP - 1, b)

    # 番号を振り直し、④以降に .more
    out = [pre]
    for i, b in enumerate(bodies):
        b = re.sub(r'<span class="stepnum">\d+</span>',
                   '<span class="stepnum">%d</span>' % (i + 1), b, count=1)
        out.append('<div class="blk-sec%s">' % (' more' if i >= KEEP else ''))
        out.append(b)
    sheet1 = ''.join(out)

    # 案内とボタン
    q = sheet1.index('  <div class="quiz">')
    sheet1 = sheet1[:q] + HINT + sheet1[q:]
    t = sheet1.index('<div class="toolbar">') + len('<div class="toolbar">')
    sheet1 = sheet1[:t] + MBTN + sheet1[t:]

    s = head + '<section class="sheet">' + sheet1 + '</section>' + tail

    jt = '\nfunction toggleHint(btn){'
    assert s.count(jt) == 1, ('js anchor', name)
    s = s.replace(JS, '')          # 念のため重複防止
    s = s.replace(jt, JS + jt)

    open(path, 'w', encoding='utf-8').write(s)
    titles = [title_of(b)[:22] for b in bodies]
    print('v11 %-12s 繰り上げ=%s' % (name, '3番目へ' if moved else '不要'))
    for i, t2 in enumerate(titles, 1):
        print('    %s%d %s' % ('  ' if i > KEEP else '◎ ', i, t2))


if __name__ == '__main__':
    for p in sys.argv[1:]:
        patch(p)
