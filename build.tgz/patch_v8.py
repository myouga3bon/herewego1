# -*- coding: utf-8 -*-
"""patch_v8: セクションごとに「テストによく出ることば」ブロックを追加（鉛筆マーク＋書き写し）"""
import re, sys, os

# id: (タイトル, リード文, [(語, 意味, れい), ...], 書き写し文)
DATA = {
'u1-1': ('テストによく出ることば',
  'この3つが書ければ、<span class="en">I am ～.</span> の文はつくれます。<br>　とくに <span class="en">a</span> を忘れる人がとても多いです。',
  [('I am','わたしは ～ です','<u>I am</u> Ken.'),
   ("I&#39;m",'I am を短くした形','<u>I&#39;m</u> from Nagano.'),
   ('a','ひとつの（数えられるもの）','I am <u>a</u> student.')],
  '<span class="en">I am</span> ・ <span class="en">I&#39;m</span> ・ <span class="en">a</span> を3回ずつ書き写そう！'),

'u1-2': ('テストによく出ることば',
  '「する・好き」をあらわすことばが <b>動作のことば</b>です。<br>　打ち消すときは、その前に <span class="en">don&#39;t</span> を置きます。',
  [('like','好きです','I <u>like</u> dogs.'),
   ('play','します（スポーツなど）','I <u>play</u> soccer.'),
   ("don&#39;t",'～しません（打ち消し）','I <u>don&#39;t</u> like natto.')],
  '<span class="en">like</span> ・ <span class="en">play</span> ・ <span class="en">don&#39;t</span> を3回ずつ書き写そう！'),

'u1-3': ('テストによく出ることば',
  '<span class="en">can</span> のうしろは、かならず <b>かざりのない「原形（もとの形）」</b>です。<br>　<span class="en">swims</span> や <span class="en">swimming</span> にはしません。',
  [('can','～できます','I <u>can</u> swim.'),
   ("can&#39;t",'～できません','I <u>can&#39;t</u> swim.')],
  '<span class="en">can</span> ・ <span class="en">can&#39;t</span> を3回ずつ書き写そう！'),

'u2-1': ('テストによく出ることば',
  'たずねる文は <b><span class="en">Are</span> を前に出す</b>だけです。<br>　答え方もセットでおぼえましょう。',
  [('You are','あなたは ～ です','<u>You are</u> a student.'),
   ('Are you','あなたは ～ ですか','<u>Are you</u> a student?'),
   ('Yes, I am.','はい、そうです','Are you Ken? — <u>Yes, I am.</u>'),
   ("No, I&#39;m not.",'いいえ、ちがいます','Are you Ken? — <u>No, I&#39;m not.</u>')],
  '<span class="en">Are you</span> ・ <span class="en">Yes, I am.</span> ・ <span class="en">No, I&#39;m not.</span> を3回ずつ書き写そう！'),

'u2-2': ('テストによく出ることば',
  '動作のことばをたずねるときは <b><span class="en">Do you</span></b> で始めます。<br>　答えも <span class="en">do</span> を使います。',
  [('Do you','あなたは ～ しますか','<u>Do you</u> like soccer?'),
   ('Yes, I do.','はい、します','Do you play tennis? — <u>Yes, I do.</u>'),
   ("No, I don&#39;t.",'いいえ、しません','Do you play tennis? — <u>No, I don&#39;t.</u>')],
  '<span class="en">Do you</span> ・ <span class="en">Yes, I do.</span> ・ <span class="en">No, I don&#39;t.</span> を3回ずつ書き写そう！'),

'u2-3': ('テストによく出ることば',
  '<span class="en">Can you ～?</span> で聞かれたら、答えにも <span class="en">can</span> を使います。<br>　<span class="en">do</span> は使いません。',
  [('Can you','あなたは ～ できますか','<u>Can you</u> swim?'),
   ('Yes, I can.','はい、できます','Can you swim? — <u>Yes, I can.</u>'),
   ("No, I can&#39;t.",'いいえ、できません','Can you swim? — <u>No, I can&#39;t.</u>')],
  '<span class="en">Can you</span> ・ <span class="en">Yes, I can.</span> ・ <span class="en">No, I can&#39;t.</span> を3回ずつ書き写そう！'),

'u3-1': ('テストによく出ることば',
  '<span class="en">What</span> は<b>いちばん前</b>。<br>　そのうしろは <span class="en">do you</span> の順です。',
  [('What','なに','<u>What</u> do you like?'),
   ('What do you','あなたは なにを ～ しますか','<u>What do you</u> study?'),
   ('What sport','どのスポーツ','<u>What sport</u> do you like?')],
  '<span class="en">What</span> ・ <span class="en">What do you</span> を3回ずつ書き写そう！'),

'u3-2': ('つづりが変わることば',
  '<span class="en">-ing</span> のつけ方は3パターンあります。<br>　<b>そのままつける・字をかさねる・<span class="en">e</span> をとる</b> の3つです。',
  [('playing','そのまま ing をつける','I like <u>playing</u> tennis.'),
   ('swimming','m をかさねて ing','I like <u>swimming</u>.'),
   ('running','n をかさねて ing','I like <u>running</u>.'),
   ('dancing','e をとって ing','I like <u>dancing</u>.')],
  '<span class="en">playing</span> ・ <span class="en">swimming</span> ・ <span class="en">running</span> ・ <span class="en">dancing</span> を3回ずつ書き写そう！'),

'u3-3': ('テストによく出ることば',
  '<span class="en">to</span> のうしろは、かならず <b>原形（もとの形）</b>です。<br>　「～になる」は <span class="en">am・is・are</span> の原形（もとの形） <span class="en">be</span> を使います。',
  [('want to','～したいです','I <u>want to</u> swim.'),
   ('to be','～になりたい','I want <u>to be</u> a doctor.'),
   ('to go to','～へ行きたい','I want <u>to go to</u> America.')],
  '<span class="en">want to</span> ・ <span class="en">to be</span> を3回ずつ書き写そう！'),

'u4-1': ('テストによく出ることば',
  '<span class="en">he</span>・<span class="en">she</span> の文の be動詞は <b>かならず <span class="en">is</span></b>。<br>　<span class="en">am</span> も <span class="en">are</span> も使いません。',
  [('He is','彼は ～ です','<u>He is</u> my friend.'),
   ('She is','彼女は ～ です','<u>She is</u> my sister.'),
   ("He&#39;s",'He is を短くした形','<u>He&#39;s</u> kind.'),
   ("She&#39;s",'She is を短くした形','<u>She&#39;s</u> my sister.')],
  '<span class="en">He is</span> ・ <span class="en">She is</span> ・ <span class="en">He&#39;s</span> ・ <span class="en">She&#39;s</span> を3回ずつ書き写そう！'),

'u4-2': ('テストによく出ることば',
  '<span class="en">Who&#39;s</span> は <span class="en">Who is</span> を短くした形です。<br>　答えは <span class="en">He&#39;s</span>・<span class="en">She&#39;s</span> で<b>だれなのかを言います</b>。',
  [("Who&#39;s",'～は だれ ですか','<u>Who&#39;s</u> that girl?'),
   ("He&#39;s",'彼は ～ です','<u>He&#39;s</u> my friend.'),
   ("She&#39;s",'彼女は ～ です','<u>She&#39;s</u> my sister.')],
  '<span class="en">Who&#39;s</span> ・ <span class="en">He&#39;s</span> ・ <span class="en">She&#39;s</span> を3回ずつ書き写そう！'),

'u4-3': ('テストによく出ることば',
  'たずねる文は <b><span class="en">Is</span> を前に出す</b>。<br>　打ち消しは <span class="en">is</span> のうしろに <span class="en">not</span> を置きます。',
  [('Is this','これは ～ ですか','<u>Is this</u> your bag?'),
   ('Yes, it is.','はい、そうです','Is this your bag? — <u>Yes, it is.</u>'),
   ('is not','～ではありません','This <u>is not</u> my bag.'),
   ("isn&#39;t",'is not を短くした形','This <u>isn&#39;t</u> my bag.')],
  '<span class="en">Is this</span> ・ <span class="en">is not</span> ・ <span class="en">isn&#39;t</span> を3回ずつ書き写そう！'),

'u5-1': ('テストによく出ることば',
  '命令文は <b>主語を書かずに、原形（もとの形）で始めます</b>。<br>　<span class="en">You</span> を前に置かないのがポイントです。',
  [('Look','見て（原形（もとの形）で始める）','<u>Look</u> at this.'),
   ("Don&#39;t",'～しないで','<u>Don&#39;t</u> run here.'),
   ("Let&#39;s",'～しましょう','<u>Let&#39;s</u> go.')],
  '<span class="en">Look</span> ・ <span class="en">Don&#39;t</span> ・ <span class="en">Let&#39;s</span> を3回ずつ書き写そう！'),

'u5-3': ('時を表すことば',
  '答えるときは、<b>時を表すことば</b>を使います。<br>　<span class="en">in</span>・<span class="en">on</span>・<span class="en">at</span> の使い分けをおぼえましょう。',
  [('in','～月に・季節に','It&#39;s <u>in</u> August.'),
   ('on','～日に・曜日に','It&#39;s <u>on</u> May 5.'),
   ('at','～時に','I study <u>at</u> seven.'),
   ('When','いつ','<u>When</u> is your birthday?')],
  '時のことば <span class="en">in / on / at</span> を3回ずつ書き写そう！'),

'u6-1': ('テストによく出ることば',
  '<span class="en">he</span>・<span class="en">she</span> の文は、動作のことばに <b><span class="en">s</span></b> がつきます。<br>　ただし、つけ方が変わるものがあります。',
  [('plays','彼は ～ します','He <u>plays</u> soccer.'),
   ('has','have が変わる形','He <u>has</u> a dog.'),
   ('studies','y を i に変えて es','He <u>studies</u> math.'),
   ('watches','ch のあとは es','He <u>watches</u> TV.')],
  '<span class="en">plays</span> ・ <span class="en">has</span> ・ <span class="en">studies</span> ・ <span class="en">watches</span> を3回ずつ書き写そう！'),

'u6-2': ('テストによく出ることば',
  '<span class="en">Does</span> を前に出したら、うしろの動詞は <b>原形（もとの形）</b>にもどします。<br>　答えにも <span class="en">does</span> を使います。',
  [('Does he','彼は ～ しますか','<u>Does he</u> play soccer?'),
   ('Yes, he does.','はい、します','Does he play soccer? — <u>Yes, he does.</u>'),
   ("No, he doesn&#39;t.",'いいえ、しません','Does he play soccer? — <u>No, he doesn&#39;t.</u>')],
  '<span class="en">Does he</span> ・ <span class="en">Yes, he does.</span> ・ <span class="en">No, he doesn&#39;t.</span> を3回ずつ書き写そう！'),

'u6-3': ('テストによく出ることば',
  '<span class="en">doesn&#39;t</span> のうしろは <b>原形（もとの形）</b>。<br>　<span class="en">s</span> はもうつけません。',
  [("doesn&#39;t",'彼は ～ しません','He <u>doesn&#39;t</u> play soccer.'),
   ("don&#39;t",'わたし・あなたは ～ しません','I <u>don&#39;t</u> like natto.'),
   ("doesn&#39;t have",'has ではなく have にもどす','He <u>doesn&#39;t have</u> a dog.')],
  '<span class="en">doesn&#39;t</span> ・ <span class="en">don&#39;t</span> を3回ずつ書き写そう！'),

'u7-1': ('テストによく出ることば',
  '過去形は <span class="en">ed</span> をつけるのが基本です。<br>　でも、<b>形がまるごと変わるもの</b>もあります。',
  [('played','ed をつける','I <u>played</u> soccer.'),
   ('liked','e のあとは d だけ','I <u>liked</u> music.'),
   ('studied','y を i に変えて ed','I <u>studied</u> math.'),
   ('went','go の過去形（不規則）','I <u>went</u> to the park.')],
  '<span class="en">played</span> ・ <span class="en">liked</span> ・ <span class="en">studied</span> ・ <span class="en">went</span> を3回ずつ書き写そう！'),

'u7-2': ('テストによく出ることば',
  '<span class="en">Did</span> を前に出したら、うしろの動詞は <b>原形（もとの形）</b>にもどします。<br>　<span class="en">played</span> や <span class="en">went</span> にはしません。',
  [('Did you','あなたは ～ しましたか','<u>Did you</u> play soccer?'),
   ('Yes, I did.','はい、しました','Did you play soccer? — <u>Yes, I did.</u>'),
   ("No, I didn&#39;t.",'いいえ、しませんでした','Did you play soccer? — <u>No, I didn&#39;t.</u>'),
   ("didn&#39;t",'～しませんでした','I <u>didn&#39;t</u> play soccer.')],
  '<span class="en">Did you</span> ・ <span class="en">didn&#39;t</span> ・ <span class="en">Yes, I did.</span> を3回ずつ書き写そう！'),

'u7-4': ('テストによく出ることば',
  'be動詞の過去形は <span class="en">was</span> と <span class="en">were</span> の2つだけ。<br>　<b>主語で決まります</b>。',
  [('was','I・he・she のとき','I <u>was</u> happy.'),
   ('were','you・2人以上のとき','You <u>were</u> happy.'),
   ("wasn&#39;t",'was not を短くした形','I <u>wasn&#39;t</u> busy.'),
   ('Were you','あなたは ～ でしたか','<u>Were you</u> busy?')],
  '<span class="en">was</span> ・ <span class="en">were</span> ・ <span class="en">wasn&#39;t</span> を3回ずつ書き写そう！'),

'u8-1': ('テストによく出ることば',
  '進行形は <b>be動詞 ＋ 動詞ing</b> の<b>2つで1セット</b>です。<br>　<span class="en">ing</span> のつけ方は3-2と同じです。',
  [('am playing','～しているところです','I <u>am playing</u> soccer.'),
   ('is running','n をかさねて ing','He <u>is running</u>.'),
   ('is taking','e をとって ing','He <u>is taking</u> a picture.'),
   ('am swimming','m をかさねて ing','I <u>am swimming</u>.')],
  '<span class="en">am playing</span> ・ <span class="en">is running</span> ・ <span class="en">is taking</span> を3回ずつ書き写そう！'),

'u8-2': ('テストによく出ることば',
  'たずねる文は <b>be動詞を前に出す</b>だけ。<br>　<span class="en">Do</span> は使いません。答えも be動詞で返します。',
  [('Are you','あなたは ～ していますか','<u>Are you</u> playing soccer?'),
   ('Yes, I am.','はい、しています','Are you playing? — <u>Yes, I am.</u>'),
   ("No, I&#39;m not.",'いいえ、していません','Are you playing? — <u>No, I&#39;m not.</u>'),
   ('What are you doing?','なにをしていますか','<u>What are you doing?</u>')],
  '<span class="en">Are you</span> ・ <span class="en">Yes, I am.</span> ・ <span class="en">What are you doing?</span> を3回ずつ書き写そう！'),

'u8-3': ('テストによく出ることば',
  '過去進行形は <b><span class="en">was</span>・<span class="en">were</span> ＋ 動詞ing</b>。<br>　be動詞を過去形にするだけです。',
  [('was playing','～しているところでした','I <u>was playing</u> soccer.'),
   ('were playing','you・2人以上のとき','You <u>were playing</u> soccer.'),
   ('then','そのとき','I was playing soccer <u>then</u>.')],
  '<span class="en">was playing</span> ・ <span class="en">were playing</span> ・ <span class="en">then</span> を3回ずつ書き写そう！'),

}

ROW = ('        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg>'
       '<span class="en">%s</span></td><td class="k">%s</td><td class="e">%s</td></tr>')

BLOCK = '''  <div class="blk-sec">
    <h3 class="st"><span class="stepnum">%d</span>%s<button class="ksm" onclick="toggleKanaBlock(this)">カタカナ</button></h3>
    <p class="talk">%s</p>
    <table class="kind kw">
      <thead><tr><th>ことば</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
%s
      </tbody>
    </table>
    <div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>%s</div>
    </div>
  </div>

'''

def patch(path):
    name = os.path.basename(path).replace('.html', '')
    if name not in DATA:
        print('skip (データなし):', name); return
    s = open(path, encoding='utf-8').read()
    if 'v8: 必須のことば' in s:
        print('already v8:', name); return

    title, lead, rows, copy = DATA[name]
    nums = [int(x) for x in re.findall(r'<span class="stepnum">(\d+)</span>', s)]
    step = max(nums) + 1
    body = '\n'.join(ROW % r for r in rows)
    blk = BLOCK % (step, title, lead, body, copy)

    anchor = '  <div class="quiz">'
    assert s.count(anchor) == 1, ('sum anchor', name, s.count(anchor))
    s = s.replace(anchor, '<!-- v8: 必須のことば -->\n' + blk + anchor)

    open(path, 'w', encoding='utf-8').write(s)
    print('patched v8: %-12s step=%d rows=%d' % (name, step, len(rows)))

if __name__ == '__main__':
    for p in sys.argv[1:]:
        patch(p)
