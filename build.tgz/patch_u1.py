# -*- coding: utf-8 -*-
"""ソースを失った u1-1 / u1-2 の HTML を直接パッチ（改訂6点）"""
import io, re, sys

JP = {
 'I play soccer.':'わたしは サッカーを します。',
 'I like dogs.':'わたしは 犬が 好きです。',
 'I am a student.':'わたしは 学生 です。',
 'I&#39;m from Nagano.':'わたしは 長野出身 です。',
 'I am Ken.':'わたしは ケン です。',
 'I like spring.':'わたしは 春が 好きです。',
 'I don&#39;t like natto.':'わたしは 納豆が 好きでは ありません。',
 'I don&#39;t like dogs.':'わたしは 犬が 好きでは ありません。',
}
HERO = {
 'u1-1.html': ('I am Ken.', 'わたしは ケン です'),
 'u1-2.html': ('I like spring. ／ I don&#39;t like natto.', 'わたしは 春が 好きです ／ 納豆は 好きでは ありません'),
}
CSS_ANCHOR = '  .qza .qzp{display:block;'
CSS_NEW = ('  .qza .gjp{font-family:"Zen Kaku Gothic New",sans-serif;font-weight:500;\n'
           '    font-size:9.5pt;color:#4A4A4A;margin-left:9px;}\n')

for p in sys.argv[1:]:
    name = p.split('/')[-1]
    s = io.open(p, encoding='utf-8').read()
    # 1) 見出し
    s = s.replace('かならず書けることば', 'テストによく出ることば')
    # 2) もとの形 → 原形（もとの形）／解答欄内は「原形」
    s = re.sub(r'(<span class="ansfill">)もとの形(</span>)', r'\1原形\2', s)
    s = s.replace('／ もとの形', '／ 原形').replace('もとの形 ／', '原形 ／')
    s = s.replace('もとの形', '原形（もとの形）')
    # 3) CSS
    if '.qza .gjp' not in s:
        assert s.count(CSS_ANCHOR) == 1, (name, 'css anchor')
        s = s.replace(CSS_ANCHOR, CSS_NEW + CSS_ANCHOR)
    # 4) クイズ和訳
    def add(m):
        g = m.group(1)
        assert g in JP, (name, g)
        return m.group(0) + '<span class="gjp">%s</span>' % JP[g]
    s, n = re.subn(r'<span class="good en">○ ([^<]*)</span>(?!<span class="gjp")', add, s)
    # 5) hero
    if name in HERO:
        hb, hj = HERO[name]
        s = re.sub(r'(<div class="big">)[^<]*(</div>)', lambda m: m.group(1)+hb+m.group(2), s, count=1)
        s = re.sub(r'(<div class="jp">)[^<]*(</div>)', lambda m: m.group(1)+hj+m.group(2), s, count=1)
    io.open(p, 'w', encoding='utf-8').write(s)
    print('%-12s 訳%d件' % (name, n))
