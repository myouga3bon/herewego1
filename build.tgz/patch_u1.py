# -*- coding: utf-8 -*-
"""ソースを失った u1-1 / u1-2 の HTML を直接パッチ（改訂6点）"""
import io, re, sys

JP = {
 'I play soccer.':'わたしは サッカーを します。',
 'I like dogs.':'わたしは 犬が 好きです。',
 'I am a student.':'わたしは 学生 です。',
 'I&#39;m from Nagano.':'わたしは 長野出身 です。',
 'I am Ken.':'わたしは ケン です。',
 'I like spring.':'わたしは 春が 好きです。',
 'I don&#39;t like natto.':'わたしは 納豆が 好きでは ありません。',
 'I don&#39;t like dogs.':'わたしは 犬が 好きでは ありません。',
}
HERO = {
 'u1-1.html': ('I am Ken.', 'わたしは ケン です'),
 'u1-2.html': ('I like spring. ／ I don&#39;t like natto.', 'わたしは 春が 好きです ／ 納豆は 好きでは ありません'),
}

PEN = '<svg class="pn"><use href="#i-pen"/></svg>'

def _ex(a, b):
    return ('<div class="exline">%s<span class="s en">%s</span>'
            '<span class="t">%s</span></div>' % (PEN, a, b))

def _gitem(n, title, sub, jp, en, rows, note, b2=False):
    o = ['    <div class="gitem%s">' % (' b2' if b2 else '')]
    o.append('      <div class="gh"><span class="gn">%s</span>%s<small>%s</small></div>' % (n, title, sub))
    o.append('      <div class="gmap"><span class="j">%s</span><span class="ar">\u2192</span>'
             '<span class="e en">%s</span></div>' % (jp, en))
    for a, b in rows:
        o.append('      ' + _ex(a, b))
    o.append('      <div class="gnote">%s</div>' % note)
    o.append('    </div>')
    return '\n'.join(o)

def _gmap(jp, en, note):
    return ('    <div class="gmap solo"><span class="j">%s</span><span class="ar">\u2192</span>'
            '<span class="e en">%s</span></div>\n'
            '    <div class="gnote">%s</div>' % (jp, en, note))

BLK1 = {
 'u1-1.html': (
   '<p class="talk">「<b>わたしは エリです</b>」「<b>わたしは 学生です</b>」のように、<br>\u3000<b>自分が どんな人か</b>を言うときの形です。</p>\n'
   '    <p class="talk">使うのは <span class="en">I am ～.</span> の形。<br>\u3000<b>うしろを入れかえるだけ</b>で、いろいろなことが言えます。</p>\n'
   + _gmap('わたしは エリ <b>です</b>', '<b>I am</b> Eri.',
           '<b>am</b> が「です」にあたります。<span class="en">I</span> のときは かならず <b>am</b> を使います。') + '\n'
   '    <div class="exbox">\n      ' + _ex('I am Eri.', 'わたしは エリ です。') + '\n      '
   + _ex('I am a student.', 'わたしは 生徒 です。') + '\n      '
   + _ex('I am from Japan.', 'わたしは 日本出身 です。') + '\n    </div>\n'
   '    <p class="talk">3つとも形は同じですね。<br>\u3000<span class="en">I am</span> のうしろが入れかわっているだけです。</p>'),
 'u1-2.html': (
   '<p class="talk">「<b>春が 好きです</b>」「<b>納豆は 好きでは ありません</b>」のように、<br>\u3000<b>自分がすること・好きなこと</b>を言う形です。</p>\n'
   '    <p class="talk">前回の <span class="en">I am ～.</span> は「どんな人か」でした。<br>\u3000今回は<b>動作のことば</b>を使います。言い方は<b>2つ</b>です。</p>\n'
   + _gitem('\u2776', '「～します・～が 好きです」', 'ふつうの文',
            '春が 好きです', 'I like spring.',
            [('I like spring.', 'わたしは 春が 好きです。'),
             ('I play soccer.', 'わたしは サッカーを します。')],
            '<span class="en">I</span> のつぎに<b>動作のことば</b>を置くだけ。<span class="en">am</span> は<b>使いません</b>。') + '\n'
   + _gitem('\u2777', '「～しません・～は 好きでは ありません」', '打ち消す文',
            '納豆は 好きでは ありません', 'I don&#39;t like natto.',
            [('I don&#39;t like natto.', 'わたしは 納豆が 好きでは ありません。'),
             ('I don&#39;t play soccer.', 'わたしは サッカーを しません。')],
            '動作のことばの<b>前</b>に <b>don&#39;t</b> を置くだけ。うしろは<b>そのまま</b>です。', b2=True) + '\n'
   '    <p class="talk">どちらも まず <span class="en">I</span> から始まり、<br>\u3000そのつぎに<b>動作のことば</b>が来ています。</p>'),
}

GITEM_CSS = """  .gitem{border:2px solid var(--key);border-radius:6px;padding:4px 12px 6px;margin:4px 0;}
  .gitem.b2{border-color:var(--gv);}
  .gitem .gh{display:flex;align-items:center;gap:7px;font-weight:700;font-size:11pt;
    color:var(--key);margin-bottom:3px;}
  .gitem.b2 .gh{color:var(--gv);}
  .gitem .gh .gn{font-size:13pt;line-height:1;}
  .gitem .gh small{font-weight:500;font-size:9.5pt;color:var(--mut);margin-left:2px;}
  .gmap{display:flex;align-items:center;gap:9px;flex-wrap:wrap;
    background:rgba(31,78,156,.07);border-radius:5px;padding:3px 10px;margin:2px 0 4px;}
  .gitem.b2 .gmap{background:rgba(194,24,91,.07);}
  .gmap.solo{margin:4px 0 5px;padding:5px 12px;}
  .gmap .j{font-size:11pt;font-weight:700;color:var(--ink);}
  .gmap .ar{font-size:12pt;color:var(--mut);font-weight:700;}
  .gmap .e{font-family:"Lexend",sans-serif;font-size:12pt;font-weight:700;color:var(--key);}
  .gitem.b2 .gmap .e{color:var(--gv);}
  .gnote{font-size:9.5pt;color:var(--mut);line-height:1.6;margin-top:2px;}
  .gnote b{color:var(--ng);}
"""

CSS_ANCHOR = '  .qza .qzp{display:block;'
CSS_NEW = ('  .qza .gjp{font-family:"Zen Kaku Gothic New",sans-serif;font-weight:500;\n'
           '    font-size:9.5pt;color:#4A4A4A;margin-left:9px;}\n')

for p in sys.argv[1:]:
    name = p.split('/')[-1]
    s = io.open(p, encoding='utf-8').read()
    # 1) 見出し
    s = s.replace('かならず書けることば', 'テストによく出ることば')
    # 2) もとの形 → 原形（もとの形）／解答欄内は「原形」
    s = re.sub(r'(<span class="ansfill">)もとの形(</span>)', r'\1原形\2', s)
    s = s.replace('／ もとの形', '／ 原形').replace('もとの形 ／', '原形 ／')
    s = s.replace('もとの形', '原形（もとの形）')
    # 3) CSS
    if '.gitem{' not in s:
        a2 = '  .exbox{'
        assert s.count(a2) == 1, (name, 'exbox css')
        s = s.replace(a2, GITEM_CSS + a2)
    if '.qza .gjp' not in s:
        assert s.count(CSS_ANCHOR) == 1, (name, 'css anchor')
        s = s.replace(CSS_ANCHOR, CSS_NEW + CSS_ANCHOR)
    # 4) クイズ和訳
    def add(m):
        g = m.group(1)
        assert g in JP, (name, g)
        return m.group(0) + '<span class="gjp">%s</span>' % JP[g]
    s, n = re.subn(r'<span class="good en">○ ([^<]*)</span>(?!<span class="gjp")', add, s)
    # 4.5) きほんの文ブロックを作り直す
    if name in BLK1:
        k = s.index('<span class="stepnum">1</span>きほんの文')
        k = s.index('</h3>\n', k) + len('</h3>\n')
        e = s.index('    <div class="copy">', k)
        s = s[:k] + '    ' + BLK1[name] + '\n' + s[e:]

    # 5) hero
    if name in HERO:
        hb, hj = HERO[name]
        s = re.sub(r'(<div class="big">)[^<]*(</div>)', lambda m: m.group(1)+hb+m.group(2), s, count=1)
        s = re.sub(r'(<div class="jp">)[^<]*(</div>)', lambda m: m.group(1)+hj+m.group(2), s, count=1)
    io.open(p, 'w', encoding='utf-8').write(s)
    print('%-12s 訳%d件' % (name, n))
