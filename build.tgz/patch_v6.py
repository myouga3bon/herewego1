# -*- coding: utf-8 -*-
"""v6: 2列の問題を「縦順」に／選択肢つきの長い問題は1問1行に"""
import re, sys

CSS = """
  /* ===== v6: 2列の問題は縦順（左に1〜、右に続き） ===== */
  .grid2.vcol{display:block;column-count:2;column-gap:20px;}
  .grid2.vcol > div{width:auto;display:block;
    break-inside:avoid;-webkit-column-break-inside:avoid;page-break-inside:avoid;}
  /* ===== v6: 選択肢つきの長い問題は1問1行 ===== */
  .grid2.one{display:block;}
  .grid2.one > div{width:auto;display:block;padding:3px 0;}
"""

LIMIT = 42   # タグを除いた文字数がこれを超える問題があれば 1問1行にする


def strip_tags(t):
    return re.sub(r'<[^>]+>', '', t)


def patch(path):
    s = open(path, encoding='utf-8').read()
    if 'v6: 2列の問題は縦順' in s:
        print('already v6:', path); return

    anchor = '  @media print{ .ansbar,.toolbar{display:none;} .sheet{box-shadow:none;margin:0;} }'
    assert s.count(anchor) == 1
    s = s.replace(anchor, CSS + '\n' + anchor)

    stats = []

    def per_grid(m):
        body = m.group(1)
        items = re.findall(r'<div>(.*?)</div>\n', body, flags=re.S)
        longest = max((len(strip_tags(x).strip()) for x in items), default=0)
        cls = 'one' if longest > LIMIT else 'vcol'
        stats.append((len(items), longest, cls))
        return '<div class="grid2 %s">\n%s\n  </div>' % (cls, body.rstrip('\n'))

    s = re.sub(r'<div class="grid2">\n(.*?)\n  </div>', per_grid, s, flags=re.S)

    open(path, 'w', encoding='utf-8').write(s)
    for n, L, c in stats:
        print('  grid2: %2d問 最長%3d字 → %s' % (n, L, c))
    print('patched v6:', path, len(s.encode('utf-8')), 'bytes')


if __name__ == '__main__':
    for p in sys.argv[1:]:
        patch(p)
