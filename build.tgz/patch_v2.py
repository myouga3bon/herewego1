# -*- coding: utf-8 -*-
"""オンライン版に v2 の機能を追加するパッチ
  1) 濃い背景の上のカタカナを白くする
  2) カタカナ辞書に共通語を追加（Where's など）
  3) 左side に乾電池のエネルギーゲージ
  4) 各パート右上に小さなタイマー
  5) 表のことばにつける鉛筆マークのスタイル
"""
import re, sys

CSS = """
  /* ===== v2: 濃い背景の上のカタカナは白く ===== */
  .hero ruby.rb rt,
  .heart ruby.rb rt,
  .blocks .blk.fill ruby.rb rt,
  .judge .ttl ruby.rb rt,
  .chip ruby.rb rt,
  .exlab ruby.rb rt,
  .abtn ruby.rb rt,
  .sbtn.on ruby.rb rt,
  .qzb.on ruby.rb rt{
    color:#FFFFFF; -webkit-text-fill-color:#FFFFFF;
    text-shadow:0 0 2px rgba(0,0,0,.45);}
  /* 色つきの枠の中（判定ボックスのタイトル）は少し濃いめの影で読みやすく */
  .judge .ttl ruby.rb rt{text-shadow:0 0 3px rgba(0,0,0,.6);}

  /* ===== v2: 表のことばの鉛筆マーク ===== */
  table.kind td.k .pn{width:13px;height:13px;color:#C88A16;
    vertical-align:-2px;margin-right:5px;flex:none;}

  /* ===== v2: エネルギーゲージ（乾電池） ===== */
  .gauge{position:fixed;left:7px;top:50%;transform:translateY(-50%);z-index:60;
    display:flex;flex-direction:column;align-items:center;gap:3px;
    pointer-events:none;user-select:none;}
  .gauge .cap{width:9px;height:4px;background:#C2185B;border-radius:2px 2px 0 0;}
  .gauge .body{width:19px;height:72px;border:2px solid #C2185B;border-radius:4px;
    background:#fff;padding:2px;display:flex;flex-direction:column-reverse;
    overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.14);}
  .gauge .fill{width:100%;height:0%;border-radius:2px;
    background:repeating-linear-gradient(to top,
      #FF6B8A 0, #FF6B8A 5.4px, #E0447A 5.4px, #E0447A 6.8px);
    transition:height .3s ease;}
  .gauge .pct{font-family:"Lexend",sans-serif;font-weight:700;font-size:9px;
    color:#C2185B;line-height:1;}
  @media print{.gauge{display:none;}}
  @media (max-width:560px){
    .gauge{left:1px;} .gauge .body{width:14px;height:54px;}
    .gauge .cap{width:7px;} .gauge .pct{font-size:8px;}
  }

  /* ===== v2: アナログタイマー（30分で一周／セット全体の時間） ===== */
  .clock{display:flex;flex-direction:column;align-items:center;gap:2px;margin-top:9px;}
  .clock .cl{width:34px;height:34px;display:block;}
  .clock .cf{fill:#fff;stroke:var(--key);stroke-width:2.4;}
  .clock .cp{fill:rgba(31,78,156,.22);}
  .clock .ct{stroke:var(--key);stroke-width:1.5;opacity:.55;}
  .clock .ch{stroke:var(--key);stroke-width:2;stroke-linecap:round;}
  .clock .cc{fill:var(--key);}
  .clock .cm{font-family:"Lexend",sans-serif;font-weight:700;font-size:9px;
    color:var(--key);line-height:1;}
  .clock.over .cf{stroke:var(--ng);}
  .clock.over .cp{fill:rgba(181,39,63,.22);}
  .clock.over .ct{stroke:var(--ng);}
  .clock.over .ch{stroke:var(--ng);}
  .clock.over .cc{fill:var(--ng);}
  .clock.over .cm{color:var(--ng);}
  @media (max-width:560px){ .clock .cl{width:26px;height:26px;} .clock .cm{font-size:8px;} }
"""

CLOCK = ('<symbol id="i-clock" viewBox="0 0 24 24">'
         '<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/>'
         '<path d="M12 7v5.3l3.4 2" fill="none" stroke="currentColor" stroke-width="2" '
         'stroke-linecap="round" stroke-linejoin="round"/></symbol>')

KANA_ADD = """,
  // ===== v2: 共通語の追加 =====
  "you":"ユー","your":"ユア","yes":"イエス","no":"ノウ","what":"ワット",
  "who":"フー","where":"ウェア","when":"ウェン","how":"ハウ","why":"ワイ",
  "where's":"ウェアズ","when's":"ウェンズ","who's":"フーズ","what's":"ワッツ",
  "it's":"イッツ","he's":"ヒーズ","she's":"シーズ","you're":"ユア","that's":"ザッツ",
  "let's":"レッツ","isn't":"イズント","aren't":"アーント","wasn't":"ワズント",
  "weren't":"ワーント","doesn't":"ダズント","didn't":"ディドゥント","can't":"キャント",
  "cannot":"キャナット","does":"ダズ","did":"ディッド","was":"ワズ","were":"ワー",
  "he":"ヒー","she":"シー","it":"イット","we":"ウィー","they":"ゼイ","this":"ズィス",
  "that":"ザット","these":"ズィーズ","those":"ゾウズ","there":"ゼア","here":"ヒア",
  "in":"イン","on":"オン","at":"アット","to":"トゥ","of":"オヴ","and":"アンド",
  "or":"オア","but":"バット","under":"アンダー","near":"ニア","by":"バイ","with":"ウィズ",
  "for":"フォー","after":"アフター","before":"ビフォー","every":"エヴリィ","day":"デイ",
  "now":"ナウ","then":"ゼン","yesterday":"イエスタデイ","tomorrow":"トゥモロウ",
  "last":"ラスト","next":"ネクスト","week":"ウィーク","night":"ナイト","morning":"モーニング",
  "eat":"イート","ate":"エイト","go":"ゴウ","went":"ウェント","see":"スィー","saw":"ソー",
  "get":"ゲット","got":"ガット","make":"メイク","made":"メイド","had":"ハッド","has":"ハズ",
  "study":"スタディ","studies":"スタディーズ","studied":"スタディド","live":"リヴ","lives":"リヴズ",
  "cook":"クック","sing":"スィング","swim":"スウィム","dance":"ダンス","read":"リード",
  "write":"ライト","speak":"スピーク","want":"ウォント","help":"ヘルプ","open":"オウプン",
  "close":"クロウズ","look":"ルック","listen":"リスン","come":"カム","take":"テイク",
  "jump":"ジャンプ","walk":"ウォーク","talk":"トーク","practice":"プラクティス",
  "visit":"ヴィズィット","enjoy":"エンジョイ","stop":"スタップ","sit":"シット","stand":"スタンド",
  "bag":"バッグ","desk":"デスク","table":"テイブル","room":"ルーム","school":"スクール",
  "library":"ライブラリィ","park":"パーク","station":"ステイション","home":"ホウム",
  "book":"ブック","books":"ブックス","pen":"ペン","cap":"キャップ","bike":"バイク",
  "lunch":"ランチ","dinner":"ディナー","breakfast":"ブレックファスト","rice":"ライス",
  "sushi":"スーシ","water":"ウォーター","picture":"ピクチャ","guitar":"ギター",
  "piano":"ピアノ","math":"マス","science":"サイエンス","subject":"サブジェクト",
  "color":"カラー","sport":"スポート","sports":"スポーツ","food":"フード",
  "friend":"フレンド","brother":"ブラザー","sister":"スィスター","father":"ファーザー",
  "mother":"マザー","teacher":"ティーチャー","doctor":"ダクター","singer":"スィンガー",
  "girl":"ガール","boy":"ボイ","man":"マン","woman":"ウーマン","birthday":"バースデイ",
  "kind":"カインド","tall":"トール","nice":"ナイス","cute":"キュート","busy":"ビズィ",
  "tired":"タイアド","free":"フリー","sick":"スィック","sleepy":"スリーピィ","fun":"ファン",
  "good":"グッド","well":"ウェル","high":"ハイ","please":"プリーズ","together":"トゥゲザー",
  "monday":"マンデイ","sunday":"サンデイ","saturday":"サタデイ","summer":"サマー",
  "winter":"ウィンター","august":"オーガスト","july":"ジュライ","america":"アメリカ",
  "paris":"パリス","tokyo":"トウキョウ","kyoto":"キョウト","mike":"マイク","emma":"エマ",
  "saki":"サキ","six":"スィックス","seven":"セヴン","five":"ファイヴ","ten":"テン\""""

GAUGE_HTML = """<div class="gauge" aria-hidden="true">
  <div class="cap"></div>
  <div class="body"><div class="fill" id="gfill"></div></div>
  <div class="pct" id="gpct">0%</div>
  <div class="clock" id="clock">
    <svg class="cl" viewBox="0 0 40 40">
      <circle class="cf" cx="20" cy="20" r="17"/>
      <path class="cp" id="cpie" d=""/>
      <g class="ct">
        <line x1="20" y1="4.4" x2="20" y2="7.4"/>
        <line x1="35.6" y1="20" x2="32.6" y2="20"/>
        <line x1="20" y1="35.6" x2="20" y2="32.6"/>
        <line x1="4.4" y1="20" x2="7.4" y2="20"/>
      </g>
      <line class="ch" id="chand" x1="20" y1="20" x2="20" y2="6.5"/>
      <circle class="cc" cx="20" cy="20" r="2.1"/>
    </svg>
    <div class="cm" id="cmin">0分</div>
  </div>
</div>

"""


JS = """
// ===== v2: エネルギーゲージ（進んだ量を乾電池で表す） =====
(function energyGauge(){
  const fill = document.getElementById('gfill');
  const pct  = document.getElementById('gpct');
  if(!fill) return;
  let shown = -1;
  function update(){
    const doc = document.documentElement;
    const max = doc.scrollHeight - window.innerHeight;
    const r = max > 0 ? window.scrollY / max : 0;
    const p = Math.max(0, Math.min(100, Math.round(r * 10) * 10));
    if(p === shown) return;
    shown = p;
    fill.style.height = p + '%';
    pct.textContent = p + '%';
  }
  window.addEventListener('scroll', update, {passive:true});
  window.addEventListener('resize', update);
  update();
})();

// ===== v2: アナログタイマー（30分で一周。セット全体の時間を計る） =====
(function setTimer(){
  const box  = document.getElementById('clock');
  const pie  = document.getElementById('cpie');
  const hand = document.getElementById('chand');
  const lab  = document.getElementById('cmin');
  if(!box) return;
  const FULL = 30 * 60;           // 30分で一周
  const KEY  = 'hwg_timer_' + location.pathname;
  let sec = 0;
  try{ sec = parseInt(sessionStorage.getItem(KEY) || '0', 10) || 0; }catch(e){}

  function sector(a){             // 12時から時計回りに a 度ぶんの扇形
    if(a <= 0) return '';
    if(a >= 359.9) a = 359.9;
    const r = 17, c = 20, rad = a * Math.PI / 180;
    const x = c + r * Math.sin(rad), y = c - r * Math.cos(rad);
    return 'M' + c + ',' + c + ' L' + c + ',' + (c - r) +
           ' A' + r + ',' + r + ' 0 ' + (a > 180 ? 1 : 0) + ',1 ' +
           x.toFixed(2) + ',' + y.toFixed(2) + ' Z';
  }
  function draw(){
    const t = Math.min(sec, FULL);
    const a = t / FULL * 360;
    pie.setAttribute('d', sector(a));
    hand.setAttribute('transform', 'rotate(' + (sec / FULL * 360) % 360 + ',20,20)');
    lab.textContent = Math.floor(sec / 60) + '分';
    box.classList.toggle('over', sec >= FULL);
  }
  draw();
  setInterval(() => {
    if(document.hidden) return;
    sec++;
    try{ sessionStorage.setItem(KEY, String(sec)); }catch(e){}
    draw();
  }, 1000);
})();
"""


def patch(path):
    s = open(path, encoding='utf-8').read()
    if 'v2: エネルギーゲージ' in s:
        print('already patched:', path); return

    # 1) CSS
    anchor = '  @media print{ .ansbar,.toolbar{display:none;} .sheet{box-shadow:none;margin:0;} }'
    assert s.count(anchor) == 1, 'css anchor'
    s = s.replace(anchor, CSS + '\n' + anchor)

    # 2) 時計アイコン
    m = re.search(r'<symbol id="i-pen".*?</symbol>', s, re.S)
    assert m, 'pen symbol'
    s = s[:m.end()] + '\n    ' + CLOCK + s[m.end():]

    # 3) カタカナ辞書
    m = re.search(r'(const KANA = \{.*?)(\n\};)', s, re.S)
    assert m, 'kana dict'
    s = s[:m.end(1)] + KANA_ADD + s[m.start(2):]

    # 4) ゲージ本体（最初の .sheet の直前）
    i = s.index('<section class="sheet">')
    s = s[:i] + GAUGE_HTML + s[i:]

    # 5) カタカナの対象に判定ボックスの見出しも加える
    sel_old = ("const SEL = '.en, .exline .s, .judge .ex, .eqbox .eq, .hero .big, "
               ".fill2, .ansfill, table.kind td.e, .model .ex';")
    sel_new = ("const SEL = '.en, .exline .s, .judge .ex, .judge .ttl span, .eqbox .eq, "
               ".hero .big, .fill2, .ansfill, table.kind td.e, .model .ex';")
    assert s.count(sel_old) == 1, 'kana SEL'
    s = s.replace(sel_old, sel_new)

    # 6) JS
    tail = '\nfunction toggleHint(btn){'
    assert s.count(tail) == 1, 'js anchor'
    s = s.replace(tail, JS + tail)

    open(path, 'w', encoding='utf-8').write(s)
    print('patched:', path, len(s.encode('utf-8')), 'bytes')


if __name__ == '__main__':
    for p in sys.argv[1:]:
        patch(p)
