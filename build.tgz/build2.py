# -*- coding: utf-8 -*-
"""2年生セクションのビルド＋パッチ一括実行"""
import sys, os, importlib, subprocess
sys.path.insert(0, '/home/claude/build')
sys.path.insert(0, '/home/claude/build/sections2')
import gen

PATCHES = ['patch_v2', 'patch_v3', 'patch_v5', 'patch_v6', 'patch_v8', 'patch_v11', 'patch_v12']

def build(ids):
    paths = []
    for i in ids:
        m = importlib.import_module('g2_' + i.replace('-', '_'))
        importlib.reload(m)
        p, n = gen.build(m.S)
        print('built %-12s %6d bytes' % (os.path.basename(p), n))
        paths.append(p)
    for pt in PATCHES:
        r = subprocess.run([sys.executable, '-I', pt + '.py'] + paths,
                           capture_output=True, text=True, cwd='/home/claude/build')
        if r.returncode:
            print('!! %s FAILED\n%s' % (pt, r.stderr[-1500:])); return paths
        print('%-11s ok' % pt)
    return paths

if __name__ == '__main__':
    build(sys.argv[1:])
