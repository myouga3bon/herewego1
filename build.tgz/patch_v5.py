# -*- coding: utf-8 -*-
"""v5: 英語を押すと読み上げる（Web Speech API）"""
import sys

CSS = """
  /* ===== v5: 英語を押すと読み上げ ===== */
  .sp{cursor:pointer;border-radius:3px;transition:background .12s;}
  .sp:hover{background:#E6F0FF;box-shadow:0 0 0 2px #E6F0FF;}
  .sp.playing{background:#FFE9A8 !important;box-shadow:0 0 0 2px #FFE9A8;}
  .hero .sp:hover, .heart .sp:hover, .judge .ttl .sp:hover,
  .blocks .blk.fill .sp:hover{background:rgba(255,255,255,.26);
    box-shadow:0 0 0 2px rgba(255,255,255,.26);}
  .hero .sp.playing, .heart .sp.playing, .judge .ttl .sp.playing,
  .blocks .blk.fill .sp.playing{background:rgba(255,220,120,.45) !important;
    box-shadow:0 0 0 2px rgba(255,220,120,.45);}
  .spnote{font-size:9pt;color:#5A7FA8;display:inline-flex;align-items:center;gap:4px;}
  .spnote svg{width:13px;height:13px;color:#5A7FA8;}
  .spbtn{font-family:"Zen Maru Gothic",sans-serif;font-weight:700;font-size:8.5pt;
    border:1.5px solid #AEC4DE;border-radius:6px;padding:1px 9px;cursor:pointer;
    background:#F4F8FD;color:#4A7FB5;line-height:1.5;flex:none;}
  .spbtn:hover{border-color:#5E9BE0;}
  .spbtn.on{background:var(--key);border-color:var(--key);color:#fff;}
  @media print{.spnote,.spbtn{display:none;} .sp{cursor:auto;}}
"""

SPEAKER = ('<symbol id="i-sound" viewBox="0 0 24 24">'
           '<path d="M4 9.5h3.4L12 5.5v13L7.4 14.5H4z" fill="currentColor"/>'
           '<path d="M15.4 9.2a4 4 0 0 1 0 5.6M18 6.6a7.6 7.6 0 0 1 0 10.8" '
           'fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/>'
           '</symbol>')

TOOL = ('<span class="spnote"><svg><use href="#i-sound"/></svg>英語を押すと読み上げ</span>'
        '<button class="spbtn" onclick="toggleSlow(this)">ゆっくり</button>')

RETRY_SPEECH = (
    "+ 'var SV=null;function pv(){var vs=speechSynthesis.getVoices();"
    "SV=vs.filter(function(v){return /^en/i.test(v.lang);})[0]||null;}"
    "if(window.speechSynthesis){pv();speechSynthesis.addEventListener(\"voiceschanged\",pv);"
    "document.addEventListener(\"click\",function(e){var el=e.target.closest(\".sp\");"
    "if(!el)return;var c=el.cloneNode(true);"
    "c.querySelectorAll(\"rt\").forEach(function(x){x.remove();});"
    "if(!el.closest(\".showans\"))c.querySelectorAll(\".ansfill,.fill2,.ansmark\")"
    ".forEach(function(x){x.remove();});"
    "var t=c.textContent.replace(/[\u0028\u0029\uFF08\uFF09]/g,\" \")"
    ".replace(/[^\\x20-\\x7E]/g,\" \").replace(/\\s+/g,\" \").trim();"
    "if(!t||!/[A-Za-z]/.test(t))return;speechSynthesis.cancel();"
    "el.classList.add(\"playing\");var u=new SpeechSynthesisUtterance(t);"
    "u.lang=(SV&&SV.lang)||\"en-US\";if(SV)u.voice=SV;u.rate=0.9;"
    "u.onend=u.onerror=function(){el.classList.remove(\"playing\");};"
    "speechSynthesis.speak(u);});}'"
)

JS = """
// ===== v5: 英語を押すと読み上げる（Web Speech API） =====
const SPEECH = {slow:false, voice:null, el:null};

function toggleSlow(btn){
  SPEECH.slow = !SPEECH.slow;
  document.querySelectorAll('.spbtn').forEach(b => {
    b.classList.toggle('on', SPEECH.slow);
    b.textContent = SPEECH.slow ? 'ふつうの速さ' : 'ゆっくり';
  });
}

(function initSpeech(){
  if(!('speechSynthesis' in window)){
    document.querySelectorAll('.spnote, .spbtn').forEach(e => e.remove());
    return;
  }
  function pickVoice(){
    const vs = speechSynthesis.getVoices();
    SPEECH.voice = vs.find(v => /^en[-_]US/i.test(v.lang))
                || vs.find(v => /^en[-_]GB/i.test(v.lang))
                || vs.find(v => /^en/i.test(v.lang)) || null;
  }
  pickVoice();
  speechSynthesis.addEventListener('voiceschanged', pickVoice);

  // 読み上げ対象に .sp を付ける（まちがいの例ははずす）
  const SEL = '.en, .exline .s, .judge .ex, .judge .ttl span, .eqbox .eq, '
            + '.hero .big, .fill2, .ansfill, table.kind td.e, .model .ex';
  document.querySelectorAll(SEL).forEach(el => {
    if(el.closest('.bad, .xm, .x, s, .qzq')) return;
    if(el.closest('.hbtn, .kbtn, .ksm, .abtn, .sbtn, .qzb, .rbtn, .spbtn')) return;
    el.classList.add('sp');
  });

  function textOf(el){
    const c = el.cloneNode(true);
    c.querySelectorAll('rt').forEach(x => x.remove());          // カタカナは読まない
    c.querySelectorAll('br').forEach(b => b.replaceWith(document.createTextNode('. ')));
    // 答えが隠れているときは、答えを読み上げない
    if(!el.closest('.showans')){
      c.querySelectorAll('.ansfill, .fill2, .ansmark').forEach(x => x.remove());
    }
    let t = c.textContent;
    t = t.replace(/[（）()]/g, ' ')
         .replace(/[／]/g, ' , ')
         .replace(/[～〜]/g, ' ')
         .replace(/[‘’]/g, "'")
         .replace(/[^\\x20-\\x7E]/g, ' ')       // 日本語は読まない
         .replace(/\\s*,\\s*,+/g, ' , ')
         .replace(/\\s+/g, ' ')
         .trim();
    return t;
  }

  document.addEventListener('click', e => {
    const el = e.target.closest('.sp');
    if(!el) return;
    const t = textOf(el);
    if(!t || !/[A-Za-z]/.test(t)) return;
    try{ speechSynthesis.cancel(); }catch(err){}
    if(SPEECH.el) SPEECH.el.classList.remove('playing');
    SPEECH.el = el;
    el.classList.add('playing');
    const u = new SpeechSynthesisUtterance(t);
    u.lang = (SPEECH.voice && SPEECH.voice.lang) || 'en-US';
    if(SPEECH.voice) u.voice = SPEECH.voice;
    u.rate = SPEECH.slow ? 0.6 : 0.9;
    u.pitch = 1;
    u.onend = u.onerror = () => { el.classList.remove('playing'); };
    try{ speechSynthesis.speak(u); }
    catch(err){ el.classList.remove('playing'); }
  });
})();
"""


def patch(path):
    s = open(path, encoding='utf-8').read()
    assert 'v3: 問題番号を押してチェック' in s, 'run patch_v3 first'
    if 'v5: 英語を押すと読み上げ' in s:
        print('already v5:', path); return

    anchor = '  @media print{ .ansbar,.toolbar{display:none;} .sheet{box-shadow:none;margin:0;} }'
    assert s.count(anchor) == 1
    s = s.replace(anchor, CSS + '\n' + anchor)

    clock = '<symbol id="i-clock" viewBox="0 0 24 24">'
    i = s.index(clock)
    j = s.index('</symbol>', i) + len('</symbol>')
    s = s[:j] + '\n    ' + SPEAKER + s[j:]

    kb = '<button class="kbtn" onclick="toggleKana(this)">'
    n = s.count(kb)
    assert n == 4, n
    s = s.replace(kb, TOOL + kb)

    # 解き直しページにも読み上げを入れる
    rt_old = ("+ 'function tk(b){var s=b.closest(\".sheet\");"
              "var on=s.classList.toggle(\"showkana\");'")
    assert s.count(rt_old) == 1, 'retry js anchor'
    s = s.replace(rt_old, RETRY_SPEECH + '\n    ' + rt_old)

    tail = '\nfunction toggleHint(btn){'
    assert s.count(tail) == 1
    s = s.replace(tail, JS + tail)

    open(path, 'w', encoding='utf-8').write(s)
    print('patched v5:', path, len(s.encode('utf-8')), 'bytes')


if __name__ == '__main__':
    for p in sys.argv[1:]:
        patch(p)
