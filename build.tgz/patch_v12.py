# -*- coding: utf-8 -*-
"""v12: シンプルモードを全ページ連動にし、問題数を約2割へらす"""
import sys, io, re

RATIO = 0.2

CSS = """  /* ===== v12: シンプル時は問題も約2割へらす ===== */
  .opt{}
  .simple .opt{display:none !important;}
  .qhint{display:none;align-items:center;gap:8px;margin:0 0 9px;
    border:1.5px dashed #B9C4D2;border-radius:8px;padding:5px 12px;
    background:#F6F9FD;color:var(--mut);font-size:9.5pt;}
  .qhint b{color:var(--key);}
  .simple .qhint{display:flex;}
  @media print{ .qhint{display:none;} .simple .opt{display:revert !important;} }
"""

JS_OLD = """function toggleMore(btn){
  const s = btn.closest('.sheet');
  const on = s.classList.toggle('simple');
  btn.firstChild.nodeValue = on ? 'ぜんぶ表示 ' : 'シンプルに ';
  btn.classList.toggle('on', on);
  s.scrollIntoView({behavior:'smooth', block:'start'});
}"""

JS_NEW = """function toggleMore(btn){
  const on = !btn.classList.contains('on');
  document.querySelectorAll('.sheet').forEach(function(s){
    s.classList.toggle('simple', on);
  });
  document.querySelectorAll('.mbtn').forEach(function(b){
    b.firstChild.nodeValue = on ? 'ぜんぶ表示 ' : 'シンプルに ';
    b.classList.toggle('on', on);
  });
  btn.closest('.sheet').scrollIntoView({behavior:'smooth', block:'start'});
}"""

MBTN = ('<button class="mbtn" onclick="toggleMore(this)">シンプルに '
        '<span class="cv">▼</span></button>')

QHINT = ('    <div class="qhint"><svg style="width:15px;height:15px;flex:none;color:#1F4E9C">'
         '<use href="#i-pen"/></svg><div>かくれている問題もやりたいときは、'
         '上の <b>「ぜんぶ表示」</b> を押そう。</div></div>\n')


def cut(n):
    """n問のうち、へらす数（約2割・最低1問・全体は必ず1問以上残す）"""
    if n < 3:
        return 0
    return max(1, min(n - 2, int(round(n * RATIO))))


def _mark(block, open_re, item_re):
    """ブロック内の最初のリストを見つけ、末尾2割の項目に opt を付ける"""
    import re as _re
    m = _re.search(open_re, block)
    if not m:
        return block, 0
    lines = block[m.end():].split('\n')
    idx = []
    for k, ln in enumerate(lines):
        if _re.match(item_re, ln):
            idx.append(k)
        elif idx and _re.match(r'\s*</(ol|div)>\s*$', ln):
            break
    c = cut(len(idx))
    if not c:
        return block, 0
    for k in idx[len(idx) - c:]:
        lines[k] = _re.sub(r'<(li|div)>', r'<\1 class="opt">', lines[k], count=1)
    return block[:m.end()] + '\n'.join(lines), c


def mark_ol(block):
    return _mark(block, r'<ol class="q[^"]*">', r'\s*<li>')


def mark_grid(block):
    return _mark(block, r'<div class="grid2[^"]*">', r'\s*<div>')


def patch(path):
    name = path.split('/')[-1]
    s = io.open(path, encoding='utf-8').read()
    if '.simple .opt' in s:
        print('already v12:', name)
        return

    # 1) CSS
    anchor = '  @media print{ .ansbar,.toolbar{display:none;} .sheet{box-shadow:none;margin:0;} }'
    assert s.count(anchor) == 1, (name, 'css anchor')
    s = s.replace(anchor, CSS + anchor)

    # 2) JS を全ページ連動に
    assert s.count(JS_OLD) == 1, (name, 'js')
    s = s.replace(JS_OLD, JS_NEW)

    # 3) シート分割
    parts = s.split('<section class="sheet">')
    assert len(parts) == 5, (name, 'sheets=%d' % (len(parts) - 1))
    total = 0
    for n in (2, 3, 4):
        sh = parts[n]
        # MBTN をツールバーに
        t = sh.index('<div class="toolbar">') + len('<div class="toolbar">')
        sh = sh[:t] + MBTN + sh[t:]
        # 各問題セクションの末尾2割に opt
        segs = re.split(r'(?=  <div class="(?:qsec|half)[^"]*">)', sh)
        out = []
        for seg in segs:
            if 'class="cond"' in seg:     # 自由英作文はへらさない
                out.append(seg); continue
            seg, c1 = mark_ol(seg)
            seg, c2 = mark_grid(seg)
            total += c1 + c2
            out.append(seg)
        sh = ''.join(out)
        # ヒントを最初の問題セクションの前に
        k = sh.find('  <div class="qsec')
        if k < 0:
            k = sh.find('  <div class="half')
        if k >= 0:
            sh = sh[:k] + QHINT + sh[k:]
        parts[n] = sh
    s = '<section class="sheet">'.join(parts)
    io.open(path, 'w', encoding='utf-8').write(s)
    print('%-14s シンプル時に隠す問題 %d問' % (name, total))


if __name__ == '__main__':
    for p in sys.argv[1:]:
        patch(p)
