# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'u3-1', 'unit':'3 − 1', 'unit_plain':'3-1', 'title':'What do you ～?',
 'pages':'p.48〜49',
 'hero_big':'What do you like?',
 'hero_jp':'あなたは なにが 好きですか',
 'motto':'<span class="en">What</span> は<b>いちばん前</b>。そのうしろは <span class="en">do you ～?</span> のまま。答えに <span class="en">Yes / No</span> は使わない。',
 'kana':{'what':'ワット','you':'ユー','do':'ドゥー','yes':'イエス','no':'ノウ',
         'want':'ウォント','study':'スタディ','eat':'イート','subject':'サブジェクト',
         'color':'カラー','sport':'スポート','food':'フード','blue':'ブルー',
         'red':'レッド','breakfast':'ブレックファスト','usually':'ユージュアリィ',
         'after':'アフター','school':'スクール','rice':'ライス'},
 'blocks':[
  ('きほんの文', [
    ('t','2-2 の <span class="en">Do you ～?</span> は「はい／いいえ」で答える文でした。今回は<b>「なにを？」と中身をたずねる文</b>です。<span class="en">What</span> を先頭につけます。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">What do you like?</span><span class="t">あなたは なにが 好きですか。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I like music.</span><span class="t">わたしは 音楽が 好きです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">What sport do you like?</span><span class="t">あなたは どんなスポーツが 好きですか。</span></div>
    </div>'''),
    ('t','答えは <span class="en">Yes</span> でも <span class="en">No</span> でもありません。<b>中身をそのまま答える</b>のがちがいです。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('つくり方は <span class="en">Do you ～?</span> の前に <span class="en">What</span> を足すだけ', [
    ('t','もとになるのは 2-2 で習った形です。その<b>前に <span class="en">What</span> をつける</b>だけ。うしろはそのままです。'),
    ('h','''<div class="eqbox">
      <span class="eq">Do you like music?</span>（音楽が好きですか）<br>
      → <span class="eq">What do you like?</span>（なにが好きですか）　<b>たずねたいところを <span class="en">What</span> に変えて、前に出す</b>
    </div>'''),
    ('h','''<div class="blocks">
      <div class="blk fill" style="background:#D98400;"><div class="w en">What</div><div class="r">なにを</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:#7A4FBF;"><div class="w en">do</div><div class="r">たずねるしるし</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">you</div><div class="r">だれが</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">like</div><div class="r">どうする</div></div>
    </div>'''),
    ('t','<b><span class="en">What</span> のうしろは <span class="en">do you ～?</span> のまま</b>。<span class="en">What you do like?</span> のように順番を変えてはいけません。'),
    ('t','そして<b>「なにを」の部分はもう言いません</b>。<span class="en">What do you like music?</span> とすると、たずねたいことが二重になっておかしくなります。'),
  ]),
  ('かなり大事｜答えに <span class="en">Yes / No</span> は使わない', [
    ('t','ここが今回のヤマです。<span class="en">What</span> は「なに？」と中身を聞いているので、<b>はい／いいえでは答えられません</b>。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-smile"/></svg>
          <span>◯ 中身で答える<small>What で聞かれたとき</small></span></div>
        <div class="in"><div class="ex">What do you like?<br>— I like music.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>✕ はい／いいえ<small>What には合わない</small></span></div>
        <div class="in"><div class="ex">What do you like?<br>— Yes, I do.</div></div>
      </div>
    </div>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：<span class="en">What</span> で聞かれたら 中身で答える</div>
        <p><b class="cb"><span class="en">Do you ～?</span> → <span class="en">Yes / No</span></b>　<b class="cp"><span class="en">What do you ～?</span> → 中身</b>　
        先頭を見れば、答え方が決まります。<br>
        <span class="xm">✕ What do you like? — Yes, I do ✕</span></p>
      </div>
    </div>'''),
  ]),
  ('<span class="en">What</span> のうしろにことばを足せる', [
    ('t','<span class="en">What</span> だけだと「なに？」とばんやりしています。うしろにことばを足すと、<b>聞きたい種類をしぼれます</b>。'),
    ('h','''<table class="kind">
      <thead><tr><th>聞きたいこと</th><th>れい文</th><th>意味</th></tr></thead>
      <tbody>
        <tr><td class="k">スポーツ</td><td class="e">What <u>sport</u> do you like?</td><td class="j">どんなスポーツが好きですか。</td></tr>
        <tr><td class="k">教科</td><td class="e">What <u>subject</u> do you like?</td><td class="j">どんな教科が好きですか。</td></tr>
        <tr><td class="k">色</td><td class="e">What <u>color</u> do you like?</td><td class="j">どんな色が好きですか。</td></tr>
        <tr><td class="k">食べ物</td><td class="e">What <u>food</u> do you like?</td><td class="j">どんな食べ物が好きですか。</td></tr>
      </tbody>
    </table>'''),
    ('t','足すことばは <b><span class="en">What</span> のすぐうしろ</b>。<span class="en">What do you sport like?</span> とはしません。'),
  ]),
  ('<span class="en">do</span> のうしろの動詞は形を変えない', [
    ('t','2-2 と同じルールです。<b><span class="en">do</span> のうしろは 原形（もとの形）</b>のまま。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--ng);background:rgba(181,39,63,.06);">
      ○ <span class="eq" style="color:var(--vb);">What do you study?</span>　／　<span class="xm">✕ What do you studies ✕</span><br>
      <span class="en">do</span> も <span class="en">can</span> も、ついた動詞は<b>すっぴん</b>になります。
    </div>'''),
  ]),
 ],
 'quiz':[
  ('What you do like?','What do you like?','<span class="en">What</span> のうしろは <b><span class="en">do you</span></b> の順。順番を入れかえません。','あなたは なにが 好きですか。'),
  ('What do you like music?','What do you like?','「なにを」は <span class="en">What</span> で聞いているので、<b><span class="en">music</span> はいりません</b>。','あなたは なにが 好きですか。'),
  ('What do you like? — Yes, I do.','I like music.','<span class="en">What</span> で聞かれたら <b>中身で答える</b>。<span class="en">Yes / No</span> は使いません。','わたしは 音楽が 好きです。'),
  ('What do you studies?','What do you study?','<span class="en">do</span> のうしろは <b>原形（もとの形）</b>。<span class="en">s</span> はつけません。','あなたは なにを 勉強しますか。'),
  ('What do you sport like?','What sport do you like?','足すことばは <b><span class="en">What</span> のすぐうしろ</b>。','あなたは なんの スポーツが 好きですか。'),
  ('what do you like?','What do you like?','文のはじめは<b>大文字</b>。<span class="en">What</span> の <span class="en">W</span> を大文字にします。','あなたは なにが 好きですか。'),
 ],
 'summary':[
  '「なにを～しますか」は <b><span class="en">What do you ～?</span></b>　<span class="en">What</span> は<b>いちばん前</b>。',
  '<b><span class="en">What</span> のうしろは <span class="en">do you ～?</span> のまま。</b>順番を変えない。',
  '<b>答えに <span class="en">Yes / No</span> は使わない。</b>中身をそのまま答える。',
  '種類をしぼるときは <b><span class="en">What sport ～ / What subject ～</span></b> のように <span class="en">What</span> のすぐうしろに足す。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「あなたはなにを～しますか」は%sを文の%sに置く。' % (bl('What'), bl('前')),
     '<span class="en">What</span> のうしろは%sの順。順番は変えない。' % bl('do you', False),
     '<span class="en">What</span> で聞かれたら、答えに%sは使わず、%sをそのまま答える。' % (bl('Yes / No', False), bl('中身')),
     '種類をしぼるときは <span class="en">What</span> の%sにことばを足す。' % bl('すぐうしろ', False),
     '<span class="en">do</span> のうしろの動詞は%sにする。' % bl('原形', False),
   ]),
   'words':'語群：<span class="en">What</span> ／ <span class="en">do you</span> ／ <span class="en">Yes / No</span> ／ 中身 ／ 前 ／ すぐうしろ ／ 原形',
   'exp':'<b>なぜ？</b>　<span class="en">What</span> は「知りたいところ」を表すことば。だから<b>いちばん前に立って</b>、「ここが知りたい！」と示します。<br>'
         '知りたい中身を聞いているので、<span class="en">Yes / No</span> では答えになりません。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">What</span>？ それとも <span class="en">Do</span>？<em>（　）に <span class="en">What</span> か <span class="en">Do</span> を書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。日本語に「<b>なに</b>」があれば <span class="en">What</span>、なければ <span class="en">Do</span>。',
   'body':grid2([
     '1. <span class="en">%sdo you like?</span>（なにが好きですか）' % bl('What'),
     '2. <span class="en">%syou like soccer?</span>（サッカーが好きですか）' % bl('Do'),
     '3. <span class="en">%sdo you study?</span>（なにを勉強しますか）' % bl('What'),
     '4. <span class="en">%syou play tennis?</span>（テニスをしますか）' % bl('Do'),
     '5. <span class="en">%sdo you eat?</span>（なにを食べますか）' % bl('What'),
     '6. <span class="en">%syou have a dog?</span>（犬を飼っていますか）' % bl('Do'),
     '7. <span class="en">%ssport do you like?</span>（どんなスポーツが）' % bl('What'),
     '8. <span class="en">%syou study math?</span>（数学を勉強しますか）' % bl('Do'),
     '9. <span class="en">%scolor do you like?</span>（どんな色が）' % bl('What'),
     '10. <span class="en">%syou eat natto?</span>（納豆を食べますか）' % bl('Do'),
   ]),
   'exp':'<b>見つけ方</b>　日本語に「<b>なに・どんな</b>」があるかだけを見ます。<br>'
         'ある → <span class="en">What</span>（1・3・5・7・9）　ない → <span class="en">Do</span>（2・4・6・8・10）<br>'
         '7・9のように <span class="en">What</span> のうしろに <span class="en">sport・color</span> が入ることもあります。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. What do you like?','○'), ('2. What you do like?','✕'),
     ('3. What sport do you like?','○'), ('4. What do you like music?','✕'),
     ('5. What do you study?','○'), ('6. What do you studies?','✕'),
     ('7. What food do you eat?','○'), ('8. What do you sport like?','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">What do you like?</span>（<span class="en">do you</span> の順に）<br>'
         '4 → <span class="en">What do you like?</span>（<span class="en">music</span> を消す）　6 → <span class="en">What do you study?</span>（s を取る）<br>'
         '8 → <span class="en">What sport do you like?</span>（<span class="en">sport</span> を <span class="en">What</span> のすぐうしろへ）'},
  {'h':'<h3 class="sec sec2">D　答え方　正しいほうを選ぼう</h3>',
   'hint':'<span class="en">What</span> なら<b>中身</b>、<span class="en">Do</span> なら <b><span class="en">Yes / No</span></b>。先頭を見るだけです。',
   'body':grid2([
     '1. <span class="en">What do you like?</span>　—（ア <span class="en">I like music.</span> ／イ <span class="en">Yes, I do.</span>）%s' % bl('ア'),
     '2. <span class="en">Do you like music?</span>　—（ア <span class="en">I like music.</span> ／イ <span class="en">Yes, I do.</span>）%s' % bl('イ'),
     '3. <span class="en">What sport do you like?</span>　—（ア <span class="en">Yes, I do.</span> ／イ <span class="en">I like soccer.</span>）%s' % bl('イ'),
     '4. <span class="en">What do you study?</span>　—（ア <span class="en">I study math.</span> ／イ <span class="en">No, I don&#39;t.</span>）%s' % bl('ア'),
     '5. <span class="en">Do you play tennis?</span>　—（ア <span class="en">I play tennis.</span> ／イ <span class="en">No, I don&#39;t.</span>）%s' % bl('イ'),
     '6. <span class="en">What food do you like?</span>　—（ア <span class="en">I like rice.</span> ／イ <span class="en">Yes, I do.</span>）%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　<span class="en">What</span> の文に <span class="en">Yes / No</span> で答えると、まったく答えになりません。<br>'
         '<span class="en">What</span>（1・3・4・6）→ 中身　<span class="en">Do</span>（2・5）→ <span class="en">Yes / No</span>'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　日本語に「なに・どんな」があれば <span class="en">What</span> から始める。そのうしろは <span class="en">do you</span>。',
   'body':ol([
     ('<span class="jp-cue">あなたはなにが好きですか。</span>　<span class="en">%sdo you like?</span>' % bl('What'),
      '「なに」があるので <b><span class="en">What</span></b>。'),
     ('<span class="jp-cue">わたしは音楽が好きです。</span>　<span class="en">I%smusic.</span>' % bl('like'),
      '答えは<b>中身</b>。ふつうの文で言います。'),
     ('<span class="jp-cue">あなたはなにを勉強しますか。</span>　<span class="en">What%syou study?</span>' % bl('do'),
      '<span class="en">What</span> のうしろは <b><span class="en">do you</span></b>。'),
     ('<span class="jp-cue">あなたはサッカーが好きですか。</span>　<span class="en">%syou like soccer?</span>' % bl('Do'),
      '「なに」がないので <b><span class="en">Do</span></b>。'),
     ('<span class="jp-cue">あなたはどんなスポーツが好きですか。</span>　<span class="en">What%sdo you like?</span>' % bl('sport'),
      '「どんなスポーツ」→ <b><span class="en">What sport</span></b>。'),
     ('<span class="jp-cue">あなたはなにを食べますか。</span>　<span class="en">%s%syou eat?</span>' % (bl('What'), bl('do')),
      '（　）が2つ。<b><span class="en">What</span> → <span class="en">do</span></b> の順。'),
     ('<span class="jp-cue">あなたはどんな色が好きですか。</span>　<span class="en">What%sdo you like?</span>' % bl('color'),
      '「どんな色」→ <b><span class="en">What color</span></b>。'),
     ('<span class="jp-cue">わたしは数学を勉強します。</span>　<span class="en">I%smath.</span>' % bl('study'),
      '3番の答え。<b>中身</b>をふつうの文で言う。'),
     ('<span class="jp-cue">あなたはどんな教科が好きですか。</span>　<span class="en">What subject%syou like?</span>' % bl('do'),
      '<span class="en">What subject</span> のうしろも <b><span class="en">do you</span></b>。'),
     ('<span class="jp-cue">はい、好きです。</span>（<span class="en">Do you ～?</span> の答え）　<span class="en">Yes, I%s.</span>' % bl('do'),
      '4番の答え。<span class="en">Do</span> なら <b><span class="en">Yes / No</span></b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群に <span class="en">What</span> があれば<b>それが先頭</b>。そのあと <span class="en">do</span> → <span class="en">you</span> → 動詞。',
   'body':ol([
     ('<span class="jp-cue">あなたはなにが好きですか。</span>　<span class="paren en">（ like / you / What / do ）</span>' + line('What do you like?'),
      '<span class="en">What</span> → <span class="en">do</span> → <span class="en">you</span> → <span class="en">like</span>。終わりは <b>?</b>。'),
     ('<span class="jp-cue">あなたはなにを勉強しますか。</span>　<span class="paren en">（ you / study / What / do ）</span>' + line('What do you study?'),
      '1番と同じ形。<b>順番をおぼえてしまおう。</b>'),
     ('<span class="jp-cue">あなたはどんなスポーツが好きですか。</span>　<span class="paren en">（ sport / do / What / like / you ）</span>' + line('What sport do you like?'),
      '<span class="en">What sport</span> でひとかたまり。'),
     ('<span class="jp-cue">わたしは音楽が好きです。</span>　<span class="paren en">（ music / I / like ）</span>' + line('I like music.'),
      '語群に <span class="en">What</span> がない。<b>ふつうの文</b>です。'),
     ('<span class="jp-cue">あなたはどんな色が好きですか。</span>　<span class="paren en">（ color / you / What / like / do ）</span>' + line('What color do you like?'),
      '3番と同じ形。<span class="en">What color</span> が先頭。'),
     ('<span class="jp-cue">あなたはサッカーが好きですか。</span>　<span class="paren en">（ soccer / Do / like / you ）</span>' + line('Do you like soccer?'),
      '語群に <span class="en">What</span> がなく <span class="en">Do</span> がある。<b>はい／いいえの文</b>。'),
     ('<span class="jp-cue">あなたはなにを食べますか。</span>　<span class="paren en">（ eat / do / What / you ）</span>' + line('What do you eat?'),
      '1・2番と同じ形。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('あなたはなにが好きですか。' + wline('What do you like?'),
      '4語。<span class="en">What</span> → <span class="en">do</span> → <span class="en">you</span> → 動詞。'),
     ('わたしは音楽が好きです。' + wline('I like music.'),
      '答えは<b>中身</b>。<span class="en">Yes, I do.</span> ではありません。'),
     ('あなたはどんなスポーツが好きですか。' + wline('What sport do you like?'),
      '<span class="en">sport</span> は <span class="en">What</span> のすぐうしろ。'),
     ('あなたはなにを勉強しますか。' + wline('What do you study?'),
      '<span class="en">study</span> は原形（もとの形）のまま。'),
     ('あなたはどんな食べ物が好きですか。' + wline('What food do you like?'),
      '3番と同じ形。<span class="en">What food</span>。'),
     ('あなたはサッカーが好きですか。' + wline('Do you like soccer?'),
      '「なに」がないので <span class="en">Do</span> の文。混ぜないこと。'),
   ]),
   'words':'<span class="en">like ／ study ／ music ／ sport ／ food ／ soccer</span>'},
  'l4':{'sub':'友だちに「なにが好きか」をたずねる文を書こう',
   'cond':['<span class="en">What do you ～?</span> の文を <b>2つ以上</b>',
           '<span class="en">What</span> のうしろにことばを足した文（<span class="en">What sport ～</span> など）を <b>1つ以上</b>',
           'それぞれの答えも <b>中身で書く</b>'],
   'example':['What do you like? — I like music.','What sport do you like? — I like soccer.','What food do you eat? — I eat rice.'],
   'note':'これは例です。同じでなくてかまいません。スポーツ・教科・色・食べ物 のどれかを聞いてみよう。',
   'check':['What のうしろは do you の順','答えに Yes / No を使っていない','足すことばは What のすぐうしろ','終わりは ?'],
   'review':'じぶんの文の答えに○をつけよう。<span class="en">What</span> の文の答えが <span class="en">Yes</span> や <span class="en">No</span> なら、そこがまちがい。'},
 },
}
