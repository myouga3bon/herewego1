# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'u8-3', 'unit':'8 − 3', 'unit_plain':'8-3', 'title':'過去進行形',
 'pages':'p.120〜121',
 'hero_big':'I was playing soccer then.',
 'hero_jp':'わたしは そのとき サッカーを しているところでした',
 'motto':'過去進行形は <b><span class="en">was</span>／<span class="en">were</span> ＋ 動詞ing</b>。be動詞を過去形にするだけ。',
 'kana':{'was':'ワズ','were':'ワー',"wasn't":'ワズント',"weren't":'ワーント',
         'playing':'プレイイング','running':'ラニング','swimming':'スウィミング',
         'studying':'スタディイング','watching':'ウォッチング','eating':'イーティング',
         'cooking':'クッキング','reading':'リーディング','doing':'ドゥーイング',
         'then':'ゼン','night':'ナイト','last':'ラスト','he':'ヒー','she':'シー',
         'yes':'イエス','no':'ノウ','what':'ワット'},
 'blocks':[
  ('きほんの文', [
    ('t','8-1 の現在進行形を、<b>過去のこと</b>にします。やることは1つだけ。<b>be動詞を <span class="en">was</span>／<span class="en">were</span> に変える</b>だけです。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I was playing soccer then.</span><span class="t">わたしは そのとき サッカーを しているところでした。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">He was running then.</span><span class="t">彼は そのとき 走っているところでした。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">You were studying then.</span><span class="t">あなたは そのとき 勉強しているところでした。</span></div>
    </div>'''),
    ('t','<span class="en">am → was</span>、<span class="en">is → was</span>、<span class="en">are → were</span>。7-4 で習ったとおりです。<b><span class="en">ing</span> の形はそのまま</b>。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜変えるのは be動詞だけ', [
    ('t','ここが今回のヤマです。<b>動詞の <span class="en">ing</span> 形は、まったく変わりません</b>。変わるのは前の be動詞だけです。'),
    ('h','''<table class="kind">
      <thead><tr><th>主語</th><th>今のこと</th><th>そのときのこと</th></tr></thead>
      <tbody>
        <tr><td class="k"><span class="en">I</span></td><td class="e">I <u>am</u> playing.</td><td class="e" style="color:#7A4FBF;">I <u>was</u> playing.</td></tr>
        <tr><td class="k"><span class="en">he / she</span>・名前</td><td class="e">He <u>is</u> playing.</td><td class="e" style="color:#7A4FBF;">He <u>was</u> playing.</td></tr>
        <tr><td class="k"><span class="en">you</span></td><td class="e">You <u>are</u> playing.</td><td class="e" style="color:#7A4FBF;">You <u>were</u> playing.</td></tr>
      </tbody>
    </table>'''),
    ('t','右の列も <span class="en">playing</span> のまま。<b><span class="en">ed</span> をつけたり、形を変えたりはしません。</b>'),
    ('t','<span class="en">I was played soccer.</span> は<b>まちがい</b>。これは「過去形」と「進行形」を混ぜてしまった形です。進行形は<b>かならず <span class="en">ing</span></b>。'),
  ]),
  ('打ち消しとたずねる文', [
    ('t','やり方は 7-4 とまったく同じ。<b>打ち消しは うしろに <span class="en">not</span>、たずねる文は 前に出す</b>だけです。'),
    ('h','''<table class="kind">
      <thead><tr><th>ふつうの文</th><th>打ち消しの文</th><th>たずねる文</th></tr></thead>
      <tbody>
        <tr><td class="e">I was playing.</td><td class="e" style="color:var(--ng);">I was <u>not</u> playing.（wasn&#39;t）</td><td class="e">Were you playing?</td></tr>
        <tr><td class="e">He was running.</td><td class="e" style="color:var(--ng);">He was <u>not</u> running.（wasn&#39;t）</td><td class="e">Was he running?</td></tr>
      </tbody>
    </table>'''),
    ('t','答えは <span class="en">Yes, I was.</span>／<span class="en">No, I wasn&#39;t.</span>。<b><span class="en">didn&#39;t</span> は使いません</b>。be動詞の文だからです。'),
  ]),
  ('「そのとき」を表すことば', [
    ('t','過去進行形には、<b>いつのことかを表すことば</b>をいっしょに使うと分かりやすくなります。'),
    ('h','''<div class="eqbox" style="border-left-color:#7A4FBF;background:rgba(122,79,191,.07);">
      <span class="eq" style="color:#7A4FBF;">then</span>（そのとき）　<span class="eq" style="color:#7A4FBF;">at that time</span>（そのときに）　<span class="eq" style="color:#7A4FBF;">last night</span>（昨夜）<br>
      置く場所は<b>文のいちばん後ろ</b>。<span class="en">I was playing soccer then.</span>
    </div>'''),
    ('t','<span class="en">now</span> なら現在進行形、<span class="en">then</span> なら過去進行形。<b>このことばが見分けの手がかり</b>になります。'),
  ]),
  ('3つの過去の文を整理する', [
    ('t','Unit 7・8 で、過去の言い方が3つ出てきました。まとめて確かめましょう。'),
    ('h','''<table class="kind">
      <thead><tr><th>言いたいこと</th><th>形</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k">したこと</td><td class="k" style="color:var(--gv);font-weight:700;">動詞の過去形</td><td class="e">I played soccer.</td></tr>
        <tr><td class="k">どんなようすだったか</td><td class="k" style="color:var(--key);font-weight:700;">was / were</td><td class="e">I was busy.</td></tr>
        <tr><td class="k">している最中だったこと</td><td class="k" style="color:#7A4FBF;font-weight:700;">was / were ＋ ing</td><td class="e">I was playing soccer.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：<span class="en">was</span> のうしろは <span class="en">ing</span> か ようす</div>
        <p><b class="cb">青＝<span class="en">was busy</span></b>　<b style="color:#C8AEF0;">むらさき＝<span class="en">was playing</span></b>　<b class="cp">ピンク＝<span class="en">played</span></b>　
        <span class="en">was</span> のうしろに<b>過去形は来ません</b>。<br>
        <span class="xm">✕ I was played soccer ✕</span>　<span class="xm">✕ I playing soccer then ✕</span></p>
      </div>
    </div>'''),
  ]),
 ],
 'quiz':[
  ('I am playing soccer then.','I was playing soccer then.','<span class="en">then</span>（そのとき）があるので、be動詞を <b>過去形</b>にします。','わたしは そのとき サッカーを しているところでした。'),
  ('I was play soccer.','I was playing soccer.','<b><span class="en">ing</span> が抜けています</b>。進行形はかならず <span class="en">ing</span>。','わたしは サッカーを しているところでした。'),
  ('I playing soccer then.','I was playing soccer then.','<b>be動詞が抜けています</b>。<span class="en">ing</span> の前に <span class="en">was</span> が必要。','わたしは そのとき サッカーを しているところでした。'),
  ('You was playing soccer.','You were playing soccer.','主語が <span class="en">you</span> なので <b><span class="en">were</span></b>。','あなたは サッカーを しているところでした。'),
  ('He were playing soccer.','He was playing soccer.','主語が <span class="en">he</span> なので <b><span class="en">was</span></b>。','彼は サッカーを しているところでした。'),
  ('I was played soccer.','I was playing soccer.','<span class="en">was</span> のうしろに<b>過去形は来ません</b>。<span class="en">ing</span> の形にします。','わたしは サッカーを しているところでした。'),
 ],
 'summary':[
  '「～しているところでした」は <b><span class="en">was</span>／<span class="en">were</span> ＋ 動詞ing</b>。',
  '<b>変えるのは be動詞だけ。</b><span class="en">ing</span> の形はそのまま。',
  '打ち消しは <b><span class="en">wasn&#39;t</span>／<span class="en">weren&#39;t</span></b>、たずねる文は <b>前に出す</b>。',
  '<b><span class="en">was</span> のうしろに過去形は来ない。</b><span class="en">I was played ～.</span> はまちがい。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～しているところでした」は、%sか%s＋ 動詞ing で表す。' % (bl('was'), bl('were')),
     '主語が <span class="en">I</span>・<span class="en">he</span>・<span class="en">she</span> なら%s、<span class="en">you</span> なら%s。' % (bl('was'), bl('were')),
     '動詞の%sの形は、現在進行形のときと変わらない。' % bl('ing'),
     '打ち消しは be動詞のうしろに%sを置く。短い形は <span class="en">wasn&#39;t</span>。' % bl('not'),
     '過去進行形には%s（そのとき）などをいっしょに使う。' % bl('then'),
   ]),
   'words':'語群：<span class="en">was</span> ／ <span class="en">were</span> ／ <span class="en">ing</span> ／ <span class="en">not</span> ／ <span class="en">then</span>',
   'exp':'<b>なぜ？</b>　進行形は <span class="en">I ＝ playing</span> という<b>be動詞の文</b>。過去にするなら、変えるのは「＝」の部分だけです。<br>'
         '<span class="en">playing</span>（している最中）というようすは変わらないので、そのまま使います。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#7A4FBF;">B　<span class="en">was</span>？ それとも <span class="en">were</span>？<em>（　）に正しい形を書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>主語だけ</b>を見ましょう。<span class="en">you</span> なら <span class="en">were</span>、それ以外は <span class="en">was</span>。',
   'body':grid2([
     '1. <span class="en">I%splaying soccer.</span>' % bl('was'),
     '2. <span class="en">You%splaying soccer.</span>' % bl('were'),
     '3. <span class="en">He%srunning then.</span>' % bl('was'),
     '4. <span class="en">She%scooking then.</span>' % bl('was'),
     '5. <span class="en">You%swatching TV.</span>' % bl('were'),
     '6. <span class="en">Mike%sstudying math.</span>' % bl('was'),
     '7. <span class="en">I%seating lunch then.</span>' % bl('was'),
     '8. <span class="en">%syou reading a book?</span>' % bl('Were'),
     '9. <span class="en">%she swimming then?</span>' % bl('Was'),
     '10. <span class="en">She%snot cooking.</span>' % bl('was'),
   ]),
   'exp':'<b>見つけ方</b>　主語を見るだけ。7-4 とまったく同じです。<br>'
         '<span class="en">you</span> → <b><span class="en">were</span></b>（2・5・8）　<span class="en">I・he・she</span>・名前 → <b><span class="en">was</span></b>（1・3・4・6・7・9・10）<br>'
         '8・9は<b>たずねる文</b>なので前に出て、文のはじめだから大文字です。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#7A4FBF;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. I was playing soccer then.','○'), ('2. I was played soccer then.','✕'),
     ('3. He was running.','○'), ('4. I playing soccer then.','✕'),
     ('5. You were studying.','○'), ('6. You was studying.','✕'),
     ('7. Were you watching TV?','○'), ('8. I was play soccer.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">I was playing soccer then.</span>（<span class="en">played</span> → <span class="en">playing</span>）<br>'
         '4 → <span class="en">I was playing soccer then.</span>（<span class="en">was</span> を足す）　6 → <span class="en">You were studying.</span>（<span class="en">you</span> には <span class="en">were</span>）<br>'
         '8 → <span class="en">I was playing soccer.</span>（ing をつける）'},
  {'h':'<h3 class="sec sec2">D　どの形を使う？　記号で答えよう</h3>',
   'hint':'<span class="chip">ア</span> 過去形（<span class="en">played</span>）　<span class="chip" style="background:var(--key);">イ</span> <span class="en">was / were</span>　<span class="chip" style="background:#7A4FBF;">ウ</span> <span class="en">was / were ＋ ing</span>',
   'body':grid2([
     '1. わたしはきのうサッカーを<b>しました</b>。%s' % bl('ア'),
     '2. わたしはそのときサッカーを<b>しているところでした</b>。%s' % bl('ウ'),
     '3. わたしはきのう<b>いそがしかった</b>です。%s' % bl('イ'),
     '4. 彼はそのとき<b>走っているところでした</b>。%s' % bl('ウ'),
     '5. 彼はきのう公園へ<b>行きました</b>。%s' % bl('ア'),
     '6. 彼はそのとき家に<b>いました</b>。%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　日本語の終わり方で見分けます。<br>'
         '「<b>しました</b>」→ 過去形（1・5）　「<b>でした・いました</b>」→ <span class="en">was / were</span>（3・6）<br>'
         '「<b>しているところでした</b>」→ <span class="en">was / were ＋ ing</span>（2・4）'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　<span class="en">then</span> があれば過去進行形の合図。be動詞を過去形に、<span class="en">ing</span> はそのまま。',
   'body':ol([
     ('<span class="jp-cue">わたしはそのときサッカーをしているところでした。</span>　<span class="en">I%splaying soccer then.</span>' % bl('was'),
      '主語が <span class="en">I</span> なので <b><span class="en">was</span></b>。'),
     ('<span class="jp-cue">彼はそのとき走っているところでした。</span>　<span class="en">He was%sthen.</span>' % bl('running', False),
      '<span class="en">n</span> を重ねて <b><span class="en">running</span></b>。'),
     ('<span class="jp-cue">あなたはそのとき勉強しているところでした。</span>　<span class="en">You%sstudying then.</span>' % bl('were'),
      '主語が <span class="en">you</span> なので <b><span class="en">were</span></b>。'),
     ('<span class="jp-cue">わたしは今サッカーをしているところです。</span>　<span class="en">I%splaying soccer now.</span>' % bl('am'),
      '<span class="en">now</span> なので<b>現在</b>進行形。1番とくらべよう。'),
     ('<span class="jp-cue">わたしはきのうサッカーをしました。</span>　<span class="en">I%ssoccer yesterday.</span>' % bl('played', False),
      '「しました」なので<b>過去形</b>。進行形ではありません。'),
     ('<span class="jp-cue">彼女はそのとき料理をしているところでした。</span>　<span class="en">She%s%sthen.</span>' % (bl('was'), bl('cooking', False)),
      '（　）が2つ。<b><span class="en">was</span> ＋ <span class="en">cooking</span></b>。'),
     ('<span class="jp-cue">わたしはそのときテレビを見ていませんでした。</span>　<span class="en">I%swatching TV then.</span>' % bl("wasn't", False),
      '打ち消しは <b><span class="en">wasn&#39;t</span></b>。'),
     ('<span class="jp-cue">あなたはそのとき本を読んでいるところでしたか。</span>　<span class="en">%syou reading a book then?</span>' % bl('Were'),
      'たずねる文は前に出す。<span class="en">you</span> なので <b><span class="en">Were</span></b>。'),
     ('<span class="jp-cue">はい、読んでいました。</span>　<span class="en">Yes, I%s.</span>' % bl('was'),
      '答えるのは自分のことなので <b><span class="en">I was</span></b>。'),
     ('<span class="jp-cue">彼はそのとき泳いでいるところでしたか。</span>　<span class="en">%she%sthen?</span>' % (bl('Was'), bl('swimming', False)),
      '主語が <span class="en">he</span> なので <b><span class="en">Was</span></b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群に <span class="en">was</span>・<span class="en">were</span> と <span class="en">ing</span> の形があれば過去進行形です。',
   'body':ol([
     ('<span class="jp-cue">わたしはそのときサッカーをしているところでした。</span>　<span class="paren en">（ soccer / was / then / I / playing ）</span>' + line('I was playing soccer then.'),
      '「だれが → be動詞 → ing → なにを → いつ」の順。'),
     ('<span class="jp-cue">彼はそのとき走っているところでした。</span>　<span class="paren en">（ running / then / He / was ）</span>' + line('He was running then.'),
      '<span class="en">then</span> はいちばん後ろ。'),
     ('<span class="jp-cue">あなたはそのとき勉強しているところでした。</span>　<span class="paren en">（ studying / You / then / were ）</span>' + line('You were studying then.'),
      '語群が <span class="en">were</span>。主語は <span class="en">you</span>。'),
     ('<span class="jp-cue">あなたはそのとき本を読んでいるところでしたか。</span>　<span class="paren en">（ a book / reading / Were / you ）</span>' + line('Were you reading a book?'),
      '語群の <span class="en">Were</span> が大文字。だから先頭です。'),
     ('<span class="jp-cue">わたしはテレビを見ていませんでした。</span>　<span class="paren en">（ TV / watching / wasn&#39;t / I ）</span>' + line('I wasn&#39;t watching TV.'),
      '<span class="en">wasn&#39;t</span> は <span class="en">I</span> のすぐうしろ。'),
     ('<span class="jp-cue">わたしはきのうサッカーをしました。</span>　<span class="paren en">（ soccer / played / yesterday / I ）</span>' + line('I played soccer yesterday.'),
      '語群に be動詞がない。<b>過去形のふつうの文</b>です。'),
     ('<span class="jp-cue">彼女はそのとき料理をしているところでした。</span>　<span class="paren en">（ cooking / was / then / She ）</span>' + line('She was cooking then.'),
      '2番と同じ形。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしはそのときサッカーをしているところでした。' + wline('I was playing soccer then.'),
      '<span class="en">was</span> ＋ <span class="en">ing</span> の2つをそろえる。'),
     ('彼はそのとき走っているところでした。' + wline('He was running then.'),
      '<span class="en">n</span> を重ねて <span class="en">running</span>。'),
     ('あなたはそのとき勉強しているところでした。' + wline('You were studying then.'),
      '<span class="en">you</span> なので <span class="en">were</span>。'),
     ('わたしはテレビを見ていませんでした。' + wline('I wasn&#39;t watching TV.'),
      '<span class="en">I was not watching TV.</span> でも正解。'),
     ('あなたはそのとき本を読んでいるところでしたか。' + wline('Were you reading a book then?'),
      '<span class="en">Was you ～?</span> ではありません。'),
     ('わたしはきのうサッカーをしました。' + wline('I played soccer yesterday.'),
      '「しました」なので過去形。進行形にしないこと。'),
   ]),
   'words':'<span class="en">was playing ／ running ／ were studying ／ wasn&#39;t watching ／ Were you ／ played</span>'},
  'l4':{'sub':'「きのうの夜7時ごろ、なにをしていたか」を書こう',
   'cond':['<span class="en">I was ～ing.</span> の文を <b>2つ以上</b>',
           '<span class="en">He was ～ing.</span> か <span class="en">She was ～ing.</span> の文を <b>1つ以上</b>',
           '<span class="en">then</span> か <span class="en">last night</span> を <b>1つ以上</b> 使う'],
   'example':['I was studying math last night. I was listening to music.','My brother was watching TV then.','I wasn&#39;t playing games.'],
   'note':'これは例です。同じでなくてかまいません。勉強・テレビ・ごはん・おふろ など、昨夜の様子を思い出して書こう。',
   'check':['was / were と ing の2つがそろっている','you には were、それ以外は was','was のうしろを過去形にしていない','wasn&#39;t のアポストロフィ'],
   'review':'じぶんの文の <span class="en">was</span>・<span class="en">were</span> のうしろに○をつけよう。<span class="en">ed</span> のついた形なら、そこがまちがい。'},
 },
}
