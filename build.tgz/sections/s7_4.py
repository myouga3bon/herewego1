# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'u7-4', 'unit':'7 − 4', 'unit_plain':'7-4', 'title':'be動詞の過去形（was / were）',
 'pages':'p.108〜109',
 'hero_big':'I was busy. ／ You were busy.',
 'hero_jp':'わたしは いそがしかったです ／ あなたは いそがしかったです',
 'motto':'<span class="en">am・is</span> → <span class="en">was</span>、<span class="en">are</span> → <span class="en">were</span>。<b>動作の文には使わない</b>。',
 'kana':{'was':'ワズ','were':'ワー',"wasn't":'ワズント',"weren't":'ワーント',
         'he':'ヒー','she':'シー','busy':'ビズィ','tired':'タイアド',
         'free':'フリー','happy':'ハピィ','hungry':'ハングリィ','sick':'スィック',
         'yesterday':'イエスタデイ','last':'ラスト','then':'ゼン','night':'ナイト',
         'home':'ホウム','school':'スクール','yes':'イエス','no':'ノウ','fun':'ファン'},
 'blocks':[
  ('きほんの文', [
    ('t','7-1・7-2 は<b>動作の過去形</b>でした。今回は <span class="en">am・are・is</span> の<b>be動詞の過去形</b>です。形は2つだけです。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I was busy yesterday.</span><span class="t">わたしは きのう いそがしかったです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">You were busy yesterday.</span><span class="t">あなたは きのう いそがしかったです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">He was at home.</span><span class="t">彼は 家に いました。</span></div>
    </div>'''),
    ('t','<span class="en">I am</span> が <span class="en">I was</span>、<span class="en">You are</span> が <span class="en">You were</span> になっています。<b>主語との組み合わせはそのまま</b>です。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜変わり方は 3対1', [
    ('t','ここが今回のヤマです。be動詞は<b>現在は3つ、過去は2つ</b>になります。'),
    ('h','''<table class="kind">
      <thead><tr><th>主語</th><th>今のこと</th><th>きのうのこと</th></tr></thead>
      <tbody>
        <tr><td class="k"><span class="en">I</span></td><td class="e">am</td><td class="e" style="color:#7A4FBF;font-weight:700;">was</td></tr>
        <tr><td class="k"><span class="en">he / she</span>・名前</td><td class="e">is</td><td class="e" style="color:#7A4FBF;font-weight:700;">was</td></tr>
        <tr><td class="k"><span class="en">you</span></td><td class="e">are</td><td class="e" style="color:#7A4FBF;font-weight:700;">were</td></tr>
      </tbody>
    </table>'''),
    ('t','おぼえ方は<b>「<span class="en">am</span> と <span class="en">is</span> は <span class="en">was</span>、<span class="en">are</span> は <span class="en">were</span>」</b>。これだけです。声に出して3回となえましょう。'),
    ('t','<span class="en">you</span> だけ <span class="en">were</span> になる、と覚えてもよいです。<span class="en">You was ～.</span> とは言いません。'),
  ]),
  ('打ち消しとたずねる文', [
    ('t','やり方は 2-1・4-3 とまったく同じ。<b>打ち消しは うしろに <span class="en">not</span>、たずねる文は 前に出す</b>だけです。'),
    ('h','''<table class="kind">
      <thead><tr><th>ふつうの文</th><th>打ち消しの文</th><th>たずねる文</th></tr></thead>
      <tbody>
        <tr><td class="e">I was busy.</td><td class="e" style="color:var(--ng);">I was <u>not</u> busy.（wasn&#39;t）</td><td class="e">Were you busy?</td></tr>
        <tr><td class="e">He was at home.</td><td class="e" style="color:var(--ng);">He was <u>not</u> at home.（wasn&#39;t）</td><td class="e">Was he at home?</td></tr>
      </tbody>
    </table>'''),
    ('t','短い形は <b><span class="en">wasn&#39;t</span>／<span class="en">weren&#39;t</span></b>。答えは <span class="en">Yes, I was.</span>／<span class="en">No, I wasn&#39;t.</span> です。'),
    ('t','<span class="en">Were you ～?</span> と聞かれたら、答えるのは自分のことなので <span class="en">I was</span>。2-1 で習ったとおりです。'),
  ]),
  ('動作の文には使わない', [
    ('t','ここをまちがえる人がとても多いところです。<b>「サッカーをしました」は動作</b>なので、<span class="en">was</span> は使いません。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ was を使う<small>「<u>どんなようすだったか</u>」</small></span></div>
        <div class="in"><div class="ex">I was busy.<br>I was at home.</div>
          <div class="memo">動作のことばが<b>ない</b>文。</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-run"/></svg>
          <span>✕ was を使わない<small>「<u>なにをしたか</u>」</small></span></div>
        <div class="in"><div class="ex">I played soccer.<br>I went to the park.</div>
          <div class="memo">動詞を<b>過去形</b>にするだけ。</div></div>
      </div>
    </div>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：心臓（動詞）は 青かピンクの どちらか1つ</div>
        <p><b class="cb">青＝<span class="en">was・were</span></b>　<b class="cp">ピンク＝<span class="en">played・went</span></b>　
        過去形になっても、まざらないのは同じです。<br>
        <span class="xm">✕ I was played soccer ✕</span>　<span class="xm">✕ I didn&#39;t busy ✕</span></p>
      </div>
    </div>'''),
    ('t','打ち消しも同じで、<b>青は <span class="en">wasn&#39;t</span>、ピンクは <span class="en">didn&#39;t</span></b>。<span class="en">I didn&#39;t busy.</span> とは言いません。'),
  ]),
  ('「そのとき」を表すことば', [
    ('t','過去の文には、<b>いつのことかを表すことば</b>をいっしょに使います。'),
    ('h','''<div class="eqbox" style="border-left-color:#7A4FBF;background:rgba(122,79,191,.07);">
      <span class="eq" style="color:#7A4FBF;">yesterday</span>（きのう）　<span class="eq" style="color:#7A4FBF;">then</span>（そのとき）　<span class="eq" style="color:#7A4FBF;">last night</span>（昨夜）<br>
      置く場所は<b>文のいちばん後ろ</b>。<span class="en">I was busy yesterday.</span>
    </div>'''),
    ('t','これらが文にあったら、<b>be動詞を <span class="en">was</span>／<span class="en">were</span> にする</b>という合図です。'),
  ]),
 ],
 'quiz':[
  ('I were happy.','I was happy.','主語が <span class="en">I</span> なので <b><span class="en">was</span></b>。<span class="en">were</span> は <span class="en">you</span> 用です。','わたしは うれしかったです。'),
  ('You was happy.','You were happy.','主語が <span class="en">you</span> なので <b><span class="en">were</span></b>。','あなたは うれしかったです。'),
  ('He were a student.','He was a student.','<span class="en">he</span> は <span class="en">is</span> の仲間なので、過去形は <b><span class="en">was</span></b>。','彼は 学生 でした。'),
  ('I was played soccer.','I played soccer.','心臓（動詞）が2つ。動作の文に <b><span class="en">was</span> はいりません</b>。','わたしは サッカーを しました。'),
  ('I didn&#39;t busy yesterday.','I wasn&#39;t busy yesterday.','be動詞の文の打ち消しは <b><span class="en">wasn&#39;t</span></b>。<span class="en">didn&#39;t</span> は動作用です。','わたしは きのう いそがしく ありませんでした。'),
  ('Was you busy?','Were you busy?','主語が <span class="en">you</span> なので <b><span class="en">Were</span></b>。','あなたは いそがしかったですか。'),
 ],
 'summary':[
  '<b><span class="en">am</span>・<span class="en">is</span> → <span class="en">was</span>、<span class="en">are</span> → <span class="en">were</span>。</b>過去形は2つだけ。',
  '打ち消しは <b><span class="en">wasn&#39;t</span>／<span class="en">weren&#39;t</span></b>、たずねる文は <b>前に出す</b>。',
  '答えは <b><span class="en">Yes, I was.</span> ／ <span class="en">No, I wasn&#39;t.</span></b>',
  '<b>動作の文には使わない。</b>青は <span class="en">wasn&#39;t</span>、ピンクは <span class="en">didn&#39;t</span>。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '<span class="en">am</span> と <span class="en">is</span> の過去形は%s、<span class="en">are</span> の過去形は%s。' % (bl('was'), bl('were')),
     '主語が <span class="en">I</span> なら%s、<span class="en">you</span> なら%s、<span class="en">he</span> なら%s。' % (bl('was'), bl('were'), bl('was')),
     '打ち消しは be動詞のうしろに%sを置く。短い形は <span class="en">wasn&#39;t</span>。' % bl('not'),
     'たずねる文は be動詞を文の%sに出す。' % bl('前'),
     '動作の文の打ち消しには%sを使う。be動詞の文には使わない。' % bl("didn't"),
   ]),
   'words':'語群：<span class="en">was</span> ／ <span class="en">were</span> ／ <span class="en">not</span> ／ <span class="en">didn&#39;t</span> ／ 前',
   'exp':'<b>なぜ？</b>　be動詞は「＝」のしるし。過去になっても、<b>主語との組み合わせ方は変わりません</b>。<br>'
         'ただし形がへって2つになるので、<span class="en">am</span> と <span class="en">is</span> が合体して <span class="en">was</span> になった、と考えると覚えやすいです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--key);">B　<span class="en">was</span>？ それとも <span class="en">were</span>？<em>（　）に正しい形を書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>主語だけ</b>を見ましょう。<span class="en">you</span> なら <span class="en">were</span>、それ以外は <span class="en">was</span>。',
   'body':grid2([
     '1. <span class="en">I%sbusy yesterday.</span>' % bl('was'),
     '2. <span class="en">You%sbusy yesterday.</span>' % bl('were'),
     '3. <span class="en">He%sat home.</span>' % bl('was'),
     '4. <span class="en">She%shappy.</span>' % bl('was'),
     '5. <span class="en">You%stired.</span>' % bl('were'),
     '6. <span class="en">Mike%sa student.</span>' % bl('was'),
     '7. <span class="en">I%shungry then.</span>' % bl('was'),
     '8. <span class="en">%syou free?</span>' % bl('Were'),
     '9. <span class="en">%she at school?</span>' % bl('Was'),
     '10. <span class="en">It%sfun.</span>' % bl('was'),
   ]),
   'exp':'<b>見つけ方</b>　主語を見るだけ。<br>'
         '<span class="en">you</span> → <b><span class="en">were</span></b>（2・5・8）　<span class="en">I・he・she</span>・名前・<span class="en">it</span> → <b><span class="en">was</span></b>（1・3・4・6・7・9・10）<br>'
         '8・9は<b>たずねる文</b>なので前に出て、文のはじめだから大文字です。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--key);">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. I was busy yesterday.','○'), ('2. I were busy yesterday.','✕'),
     ('3. You were tired.','○'), ('4. You was tired.','✕'),
     ('5. He was at home.','○'), ('6. He were at home.','✕'),
     ('7. I played soccer.','○'), ('8. I was played soccer.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">I was busy yesterday.</span>（<span class="en">I</span> には <span class="en">was</span>）<br>'
         '4 → <span class="en">You were tired.</span>（<span class="en">you</span> には <span class="en">were</span>）　6 → <span class="en">He was at home.</span>（<span class="en">he</span> には <span class="en">was</span>）<br>'
         '8 → <span class="en">I played soccer.</span>（<span class="en">was</span> を消す）　8だけ<b>心臓（動詞）が2つ</b>のまちがいです。'},
  {'h':'<h3 class="sec sec2">D　<span class="en">wasn&#39;t</span>？ それとも <span class="en">didn&#39;t</span>？<em>正しいほうを選ぼう</em></h3>',
   'hint':'動作のことばがあれば <span class="en">didn&#39;t</span>、なければ <span class="en">wasn&#39;t</span>／<span class="en">weren&#39;t</span>。',
   'body':grid2([
     '1. <span class="en">I（ア wasn&#39;t ／イ didn&#39;t）busy yesterday.</span>%s' % bl('ア'),
     '2. <span class="en">I（ア wasn&#39;t ／イ didn&#39;t）play soccer.</span>%s' % bl('イ'),
     '3. <span class="en">He（ア didn&#39;t ／イ wasn&#39;t）at home.</span>%s' % bl('イ'),
     '4. <span class="en">He（ア didn&#39;t ／イ wasn&#39;t）go to the park.</span>%s' % bl('ア'),
     '5. <span class="en">You（ア weren&#39;t ／イ didn&#39;t）tired.</span>%s' % bl('ア'),
     '6. <span class="en">I（ア weren&#39;t ／イ didn&#39;t）eat natto.</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　うしろに動作のことばがあるかを見るだけ。<br>'
         '<b>ある</b>（<span class="en">play・go・eat</span>）→ <span class="en">didn&#39;t</span>（2・4・6）　<b>ない</b>（いそがしい・家に・つかれた）→ <span class="en">wasn&#39;t / weren&#39;t</span>（1・3・5）'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　主語が <span class="en">you</span> なら <span class="en">were</span>、それ以外は <span class="en">was</span>。動作の文には使いません。',
   'body':ol([
     ('<span class="jp-cue">わたしはきのういそがしかったです。</span>　<span class="en">I%sbusy yesterday.</span>' % bl('was'),
      '主語が <span class="en">I</span> なので <b><span class="en">was</span></b>。'),
     ('<span class="jp-cue">あなたはきのういそがしかったです。</span>　<span class="en">You%sbusy yesterday.</span>' % bl('were'),
      '主語が <span class="en">you</span> なので <b><span class="en">were</span></b>。'),
     ('<span class="jp-cue">彼は家にいました。</span>　<span class="en">He%sat home.</span>' % bl('was'),
      '<span class="en">he</span> は <span class="en">is</span> の仲間。過去形は <b><span class="en">was</span></b>。'),
     ('<span class="jp-cue">わたしはいそがしくありませんでした。</span>　<span class="en">I%sbusy.</span>' % bl("wasn't", False),
      '打ち消しは <b><span class="en">wasn&#39;t</span></b>。'),
     ('<span class="jp-cue">あなたはいそがしかったですか。</span>　<span class="en">%syou busy?</span>' % bl('Were'),
      'たずねる文は前に出す。<span class="en">you</span> なので <b><span class="en">Were</span></b>。'),
     ('<span class="jp-cue">はい、いそがしかったです。</span>　<span class="en">Yes, I%s.</span>' % bl('was'),
      '答えるのは自分のことなので <b><span class="en">I was</span></b>。'),
     ('<span class="jp-cue">わたしはサッカーをしました。</span>　<span class="en">I%ssoccer.</span>' % bl('played', False),
      '動作の文なので <b><span class="en">was</span> はいりません</b>。'),
     ('<span class="jp-cue">彼は家にいませんでした。</span>　<span class="en">He%sat home.</span>' % bl("wasn't", False),
      '3番の打ち消し。<b><span class="en">wasn&#39;t</span></b>。'),
     ('<span class="jp-cue">わたしはサッカーをしませんでした。</span>　<span class="en">I%splay soccer.</span>' % bl("didn't", False),
      '動作の文の打ち消しは <b><span class="en">didn&#39;t</span></b>。4番とくらべよう。'),
     ('<span class="jp-cue">彼は生徒でしたか。</span>　<span class="en">%she a student?</span>' % bl('Was'),
      '<span class="en">he</span> なので <b><span class="en">Was</span></b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群に <span class="en">was</span>・<span class="en">were</span> があれば be動詞の文。動作の過去形があれば ふつうの文です。',
   'body':ol([
     ('<span class="jp-cue">わたしはきのういそがしかったです。</span>　<span class="paren en">（ busy / was / yesterday / I ）</span>' + line('I was busy yesterday.'),
      '<span class="en">yesterday</span> はいちばん後ろ。'),
     ('<span class="jp-cue">あなたはつかれていました。</span>　<span class="paren en">（ tired / You / were ）</span>' + line('You were tired.'),
      '語群が <span class="en">were</span>。主語は <span class="en">you</span>。'),
     ('<span class="jp-cue">彼は家にいました。</span>　<span class="paren en">（ at home / was / He ）</span>' + line('He was at home.'),
      '<span class="en">at home</span> でひとかたまり。'),
     ('<span class="jp-cue">あなたはいそがしかったですか。</span>　<span class="paren en">（ busy / you / Were ）</span>' + line('Were you busy?'),
      '語群の <span class="en">Were</span> が大文字。だから先頭です。'),
     ('<span class="jp-cue">わたしはいそがしくありませんでした。</span>　<span class="paren en">（ busy / I / wasn&#39;t ）</span>' + line('I wasn&#39;t busy.'),
      '<span class="en">wasn&#39;t</span> は <span class="en">I</span> のすぐうしろ。'),
     ('<span class="jp-cue">わたしはきのうサッカーをしました。</span>　<span class="paren en">（ soccer / played / I / yesterday ）</span>' + line('I played soccer yesterday.'),
      '語群に <span class="en">was</span> がない。<b>動作の文</b>です。'),
     ('<span class="jp-cue">彼は生徒でしたか。</span>　<span class="paren en">（ a / student / he / Was ）</span>' + line('Was he a student?'),
      '語群が <span class="en">Was</span>。主語は <span class="en">he</span>。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしはきのういそがしかったです。' + wline('I was busy yesterday.'),
      '<span class="en">I</span> には <span class="en">was</span>。'),
     ('あなたはつかれていました。' + wline('You were tired.'),
      '<span class="en">you</span> には <span class="en">were</span>。'),
     ('彼は家にいました。' + wline('He was at home.'),
      '「家に」は <span class="en">at home</span>。'),
     ('わたしはいそがしくありませんでした。' + wline('I wasn&#39;t busy.'),
      '<span class="en">I was not busy.</span> でも正解。'),
     ('あなたはいそがしかったですか。' + wline('Were you busy?'),
      '<span class="en">Was you ～?</span> ではありません。'),
     ('わたしはきのうサッカーをしました。' + wline('I played soccer yesterday.'),
      '動作の文なので <span class="en">was</span> はいりません。'),
   ]),
   'words':'<span class="en">busy ／ tired ／ at home ／ wasn&#39;t ／ Were you ／ played soccer</span>'},
  'l4':{'sub':'きのうの自分のようすを書こう',
   'cond':['<span class="en">I was ～.</span> の文を <b>2つ以上</b>',
           '<span class="en">I wasn&#39;t ～.</span> の文を <b>1つ以上</b>',
           '動作の過去形の文（<span class="en">I played ～.</span> など）も <b>1つ</b> 入れる'],
   'example':['I was busy yesterday. I was at school.','I wasn&#39;t free in the morning.','I played soccer after school.'],
   'note':'これは例です。同じでなくてかまいません。きのうの気分・いた場所・したこと の3つを書くとまとまります。',
   'check':['I・he・she には was、you には were','be動詞の文の打ち消しは wasn&#39;t','動作の文に was を入れていない','wasn&#39;t のアポストロフィ'],
   'review':'じぶんの文の <span class="en">was</span> のうしろに○をつけよう。動作のことばが来ていたら、そこがまちがい。'},
 },
}
