# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox, gmap

S = {
 'id':'u5-3', 'unit':'5 − 3', 'unit_plain':'5-3', 'title':'When ～?',
 'pages':'p.78〜79',
 'hero_big':'When is your birthday? ／ When do you study?',
 'hero_jp':'あなたの 誕生日は いつ ですか ／ あなたは いつ 勉強しますか',
 'motto':'<span class="en">When</span> は「いつ」。答えは <b>時</b>で言う。<span class="en">What・Who・Where・When</span> は <span class="en">Yes / No</span> を使わない。',
 'kana':{'when':'ウェン','where':'ウェア','is':'イズ','do':'ドゥー',
         'on':'オン','in':'イン','at':'アット','after':'アフター',
         'monday':'マンデイ','sunday':'サンデイ','saturday':'サタデイ',
         'summer':'サマー','winter':'ウィンター','birthday':'バースデイ',
         'august':'オーガスト','july':'ジュライ','festival':'フェスティヴァル',
         'school':'スクール','dinner':'ディナー','study':'スタディ','get':'ゲット',
         'practice':'プラクティス','six':'スィックス','seven':'セヴン',"it's":'イッツ'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>誕生日は いつですか</b>」「<b>いつ 勉強しますか</b>」のように、<b>時</b>をたずねるときの形です。'),
    ('t','使うのは <span class="en">When</span>（いつ）。作り方は 5-2 の <span class="en">Where</span> とまったく同じで、<b>2通り</b>あります。'),
    ('h', gitem('❶', '「～は いつですか」', '日づけや時こくをきく',
                '誕生日は いつ ですか', 'When is your birthday?',
                [('When is your birthday?','あなたの 誕生日は いつ ですか。'),
                 ('— It&#39;s in August.','— それは 8月 です。')],
                '<b>When ＋ is ～?</b> の形。答えるときは <span class="en">in August</span> のように時を言います。')),
    ('h', gitem('❷', '「いつ ～ しますか」', 'することをする時をきく',
                'いつ 勉強しますか', 'When do you study?',
                [('When do you study?','あなたは いつ 勉強しますか。'),
                 ('— I study after dinner.','— わたしは 夕食の あとに 勉強します。')],
                '<b>When ＋ do you ～?</b> の形。<span class="en">Do you ～?</span> の前に <span class="en">When</span> を置くだけ。', b2=True)),
    ('t','<span class="en">Where</span> も <span class="en">When</span> も、<b>前に置いて うしろはそのまま</b>。この作り方は これからも ずっと使います。'),
    ('h', copybox()),
  ]),
  ('2つのパターンは <span class="en">Where</span> と同じ', [
    ('t','<b>動作のことばがあれば <span class="en">do you</span>、なければ <span class="en">is</span></b>。5-2 で練習したとおりです。'),
    ('h','''<table class="kind">
      <thead><tr><th>たずねたいこと</th><th>形</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k">行事などの時</td><td class="k" style="color:var(--key);font-weight:700;">When is ～?</td><td class="e">When <u>is</u> your birthday?</td></tr>
        <tr><td class="k">することの時</td><td class="k" style="color:var(--gv);font-weight:700;">When do you ～?</td><td class="e">When <u>do you</u> study?</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">When is</span> も <span class="en">When&#39;s</span> と短くできます。<span class="en">Who&#39;s</span>・<span class="en">Where&#39;s</span> と同じです。'),
  ]),
  ('時を表すことば', [
    ('t','答えるときは、<b>時を表すことば</b>を使います。前につくことばが3つあります。'),
    ('h','''<table class="kind">
      <thead><tr><th>ことば</th><th>つくもの</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><span class="en">on</span></td><td class="k">曜日・日づけ</td><td class="e">It&#39;s <u>on</u> Monday.</td></tr>
        <tr><td class="k"><span class="en">in</span></td><td class="k">月・季節</td><td class="e">It&#39;s <u>in</u> August.</td></tr>
        <tr><td class="k"><span class="en">at</span></td><td class="k">時こく</td><td class="e">I study <u>at</u> seven.</td></tr>
      </tbody>
    </table>'''),
    ('t','おぼえ方は<b>「せまいほど <span class="en">at</span>、広いほど <span class="en">in</span>」</b>。曜日はそのまん中で <span class="en">on</span> です。'),
    ('t','<span class="en">after school</span>（放課後）、<span class="en">after dinner</span>（夕食のあと）のように、<span class="en">after</span> を使う言い方もよく出ます。'),
  ]),
  ('かなり大事｜4つのたずねことばの整理', [
    ('t','ここが今回のヤマです。ここまでに<b>4つのたずねことば</b>を習いました。答え方はぜんぶ同じで、<b>中身で答える</b>です。'),
    ('h','''<table class="kind">
      <thead><tr><th>ことば</th><th>意味</th><th>答えるもの</th></tr></thead>
      <tbody>
        <tr><td class="k"><span class="en">What</span></td><td class="k">なに</td><td class="e">もの（I like music.）</td></tr>
        <tr><td class="k"><span class="en">Who</span></td><td class="k">だれ</td><td class="e">人（She&#39;s my sister.）</td></tr>
        <tr><td class="k"><span class="en">Where</span></td><td class="k">どこ</td><td class="e">場所（It&#39;s on the desk.）</td></tr>
        <tr><td class="k"><span class="en">When</span></td><td class="k">いつ</td><td class="e">時（It&#39;s in August.）</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：<span class="en">W</span> で始まることばは <span class="en">Yes / No</span> で答えない</div>
        <p><b class="cb"><span class="en">Is / Do / Can</span> → <span class="en">Yes / No</span></b>　<b class="cp"><span class="en">What / Who / Where / When</span> → 中身</b>　
        先頭を見れば、答え方が決まります。<br>
        <span class="xm">✕ When is your birthday? — Yes, it is ✕</span></p>
      </div>
    </div>'''),
    ('t','<span class="en">What・Who・Where・When</span> はぜんぶ <span class="en">W</span> で始まります。<b>「<span class="en">W</span> なら中身」</b>とおぼえておけば迷いません。'),
  ]),
  ('<span class="en">When</span> と <span class="en">Where</span> を混ぜない', [
    ('t','形がにていて、スペルも1字しかちがわないので、混ぜる人がとても多いところです。'),
    ('h','''<div class="eqbox" style="border-left-color:#D98400;background:rgba(217,132,0,.07);">
      <span class="eq" style="color:#D98400;">When</span>　… <b>いつ</b>（時）　<span class="en">It&#39;s in August.</span><br>
      <span class="eq" style="color:#D98400;">Where</span>　… <b>どこ</b>（場所）　<span class="en">It&#39;s on the desk.</span>
    </div>'''),
    ('t','<span class="en">When</span> に <b><span class="en">n</span></b>、<span class="en">Where</span> に <b><span class="en">r</span></b>。日本語の「<b>いつ</b>」「<b>どこ</b>」と結びつけて声に出しておぼえましょう。'),
  ]),
 ],
 'quiz':[
  ('When your birthday is?','When is your birthday?','<span class="en">When</span> のうしろは <b><span class="en">is</span> → 主語</b> の順。','あなたの 誕生日は いつ ですか。'),
  ('When is your birthday? — Yes, it is.','It&#39;s in August.','<span class="en">When</span> で聞かれたら <b>時で答える</b>。<span class="en">Yes / No</span> は使いません。','それは 8月 です。'),
  ('When you do study?','When do you study?','<span class="en">When</span> のうしろは <b><span class="en">do you</span></b> の順。','あなたは いつ 勉強しますか。'),
  ('When is you study?','When do you study?','<span class="en">study</span> は動作のことば。<b>動作の文は <span class="en">do you</span></b>。','あなたは いつ 勉強しますか。'),
  ('It&#39;s on August.','It&#39;s in August.','月には <b><span class="en">in</span></b> をつけます。<span class="en">on</span> は曜日や日づけ用です。','それは 8月 です。'),
  ('Where is your birthday?','When is your birthday?','誕生日は<b>時</b>なので <span class="en">When</span>。<span class="en">Where</span> は場所用です。','あなたの 誕生日は いつ ですか。'),
 ],
 'summary':[
  '「～はいつですか」は <b><span class="en">When is ～?</span></b>　「いつ～しますか」は <b><span class="en">When do you ～?</span></b>',
  '<b>答えは時。<span class="en">Yes / No</span> は使わない。</b>',
  '時のことばは <b><span class="en">on</span>（曜日）・<span class="en">in</span>（月・季節）・<span class="en">at</span>（時こく）</b>。',
  '<b><span class="en">What・Who・Where・When</span> はぜんぶ中身で答える。</b><span class="en">W</span> なら中身。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～はいつですか」は%sを文の前に置く。そのうしろは <span class="en">%s</span> ＋ 主語。' % (bl('When'), bl('is')),
     '動作の時をたずねるときは <span class="en">When%s</span> ～? の形を使う。' % bl('do you', False),
     '<span class="en">When</span> で聞かれたら、答えに%sは使わず、%sを答える。' % (bl('Yes / No', False), bl('時')),
     '曜日には%s、月や季節には%s、時こくには%sをつける。' % (bl('on'), bl('in'), bl('at')),
     '「どこ」をたずねるのは%s、「いつ」をたずねるのは <span class="en">When</span>。' % bl('Where'),
   ]),
   'words':'語群：<span class="en">When</span> ／ <span class="en">Where</span> ／ <span class="en">is</span> ／ <span class="en">do you</span> ／ <span class="en">on</span> ／ <span class="en">in</span> ／ <span class="en">at</span> ／ <span class="en">Yes / No</span> ／ 時',
   'exp':'<b>なぜ？</b>　<span class="en">What・Who・Where・When</span> はぜんぶ<b>「知りたいところ」</b>を表すことば。だから いちばん前に立ち、中身で答えます。<br>'
         '時のことばは<b>範囲の大きさ</b>で決まります。時こく（せまい）→<span class="en">at</span>、曜日→<span class="en">on</span>、月・季節（広い）→<span class="en">in</span>。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">on</span>？ <span class="en">in</span>？ <span class="en">at</span>？<em>（　）に正しいものを書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。時こく→<span class="en">at</span>／曜日・日づけ→<span class="en">on</span>／月・季節→<span class="en">in</span>。',
   'body':grid2([
     '1. <span class="en">It&#39;s%sAugust.</span>（8月）' % bl('in'),
     '2. <span class="en">It&#39;s%sMonday.</span>（月曜日）' % bl('on'),
     '3. <span class="en">I study%sseven.</span>（7時に）' % bl('at'),
     '4. <span class="en">It&#39;s%ssummer.</span>（夏）' % bl('in'),
     '5. <span class="en">It&#39;s%sSunday.</span>（日曜日）' % bl('on'),
     '6. <span class="en">I get up%ssix.</span>（6時に）' % bl('at'),
     '7. <span class="en">It&#39;s%sJuly.</span>（7月）' % bl('in'),
     '8. <span class="en">It&#39;s%sSaturday.</span>（土曜日）' % bl('on'),
     '9. <span class="en">It&#39;s%swinter.</span>（冬）' % bl('in'),
     '10. <span class="en">I practice%sfive.</span>（5時に）' % bl('at'),
   ]),
   'exp':'<b>見つけ方</b>　日本語を見るだけ。<br>'
         '<b>時こく</b>（7時・6時・5時）→ <span class="en">at</span>（3・6・10）　<b>曜日</b>（月・日・土）→ <span class="en">on</span>（2・5・8）<br>'
         '<b>月・季節</b>（8月・夏・7月・冬）→ <span class="en">in</span>（1・4・7・9）'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. When is your birthday?','○'), ('2. When your birthday is?','✕'),
     ('3. When do you study?','○'), ('4. When you do study?','✕'),
     ('5. It&#39;s in August.','○'), ('6. It&#39;s on August.','✕'),
     ('7. It&#39;s on Monday.','○'), ('8. When is you study?','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">When is your birthday?</span>（<span class="en">is</span> → 主語 の順に）<br>'
         '4 → <span class="en">When do you study?</span>（<span class="en">do you</span> の順に）　6 → <span class="en">It&#39;s in August.</span>（月は <span class="en">in</span>）<br>'
         '8 → <span class="en">When do you study?</span>（動作の文は <span class="en">do you</span>）'},
  {'h':'<h3 class="sec sec2">D　どのたずねことば？　記号で答えよう</h3>',
   'hint':'<span class="chip">ア</span> <span class="en">What</span>（なに）　<span class="chip" style="background:var(--gv);">イ</span> <span class="en">Who</span>（だれ）　<span class="chip" style="background:#D98400;">ウ</span> <span class="en">Where</span>（どこ）　<span class="chip" style="background:#7A4FBF;">エ</span> <span class="en">When</span>（いつ）',
   'body':grid2([
     '1. あなたの誕生日は<b>いつ</b>ですか。%s' % bl('エ'),
     '2. あの女の子は<b>だれ</b>ですか。%s' % bl('イ'),
     '3. わたしのかばんは<b>どこ</b>ですか。%s' % bl('ウ'),
     '4. あなたは<b>なに</b>が好きですか。%s' % bl('ア'),
     '5. あなたは<b>いつ</b>勉強しますか。%s' % bl('エ'),
     '6. あなたは<b>どこ</b>に住んでいますか。%s' % bl('ウ'),
   ]),
   'exp':'<b>ここが大事</b>　4つとも <span class="en">W</span> で始まり、<b>どれも <span class="en">Yes / No</span> では答えません</b>。<br>'
         '日本語の「なに・だれ・どこ・いつ」と1対1で結びつけておけば、まちがえません。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　「いつ」なら <span class="en">When</span>。そのうしろは 動作のことばがあれば <span class="en">do you</span>、なければ <span class="en">is</span>。',
   'body':ol([
     ('<span class="jp-cue">あなたの誕生日はいつですか。</span>　<span class="en">%sis your birthday?</span>' % bl('When'),
      '「いつ」なので <b><span class="en">When</span></b>。'),
     ('<span class="jp-cue">それは8月です。</span>　<span class="en">It&#39;s%sAugust.</span>' % bl('in'),
      '月には <b><span class="en">in</span></b>。'),
     ('<span class="jp-cue">あなたはいつ勉強しますか。</span>　<span class="en">When%syou study?</span>' % bl('do'),
      '<span class="en">study</span> は動作のことば。<b><span class="en">do you</span></b>。'),
     ('<span class="jp-cue">それは月曜日です。</span>　<span class="en">It&#39;s%sMonday.</span>' % bl('on'),
      '曜日には <b><span class="en">on</span></b>。'),
     ('<span class="jp-cue">わたしは7時に勉強します。</span>　<span class="en">I study%sseven.</span>' % bl('at'),
      '時こくには <b><span class="en">at</span></b>。'),
     ('<span class="jp-cue">わたしのかばんはどこですか。</span>　<span class="en">%sis my bag?</span>' % bl('Where'),
      '「どこ」なので <b><span class="en">Where</span></b>。1番とくらべよう。'),
     ('<span class="jp-cue">それは夏です。</span>　<span class="en">It&#39;s%ssummer.</span>' % bl('in'),
      '季節にも <b><span class="en">in</span></b>。'),
     ('<span class="jp-cue">あなたはいつサッカーを練習しますか。</span>　<span class="en">%s%syou practice soccer?</span>' % (bl('When'), bl('do')),
      '（　）が2つ。<b><span class="en">When</span> → <span class="en">do</span></b>。'),
     ('<span class="jp-cue">短い形にしよう。</span>　<span class="en">When is your birthday?</span> →　<span class="en">%syour birthday?</span>' % bl("When's", False),
      '<b><span class="en">When is</span> ＝ <span class="en">When&#39;s</span></b>。'),
     ('<span class="jp-cue">わたしは放課後に練習します。</span>　<span class="en">I practice%sschool.</span>' % bl('after'),
      '「放課後」は <b><span class="en">after school</span></b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　<span class="en">When</span> が先頭。そのうしろは <span class="en">is</span> ＋ 主語、または <span class="en">do</span> ＋ <span class="en">you</span> ＋ 動詞。',
   'body':ol([
     ('<span class="jp-cue">あなたの誕生日はいつですか。</span>　<span class="paren en">（ your birthday / When / is ）</span>' + line('When is your birthday?'),
      '<span class="en">When</span> → <span class="en">is</span> → 主語 の順。終わりは <b>?</b>。'),
     ('<span class="jp-cue">それは8月です。</span>　<span class="paren en">（ August / It&#39;s / in ）</span>' + line('It&#39;s in August.'),
      '<span class="en">in August</span> でひとかたまり。月は大文字ではじめる。'),
     ('<span class="jp-cue">あなたはいつ勉強しますか。</span>　<span class="paren en">（ study / you / When / do ）</span>' + line('When do you study?'),
      '<span class="en">When</span> → <span class="en">do</span> → <span class="en">you</span> → 動詞。'),
     ('<span class="jp-cue">それは月曜日です。</span>　<span class="paren en">（ Monday / on / It&#39;s ）</span>' + line('It&#39;s on Monday.'),
      '曜日なので <span class="en">on</span>。曜日も大文字ではじめる。'),
     ('<span class="jp-cue">わたしのかばんはどこですか。</span>　<span class="paren en">（ my bag / is / Where ）</span>' + line('Where is my bag?'),
      '語群が <span class="en">Where</span>。<b>場所をたずねる文</b>です。'),
     ('<span class="jp-cue">わたしは7時に勉強します。</span>　<span class="paren en">（ seven / study / at / I ）</span>' + line('I study at seven.'),
      '時こくなので <span class="en">at</span>。いちばん後ろに置きます。'),
     ('<span class="jp-cue">あなたはいつサッカーを練習しますか。</span>　<span class="paren en">（ soccer / practice / When / you / do ）</span>' + line('When do you practice soccer?'),
      '3番と同じ形。<span class="en">soccer</span> はいちばん後ろ。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('あなたの誕生日はいつですか。' + wline('When is your birthday?'),
      '<span class="en">When&#39;s your birthday?</span> でも正解。'),
     ('それは8月です。' + wline('It&#39;s in August.'),
      '月には <span class="en">in</span>。<span class="en">August</span> は大文字ではじめる。'),
     ('あなたはいつ勉強しますか。' + wline('When do you study?'),
      '動作のことばなので <span class="en">do you</span>。'),
     ('それは月曜日です。' + wline('It&#39;s on Monday.'),
      '曜日には <span class="en">on</span>。2番とくらべよう。'),
     ('わたしは7時に勉強します。' + wline('I study at seven.'),
      '時こくには <span class="en">at</span>。'),
     ('わたしのかばんはどこですか。' + wline('Where is my bag?'),
      '「どこ」なので <span class="en">Where</span>。<span class="en">When</span> とまちがえないこと。'),
   ]),
   'words':'<span class="en">your birthday ／ in August ／ study ／ on Monday ／ at seven ／ my bag</span>'},
  'l4':{'sub':'友だちに「いつ」をたずねる会話を書こう',
   'cond':['<span class="en">When is ～?</span> の文を <b>1つ以上</b>',
           '<span class="en">When do you ～?</span> の文を <b>1つ以上</b>',
           'それぞれの答えを書く（<span class="en">on・in・at</span> を使い分ける）'],
   'example':['When is your birthday? — It&#39;s in July.','When do you study? — I study at seven.','When do you practice soccer? — On Sunday.'],
   'note':'これは例です。同じでなくてかまいません。誕生日・部活・勉強・好きな季節 のどれかを聞いてみよう。',
   'check':['When のうしろは is か do you','答えは時で言う','Yes / No を使っていない','on・in・at を使い分けた'],
   'review':'じぶんの文の時のことばに○をつけよう。月に <span class="en">on</span>、曜日に <span class="en">in</span> がついていたら、そこがまちがい。'},
 },
}
