# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, copybox, gmap

S = {
 'id':'u4-2', 'unit':'4 − 2', 'unit_plain':'4-2', 'title':"Who's ～?",
 'pages':'p.64〜65',
 'hero_big':'Who&#39;s that girl?',
 'hero_jp':'あの 女の子は だれ ですか',
 'motto':'<span class="en">Who</span> は「だれ」。答えは <b>名前や関係</b>で言う。<span class="en">Yes / No</span> は使わない。',
 'kana':{'who':'フー',"who's":'フーズ','he':'ヒー','she':'シー','is':'イズ',
         "he's":'ヒーズ',"she's":'シーズ','that':'ザット','this':'ズィス',
         'girl':'ガール','boy':'ボイ','man':'マン','woman':'ウーマン',
         'my':'マイ','friend':'フレンド','brother':'ブラザー','sister':'スィスター',
         'teacher':'ティーチャー','mike':'マイク','emma':'エマ','saki':'サキ'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>あの女の子は だれですか</b>」のように、<b>人がだれか</b>をたずねる文です。'),
    ('t','3-1 の <span class="en">What</span>（なに）の仲間で、今回は <span class="en">Who</span>（だれ）です。'),
    ('h', gmap('あの女の子は <b>だれ</b> ですか', '<b>Who&#39;s</b> that girl?',
               '<b>Who&#39;s</b> は <span class="en">Who is</span> を短くした形。答えは <span class="en">He&#39;s ～. / She&#39;s ～.</span> と言います。')),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Who&#39;s that girl?</span><span class="t">あの 女の子は だれ ですか。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">She&#39;s my sister.</span><span class="t">彼女は わたしの 姉妹 です。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Who&#39;s that boy?</span><span class="t">あの 男の子は だれ ですか。</span></div>
    </div>'''),
    ('t','<span class="en">Who&#39;s</span> は <span class="en">Who is</span> を短くした形です。答えは <span class="en">he</span> や <span class="en">she</span> を使って、<b>名前や関係</b>を言います。'),
    ('h', copybox()),
  ]),
  ('つくり方は <span class="en">Who&#39;s</span> ＋ だれのことか', [
    ('t','やり方はかんたん。<b><span class="en">Who&#39;s</span> のうしろに「だれのことか」を置く</b>だけです。'),
    ('h','''<div class="blocks">
      <div class="blk fill" style="background:#D98400;"><div class="w en">Who&#39;s</div><div class="r">だれですか</div></div>
      <div class="plus">＋</div>
      <div class="blk line"><div class="w">だれのこと</div><div class="r">that girl / that boy / he …</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--ng);"><div class="w">?</div><div class="r">わすれない</div></div>
    </div>'''),
    ('t','<span class="en">that</span> は「あの」という意味です。<span class="en">that girl</span>（あの女の子）、<span class="en">that boy</span>（あの男の子）のように使います。'),
    ('t','<span class="en">Who&#39;s</span> は <span class="en">Who is</span> の短い形。<b>&#39;（アポストロフィ）を忘れない</b>のは今までと同じです。'),
  ]),
  ('かなり大事｜答えは <span class="en">Yes / No</span> ではなく <b>名前や関係</b>', [
    ('t','ここが今回のヤマです。<span class="en">Who</span> は「だれ？」と中身を聞いているので、<b>はい／いいえでは答えられません</b>。3-1 の <span class="en">What</span> と同じ考え方です。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-smile"/></svg>
          <span>◯ 名前や関係で答える<small>Who で聞かれたとき</small></span></div>
        <div class="in"><div class="ex">Who&#39;s that girl?<br>— She&#39;s my sister.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>✕ はい／いいえ<small>Who には合わない</small></span></div>
        <div class="in"><div class="ex">Who&#39;s that girl?<br>— Yes, she is.</div></div>
      </div>
    </div>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：<span class="en">Who</span>・<span class="en">What</span> で聞かれたら 中身で答える</div>
        <p><b class="cb"><span class="en">Is he ～?</span> → <span class="en">Yes / No</span></b>　<b class="cp"><span class="en">Who&#39;s ～?</span> → 名前や関係</b>　
        先頭を見れば、答え方が決まります。<br>
        <span class="xm">✕ Who&#39;s that girl? — Yes, she is ✕</span></p>
      </div>
    </div>'''),
  ]),
  ('答えるときは <span class="en">he</span> か <span class="en">she</span> に言いかえる', [
    ('t','<span class="en">that girl</span> と聞かれたら、答えでは <b><span class="en">she</span></b> に言いかえます。<span class="en">that boy</span> なら <b><span class="en">he</span></b> です。'),
    ('h','''<table class="kind">
      <thead><tr><th>たずねる文</th><th>答えの主語</th><th>答えの文</th></tr></thead>
      <tbody>
        <tr><td class="k">Who&#39;s that <u>girl</u>?</td><td class="k" style="color:var(--key);font-weight:700;">she</td><td class="e">She&#39;s my sister.</td></tr>
        <tr><td class="k">Who&#39;s that <u>boy</u>?</td><td class="k" style="color:var(--key);font-weight:700;">he</td><td class="e">He&#39;s my friend.</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">That girl is my sister.</span> と答えても通じますが、<b><span class="en">she</span> を使うほうが自然</b>です。'),
  ]),
  ('<span class="en">Who</span> と <span class="en">What</span> の使い分け', [
    ('t','どちらも「中身をたずねる」ことばですが、聞いているものがちがいます。'),
    ('h','''<div class="eqbox">
      <span class="eq">Who&#39;s that girl?</span>　→　<b>人</b>をたずねる（だれ）<br>
      <span class="eq">What do you like?</span>　→　<b>もの</b>をたずねる（なに）
    </div>'''),
    ('t','<b>人なら <span class="en">Who</span>、ものなら <span class="en">What</span></b>。日本語の「だれ」「なに」と同じ区別です。'),
  ]),
 ],
 'quiz':[
  ('Who that girl?','Who&#39;s that girl?','<span class="en">Who</span> だけでは文になりません。<b><span class="en">Who&#39;s</span></b>（＝<span class="en">Who is</span>）にします。','あの 女の子は だれ ですか。'),
  ('Whos that girl?','Who&#39;s that girl?','<b>&#39;（アポストロフィ）</b>を忘れています。<span class="en">Who is</span> → <span class="en">Who&#39;s</span>。','あの 女の子は だれ ですか。'),
  ('Who&#39;s that girl? — Yes, she is.','She&#39;s my sister.','<span class="en">Who</span> で聞かれたら <b>名前や関係で答える</b>。<span class="en">Yes / No</span> は使いません。','彼女は わたしの 姉妹 です。'),
  ('Who&#39;s that boy? — She&#39;s my friend.','He&#39;s my friend.','<span class="en">boy</span>（男の子）なので <b><span class="en">he</span></b>。<span class="en">she</span> は女の人です。','彼は わたしの 友だち です。'),
  ('Who&#39;s that girl.','Who&#39;s that girl?','終わりが<b>ピリオド</b>です。たずねる文の終わりは <b>?</b>。','あの 女の子は だれ ですか。'),
  ('What&#39;s that girl?','Who&#39;s that girl?','人をたずねるときは <b><span class="en">Who</span></b>。<span class="en">What</span> は「もの」用です。','あの 女の子は だれ ですか。'),
 ],
 'summary':[
  '「～はだれですか」は <b><span class="en">Who&#39;s ～?</span></b>　<span class="en">Who&#39;s</span>＝<span class="en">Who is</span>、&#39; を忘れない。',
  '<b>答えは <span class="en">Yes / No</span> ではなく、名前や関係。</b>',
  '答えの主語は <b><span class="en">he</span>（男の人）／<span class="en">she</span>（女の人）</b> に言いかえる。',
  '<b>人なら <span class="en">Who</span>、ものなら <span class="en">What</span>。</b>',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～はだれですか」は%s～? と言う。これは <span class="en">Who%s</span> を短くした形。' % (bl("Who's", False), bl('is')),
     '<span class="en">Who</span> で聞かれたら、答えに%sは使わず、%sや関係を答える。' % (bl('Yes / No', False), bl('名前')),
     '答えの主語は、男の人なら%s、女の人なら%s。' % (bl('he'), bl('she')),
     '人をたずねるときは <span class="en">Who</span>、ものをたずねるときは%s。' % bl('What'),
     'たずねる文の終わりは%sにする。' % bl('?'),
   ]),
   'words':'語群：<span class="en">Who&#39;s</span> ／ <span class="en">is</span> ／ <span class="en">he</span> ／ <span class="en">she</span> ／ <span class="en">What</span> ／ <span class="en">Yes / No</span> ／ 名前 ／ ?',
   'exp':'<b>なぜ？</b>　<span class="en">Who</span> も <span class="en">What</span> も「知りたいところ」を表すことば。だから<b>いちばん前に立ちます</b>。<br>'
         '知りたい中身を聞いているので、<span class="en">Yes / No</span> では答えになりません。3-1 とまったく同じ考え方です。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">Who&#39;s</span>？ それとも <span class="en">What</span>？<em>（　）に入るものを書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。たずねているのが<b>人かものか</b>だけを見ましょう。',
   'body':grid2([
     '1. <span class="en">%sthat girl?</span>（だれ）' % bl("Who's", False),
     '2. <span class="en">%sdo you like?</span>（なに）' % bl('What'),
     '3. <span class="en">%sthat boy?</span>（だれ）' % bl("Who's", False),
     '4. <span class="en">%ssport do you like?</span>（どんなスポーツ）' % bl('What'),
     '5. <span class="en">%syour teacher?</span>（だれ）' % bl("Who's", False),
     '6. <span class="en">%sdo you study?</span>（なに）' % bl('What'),
     '7. <span class="en">%sthat man?</span>（だれ）' % bl("Who's", False),
     '8. <span class="en">%scolor do you like?</span>（どんな色）' % bl('What'),
     '9. <span class="en">%sthat woman?</span>（だれ）' % bl("Who's", False),
     '10. <span class="en">%sdo you eat?</span>（なに）' % bl('What'),
   ]),
   'exp':'<b>見つけ方</b>　日本語を見るだけ。<br>'
         '「<b>だれ</b>」→ <span class="en">Who&#39;s</span>（1・3・5・7・9）　「<b>なに・どんな</b>」→ <span class="en">What</span>（2・4・6・8・10）<br>'
         '<span class="en">man</span> は男の人、<span class="en">woman</span> は女の人という意味です。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. Who&#39;s that girl?','○'), ('2. Who that girl?','✕'),
     ('3. He&#39;s my friend.','○'), ('4. Whos that boy?','✕'),
     ('5. She&#39;s my sister.','○'), ('6. Who&#39;s that girl.','✕'),
     ('7. Who&#39;s your teacher?','○'), ('8. What&#39;s that boy?','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">Who&#39;s that girl?</span>（<span class="en">is</span> が必要）　4 → <span class="en">Who&#39;s that boy?</span>（&#39;を入れる）<br>'
         '6 → <span class="en">Who&#39;s that girl?</span>（終わりを ? に）　8 → <span class="en">Who&#39;s that boy?</span>（人なので <span class="en">Who</span>）'},
  {'h':'<h3 class="sec sec2">D　答え方　正しいほうを選ぼう</h3>',
   'hint':'<span class="en">Who</span> なら<b>名前や関係</b>。男の人は <span class="en">he</span>、女の人は <span class="en">she</span>。',
   'body':grid2([
     '1. <span class="en">Who&#39;s that girl?</span>　—（ア <span class="en">She&#39;s my sister.</span> ／イ <span class="en">Yes, she is.</span>）%s' % bl('ア'),
     '2. <span class="en">Who&#39;s that boy?</span>　—（ア <span class="en">She&#39;s my friend.</span> ／イ <span class="en">He&#39;s my friend.</span>）%s' % bl('イ'),
     '3. <span class="en">Who&#39;s that man?</span>　—（ア <span class="en">No, he isn&#39;t.</span> ／イ <span class="en">He&#39;s my teacher.</span>）%s' % bl('イ'),
     '4. <span class="en">What do you like?</span>　—（ア <span class="en">I like music.</span> ／イ <span class="en">Yes, I do.</span>）%s' % bl('ア'),
     '5. <span class="en">Who&#39;s that woman?</span>　—（ア <span class="en">She&#39;s my mother.</span> ／イ <span class="en">He&#39;s my mother.</span>）%s' % bl('ア'),
     '6. <span class="en">Who&#39;s your teacher?</span>　—（ア <span class="en">Yes, he is.</span> ／イ <span class="en">Mike is.</span>）%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　<span class="en">Who</span> の文に <span class="en">Yes / No</span> で答えると、答えになりません（1・3・6）。<br>'
         '男の人か女の人かで <span class="en">he</span>／<span class="en">she</span> を選びます（2・5）。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　「だれ」なら <span class="en">Who&#39;s</span>。答えは男の人なら <span class="en">He&#39;s</span>、女の人なら <span class="en">She&#39;s</span>。',
   'body':ol([
     ('<span class="jp-cue">あの女の子はだれですか。</span>　<span class="en">%sthat girl?</span>' % bl("Who's", False),
      '「だれ」なので <b><span class="en">Who&#39;s</span></b>。'),
     ('<span class="jp-cue">彼女はわたしの姉妹です。</span>　<span class="en">%smy sister.</span>' % bl("She's", False),
      '女の子なので <b><span class="en">She&#39;s</span></b>。'),
     ('<span class="jp-cue">あの男の子はだれですか。</span>　<span class="en">Who&#39;s that%s?</span>' % bl('boy'),
      '「男の子」は <b><span class="en">boy</span></b>。'),
     ('<span class="jp-cue">彼はわたしの友だちです。</span>　<span class="en">%smy friend.</span>' % bl("He's", False),
      '男の子なので <b><span class="en">He&#39;s</span></b>。'),
     ('<span class="jp-cue">短くしない形にしよう。</span>　<span class="en">Who&#39;s that girl?</span> →　<span class="en">%s%sthat girl?</span>' % (bl('Who'), bl('is')),
      '<span class="en">Who&#39;s</span> をもどすと <b><span class="en">Who is</span></b>。'),
     ('<span class="jp-cue">あなたの先生はだれですか。</span>　<span class="en">%syour teacher?</span>' % bl("Who's", False),
      '<span class="en">your</span> は「あなたの」。'),
     ('<span class="jp-cue">あなたはなにが好きですか。</span>　<span class="en">%sdo you like?</span>' % bl('What'),
      '「なに」なので <b><span class="en">What</span></b>。<span class="en">Who</span> ではありません。'),
     ('<span class="jp-cue">彼はわたしの先生です。</span>　<span class="en">He%smy teacher.</span>' % bl('is'),
      '<span class="en">he</span> なので <b><span class="en">is</span></b>。'),
     ('<span class="jp-cue">あの女の人はだれですか。</span>　<span class="en">Who&#39;s that%s?</span>' % bl('woman'),
      '「女の人」は <b><span class="en">woman</span></b>。'),
     ('<span class="jp-cue">彼女はわたしの母です。</span>　<span class="en">She&#39;s my%s.</span>' % bl('mother'),
      '「母」は <b><span class="en">mother</span></b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群の<b>大文字で始まることば</b>が先頭。<span class="en">Who&#39;s</span> か <span class="en">What</span> です。',
   'body':ol([
     ('<span class="jp-cue">あの女の子はだれですか。</span>　<span class="paren en">（ that girl / Who&#39;s ）</span>' + line('Who&#39;s that girl?'),
      '2つだけ。<span class="en">Who&#39;s</span> が先頭、終わりは <b>?</b>。'),
     ('<span class="jp-cue">彼女はわたしの姉妹です。</span>　<span class="paren en">（ my sister / She&#39;s ）</span>' + line('She&#39;s my sister.'),
      '<span class="en">my sister</span> でひとかたまり。'),
     ('<span class="jp-cue">あの男の子はだれですか。</span>　<span class="paren en">（ boy / Who&#39;s / that ）</span>' + line('Who&#39;s that boy?'),
      '<span class="en">that boy</span> でひとかたまり。'),
     ('<span class="jp-cue">彼はわたしの友だちです。</span>　<span class="paren en">（ friend / He&#39;s / my ）</span>' + line('He&#39;s my friend.'),
      '男の子なので <span class="en">He&#39;s</span>。'),
     ('<span class="jp-cue">あなたの先生はだれですか。</span>　<span class="paren en">（ teacher / your / Who&#39;s ）</span>' + line('Who&#39;s your teacher?'),
      '<span class="en">your teacher</span> でひとかたまり。'),
     ('<span class="jp-cue">あなたはなにが好きですか。</span>　<span class="paren en">（ like / you / What / do ）</span>' + line('What do you like?'),
      '語群に <span class="en">What</span> がある。3-1 の形です。'),
     ('<span class="jp-cue">彼女はわたしの先生です。</span>　<span class="paren en">（ my / is / teacher / She ）</span>' + line('She is my teacher.'),
      '語群が <span class="en">She</span> と <span class="en">is</span>。短くしない形です。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('あの女の子はだれですか。' + wline('Who&#39;s that girl?'),
      '<span class="en">Who is that girl?</span> でも正解。'),
     ('彼女はわたしの姉妹です。' + wline('She&#39;s my sister.'),
      '<span class="en">She is my sister.</span> でも正解。'),
     ('あの男の子はだれですか。' + wline('Who&#39;s that boy?'),
      '男の子は <span class="en">boy</span>。'),
     ('彼はわたしの友だちです。' + wline('He&#39;s my friend.'),
      '男の人なので <span class="en">He&#39;s</span>。<span class="en">She&#39;s</span> にしないこと。'),
     ('あなたの先生はだれですか。' + wline('Who&#39;s your teacher?'),
      '「あなたの」は <span class="en">your</span>。'),
     ('あなたはなにが好きですか。' + wline('What do you like?'),
      '「なに」なので <span class="en">What</span>。<span class="en">Who</span> とまちがえないこと。'),
   ]),
   'words':'<span class="en">that girl ／ my sister ／ that boy ／ my friend ／ your teacher ／ like</span>'},
  'l4':{'sub':'写真を見せながら、人をしょうかいする会話を書こう',
   'cond':['<span class="en">Who&#39;s ～?</span> の文を <b>2つ以上</b>',
           'それぞれの答えを <span class="en">He&#39;s ～.</span> か <span class="en">She&#39;s ～.</span> で書く',
           'しょうかいのあとに <span class="en">He is ～.</span> などで<b>ようすを1つ</b>足す'],
   'example':['Who&#39;s that girl? — She&#39;s my sister.','Who&#39;s that boy? — He&#39;s my friend.','He is kind.'],
   'note':'これは例です。同じでなくてかまいません。家族・友だち・先生 を写真で見せているつもりで書いてみよう。',
   'check':['Who&#39;s のアポストロフィ','答えに Yes / No を使っていない','男の人は he、女の人は she','終わりは ?'],
   'review':'じぶんの文の答えに○をつけよう。<span class="en">Who</span> の文の答えが <span class="en">Yes</span> や <span class="en">No</span> なら、そこがまちがい。'},
 },
}
