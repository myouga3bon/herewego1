# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, copybox, gmap

S = {
 'id':'u2-3', 'unit':'2 − 3', 'unit_plain':'2-3', 'title':'Can you ～?',
 'pages':'p.42〜43',
 'hero_big':'Can you swim?',
 'hero_jp':'あなたは 泳ぐことが できますか',
 'motto':'<span class="en">Are</span>・<span class="en">Do</span>・<span class="en">Can</span> は<b>聞かれたことばで答える</b>。<span class="en">Can</span> のうしろは 原形（もとの形）。',
 'kana':{'you':'ユー','are':'アー','yes':'イエス','no':'ノウ','can':'キャン',
         "can't":'キャント','swim':'スウィム','piano':'ピアノ','cook':'クック',
         'sing':'スィング','ski':'スキー','dance':'ダンス','speak':'スピーク',
         'jump':'ジャンプ','high':'ハイ','guitar':'ギター','the':'ザ'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>泳ぐことが できますか</b>」のように、相手に<b>できるかどうか</b>をたずねる文です。'),
    ('t','1-3 の <span class="en">I can ～.</span> を、たずねる形に変えるだけです。'),
    ('h', gmap('泳ぐことが <b>できますか</b>', 'Can you swim?',
               '<b>can を前に出す</b>だけ。2-1 の <span class="en">Are you ～?</span> と同じやり方です。')),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Can you swim?</span><span class="t">あなたは 泳ぐことが できますか。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Yes, I can.</span><span class="t">はい、できます。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">No, I can&#39;t.</span><span class="t">いいえ、できません。</span></div>
    </div>'''),
    ('t','答えも <span class="en">can</span> を使います。<b>聞かれたことばで答える</b>というルールは、ずっと同じです。'),
    ('h', copybox()),
  ]),
  ('つくり方は <span class="en">can</span> を前に出すだけ', [
    ('t','<b>① <span class="en">can</span> を文のいちばん前に出す　② 終わりを <b>?</b> にする</b>。これだけです。'),
    ('h','''<div class="eqbox">
      <span class="eq">You can swim.</span>　→　<span class="eq">Can you swim?</span><br>
      <span class="en">Can</span> は文のはじめなので<b>大文字</b>。うしろの <span class="en">swim</span> は<b>原形（もとの形）のまま</b>です。
    </div>'''),
    ('h','''<div class="blocks">
      <div class="blk fill" style="background:#7A4FBF;"><div class="w en">Can</div><div class="r">前に出す</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">you</div><div class="r">だれが</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">swim</div><div class="r">原形（もとの形）</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--ng);"><div class="w">?</div><div class="r">わすれない</div></div>
    </div>'''),
    ('t','<span class="en">Do you can swim?</span> とはしません。<b><span class="en">can</span> 自身が前に出る</b>ので、<span class="en">Do</span> はいらないのです。'),
  ]),
  ('かなり大事｜<span class="en">Are</span>・<span class="en">Do</span>・<span class="en">Can</span> の使い分け', [
    ('t','ここまでに3つのたずね方を習いました。<b>何をたずねたいか</b>で決まります。'),
    ('h','''<table class="kind">
      <thead><tr><th>たずねたいこと</th><th>形</th><th>答え</th></tr></thead>
      <tbody>
        <tr><td class="k">どんな人か</td><td class="e" style="color:var(--key);">Are you ～?</td><td class="e" style="color:var(--key);">Yes, I am. / No, I&#39;m not.</td></tr>
        <tr><td class="k">ふだん するか</td><td class="e" style="color:var(--gv);">Do you ～?</td><td class="e" style="color:var(--gv);">Yes, I do. / No, I don&#39;t.</td></tr>
        <tr><td class="k">できるか</td><td class="e" style="color:#7A4FBF;">Can you ～?</td><td class="e" style="color:#7A4FBF;">Yes, I can. / No, I can&#39;t.</td></tr>
      </tbody>
    </table>'''),
    ('t','<b>先頭のことばと、答えのことばは そろえる</b>。これだけ守れば、3つとも迷いません。'),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：聞かれたことばで 答える</div>
        <p><b class="cb">Are → am</b>　<b class="cp">Do → do</b>　<b style="color:#C8AEF0;">Can → can</b>　
        先頭と答えがちがっていたら、そこがまちがい。<br>
        <span class="xm">✕ Can you swim? — Yes, I do ✕</span>　<span class="xm">✕ Do you can swim ✕</span></p>
      </div>
    </div>'''),
  ]),
  ('<span class="en">Can you ～?</span> は「お願い」にも使う', [
    ('t','<span class="en">Can you ～?</span> は「～できますか」のほかに、<b>「～してくれますか」というお願い</b>にも使えます。'),
    ('h','''<div class="eqbox" style="border-left-color:#7A4FBF;background:rgba(122,79,191,.07);">
      <span class="eq" style="color:#7A4FBF;">Can you help me?</span>　あなたは わたしを 手伝ってくれますか。<br>
      答えるときは <span class="en">Sure.</span>（いいですよ）や <span class="en">OK.</span> も使えます。
    </div>'''),
    ('t','どちらの意味かは、話のながれで決まります。今は<b>形が同じ</b>ということだけおさえておけばだいじょうぶです。'),
  ]),
 ],
 'quiz':[
  ('Do you can swim?','Can you swim?','<span class="en">can</span> が<b>自分で前に出る</b>ので、<span class="en">Do</span> はいりません。','あなたは 泳ぐことが できますか。'),
  ('You can swim?','Can you swim?','たずねる文は <b><span class="en">can</span> を前に出す</b>。順番を変えます。','あなたは 泳ぐことが できますか。'),
  ('Can you swimming?','Can you swim?','<span class="en">can</span> のうしろは <b>原形（もとの形）</b>。<span class="en">ing</span> はつけません。','あなたは 泳ぐことが できますか。'),
  ('Can you swim.','Can you swim?','終わりが<b>ピリオド</b>です。たずねる文の終わりは <b>?</b>。','あなたは 泳ぐことが できますか。'),
  ('Can you swim? — Yes, I do.','Yes, I can.','<span class="en">Can</span> で聞かれたら <b><span class="en">can</span> で答える</b>。','はい、できます。'),
  ('Can you swim? — No, I cant.','No, I can&#39;t.','<b>&#39;（アポストロフィ）</b>を忘れています。','いいえ、できません。'),
 ],
 'summary':[
  '「あなたは～できますか」は <b><span class="en">Can you ～?</span></b>　<span class="en">can</span> を前に出すだけ。',
  '答えは <b><span class="en">Yes, I can.</span> ／ <span class="en">No, I can&#39;t.</span></b>',
  '<b><span class="en">Can</span> の文に <span class="en">Do</span> はいらない。</b>うしろの動詞は 原形（もとの形）。',
  '<b>先頭と答えをそろえる。</b><span class="en">Are</span>→<span class="en">am</span>、<span class="en">Do</span>→<span class="en">do</span>、<span class="en">Can</span>→<span class="en">can</span>。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「あなたは～できますか」は、%sを文の前に出して、終わりを%sにする。' % (bl('can'), bl('?')),
     '<span class="en">Can</span> のうしろの動詞は%sにする。' % bl('原形', False),
     '答えは <span class="en">Yes, I%s.</span> ／ <span class="en">No, I%s.</span>' % (bl('can'), bl("can't")),
     '<span class="en">Can</span> の文に%sは使わない。<span class="en">can</span> が自分で前に出るから。' % bl('Do'),
     '<span class="en">Are</span> で聞かれたら%s、<span class="en">Do</span> で聞かれたら%sで答える。' % (bl('am'), bl('do')),
   ]),
   'words':'語群：<span class="en">can</span> ／ <span class="en">can&#39;t</span> ／ <span class="en">Do</span> ／ <span class="en">am</span> ／ <span class="en">do</span> ／ 原形 ／ ?',
   'exp':'<b>なぜ？</b>　<span class="en">can</span> はもともと「助っ人」のことばなので、<b>自分で前に出る力</b>を持っています。<br>'
         'だから <span class="en">Do</span> という別の合図はいりません。be動詞（<span class="en">are</span>）とおなじ仲間です。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#7A4FBF;">B　<span class="en">Are</span>？ <span class="en">Do</span>？ <span class="en">Can</span>？<em>（　）に入るものを書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。「どんな人か」→<span class="en">Are</span>／「ふだんするか」→<span class="en">Do</span>／「できるか」→<span class="en">Can</span>。',
   'body':grid2([
     '1. <span class="en">%syou swim?</span>（泳げますか）' % bl('Can'),
     '2. <span class="en">%syou a student?</span>' % bl('Are'),
     '3. <span class="en">%syou like soccer?</span>' % bl('Do'),
     '4. <span class="en">%syou play the piano?</span>（ひけますか）' % bl('Can'),
     '5. <span class="en">%syou from Japan?</span>' % bl('Are'),
     '6. <span class="en">%syou have a dog?</span>（飼っていますか）' % bl('Do'),
     '7. <span class="en">%syou cook?</span>（料理できますか）' % bl('Can'),
     '8. <span class="en">%syou happy?</span>' % bl('Are'),
     '9. <span class="en">%syou study math?</span>（勉強しますか）' % bl('Do'),
     '10. <span class="en">%syou twelve?</span>' % bl('Are'),
   ]),
   'exp':'<b>見つけ方</b>　日本語の文の終わりを見よう。<br>'
         '「<b>できますか</b>」→ <span class="en">Can</span>（1・4・7）　「<b>しますか・好きですか</b>」→ <span class="en">Do</span>（3・6・9）<br>'
         '「<b>ですか</b>」で動作のことばがない → <span class="en">Are</span>（2・5・8・10）'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#7A4FBF;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. Can you swim?','○'), ('2. Do you can swim?','✕'),
     ('3. Can you play the piano?','○'), ('4. Can you swimming?','✕'),
     ('5. Yes, I can.','○'), ('6. Can you swim? — Yes, I do.','✕'),
     ('7. No, I can&#39;t.','○'), ('8. You can swim?','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">Can you swim?</span>（<span class="en">Do</span> を消す）　4 → <span class="en">Can you swim?</span>（ing を取る）<br>'
         '6 → <span class="en">Yes, I can.</span>（聞かれたことばで答える）　8 → <span class="en">Can you swim?</span>（<span class="en">can</span> を前に出す）'},
  {'h':'<h3 class="sec sec2">D　答え方　正しいほうを選ぼう</h3>',
   'hint':'先頭のことばと、答えのことばを<b>そろえる</b>だけです。',
   'body':grid2([
     '1. <span class="en">Can you swim?</span>　—（ア <span class="en">Yes, I can.</span> ／イ <span class="en">Yes, I do.</span>）%s' % bl('ア'),
     '2. <span class="en">Do you like soccer?</span>　—（ア <span class="en">Yes, I can.</span> ／イ <span class="en">Yes, I do.</span>）%s' % bl('イ'),
     '3. <span class="en">Are you a student?</span>　—（ア <span class="en">No, I can&#39;t.</span> ／イ <span class="en">No, I&#39;m not.</span>）%s' % bl('イ'),
     '4. <span class="en">Can you cook?</span>　—（ア <span class="en">No, I can&#39;t.</span> ／イ <span class="en">No, I don&#39;t.</span>）%s' % bl('ア'),
     '5. <span class="en">Can you sing well?</span>　—（ア <span class="en">Yes, I am.</span> ／イ <span class="en">Yes, I can.</span>）%s' % bl('イ'),
     '6. <span class="en">Do you have a dog?</span>　—（ア <span class="en">Yes, I do.</span> ／イ <span class="en">Yes, I can.</span>）%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　答えのことばは、先頭のことばのコピーです。<br>'
         '<span class="en">Can</span> → <span class="en">can</span>（1・4・5）　<span class="en">Do</span> → <span class="en">do</span>（2・6）　<span class="en">Are</span> → <span class="en">am</span>（3）'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　日本語の終わりが「できますか」なら <span class="en">Can</span>。答えも <span class="en">can</span> でそろえます。',
   'body':ol([
     ('<span class="jp-cue">あなたは泳ぐことができますか。</span>　<span class="en">%syou swim?</span>' % bl('Can'),
      '「できますか」なので <b><span class="en">Can</span></b>。'),
     ('<span class="jp-cue">はい、できます。</span>　<span class="en">Yes, I%s.</span>' % bl('can'),
      '聞かれたことばで答える。<b><span class="en">can</span></b>。'),
     ('<span class="jp-cue">いいえ、できません。</span>　<span class="en">No, I%s.</span>' % bl("can't"),
      '<b><span class="en">can&#39;t</span></b>。&#39;（アポストロフィ）を忘れずに。'),
     ('<span class="jp-cue">あなたはピアノをひくことができますか。</span>　<span class="en">Can you%sthe piano?</span>' % bl('play'),
      '<span class="en">Can</span> のうしろは<b>原形（もとの形）</b>の <span class="en">play</span>。'),
     ('<span class="jp-cue">あなたはサッカーが好きですか。</span>　<span class="en">%syou like soccer?</span>' % bl('Do'),
      '「好きですか」なので <b><span class="en">Do</span></b>。<span class="en">Can</span> ではありません。'),
     ('<span class="jp-cue">あなたは生徒ですか。</span>　<span class="en">%syou a student?</span>' % bl('Are'),
      '動作のことばがないので <b><span class="en">Are</span></b>。'),
     ('<span class="jp-cue">あなたは料理をすることができますか。</span>　<span class="en">%syou%s?</span>' % (bl('Can'), bl('cook')),
      '（　）が2つ。<b><span class="en">Can</span> → <span class="en">cook</span></b>。'),
     ('<span class="jp-cue">はい、します。</span>（<span class="en">Do you ～?</span> の答え）　<span class="en">Yes, I%s.</span>' % bl('do'),
      '2番とくらべよう。<span class="en">Do</span> なら <b><span class="en">do</span></b>。'),
     ('<span class="jp-cue">あなたは上手に歌うことができますか。</span>　<span class="en">Can you%swell?</span>' % bl('sing'),
      '<span class="en">sings</span> にはしない。<b>原形（もとの形）</b>。'),
     ('<span class="jp-cue">はい、そうです。</span>（<span class="en">Are you ～?</span> の答え）　<span class="en">Yes, I%s.</span>' % bl('am'),
      '3つの答え方がそろいました。先頭とそろえるだけ。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群の<b>大文字で始まることば</b>が先頭。<span class="en">Can</span>・<span class="en">Do</span>・<span class="en">Are</span> のどれかです。',
   'body':ol([
     ('<span class="jp-cue">あなたは泳ぐことができますか。</span>　<span class="paren en">（ swim / you / Can ）</span>' + line('Can you swim?'),
      '<span class="en">Can</span> → <span class="en">you</span> → 動詞 の順。終わりは <b>?</b>。'),
     ('<span class="jp-cue">あなたはピアノをひくことができますか。</span>　<span class="paren en">（ the piano / Can / play / you ）</span>' + line('Can you play the piano?'),
      '<span class="en">the piano</span> でひとかたまり。'),
     ('<span class="jp-cue">はい、できます。</span>　<span class="paren en">（ can / I / Yes, ）</span>' + line('Yes, I can.'),
      '<span class="en">Yes,</span> のコンマはそのまま。'),
     ('<span class="jp-cue">あなたはサッカーをしますか。</span>　<span class="paren en">（ soccer / you / play / Do ）</span>' + line('Do you play soccer?'),
      '語群に <span class="en">Do</span> がある。<b>語群を見れば形が分かる。</b>'),
     ('<span class="jp-cue">いいえ、できません。</span>　<span class="paren en">（ can&#39;t / I / No, ）</span>' + line('No, I can&#39;t.'),
      '<span class="en">No,</span> → <span class="en">I</span> → <span class="en">can&#39;t</span>。'),
     ('<span class="jp-cue">あなたは生徒ですか。</span>　<span class="paren en">（ a / student / you / Are ）</span>' + line('Are you a student?'),
      '語群に <span class="en">Are</span> がある。be動詞の文。'),
     ('<span class="jp-cue">あなたは速く走ることができますか。</span>　<span class="paren en">（ fast / you / run / Can ）</span>' + line('Can you run fast?'),
      '<span class="en">fast</span> はいちばん後ろ。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('あなたは泳ぐことができますか。' + wline('Can you swim?'),
      '3語だけ。<span class="en">Do</span> はいりません。'),
     ('はい、できます。' + wline('Yes, I can.'),
      '先頭の <span class="en">Can</span> とそろえる。'),
     ('あなたはピアノをひくことができますか。' + wline('Can you play the piano?'),
      '楽器には <span class="en">the</span> をつけます。'),
     ('いいえ、できません。' + wline('No, I can&#39;t.'),
      '<span class="en">cannot</span> でも正解。'),
     ('あなたはサッカーが好きですか。' + wline('Do you like soccer?'),
      '「好きですか」なので <span class="en">Do</span>。ここを <span class="en">Can</span> にしないこと。'),
     ('あなたは生徒ですか。' + wline('Are you a student?'),
      '3つの形がそろいました。日本語をよく読んで選ぶ。'),
   ]),
   'words':'<span class="en">swim ／ play the piano ／ like soccer ／ a student ／ Yes ／ No</span>'},
  'l4':{'sub':'友だちに「できること」をたずねる文を書こう',
   'cond':['<span class="en">Can you ～?</span> の文を <b>2つ以上</b>',
           '<span class="en">Do you ～?</span> か <span class="en">Are you ～?</span> の文を <b>1つ以上</b>',
           'それぞれの答えも <b>いっしょに書く</b>'],
   'example':['Can you swim? — Yes, I can.','Can you play the guitar? — No, I can&#39;t.','Do you like music? — Yes, I do.'],
   'note':'これは例です。同じでなくてかまいません。スポーツ・楽器・料理・外国語 から選ぶと書きやすいです。',
   'check':['Can の文に Do を入れていない','Can のうしろは 原形（もとの形）','終わりは ?','答えを先頭のことばとそろえた'],
   'review':'じぶんの文の<b>先頭のことば</b>と<b>答えのことば</b>に○をつけよう。2つがちがっていたら、そこがまちがい。'},
 },
}
