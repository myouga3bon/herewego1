# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'u2-2', 'unit':'2 − 2', 'unit_plain':'2-2', 'title':'Do you ～?',
 'pages':'p.40〜41',
 'hero_big':'Do you like soccer?',
 'hero_jp':'あなたは サッカーが 好きですか',
 'motto':'動作の文をたずねるときは <span class="en">Do</span> を前に。be動詞の文は <span class="en">Are</span> を前に。まざらない。',
 'kana':{'you':'ユー','are':'アー','yes':'イエス','no':'ノウ',
         'study':'スタディ','eat':'イート','every':'エヴリィ','day':'デイ',
         'cook':'クック','sing':'スィング','read':'リード','books':'ブックス',
         'book':'ブック','swim':'スウィム','math':'マス','science':'サイエンス'},
 'blocks':[
  ('きほんの文', [
    ('t','前回は <span class="en">Are you ～?</span>（あなたは～ですか）を習いました。今回は<b>「なにをするか」をたずねる文</b>です。文の前に <span class="en">Do</span> を置きます。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Do you like soccer?</span><span class="t">あなたは サッカーが 好きですか。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Yes, I do.</span><span class="t">はい、好きです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">No, I don&#39;t.</span><span class="t">いいえ、好きではありません。</span></div>
    </div>'''),
    ('t','<span class="en">Do</span> を前に置いただけで、<b>うしろは <span class="en">you like soccer</span> のまま</b>ですね。ことばの順番は入れかえません。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('<span class="en">Do</span> は文のいちばん前に置くだけ', [
    ('t','やることは2つだけ。<b>① <span class="en">Do</span> を先頭に置く　② 終わりを <b>?</b> にする</b>。これだけです。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">You like soccer.</span>　→　<span class="eq" style="color:var(--gv);">Do you like soccer?</span><br>
      <span class="en">Do</span> は文のはじめなので<b>大文字</b>。うしろの <span class="en">like</span> は<b>形を変えません</b>。
    </div>'''),
    ('h','''<div class="blocks">
      <div class="blk fill" style="background:#7A4FBF;"><div class="w en">Do</div><div class="r">たずねるしるし</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">you</div><div class="r">だれが</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">like</div><div class="r">どうする</div></div>
      <div class="plus">＋</div>
      <div class="blk line" style="border-color:var(--gv);color:var(--gv);"><div class="w">なにを</div><div class="r">soccer …</div></div>
    </div>'''),
    ('t','<span class="en">Do</span> は「これからたずねますよ」という<b>合図のことば</b>。日本語には訳されません。'),
  ]),
  ('答え方は <span class="en">Yes, I do.</span> ／ <span class="en">No, I don&#39;t.</span>', [
    ('t','<b>聞かれたことばで答える</b>のがルールです。<span class="en">Do</span> で聞かれたら <span class="en">do</span> で答えます。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-smile"/></svg>
          <span>◯ そうです<small>Do you ～? の答え</small></span></div>
        <div class="in"><div class="ex">Yes, I do.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-run"/></svg>
          <span>✕ ちがいます<small>Do you ～? の答え</small></span></div>
        <div class="in"><div class="ex">No, I don&#39;t.</div></div>
      </div>
    </div>'''),
    ('t','答えに <span class="en">like</span> や <span class="en">soccer</span> をくりかえす必要はありません。<b><span class="en">do</span> か <span class="en">don&#39;t</span> だけ</b>でじゅうぶんです。'),
  ]),
  ('かなり大事｜<span class="en">Do</span> と <span class="en">Are</span> の使い分け', [
    ('t','ここが今回のヤマです。<b>うしろに動作のことばがあるかどうか</b>だけを見ます。'),
    ('h','''<table class="kind">
      <thead><tr><th>たずねたいこと</th><th>使う形</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k">どんな人か</td><td class="k" style="color:var(--key);font-weight:700;">Are you ～?</td><td class="e">Are you a student?</td></tr>
        <tr><td class="k">なにをするか</td><td class="k" style="color:var(--gv);font-weight:700;">Do you ～?</td><td class="e">Do you play soccer?</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：心臓（動詞）は 青かピンクの どちらか1つ</div>
        <p><b class="cb">青＝<span class="en">Are you ～?</span></b>　<b class="cp">ピンク＝<span class="en">Do you ～?</span></b>　
        青とピンクはまざりません。<br>
        <span class="xm">✕ Are you like soccer ✕</span>　<span class="xm">✕ Do you a student ✕</span></p>
      </div>
    </div>'''),
    ('t','見分け方はかんたん。文の中に <span class="en">like・play・have・study</span> などの<b>動作のことばがあれば <span class="en">Do</span></b>、なければ <span class="en">Are</span> です。'),
  ]),
  ('<span class="en">Do</span> のうしろの動詞は形を変えない', [
    ('t','<span class="en">Do you likes ～?</span> とはしません。<b><span class="en">Do</span> のうしろは 原形（もとの形）</b>のままです。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--ng);background:rgba(181,39,63,.06);">
      ○ <span class="eq" style="color:var(--vb);">Do you like soccer?</span>　／　<span class="xm">✕ Do you likes soccer ✕</span><br>
      <span class="en">can</span> のうしろと同じ。<b>助っ人がついた動詞は すっぴん</b>です。
    </div>'''),
  ]),
 ],
 'quiz':[
  ('You like soccer?','Do you like soccer?','たずねる文には <b><span class="en">Do</span></b> が必要。文の前に置きます。','あなたは サッカーが 好きですか。'),
  ('Are you like soccer?','Do you like soccer?','<span class="en">like</span> は動作のことば。<b>動作の文は <span class="en">Do</span></b>。<span class="en">Are</span> は使いません。','あなたは サッカーが 好きですか。'),
  ('Do you a student?','Are you a student?','「どんな人か」なので <b><span class="en">Are</span></b>。動作のことばがないときは <span class="en">Do</span> を使いません。','あなたは 学生 ですか。'),
  ('Do you likes soccer?','Do you like soccer?','<span class="en">Do</span> のうしろは <b>原形（もとの形）</b>。<span class="en">s</span> はつけません。','あなたは サッカーが 好きですか。'),
  ('Do you like soccer.','Do you like soccer?','終わりが<b>ピリオド</b>になっています。たずねる文の終わりは <b>?</b>。','あなたは サッカーが 好きですか。'),
  ('Do you like soccer? — Yes, I am.','Yes, I do.','<span class="en">Do</span> で聞かれたら <b><span class="en">do</span> で答える</b>。<span class="en">am</span> は <span class="en">Are</span> の答えです。','はい、します。'),
 ],
 'summary':[
  '「あなたは～しますか」は <b><span class="en">Do you ～?</span></b>　<span class="en">Do</span> を<b>いちばん前</b>に置くだけ。',
  '答えは <b><span class="en">Yes, I do.</span> ／ <span class="en">No, I don&#39;t.</span></b>',
  '<b>動作のことばがあれば <span class="en">Do</span>、なければ <span class="en">Are</span>。</b>これが見分け方。',
  '<b><span class="en">Do</span> のうしろの動詞は 原形（もとの形）。</b><span class="en">s</span> も <span class="en">ing</span> もつけない。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「あなたは～しますか」は、文の前に%sを置いて、終わりを%sにする。' % (bl('Do'), bl('?')),
     '<span class="en">Do</span> のうしろの動詞は%sにする。<span class="en">s</span> は%s。' % (bl('原形', False), bl('つけない')),
     '答えは <span class="en">Yes, I%s.</span> ／ <span class="en">No, I%s.</span>' % (bl('do'), bl("don't")),
     '「どんな人か」をたずねるときは%s、「なにをするか」をたずねるときは%sを使う。' % (bl('Are'), bl('Do')),
     '1つの文に心臓（動詞）は%sつだけ。だから <span class="en">Are</span> と <span class="en">like</span> はいっしょに使わない。' % bl('1'),
   ]),
   'words':'語群：<span class="en">Do</span> ／ <span class="en">Are</span> ／ <span class="en">do</span> ／ <span class="en">don&#39;t</span> ／ 原形 ／ つけない ／ 1 ／ ?',
   'exp':'<b>なぜ？</b>　<span class="en">Do</span> は「たずねますよ」という合図です。合図が前に立つので、<b>うしろの文はそのまま</b>でよいのです。<br>'
         'be動詞の文には合図がもともとある（<span class="en">are</span> を前に出す）ので、<span class="en">Do</span> はいりません。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--gv);">B　<span class="en">Do</span>？ それとも <span class="en">Are</span>？<em>（　）に <span class="en">Do</span> か <span class="en">Are</span> を書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。文の中に<b>動作のことば</b>があるかだけを見ましょう。',
   'body':grid2([
     '1. <span class="en">%syou like soccer?</span>' % bl('Do'),
     '2. <span class="en">%syou a student?</span>' % bl('Are'),
     '3. <span class="en">%syou play tennis?</span>' % bl('Do'),
     '4. <span class="en">%syou from Japan?</span>' % bl('Are'),
     '5. <span class="en">%syou happy?</span>' % bl('Are'),
     '6. <span class="en">%syou have a dog?</span>' % bl('Do'),
     '7. <span class="en">%syou study math?</span>' % bl('Do'),
     '8. <span class="en">%syou twelve?</span>' % bl('Are'),
     '9. <span class="en">%syou eat natto?</span>' % bl('Do'),
     '10. <span class="en">%syou a soccer fan?</span>' % bl('Are'),
   ]),
   'exp':'<b>見つけ方</b>　<span class="en">you</span> のうしろを見よう。<br>'
         '<b>動作のことばがある</b>（<span class="en">like・play・have・study・eat</span>）→ <span class="en">Do</span>（1・3・6・7・9）<br>'
         '<b>動作のことばがない</b>（生徒・日本出身・うれしい・12歳・サッカーファン）→ <span class="en">Are</span>（2・4・5・8・10）'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--gv);">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. Do you like soccer?','○'), ('2. Are you like soccer?','✕'),
     ('3. Are you a student?','○'), ('4. Do you a student?','✕'),
     ('5. Do you likes soccer?','✕'), ('6. Do you have a dog?','○'),
     ('7. You like soccer?','✕'), ('8. No, I don&#39;t.','○'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">Do you like soccer?</span>（動作の文は <span class="en">Do</span>）<br>'
         '4 → <span class="en">Are you a student?</span>（動作のことばがないので <span class="en">Are</span>）<br>'
         '5 → <span class="en">Do you like soccer?</span>（s を取る）　7 → <span class="en">Do you like soccer?</span>（<span class="en">Do</span> を足す）'},
  {'h':'<h3 class="sec sec2">D　答え方　正しいほうを選ぼう</h3>',
   'hint':'<b>聞かれたことばで答える</b>。<span class="en">Do</span> なら <span class="en">do</span>、<span class="en">Are</span> なら <span class="en">am</span>。',
   'body':grid2([
     '1. <span class="en">Do you like soccer?</span>　—（ア <span class="en">Yes, I do.</span> ／イ <span class="en">Yes, I am.</span>）%s' % bl('ア'),
     '2. <span class="en">Are you a student?</span>　—（ア <span class="en">Yes, I do.</span> ／イ <span class="en">Yes, I am.</span>）%s' % bl('イ'),
     '3. <span class="en">Do you play tennis?</span>　—（ア <span class="en">No, I&#39;m not.</span> ／イ <span class="en">No, I don&#39;t.</span>）%s' % bl('イ'),
     '4. <span class="en">Do you have a dog?</span>　—（ア <span class="en">Yes, I do.</span> ／イ <span class="en">Yes, you do.</span>）%s' % bl('ア'),
     '5. <span class="en">Are you from Japan?</span>　—（ア <span class="en">No, I don&#39;t.</span> ／イ <span class="en">No, I&#39;m not.</span>）%s' % bl('イ'),
     '6. <span class="en">Do you study math?</span>　—（ア <span class="en">Yes, I do.</span> ／イ <span class="en">Yes, I study.</span>）%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　<span class="en">Do</span> で聞かれたら <span class="en">do</span>／<span class="en">don&#39;t</span>、<span class="en">Are</span> で聞かれたら <span class="en">am</span>／<span class="en">&#39;m not</span>。<br>'
         '6のイのように動詞をくりかえす必要はありません。4のイは「あなた」になってしまうのでまちがいです。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　動作のことばがあれば <span class="en">Do</span>、なければ <span class="en">Are</span>。うしろの動詞は<b>原形（もとの形）</b>。',
   'body':ol([
     ('<span class="jp-cue">あなたはサッカーが好きですか。</span>　<span class="en">%syou like soccer?</span>' % bl('Do'),
      '<span class="en">like</span> があるので <b><span class="en">Do</span></b>。'),
     ('<span class="jp-cue">あなたは生徒ですか。</span>　<span class="en">%syou a student?</span>' % bl('Are'),
      '動作のことばがないので <b><span class="en">Are</span></b>。'),
     ('<span class="jp-cue">はい、好きです。</span>　<span class="en">Yes, I%s.</span>' % bl('do'),
      '<span class="en">Do</span> で聞かれたから <b><span class="en">do</span></b> で答える。'),
     ('<span class="jp-cue">いいえ、好きではありません。</span>　<span class="en">No, I%s.</span>' % bl("don't"),
      '<b><span class="en">don&#39;t</span></b> ひとつで足ります。'),
     ('<span class="jp-cue">あなたはテニスをしますか。</span>　<span class="en">%syou%stennis?</span>' % (bl('Do'), bl('play')),
      '（　）が2つ。<b><span class="en">Do</span> → <span class="en">play</span></b> の順。'),
     ('<span class="jp-cue">あなたは犬を飼っていますか。</span>　<span class="en">Do you%sa dog?</span>' % bl('have'),
      '「飼っている」は <b><span class="en">have</span></b>。<span class="en">has</span> にはしない。'),
     ('<span class="jp-cue">あなたは日本出身ですか。</span>　<span class="en">%syou%sJapan?</span>' % (bl('Are'), bl('from')),
      'be動詞の文。<b><span class="en">Are</span></b> と <b><span class="en">from</span></b>。'),
     ('<span class="jp-cue">あなたは数学を勉強しますか。</span>　<span class="en">Do you%smath?</span>' % bl('study'),
      '「勉強する」は <b><span class="en">study</span></b>。'),
     ('<span class="jp-cue">はい、そうです。</span>（<span class="en">Are you ～?</span> の答え）　<span class="en">Yes, I%s.</span>' % bl('am'),
      '<span class="en">Are</span> で聞かれたら <b><span class="en">am</span></b>。3番とくらべよう。'),
     ('<span class="jp-cue">あなたは納豆を食べますか。</span>　<span class="en">%syou%snatto?</span>' % (bl('Do'), bl('eat')),
      '5番と同じ形。<b><span class="en">Do</span> → 動詞</b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群の中の<b>大文字で始まることば</b>が先頭になります。<span class="en">Do</span> か <span class="en">Are</span> のどちらかです。',
   'body':ol([
     ('<span class="jp-cue">あなたはサッカーが好きですか。</span>　<span class="paren en">（ soccer / you / Do / like ）</span>' + line('Do you like soccer?'),
      '<span class="en">Do</span> → <span class="en">you</span> → 動詞 → なにを の順。終わりは <b>?</b>。'),
     ('<span class="jp-cue">あなたは生徒ですか。</span>　<span class="paren en">（ a / you / student / Are ）</span>' + line('Are you a student?'),
      '語群に <span class="en">Are</span> がある。<b>語群を見れば形が分かる。</b>'),
     ('<span class="jp-cue">あなたはテニスをしますか。</span>　<span class="paren en">（ tennis / Do / play / you ）</span>' + line('Do you play tennis?'),
      '1番と同じ形。'),
     ('<span class="jp-cue">はい、します。</span>　<span class="paren en">（ do / I / Yes, ）</span>' + line('Yes, I do.'),
      '<span class="en">Yes,</span> のコンマはそのまま使います。'),
     ('<span class="jp-cue">あなたは犬を飼っていますか。</span>　<span class="paren en">（ a dog / you / have / Do ）</span>' + line('Do you have a dog?'),
      '<span class="en">a dog</span> でひとかたまり。'),
     ('<span class="jp-cue">いいえ、しません。</span>　<span class="paren en">（ don&#39;t / I / No, ）</span>' + line('No, I don&#39;t.'),
      '<span class="en">No,</span> → <span class="en">I</span> → <span class="en">don&#39;t</span> の順。'),
     ('<span class="jp-cue">あなたは音楽が好きです。</span>　<span class="paren en">（ music / like / You ）</span>' + line('You like music.'),
      '語群に <span class="en">Do</span> がない。だから<b>たずねる文ではありません</b>。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('あなたはサッカーが好きですか。' + wline('Do you like soccer?'),
      '<span class="en">Do</span> を前に、終わりは <b>?</b>。'),
     ('はい、好きです。' + wline('Yes, I do.'),
      '<span class="en">Yes, I like soccer.</span> でも通じますが、ここは <span class="en">do</span> で答えます。'),
     ('あなたは犬を飼っていますか。' + wline('Do you have a dog?'),
      '「1ぴき」なので <span class="en">a</span> が必要。'),
     ('いいえ、飼っていません。' + wline('No, I don&#39;t.'),
      '<span class="en">don&#39;t</span> の &#39;（アポストロフィ）を忘れない。'),
     ('あなたは生徒ですか。' + wline('Are you a student?'),
      '動作のことばがないので <b><span class="en">Are</span></b>。<span class="en">Do</span> ではありません。'),
     ('あなたは数学を勉強しますか。' + wline('Do you study math?'),
      '<span class="en">study</span> は原形（もとの形）のまま。'),
   ]),
   'words':'<span class="en">like soccer ／ have a dog ／ a student ／ study math ／ Yes ／ No</span>'},
  'l4':{'sub':'友だちにインタビューする文を書こう',
   'cond':['<span class="en">Do you ～?</span> の文を <b>2つ以上</b>',
           '<span class="en">Are you ～?</span> の文を <b>1つ以上</b>',
           'それぞれの答えも <b>いっしょに書く</b>'],
   'example':['Do you like music? — Yes, I do.','Do you play tennis? — No, I don&#39;t.','Are you a soccer fan? — Yes, I am.'],
   'note':'これは例です。同じでなくてかまいません。「すきなもの・やっていること・どんな人か」の3つを聞いてみよう。',
   'check':['動作の文は Do、be動詞の文は Are','Do のうしろは 原形（もとの形）','終わりは ?','答えは do か am でそろえる'],
   'review':'じぶんの文の先頭に○をつけよう。<span class="en">Do</span> の文に <span class="en">a student</span> が来ていたら、そこがまちがい。'},
 },
}
