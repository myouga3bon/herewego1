# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox, gmap

S = {
 'id':'u7-2', 'unit':'7 − 2', 'unit_plain':'7-2', 'title':'過去形の疑問文・否定文',
 'pages':'p.104〜105',
 'hero_big':'Did you play soccer? ／ I didn&#39;t play.',
 'hero_jp':'あなたは サッカーを しましたか ／ わたしは しませんでした',
 'motto':'<span class="en">Did</span>・<span class="en">didn&#39;t</span> のうしろは <b>かならず 原形（もとの形）</b>。<span class="en">ed</span> も形の変化も もどす。',
 'kana':{'did':'ディッド',"didn't":'ディドゥント','play':'プレイ','go':'ゴウ',
         'see':'スィー','eat':'イート','have':'ハヴ','study':'スタディ',
         'watch':'ウォッチ','visit':'ヴィズィット','cook':'クック','get':'ゲット',
         'yesterday':'イエスタデイ','last':'ラスト','week':'ウィーク',
         'yes':'イエス','no':'ノウ','park':'パーク','lunch':'ランチ'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>サッカーを しましたか</b>」「<b>サッカーを しませんでした</b>」のように、<b>過去の文を たずねる・打ち消す</b>やり方です。'),
    ('t','使うのは <span class="en">Did</span> と <span class="en">didn&#39;t</span> の2つだけ。主語がだれでも同じです。'),
    ('h', gitem('❶', '「～しましたか」とたずねる', '過去の疑問文',
                'サッカーを しましたか', 'Did you play soccer?',
                [('Did you play soccer?','あなたは サッカーを しましたか。'),
                 ('— Yes, I did. ／ No, I didn&#39;t.','— はい、しました。／ いいえ、しませんでした。')],
                '前に <b>Did</b> を置きます。そのかわり、動詞は <b>played → play</b> と原形（もとの形）にもどします。')),
    ('h', gitem('❷', '「～しませんでした」と打ち消す', '過去の否定文',
                'サッカーを しませんでした', 'I didn&#39;t play soccer.',
                [('I didn&#39;t play soccer.','わたしは サッカーを しませんでした。'),
                 ('He didn&#39;t go to the park.','彼は 公園へ 行きませんでした。')],
                '動詞の前に <b>didn&#39;t</b> を置きます。ここでも動詞は <b>原形（もとの形）</b>にもどします。', b2=True)),
    ('t','<span class="en">Did</span> や <span class="en">didn&#39;t</span> が<b>過去を引きうけている</b>ので、動詞はもどすのです。6-2 の <span class="en">Does</span> と同じしくみです。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜<span class="en">ed</span> は <span class="en">Did</span> に引っこす', [
    ('t','ここが今回のヤマです。<b>「過去」のしるしは1つの文に1回だけ</b>。先頭の <span class="en">Did</span> がそれを持つので、動詞は 原形（もとの形）にもどります。'),
    ('h','''<div class="eqbox">
      <span class="eq">I play<b style="color:var(--ng);">ed</b> soccer.</span>　→　<span class="eq">Di<b style="color:var(--ng);">d</b> you play soccer?</span><br>
      <span class="eq">I play<b style="color:var(--ng);">ed</b> soccer.</span>　→　<span class="eq">I di<b style="color:var(--ng);">d</b>n&#39;t play soccer.</span>
    </div>'''),
    ('h','''<div class="blocks">
      <div class="blk fill" style="background:#7A4FBF;"><div class="w en">Did</div><div class="r">過去のしるし</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">you</div><div class="r">だれが</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">play</div><div class="r">原形（もとの形）</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--ng);"><div class="w">?</div><div class="r">わすれない</div></div>
    </div>'''),
    ('t','<b>形ごと変わる動詞も もどします。</b><span class="en">I went ～.</span> → <span class="en">Did you go ～?</span>　<span class="en">I ate ～.</span> → <span class="en">Did you eat ～?</span>'),
    ('t','<span class="en">Did you went ～?</span> は、よくあるまちがいの代表です。<b><span class="en">Did</span> を見たら、動詞を 原形（もとの形）に</b>と反射で考えましょう。'),
  ]),
  ('主語がだれでも <span class="en">Did</span>・<span class="en">didn&#39;t</span>', [
    ('t','Unit 6 では主語で <span class="en">Do</span>／<span class="en">Does</span> を使い分けました。<b>過去形ではその使い分けがありません</b>。これはラクなところです。'),
    ('h','''<table class="kind">
      <thead><tr><th>主語</th><th>今のこと</th><th>きのうのこと</th></tr></thead>
      <tbody>
        <tr><td class="k"><span class="en">I / you</span></td><td class="e">Do you play ～?</td><td class="e" style="color:#7A4FBF;">Did you play ～?</td></tr>
        <tr><td class="k"><span class="en">he / she</span></td><td class="e">Does he play ～?</td><td class="e" style="color:#7A4FBF;">Did he play ～?</td></tr>
      </tbody>
    </table>'''),
    ('t','右の列は<b>ぜんぶ <span class="en">Did</span></b>。打ち消しも同じで、<span class="en">I didn&#39;t</span>／<span class="en">He didn&#39;t</span> と、主語を気にせず使えます。'),
  ]),
  ('答え方は <span class="en">Yes, I did.</span> ／ <span class="en">No, I didn&#39;t.</span>', [
    ('t','これまでと同じ、<b>聞かれたことばで答える</b>ルールです。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-smile"/></svg>
          <span>◯ しました<small>Did ～? の答え</small></span></div>
        <div class="in"><div class="ex">Yes, I did.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-run"/></svg>
          <span>✕ しませんでした<small>Did ～? の答え</small></span></div>
        <div class="in"><div class="ex">No, I didn&#39;t.</div></div>
      </div>
    </div>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：<span class="en">Did</span> を見たら 動詞は すっぴん</div>
        <p><b class="cb"><span class="en">Did</span> → <span class="en">did</span></b>　<b class="cp">うしろは 原形（もとの形）</b>　
        <span class="en">ed</span> も形の変化も、ぜんぶ もどします。<br>
        <span class="xm">✕ Did you played soccer ✕</span>　<span class="xm">✕ Did you went to the park ✕</span></p>
      </div>
    </div>'''),
  ]),
  ('<span class="en">What did you ～?</span> も同じ', [
    ('t','3-1 の <span class="en">What</span> と組み合わせられます。<b><span class="en">What</span> を前に置くだけ</b>で、うしろは変わりません。'),
    ('h','''<div class="eqbox" style="border-left-color:#D98400;background:rgba(217,132,0,.07);">
      <span class="eq" style="color:#D98400;">What did you do yesterday?</span>（きのう なにを しましたか）<br>
      — <span class="eq" style="color:#D98400;">I played soccer.</span>　答えはふつうの文なので、<b><span class="en">ed</span> がもどってきます</b>。
    </div>'''),
    ('t','<span class="en">What did you do ～?</span> の <span class="en">do</span> は「する」という動詞。<b><span class="en">Did</span> のうしろなので 原形（もとの形）</b>です。'),
  ]),
 ],
 'quiz':[
  ('Did you played soccer?','Did you play soccer?','<span class="en">Did</span> が過去のしるしを持つので、動詞は <b>原形（もとの形）</b>。','あなたは サッカーを しましたか。'),
  ('Did you went to the park?','Did you go to the park?','形ごと変わる動詞も <b>原形（もとの形）にもどします</b>。<span class="en">went</span> → <span class="en">go</span>。','あなたは 公園へ 行きましたか。'),
  ('Do you play soccer yesterday?','Did you play soccer yesterday?','<span class="en">yesterday</span> があるので <b><span class="en">Did</span></b>。','あなたは きのう サッカーを しましたか。'),
  ('Did you play soccer? — Yes, I do.','Yes, I did.','<span class="en">Did</span> で聞かれたら <b><span class="en">did</span></b> で答える。','はい、しました。'),
  ('I didn&#39;t played soccer.','I didn&#39;t play soccer.','<span class="en">didn&#39;t</span> のうしろも <b>原形（もとの形）</b>。','わたしは サッカーを しませんでした。'),
  ('I didnt play soccer.','I didn&#39;t play soccer.','<b>&#39;（アポストロフィ）</b>を忘れています。','わたしは サッカーを しませんでした。'),
 ],
 'summary':[
  '過去のたずねる文は <b><span class="en">Did ～?</span></b>、打ち消しは <b><span class="en">didn&#39;t</span></b>。',
  '<b>どちらもうしろは 原形（もとの形）。</b><span class="en">ed</span> も <span class="en">went・ate</span> も もどす。',
  '<b>主語がだれでも同じ。</b><span class="en">Do / Does</span> のような使い分けはない。',
  '答えは <b><span class="en">Yes, I did.</span> ／ <span class="en">No, I didn&#39;t.</span></b>',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '過去のたずねる文は%sを文の前に置く。' % bl('Did'),
     '過去の打ち消しの文は%sを動詞の前に置く。' % bl("didn't"),
     '<span class="en">Did</span> や <span class="en">didn&#39;t</span> のうしろの動詞は%sにする。' % bl('原形', False),
     '<span class="en">went</span> のように形ごと変わる動詞も%sにもどす。' % bl('原形', False),
     '答えは <span class="en">Yes, I%s.</span> ／ <span class="en">No, I%s.</span>' % (bl('did'), bl("didn't")),
   ]),
   'words':'語群：<span class="en">Did</span> ／ <span class="en">did</span> ／ <span class="en">didn&#39;t</span> ／ 原形',
   'exp':'<b>なぜ？</b>　<span class="en">Did</span> の <span class="en">d</span> が「過去」のしるしです。<b>しるしは1つの文に1回あればじゅうぶん</b>。<br>'
         'だから動詞のほうは 原形（もとの形）にもどります。6-2 の <span class="en">Does</span> とまったく同じ考え方です。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#7A4FBF;">B　<span class="en">Did</span> のうしろの形<em>（　）に正しい形を書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<span class="en">Did</span>・<span class="en">didn&#39;t</span> のうしろは、ぜんぶ<b>原形（もとの形）</b>です。',
   'body':grid2([
     '1. <span class="en">Did you%ssoccer?</span>（played）' % bl('play'),
     '2. <span class="en">Did you%sto the park?</span>（went）' % bl('go'),
     '3. <span class="en">I didn&#39;t%sTV.</span>（watched）' % bl('watch'),
     '4. <span class="en">Did he%snatto?</span>（ate）' % bl('eat'),
     '5. <span class="en">I didn&#39;t%smath.</span>（studied）' % bl('study'),
     '6. <span class="en">Did she%sa dog?</span>（had）' % bl('have'),
     '7. <span class="en">I didn&#39;t%slunch.</span>（cooked）' % bl('cook'),
     '8. <span class="en">Did you%sa dog?</span>（saw）' % bl('see'),
     '9. <span class="en">He didn&#39;t%sKyoto.</span>（visited）' % bl('visit'),
     '10. <span class="en">Did you%syesterday?</span>（did）' % bl('do'),
   ]),
   'exp':'<b>見つけ方</b>　考えることは1つだけ。<b>（　）の前に <span class="en">Did</span> か <span class="en">didn&#39;t</span> があるか</b>。<br>'
         'あれば、かっこの中の形を<b>原形（もとの形）にもどす</b>だけです。<span class="en">went→go</span>、<span class="en">ate→eat</span>、<span class="en">had→have</span>、<span class="en">saw→see</span>。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#7A4FBF;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. Did you play soccer?','○'), ('2. Did you played soccer?','✕'),
     ('3. I didn&#39;t go to the park.','○'), ('4. I didn&#39;t went to the park.','✕'),
     ('5. Yes, I did.','○'), ('6. Yes, I do.','✕'),
     ('7. Did he play soccer?','○'), ('8. Did he plays soccer?','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">Did you play soccer?</span>（ed を取る）　4 → <span class="en">I didn&#39;t go to the park.</span>（<span class="en">go</span> にもどす）<br>'
         '6 → <span class="en">Yes, I did.</span>（<span class="en">did</span> で答える）　8 → <span class="en">Did he play soccer?</span>（s も取る）<br>'
         '8のように、<span class="en">Did</span> のうしろは <b>s も ed もつきません</b>。'},
  {'h':'<h3 class="sec sec2">D　どれを使う？　記号で答えよう</h3>',
   'hint':'<span class="chip">ア</span> <span class="en">Do</span>　<span class="chip" style="background:var(--gv);">イ</span> <span class="en">Does</span>　<span class="chip" style="background:#7A4FBF;">ウ</span> <span class="en">Did</span>',
   'body':grid2([
     '1. <span class="en">（　）you play soccer yesterday?</span>%s' % bl('ウ'),
     '2. <span class="en">（　）you play soccer every day?</span>%s' % bl('ア'),
     '3. <span class="en">（　）he play soccer every day?</span>%s' % bl('イ'),
     '4. <span class="en">（　）he go to the park last week?</span>%s' % bl('ウ'),
     '5. <span class="en">（　）she like music?</span>（今のこと）%s' % bl('イ'),
     '6. <span class="en">（　）you eat natto yesterday?</span>%s' % bl('ウ'),
   ]),
   'exp':'<b>ここが大事</b>　まず<b>いつのことか</b>を見ます。<span class="en">yesterday・last week</span> があれば <span class="en">Did</span>（1・4・6）。<br>'
         '今のことなら、主語で <span class="en">Do</span>（2）と <span class="en">Does</span>（3・5）を使い分けます。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　<span class="en">Did</span>・<span class="en">didn&#39;t</span> を見たら、動詞はかならず<b>原形（もとの形）</b>。',
   'body':ol([
     ('<span class="jp-cue">あなたはサッカーをしましたか。</span>　<span class="en">%syou play soccer?</span>' % bl('Did'),
      '過去のたずねる文は <b><span class="en">Did</span></b>。'),
     ('<span class="jp-cue">はい、しました。</span>　<span class="en">Yes, I%s.</span>' % bl('did'),
      '聞かれたことばで答える。<b><span class="en">did</span></b>。'),
     ('<span class="jp-cue">いいえ、しませんでした。</span>　<span class="en">No, I%s.</span>' % bl("didn't"),
      '<b><span class="en">didn&#39;t</span></b>。&#39;（アポストロフィ）を忘れずに。'),
     ('<span class="jp-cue">わたしはサッカーをしませんでした。</span>　<span class="en">I didn&#39;t%ssoccer.</span>' % bl('play'),
      '<span class="en">didn&#39;t</span> のうしろは <b>原形（もとの形）</b>。'),
     ('<span class="jp-cue">あなたは公園へ行きましたか。</span>　<span class="en">Did you%sto the park?</span>' % bl('go'),
      '<span class="en">went</span> ではなく <b><span class="en">go</span></b> にもどす。'),
     ('<span class="jp-cue">彼はきのうテレビを見ましたか。</span>　<span class="en">%she%sTV yesterday?</span>' % (bl('Did'), bl('watch')),
      '（　）が2つ。主語が <span class="en">he</span> でも <b><span class="en">Did</span></b>。'),
     ('<span class="jp-cue">わたしは納豆を食べませんでした。</span>　<span class="en">I didn&#39;t%snatto.</span>' % bl('eat'),
      '<span class="en">ate</span> ではなく <b><span class="en">eat</span></b>。'),
     ('<span class="jp-cue">あなたはきのうなにをしましたか。</span>　<span class="en">What%syou do yesterday?</span>' % bl('did'),
      '<span class="en">What</span> のうしろは <b><span class="en">did you</span></b>。'),
     ('<span class="jp-cue">わたしはサッカーをしました。</span>　<span class="en">I%ssoccer.</span>' % bl('played', False),
      '8番の答え。<b>ふつうの文にもどると <span class="en">ed</span> が返ってくる</b>。'),
     ('<span class="jp-cue">彼女は数学を勉強しませんでした。</span>　<span class="en">She%s%smath.</span>' % (bl("didn't"), bl('study')),
      '主語が <span class="en">she</span> でも <b><span class="en">didn&#39;t</span></b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群に <span class="en">Did</span> か <span class="en">didn&#39;t</span> があれば、動詞は<b>原形（もとの形）</b>のはずです。',
   'body':ol([
     ('<span class="jp-cue">あなたはサッカーをしましたか。</span>　<span class="paren en">（ soccer / you / Did / play ）</span>' + line('Did you play soccer?'),
      '<span class="en">Did</span> → <span class="en">you</span> → 動詞 → なにを の順。終わりは <b>?</b>。'),
     ('<span class="jp-cue">わたしはサッカーをしませんでした。</span>　<span class="paren en">（ soccer / didn&#39;t / play / I ）</span>' + line('I didn&#39;t play soccer.'),
      '<span class="en">I</span> → <span class="en">didn&#39;t</span> → 動詞 の順。'),
     ('<span class="jp-cue">はい、しました。</span>　<span class="paren en">（ did / I / Yes, ）</span>' + line('Yes, I did.'),
      '<span class="en">Yes,</span> のコンマはそのまま。'),
     ('<span class="jp-cue">あなたは公園へ行きましたか。</span>　<span class="paren en">（ to the park / go / Did / you ）</span>' + line('Did you go to the park?'),
      '語群が <span class="en">go</span>（原形（もとの形））。<b>語群を見れば形が分かる。</b>'),
     ('<span class="jp-cue">彼はきのうテレビを見ましたか。</span>　<span class="paren en">（ TV / he / yesterday / Did / watch ）</span>' + line('Did he watch TV yesterday?'),
      '<span class="en">yesterday</span> はいちばん後ろ。'),
     ('<span class="jp-cue">わたしは納豆を食べませんでした。</span>　<span class="paren en">（ natto / eat / I / didn&#39;t ）</span>' + line('I didn&#39;t eat natto.'),
      '語群が <span class="en">eat</span>。<span class="en">ate</span> ではありません。'),
     ('<span class="jp-cue">わたしはきのうサッカーをしました。</span>　<span class="paren en">（ soccer / played / yesterday / I ）</span>' + line('I played soccer yesterday.'),
      '語群が <span class="en">played</span>。<b>ふつうの文</b>です。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('あなたはサッカーをしましたか。' + wline('Did you play soccer?'),
      '<span class="en">played</span> にしないこと。'),
     ('はい、しました。' + wline('Yes, I did.'),
      '<span class="en">Yes, I do.</span> ではありません。'),
     ('わたしはサッカーをしませんでした。' + wline('I didn&#39;t play soccer.'),
      '<span class="en">did not</span> と書いても正解。'),
     ('あなたは公園へ行きましたか。' + wline('Did you go to the park?'),
      '<span class="en">went</span> を <span class="en">go</span> にもどす。'),
     ('わたしは納豆を食べませんでした。' + wline('I didn&#39;t eat natto.'),
      '<span class="en">ate</span> を <span class="en">eat</span> にもどす。'),
     ('彼はきのうテレビを見ましたか。' + wline('Did he watch TV yesterday?'),
      '主語が <span class="en">he</span> でも <span class="en">Did</span>。'),
   ]),
   'words':'<span class="en">play soccer ／ go to the park ／ eat natto ／ watch TV ／ Yes ／ No</span>'},
  'l4':{'sub':'友だちに「きのうしたこと」をたずねよう',
   'cond':['<span class="en">Did you ～?</span> の文を <b>2つ以上</b>',
           'それぞれの答えを <span class="en">Yes, I did.</span> ／ <span class="en">No, I didn&#39;t.</span> で書く',
           '<span class="en">I didn&#39;t ～.</span> の文も <b>1つ</b> 入れる'],
   'example':['Did you play soccer yesterday? — Yes, I did.','Did you watch TV? — No, I didn&#39;t.','I didn&#39;t study math yesterday.'],
   'note':'これは例です。同じでなくてかまいません。きのうの部活・勉強・テレビ・ごはん について聞いてみよう。',
   'check':['Did のうしろは 原形（もとの形）','didn&#39;t のうしろも 原形（もとの形）','went・ate なども もどした','答えは did でそろえた'],
   'review':'じぶんの文の <span class="en">Did</span>・<span class="en">didn&#39;t</span> のうしろに○をつけよう。<span class="en">ed</span> がついていたら、そこがまちがい。'},
 },
}
