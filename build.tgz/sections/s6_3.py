# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'u6-3', 'unit':'6 − 3', 'unit_plain':'6-3', 'title':"三単現の否定文（doesn't）",
 'pages':'p.90〜91',
 'hero_big':'He doesn&#39;t play soccer.',
 'hero_jp':'彼は サッカーを しません',
 'motto':'主語が <span class="en">he・she</span>・名前なら <span class="en">doesn&#39;t</span>。<b>そのあとの動詞は 原形（もとの形）</b>。',
 'kana':{"doesn't":'ダズント',"don't":'ドウント','does':'ダズ','he':'ヒー','she':'シー',
         'play':'プレイ','like':'ライク','have':'ハヴ','study':'スタディ',
         'watch':'ウォッチ','go':'ゴウ','live':'リヴ','cook':'クック','eat':'イート',
         'mike':'マイク','emma':'エマ','math':'マス','school':'スクール',
         'natto':'ナットウ','kind':'カインド'},
 'blocks':[
  ('きほんの文', [
    ('t','1-2 で <span class="en">I don&#39;t ～.</span> を習いました。主語が <span class="en">he</span>・<span class="en">she</span>・人の名前になると、<b><span class="en">don&#39;t</span> が <span class="en">doesn&#39;t</span> に変わります</b>。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">He doesn&#39;t play soccer.</span><span class="t">彼は サッカーを しません。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">She doesn&#39;t like natto.</span><span class="t">彼女は 納豆が 好きではありません。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I don&#39;t play soccer.</span><span class="t">わたしは サッカーを しません。</span></div>
    </div>'''),
    ('t','3つめだけ <span class="en">don&#39;t</span> です。<b>主語が <span class="en">I</span> だから</b>ですね。使い分けは 6-1・6-2 とまったく同じです。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜<span class="en">s</span> は <span class="en">doesn&#39;t</span> に引っこす', [
    ('t','ここが今回のヤマです。6-2 とまったく同じしくみ。<b><span class="en">s</span> は1つの文に1回だけ</b>なので、動詞は 原形（もとの形）にもどります。'),
    ('h','''<div class="eqbox">
      <span class="eq">He play<b style="color:var(--ng);">s</b> soccer.</span>　→　<span class="eq">He doe<b style="color:var(--ng);">s</b>n&#39;t play soccer.</span><br>
      <b><span class="en">s</span> が <span class="en">doesn&#39;t</span> に引っこして、動詞は 原形（もとの形）にもどる</b>。
    </div>'''),
    ('h','''<div class="blocks">
      <div class="blk fill" style="background:var(--gv);"><div class="w en">He</div><div class="r">だれが</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--ng);"><div class="w en">doesn&#39;t</div><div class="r">～しない</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">play</div><div class="r">原形（もとの形）</div></div>
      <div class="plus">＋</div>
      <div class="blk line" style="border-color:var(--gv);color:var(--gv);"><div class="w">なにを</div><div class="r">soccer …</div></div>
    </div>'''),
    ('t','<span class="en">He doesn&#39;t plays ～.</span> は <span class="en">s</span> が2つになってしまうのでまちがいです。<b>どちらか1つ</b>と覚えましょう。'),
  ]),
  ('<span class="en">don&#39;t</span> と <span class="en">doesn&#39;t</span> の使い分け', [
    ('t','ここまでの3つ（<span class="en">s</span>・<span class="en">Does</span>・<span class="en">doesn&#39;t</span>）は、<b>ぜんぶ主語で決まります</b>。表で一度に整理しましょう。'),
    ('h','''<table class="kind">
      <thead><tr><th>主語</th><th>ふつうの文</th><th>打ち消しの文</th><th>たずねる文</th></tr></thead>
      <tbody>
        <tr><td class="k"><span class="en">I / you</span></td><td class="e">I play ～.</td><td class="e" style="color:var(--ng);">I <u>don&#39;t</u> play ～.</td><td class="e">Do you play ～?</td></tr>
        <tr><td class="k"><span class="en">he / she</span>・名前</td><td class="e">He play<u>s</u> ～.</td><td class="e" style="color:var(--ng);">He <u>doesn&#39;t</u> play ～.</td><td class="e">Does he play ～?</td></tr>
      </tbody>
    </table>'''),
    ('t','<b>打ち消しとたずねる文では、動詞は どちらも 原形（もとの形）</b>。<span class="en">s</span> がつくのは「ふつうの文」のときだけです。'),
  ]),
  ('be動詞の文には <span class="en">doesn&#39;t</span> を使わない', [
    ('t','4-3 で習ったとおり、be動詞の文の打ち消しは <b>be動詞のうしろに <span class="en">not</span></b> です。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ isn&#39;t<small>「彼は <u>どんな人か</u>」</small></span></div>
        <div class="in"><div class="ex">He isn&#39;t a student.<br>He isn&#39;t kind.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-run"/></svg>
          <span>◯ doesn&#39;t<small>「彼は <u>なにをするか</u>」</small></span></div>
        <div class="in"><div class="ex">He doesn&#39;t play soccer.<br>He doesn&#39;t like natto.</div></div>
      </div>
    </div>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：青は <span class="en">not</span>、ピンクは <span class="en">doesn&#39;t</span></div>
        <p><b class="cb">青＝<span class="en">isn&#39;t</span></b>　<b class="cp">ピンク＝<span class="en">doesn&#39;t</span></b>　
        打ち消し方も、青とピンクでちがいます。<br>
        <span class="xm">✕ He isn&#39;t play soccer ✕</span>　<span class="xm">✕ He doesn&#39;t a student ✕</span></p>
      </div>
    </div>'''),
  ]),
  ('<span class="en">have</span> は <span class="en">have</span> にもどる', [
    ('t','6-1 で <span class="en">have → has</span> と習いました。でも <span class="en">doesn&#39;t</span> のうしろでは、<b>原形（もとの形）の <span class="en">have</span> にもどります</b>。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--ng);background:rgba(181,39,63,.06);">
      ○ <span class="eq" style="color:var(--vb);">He doesn&#39;t have a dog.</span>　／　<span class="xm">✕ He doesn&#39;t has a dog ✕</span><br>
      <span class="en">has</span> は「<span class="en">s</span> がついた形」。<b><span class="en">doesn&#39;t</span> が <span class="en">s</span> を持っている</b>ので、こちらは 原形（もとの形）です。
    </div>'''),
    ('t','<span class="en">studies → study</span>、<span class="en">goes → go</span>、<span class="en">watches → watch</span> も同じ。<b>ぜんぶ 原形（もとの形）にもどす</b>と考えれば迷いません。'),
  ]),
 ],
 'quiz':[
  ('He don&#39;t play soccer.','He doesn&#39;t play soccer.','主語が <span class="en">he</span> なので <b><span class="en">doesn&#39;t</span></b>。','彼は サッカーを しません。'),
  ('He doesn&#39;t plays soccer.','He doesn&#39;t play soccer.','<span class="en">s</span> が2つになっています。動詞は <b>原形（もとの形）</b>。','彼は サッカーを しません。'),
  ('He doesnt play soccer.','He doesn&#39;t play soccer.','<b>&#39;（アポストロフィ）</b>を忘れています。','彼は サッカーを しません。'),
  ('He isn&#39;t play soccer.','He doesn&#39;t play soccer.','動作のことばがあるので <b><span class="en">doesn&#39;t</span></b>。<span class="en">isn&#39;t</span> は be動詞用です。','彼は サッカーを しません。'),
  ('I doesn&#39;t like natto.','I don&#39;t like natto.','主語が <span class="en">I</span> なので <b><span class="en">don&#39;t</span></b>。','わたしは 納豆が 好きでは ありません。'),
  ('He doesn&#39;t has a dog.','He doesn&#39;t have a dog.','<span class="en">doesn&#39;t</span> のうしろは <b>原形（もとの形）</b>。<span class="en">has</span> にしません。','彼は 犬を 飼って いません。'),
 ],
 'summary':[
  '主語が <b><span class="en">he</span>・<span class="en">she</span>・名前</b> の打ち消しは <span class="en">doesn&#39;t</span>。',
  '<b><span class="en">doesn&#39;t</span> のあとの動詞は 原形（もとの形）。</b><span class="en">has</span> も <span class="en">have</span> にもどす。',
  '主語が <span class="en">I</span>・<span class="en">you</span> なら <b><span class="en">don&#39;t</span></b>。',
  'be動詞の文の打ち消しは <b><span class="en">isn&#39;t</span></b>。<span class="en">doesn&#39;t</span> は使わない。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '主語が <span class="en">he</span>・<span class="en">she</span>・名前のときの打ち消しは%sを使う。' % bl("doesn't"),
     '主語が <span class="en">I</span> や <span class="en">you</span> のときは%sを使う。' % bl("don't"),
     '<span class="en">doesn&#39;t</span> のあとの動詞は%sにする。' % bl('原形', False),
     '<span class="en">has</span> は%sにもどす。' % bl('have'),
     'be動詞の文の打ち消しは%sを使う。' % bl("isn't"),
   ]),
   'words':'語群：<span class="en">don&#39;t</span> ／ <span class="en">doesn&#39;t</span> ／ <span class="en">isn&#39;t</span> ／ <span class="en">have</span> ／ 原形',
   'exp':'<b>なぜ？</b>　<span class="en">doesn&#39;t</span> の中には <span class="en">does</span> が入っていて、そこが <span class="en">s</span> のしるしを持っています。<br>'
         'だから動詞のほうは 原形（もとの形）でよいのです。<b><span class="en">s</span> は1つの文に1回だけ</b>、と覚えましょう。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--ng);">B　<span class="en">don&#39;t</span>？ <span class="en">doesn&#39;t</span>？ それとも <span class="en">isn&#39;t</span>？<em>（　）に入るものを書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。まず動作のことばがあるか、つぎに主語を見ましょう。',
   'body':grid2([
     '1. <span class="en">He%splay soccer.</span>' % bl("doesn't"),
     '2. <span class="en">I%splay soccer.</span>' % bl("don't"),
     '3. <span class="en">She%slike natto.</span>' % bl("doesn't"),
     '4. <span class="en">He%sa student.</span>' % bl("isn't"),
     '5. <span class="en">You%slike natto.</span>' % bl("don't"),
     '6. <span class="en">Mike%shave a dog.</span>' % bl("doesn't"),
     '7. <span class="en">She%skind.</span>' % bl("isn't"),
     '8. <span class="en">I%shave a dog.</span>' % bl("don't"),
     '9. <span class="en">He%sstudy math.</span>' % bl("doesn't"),
     '10. <span class="en">Emma%sfrom Japan.</span>' % bl("isn't"),
   ]),
   'exp':'<b>見つけ方</b>　2段階で決めます。<br>'
         '① <b>動作のことばがない</b>（生徒・親切・日本出身）→ <span class="en">isn&#39;t</span>（4・7・10）<br>'
         '② 動作のことばがあるとき、主語が <span class="en">I・you</span> → <span class="en">don&#39;t</span>（2・5・8）、<span class="en">he・she</span>・名前 → <span class="en">doesn&#39;t</span>（1・3・6・9）'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--ng);">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. He doesn&#39;t play soccer.','○'), ('2. He don&#39;t play soccer.','✕'),
     ('3. She doesn&#39;t like natto.','○'), ('4. She doesn&#39;t likes natto.','✕'),
     ('5. I don&#39;t play soccer.','○'), ('6. I doesn&#39;t play soccer.','✕'),
     ('7. He isn&#39;t a student.','○'), ('8. He doesn&#39;t has a dog.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">He doesn&#39;t play soccer.</span>（主語が <span class="en">he</span>）<br>'
         '4 → <span class="en">She doesn&#39;t like natto.</span>（s を取る）　6 → <span class="en">I don&#39;t play soccer.</span>（主語が <span class="en">I</span>）<br>'
         '8 → <span class="en">He doesn&#39;t have a dog.</span>（<span class="en">have</span> にもどす）'},
  {'h':'<h3 class="sec sec2">D　<span class="en">doesn&#39;t</span> のうしろの形　正しいほうを選ぼう</h3>',
   'hint':'<span class="en">doesn&#39;t</span> のうしろは、ぜんぶ<b>原形（もとの形）</b>です。',
   'body':grid2([
     '1. <span class="en">He doesn&#39;t（ア play ／イ plays）soccer.</span>%s' % bl('ア'),
     '2. <span class="en">She doesn&#39;t（ア likes ／イ like）music.</span>%s' % bl('イ'),
     '3. <span class="en">He doesn&#39;t（ア has ／イ have）a dog.</span>%s' % bl('イ'),
     '4. <span class="en">She doesn&#39;t（ア study ／イ studies）math.</span>%s' % bl('ア'),
     '5. <span class="en">He doesn&#39;t（ア watch ／イ watches）TV.</span>%s' % bl('ア'),
     '6. <span class="en">She doesn&#39;t（ア goes ／イ go）to school.</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　答えはぜんぶ<b>原形（もとの形）</b>です。<span class="en">s</span> や <span class="en">es</span> がついた形は使いません。<br>'
         '3の <span class="en">has</span> も「<span class="en">s</span> がついた形」なので、<span class="en">have</span> にもどします。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　主語が <span class="en">he</span>・<span class="en">she</span>・名前なら <span class="en">doesn&#39;t</span>。そのあとは<b>原形（もとの形）</b>。',
   'body':ol([
     ('<span class="jp-cue">彼はサッカーをしません。</span>　<span class="en">He%splay soccer.</span>' % bl("doesn't"),
      '主語が <span class="en">he</span> なので <b><span class="en">doesn&#39;t</span></b>。'),
     ('<span class="jp-cue">わたしはサッカーをしません。</span>　<span class="en">I%splay soccer.</span>' % bl("don't"),
      '主語が <span class="en">I</span> なので <b><span class="en">don&#39;t</span></b>。1番とくらべよう。'),
     ('<span class="jp-cue">彼女は納豆が好きではありません。</span>　<span class="en">She doesn&#39;t%snatto.</span>' % bl('like'),
      '<span class="en">doesn&#39;t</span> のうしろは <b>原形（もとの形）</b>。<span class="en">likes</span> にしない。'),
     ('<span class="jp-cue">彼は犬を飼っていません。</span>　<span class="en">He doesn&#39;t%sa dog.</span>' % bl('have'),
      '<span class="en">has</span> ではなく <b><span class="en">have</span></b>。'),
     ('<span class="jp-cue">彼は生徒ではありません。</span>　<span class="en">He%sa student.</span>' % bl("isn't"),
      '動作のことばがないので <b><span class="en">isn&#39;t</span></b>。'),
     ('<span class="jp-cue">彼女は数学を勉強しません。</span>　<span class="en">She%s%smath.</span>' % (bl("doesn't"), bl('study')),
      '（　）が2つ。<b><span class="en">doesn&#39;t</span> → <span class="en">study</span></b>。'),
     ('<span class="jp-cue">彼はテレビを見ません。</span>　<span class="en">He doesn&#39;t%sTV.</span>' % bl('watch'),
      '<span class="en">watches</span> にしない。<b>原形（もとの形）</b>。'),
     ('<span class="jp-cue">あなたは納豆が好きではありません。</span>　<span class="en">You%slike natto.</span>' % bl("don't"),
      '主語が <span class="en">you</span> なので <b><span class="en">don&#39;t</span></b>。'),
     ('<span class="jp-cue">マイクは学校へ行きません。</span>　<span class="en">Mike doesn&#39;t%sto school.</span>' % bl('go'),
      '<span class="en">goes</span> にしない。<b>原形（もとの形）</b>。'),
     ('<span class="jp-cue">彼女は親切ではありません。</span>　<span class="en">She%skind.</span>' % bl("isn't"),
      '5番と同じ。be動詞の文の打ち消し。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群の打ち消しのことばを先に見る。<span class="en">doesn&#39;t</span> があれば、動詞は 原形（もとの形）のはずです。',
   'body':ol([
     ('<span class="jp-cue">彼はサッカーをしません。</span>　<span class="paren en">（ soccer / doesn&#39;t / He / play ）</span>' + line('He doesn&#39;t play soccer.'),
      '<span class="en">He</span> → <span class="en">doesn&#39;t</span> → 動詞 → なにを の順。'),
     ('<span class="jp-cue">彼女は納豆が好きではありません。</span>　<span class="paren en">（ natto / like / She / doesn&#39;t ）</span>' + line('She doesn&#39;t like natto.'),
      '語群が <span class="en">like</span>（s なし）。<b>語群を見れば形が分かる。</b>'),
     ('<span class="jp-cue">わたしはサッカーをしません。</span>　<span class="paren en">（ soccer / play / don&#39;t / I ）</span>' + line('I don&#39;t play soccer.'),
      '語群が <span class="en">don&#39;t</span>。主語は <span class="en">I</span>。'),
     ('<span class="jp-cue">彼は犬を飼っていません。</span>　<span class="paren en">（ a dog / have / He / doesn&#39;t ）</span>' + line('He doesn&#39;t have a dog.'),
      '語群が <span class="en">have</span>。<span class="en">has</span> ではありません。'),
     ('<span class="jp-cue">彼は生徒ではありません。</span>　<span class="paren en">（ a / student / isn&#39;t / He ）</span>' + line('He isn&#39;t a student.'),
      '語群が <span class="en">isn&#39;t</span>。be動詞の文です。'),
     ('<span class="jp-cue">彼女は数学を勉強しません。</span>　<span class="paren en">（ math / study / doesn&#39;t / She ）</span>' + line('She doesn&#39;t study math.'),
      '2番と同じ形。'),
     ('<span class="jp-cue">彼はサッカーをします。</span>　<span class="paren en">（ soccer / plays / He ）</span>' + line('He plays soccer.'),
      '語群が <span class="en">plays</span>（s あり）。<b>打ち消しではありません。</b>'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('彼はサッカーをしません。' + wline('He doesn&#39;t play soccer.'),
      '<span class="en">play</span> に <span class="en">s</span> をつけないこと。'),
     ('彼女は納豆が好きではありません。' + wline('She doesn&#39;t like natto.'),
      '<span class="en">does not</span> と書いても正解。'),
     ('わたしはサッカーをしません。' + wline('I don&#39;t play soccer.'),
      '主語が <span class="en">I</span> なので <span class="en">don&#39;t</span>。'),
     ('彼は犬を飼っていません。' + wline('He doesn&#39;t have a dog.'),
      '<span class="en">has</span> にしない。'),
     ('彼は生徒ではありません。' + wline('He isn&#39;t a student.'),
      '<span class="en">He is not a student.</span> でも正解。'),
     ('彼女は数学を勉強しません。' + wline('She doesn&#39;t study math.'),
      '<span class="en">studies</span> にしない。'),
   ]),
   'words':'<span class="en">play soccer ／ like natto ／ have a dog ／ a student ／ study math</span>'},
  'l4':{'sub':'友だちや家族の「しないこと」を書こう',
   'cond':['<span class="en">He doesn&#39;t ～.</span> か <span class="en">She doesn&#39;t ～.</span> の文を <b>2つ以上</b>',
           '<span class="en">He is ～.</span> などの ふつうの文を <b>1つ以上</b> 入れる',
           '<span class="en">I don&#39;t ～.</span> の文も <b>1つ</b> 入れる'],
   'example':['Mike is my friend. He plays soccer.','He doesn&#39;t like natto. He doesn&#39;t have a dog.','I don&#39;t play tennis.'],
   'note':'これは例です。同じでなくてかまいません。きらいな食べ物・やっていないスポーツ・飼っていないペット を書くと作りやすいです。',
   'check':['he / she には doesn&#39;t','doesn&#39;t のあとは 原形（もとの形）','I・you には don&#39;t','be動詞の文には isn&#39;t'],
   'review':'じぶんの文の <span class="en">doesn&#39;t</span> のうしろに○をつけよう。動詞に <span class="en">s</span> がついていたら、そこがまちがい。'},
 },
}
