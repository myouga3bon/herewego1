# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'u8-1', 'unit':'8 − 1', 'unit_plain':'8-1', 'title':'現在進行形（肯定文）',
 'pages':'p.116〜117',
 'hero_big':'I am playing soccer now.',
 'hero_jp':'わたしは 今 サッカーを しているところです',
 'motto':'進行形は <b>be動詞 ＋ 動詞ing</b>。<b>2つで1セット</b>。どちらが欠けてもだめ。',
 'kana':{'playing':'プレイイング','running':'ラニング','swimming':'スウィミング',
         'studying':'スタディイング','watching':'ウォッチング','eating':'イーティング',
         'cooking':'クッキング','reading':'リーディング','writing':'ライティング',
         'write':'ライト','taking':'テイキング','take':'テイク','picture':'ピクチャ',
         'now':'ナウ','he':'ヒー','she':'シー','is':'イズ','are':'アー','am':'アム'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>今 ちょうど ～しているところ</b>」と言いたいときの形です。<b>be動詞と、動詞の <span class="en">ing</span> 形</b>を組み合わせます。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I am playing soccer now.</span><span class="t">わたしは 今 サッカーを しているところです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">He is running now.</span><span class="t">彼は 今 走っているところです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I play soccer.</span><span class="t">わたしは サッカーを します。</span></div>
    </div>'''),
    ('t','1つめと3つめをくらべてください。<b><span class="en">I play ～.</span> は「ふだんすること」、<span class="en">I am playing ～.</span> は「今まさにしていること」</b>。意味がちがいます。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜be動詞と <span class="en">ing</span> は 2つで1セット', [
    ('t','ここが今回のヤマです。<b>どちらか片方だけでは、進行形になりません</b>。かならず2つそろえます。'),
    ('h','''<div class="blocks">
      <div class="blk fill"><div class="w en">I</div><div class="r">だれが</div></div>
      <div class="plus">＋</div>
      <div class="blk fill"><div class="w en">am</div><div class="r">be動詞</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">playing</div><div class="r">動詞ing</div></div>
      <div class="plus">＋</div>
      <div class="blk line" style="border-color:var(--gv);color:var(--gv);"><div class="w">なにを</div><div class="r">soccer …</div></div>
    </div>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-smile"/></svg>
          <span>◯ 2つそろっている</span></div>
        <div class="in"><div class="ex">I am playing soccer.</div>
          <div class="memo"><span class="en">am</span> も <span class="en">playing</span> もある。</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-run"/></svg>
          <span>✕ 片方しかない</span></div>
        <div class="in"><div class="ex">I playing soccer.<br>I am play soccer.</div>
          <div class="memo">上は <span class="en">am</span> が、下は <span class="en">ing</span> が足りない。</div></div>
      </div>
    </div>'''),
    ('t','とくに多いのが <b>be動詞の抜け</b>（<span class="en">I playing ～.</span>）。<span class="en">ing</span> を見たら<b>その前に be動詞があるか</b>をかならず確かめましょう。'),
  ]),
  ('be動詞は主語で決まる', [
    ('t','使う be動詞は、4-1 で習ったとおり<b>主語で決まります</b>。進行形になっても同じです。'),
    ('h','''<table class="kind">
      <thead><tr><th>主語</th><th>be動詞</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k"><span class="en">I</span></td><td class="k" style="color:var(--key);font-weight:700;">am</td><td class="e">I <u>am</u> playing soccer.</td></tr>
        <tr><td class="k"><span class="en">you</span></td><td class="k" style="color:var(--key);font-weight:700;">are</td><td class="e">You <u>are</u> playing soccer.</td></tr>
        <tr><td class="k"><span class="en">he / she</span>・名前</td><td class="k" style="color:var(--key);font-weight:700;">is</td><td class="e">He <u>is</u> playing soccer.</td></tr>
      </tbody>
    </table>'''),
    ('t','<b><span class="en">ing</span> がついても、動詞に <span class="en">s</span> はつけません。</b><span class="en">He is playings ～.</span> という形はありません。'),
  ]),
  ('<span class="en">ing</span> のつけ方（3-2 の復習）', [
    ('t','3-2 で習ったとおり、つけ方は3パターンです。'),
    ('h','''<table class="kind">
      <thead><tr><th>パターン</th><th>やり方</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k">ふつう</td><td class="k">そのまま <span class="en">ing</span></td><td class="e">play → play<u>ing</u>　watch → watch<u>ing</u></td></tr>
        <tr><td class="k"><span class="en">e</span> で終わる</td><td class="k"><span class="en">e</span> を消して <span class="en">ing</span></td><td class="e">take → tak<u>ing</u>　write → writ<u>ing</u></td></tr>
        <tr><td class="k">短くて最後が1字</td><td class="k">最後の字を<b>重ねて</b> <span class="en">ing</span></td><td class="e">run → ru<u>nn</u>ing　swim → swi<u>mm</u>ing</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">running</span> と <span class="en">swimming</span> は<b>とくによく出ます</b>。<span class="en">runing</span>・<span class="en">swiming</span> と書かないように気をつけましょう。'),
  ]),
  ('「今」を表すことば', [
    ('t','進行形の文には <b><span class="en">now</span></b>（今）をいっしょに使うことが多いです。'),
    ('h','''<div class="eqbox">
      <span class="eq">I am playing soccer now.</span>（わたしは今サッカーをしているところです）<br>
      <span class="en">now</span> は<b>文のいちばん後ろ</b>に置きます。
    </div>'''),
    ('t','<span class="en">now</span> があったら<b>進行形にする</b>という合図です。見つけたらすぐ、be動詞と <span class="en">ing</span> をそろえましょう。'),
  ]),
 ],
 'quiz':[
  ('I playing soccer.','I am playing soccer.','<b>be動詞が抜けています</b>。<span class="en">ing</span> の前に <span class="en">am</span> が必要。','わたしは サッカーを しているところです。'),
  ('I am play soccer.','I am playing soccer.','<b><span class="en">ing</span> が抜けています</b>。be動詞だけでは進行形になりません。','わたしは サッカーを しているところです。'),
  ('He is runing.','He is running.','<span class="en">run</span> は<b>最後の <span class="en">n</span> を重ねて</b> <span class="en">running</span>。','彼は 走っているところです。'),
  ('He are playing soccer.','He is playing soccer.','主語が <span class="en">he</span> なので <b><span class="en">is</span></b>。','彼は サッカーを しているところです。'),
  ('I am swiming.','I am swimming.','<span class="en">swim</span> は<b><span class="en">m</span> を重ねて</b> <span class="en">swimming</span>。','わたしは 泳いでいるところです。'),
  ('He is takeing a picture.','He is taking a picture.','<span class="en">take</span> は <span class="en">e</span> で終わるので、<b><span class="en">e</span> を消して <span class="en">ing</span></b>。','彼は 写真を とっているところです。'),
 ],
 'summary':[
  '「今 ～しているところ」は <b>be動詞 ＋ 動詞ing</b>。',
  '<b>2つで1セット。</b>be動詞だけ、<span class="en">ing</span> だけ ではだめ。',
  'be動詞は主語で決まる。<b><span class="en">I</span>→<span class="en">am</span>、<span class="en">you</span>→<span class="en">are</span>、<span class="en">he/she</span>→<span class="en">is</span>。</b>',
  '<span class="en">run → running</span>、<span class="en">swim → swimming</span>、<span class="en">take → taking</span> に注意。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「今 ～しているところ」は、%s＋ 動詞の%s形で表す。' % (bl('be動詞', False), bl('ing')),
     'この2つは%sで1セット。どちらか片方だけではだめ。' % bl('2つ'),
     '使う be動詞は%sで決まる。<span class="en">I</span> なら <span class="en">am</span>、<span class="en">he</span> なら <span class="en">is</span>。' % bl('主語'),
     '<span class="en">run</span> は <span class="en">n</span> を%sて <span class="en">running</span> にする。' % bl('重ね'),
     '<span class="en">take</span> は <span class="en">e</span> を%sして <span class="en">taking</span> にする。' % bl('消'),
   ]),
   'words':'語群：<span class="en">be動詞</span> ／ <span class="en">ing</span> ／ 2つ ／ 主語 ／ 重ね ／ 消',
   'exp':'<b>なぜ？</b>　<span class="en">ing</span> の形は「～している最中」というようすを表します。それを<b>「＝」でつなぐ</b>のが be動詞の役目です。<br>'
         '<span class="en">I ＝ playing</span>（わたし＝している最中）という形なので、be動詞がないと文になりません。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--gv);">B　be動詞と <span class="en">ing</span> をそろえよう<em>（　）に正しい形を書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。be動詞は主語で、<span class="en">ing</span> はつけ方のルールで決めます。',
   'body':grid2([
     '1. <span class="en">I%splaying soccer.</span>' % bl('am'),
     '2. <span class="en">He%splaying soccer.</span>' % bl('is'),
     '3. <span class="en">You%splaying soccer.</span>' % bl('are'),
     '4. <span class="en">I am%s.</span>（run）' % bl('running', False),
     '5. <span class="en">She is%s.</span>（swim）' % bl('swimming', False),
     '6. <span class="en">He is%sa picture.</span>（take）' % bl('taking', False),
     '7. <span class="en">I am%sTV.</span>（watch）' % bl('watching', False),
     '8. <span class="en">Mike%sstudying math.</span>' % bl('is'),
     '9. <span class="en">I am%slunch.</span>（eat）' % bl('eating', False),
     '10. <span class="en">She%scooking now.</span>' % bl('is'),
   ]),
   'exp':'<b>見つけ方</b>　be動詞は<b>主語</b>を見る（1・2・3・8・10）。<span class="en">ing</span> は<b>語の終わり方</b>を見る（4〜7・9）。<br>'
         '4は <span class="en">n</span> を重ねて <span class="en">running</span>、5は <span class="en">m</span> を重ねて <span class="en">swimming</span>、6は <span class="en">e</span> を消して <span class="en">taking</span>。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--gv);">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. I am playing soccer.','○'), ('2. I playing soccer.','✕'),
     ('3. He is running.','○'), ('4. I am play soccer.','✕'),
     ('5. She is swimming.','○'), ('6. He is runing.','✕'),
     ('7. You are watching TV.','○'), ('8. He are playing soccer.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">I am playing soccer.</span>（<span class="en">am</span> を足す）　4 → <span class="en">I am playing soccer.</span>（ing をつける）<br>'
         '6 → <span class="en">He is running.</span>（<span class="en">n</span> を重ねる）　8 → <span class="en">He is playing soccer.</span>（<span class="en">is</span> に）<br>'
         '2と4は<b>セットが欠けている</b>まちがい。6は<b>つけ方</b>、8は<b>be動詞の選び方</b>のまちがいです。'},
  {'h':'<h3 class="sec sec2">D　<span class="en">ing</span> のつけ方　正しいほうを選ぼう</h3>',
   'hint':'そのまま／<span class="en">e</span> を消す／最後を重ねる、の3パターンです。',
   'body':grid2([
     '1. <span class="en">run →（ア running ／イ runing）</span>%s' % bl('ア'),
     '2. <span class="en">take →（ア takeing ／イ taking）</span>%s' % bl('イ'),
     '3. <span class="en">swim →（ア swiming ／イ swimming）</span>%s' % bl('イ'),
     '4. <span class="en">play →（ア playing ／イ plaing）</span>%s' % bl('ア'),
     '5. <span class="en">watch →（ア watching ／イ watchking）</span>%s' % bl('ア'),
     '6. <span class="en">write →（ア writeing ／イ writing）</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　ふつうはそのまま（4・5）。<span class="en">e</span> で終わる語は <span class="en">e</span> を消す（2・6）。短くて最後が1字の語は重ねる（1・3）。<br>'
         '3-2 で習ったルールとまったく同じです。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　<span class="en">now</span> があれば進行形の合図。be動詞と <span class="en">ing</span> を<b>2つそろえる</b>。',
   'body':ol([
     ('<span class="jp-cue">わたしは今サッカーをしているところです。</span>　<span class="en">I%splaying soccer now.</span>' % bl('am'),
      '主語が <span class="en">I</span> なので <b><span class="en">am</span></b>。'),
     ('<span class="jp-cue">彼は今走っているところです。</span>　<span class="en">He is%snow.</span>' % bl('running', False),
      '<span class="en">n</span> を重ねて <b><span class="en">running</span></b>。'),
     ('<span class="jp-cue">あなたは今テレビを見ているところです。</span>　<span class="en">You%swatching TV now.</span>' % bl('are'),
      '主語が <span class="en">you</span> なので <b><span class="en">are</span></b>。'),
     ('<span class="jp-cue">彼女は今泳いでいるところです。</span>　<span class="en">She is%snow.</span>' % bl('swimming', False),
      '<span class="en">m</span> を重ねて <b><span class="en">swimming</span></b>。'),
     ('<span class="jp-cue">わたしはサッカーをします。</span>　<span class="en">I%ssoccer.</span>' % bl('play'),
      '「ふだんすること」なので<b>進行形ではありません</b>。1番とくらべよう。'),
     ('<span class="jp-cue">彼は今写真をとっているところです。</span>　<span class="en">He%s%sa picture.</span>' % (bl('is'), bl('taking', False)),
      '（　）が2つ。<b><span class="en">is</span> ＋ <span class="en">taking</span></b>（<span class="en">e</span> を消す）。'),
     ('<span class="jp-cue">わたしは今 昼ごはんを食べているところです。</span>　<span class="en">I am%slunch now.</span>' % bl('eating', False),
      'そのまま <span class="en">ing</span>。'),
     ('<span class="jp-cue">マイクは今 数学を勉強しているところです。</span>　<span class="en">Mike%sstudying math now.</span>' % bl('is'),
      '人の名前なので <b><span class="en">is</span></b>。'),
     ('<span class="jp-cue">彼女は今 料理をしているところです。</span>　<span class="en">She is%snow.</span>' % bl('cooking', False),
      'そのまま <span class="en">ing</span>。'),
     ('<span class="jp-cue">わたしは今 本を読んでいるところです。</span>　<span class="en">I%s%sa book now.</span>' % (bl('am'), bl('reading', False)),
      '6番と同じ形。<b>2つで1セット</b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群に be動詞と <span class="en">ing</span> の形があれば進行形。<span class="en">now</span> はいちばん後ろに置きます。',
   'body':ol([
     ('<span class="jp-cue">わたしは今サッカーをしているところです。</span>　<span class="paren en">（ soccer / am / now / I / playing ）</span>' + line('I am playing soccer now.'),
      '「だれが → be動詞 → ing → なにを → いつ」の順。'),
     ('<span class="jp-cue">彼は今走っているところです。</span>　<span class="paren en">（ running / He / now / is ）</span>' + line('He is running now.'),
      '<span class="en">He</span> → <span class="en">is</span> → <span class="en">running</span> → <span class="en">now</span>。'),
     ('<span class="jp-cue">あなたは今テレビを見ているところです。</span>　<span class="paren en">（ TV / watching / You / are ）</span>' + line('You are watching TV.'),
      '語群が <span class="en">are</span>。主語は <span class="en">you</span>。'),
     ('<span class="jp-cue">彼女は今泳いでいるところです。</span>　<span class="paren en">（ swimming / is / She ）</span>' + line('She is swimming.'),
      '3語だけ。<b>2つで1セット</b>がそろっています。'),
     ('<span class="jp-cue">わたしはサッカーをします。</span>　<span class="paren en">（ soccer / play / I ）</span>' + line('I play soccer.'),
      '語群に be動詞も <span class="en">ing</span> もない。<b>ふつうの文</b>です。'),
     ('<span class="jp-cue">彼は今写真をとっているところです。</span>　<span class="paren en">（ a picture / taking / He / is ）</span>' + line('He is taking a picture.'),
      '<span class="en">a picture</span> でひとかたまり。'),
     ('<span class="jp-cue">マイクは今 数学を勉強しているところです。</span>　<span class="paren en">（ math / studying / Mike / is / now ）</span>' + line('Mike is studying math now.'),
      '<span class="en">now</span> はいちばん後ろ。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしは今サッカーをしているところです。' + wline('I am playing soccer now.'),
      '<span class="en">am</span> と <span class="en">ing</span> の2つをそろえる。'),
     ('彼は今走っているところです。' + wline('He is running now.'),
      '<span class="en">runing</span> にしない。<span class="en">n</span> を重ねる。'),
     ('彼女は今泳いでいるところです。' + wline('She is swimming now.'),
      '<span class="en">m</span> を重ねる。'),
     ('あなたは今テレビを見ているところです。' + wline('You are watching TV now.'),
      '<span class="en">you</span> なので <span class="en">are</span>。'),
     ('彼は今写真をとっているところです。' + wline('He is taking a picture now.'),
      '<span class="en">take</span> の <span class="en">e</span> を消す。'),
     ('わたしはサッカーをします。' + wline('I play soccer.'),
      '「ふだんすること」なので進行形にしないこと。'),
   ]),
   'words':'<span class="en">playing ／ running ／ swimming ／ watching ／ taking a picture ／ play</span>'},
  'l4':{'sub':'教室のみんなが「今していること」を書こう',
   'cond':['<span class="en">I am ～ing.</span> の文を <b>1つ以上</b>',
           '<span class="en">He is ～ing.</span> か <span class="en">She is ～ing.</span> の文を <b>2つ以上</b>',
           '<span class="en">now</span> を <b>1つ以上</b> 使う'],
   'example':['I am studying English now.','Mike is reading a book. He is sitting by the window.','Emma is talking with her friend.'],
   'note':'これは例です。同じでなくてかまいません。今の教室・家・外の様子 を思い浮かべて書いてみよう。',
   'check':['be動詞と ing の2つがそろっている','be動詞は主語に合っている','run は running、take は taking','ing の形に s をつけていない'],
   'review':'じぶんの文の <span class="en">ing</span> の<b>前</b>に○をつけよう。be動詞がなければ、そこがまちがい。'},
 },
}
