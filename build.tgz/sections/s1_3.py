# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox, gmap

S = {
 'id':'u1-3', 'unit':'1 − 3', 'unit_plain':'1-3', 'title':'I can ～.',
 'pages':'p.32〜33',
 'hero_big':'I can swim. ／ I can&#39;t swim.',
 'hero_jp':'わたしは 泳ぐことが できます ／ できません',
 'motto':'<span class="en">can</span> のうしろは かざりのない「原形（もとの形）」。<span class="en">ing</span> も <span class="en">s</span> もつけない。',
 'kana':{'can':'キャン',"can't":'キャント','cannot':'キャナット','swim':'スウィム',
         'piano':'ピアノ','cook':'クック','sing':'スィング','ski':'スキー',
         'skate':'スケイト','dance':'ダンス','speak':'スピーク','read':'リード',
         'the':'ザ','jump':'ジャンプ','high':'ハイ','unicycle':'ユーニサイクル'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>泳ぐことが できます</b>」「<b>ピアノが ひけます</b>」のように、<b>できること</b>を言うときの形です。'),
    ('t','できないときの言い方もいっしょにならいます。'),
    ('h', gitem('❶', '「～が できます」', 'できることを言う',
                '泳ぐことが できます', 'can swim',
                [('I can swim.','わたしは 泳ぐことが できます。'),
                 ('I can play the piano.','わたしは ピアノを ひくことが できます。')],
                '<b>can</b> が「できる」。そのうしろに<b>動作のことば</b>をそのまま置きます。')),
    ('h', gitem('❷', '「～が できません」', 'できないことを言う',
                '泳ぐことが できません', 'can&#39;t swim',
                [('I can&#39;t swim.','わたしは 泳ぐことが できません。'),
                 ('I can&#39;t play the piano.','わたしは ピアノを ひくことが できません。')],
                '<b>can</b> を <b>can&#39;t</b> に変えるだけ。うしろは何も変えません。', b2=True)),
    ('t','どちらも <span class="en">I</span> → <span class="en">can</span> → 動作のことば の順。この<b>じゅんばんは ずっと変わりません</b>。'),
    ('h', copybox()),
  ]),
  ('<span class="en">can</span> は 動詞の前に置く「助っ人」', [
    ('t','<span class="en">can</span> は<b>ひとりでは使えません</b>。かならず動作のことばとペアになって、その<b>すぐ前</b>に入ります。'),
    ('h','''<div class="blocks">
      <div class="blk fill" style="background:var(--gv);"><div class="w en">I</div><div class="r">だれが</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:#7A4FBF;"><div class="w en">can</div><div class="r">できる</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">swim</div><div class="r">どうする</div></div>
      <div class="plus">＋</div>
      <div class="blk line" style="border-color:var(--gv);color:var(--gv);"><div class="w">なにを</div><div class="r">the piano / soccer …</div></div>
    </div>'''),
    ('t','<span class="en">I like soccer.</span> に <span class="en">can</span> の意味を足したいときは、<span class="en">like</span> の前に <span class="en">can</span> を入れるだけ。ことばの順番を入れかえたりはしません。'),
  ]),
  ('かなり大事｜<span class="en">can</span> のうしろは「原形（もとの形）」', [
    ('t','ここが今回のヤマです。<span class="en">can</span> のうしろの動詞は、<b>かざりのない「原形（もとの形）」</b>にします。<span class="en">ing</span> も <span class="en">s</span> もつけません。'),
    ('h','''<table class="kind">
      <thead><tr><th>言いたいこと</th><th>○ 正しい形</th><th>✕ まちがえやすい形</th></tr></thead>
      <tbody>
        <tr><td class="k">泳げる</td><td class="e">I can <u>swim</u>.</td><td class="e" style="color:var(--ng);">I can swimming. / I can swims.</td></tr>
        <tr><td class="k">走れる</td><td class="e">I can <u>run</u> fast.</td><td class="e" style="color:var(--ng);">I can running fast.</td></tr>
        <tr><td class="k">料理ができる</td><td class="e">I can <u>cook</u>.</td><td class="e" style="color:var(--ng);">I can cooking.</td></tr>
      </tbody>
    </table>'''),
    ('t','おぼえ方は<b>「<span class="en">can</span> のうしろは すっぴん」</b>。<span class="en">ing</span> や <span class="en">s</span> という「かざり」をつけないという意味です。'),
  ]),
  ('「～できない」は <span class="en">can&#39;t</span>', [
    ('t','打ち消すときは <span class="en">can</span> を <span class="en">can&#39;t</span> に変えるだけ。<b>うしろの形は変えません</b>。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--ng);background:rgba(181,39,63,.06);">
      <span class="eq" style="color:var(--gv);">I can swim.</span>　→　<span class="eq" style="color:var(--ng);">I can&#39;t swim.</span>（泳げません）<br>
      <span class="en">can&#39;t</span>＝<span class="en">cannot</span>。どちらも同じ意味です。&#39;（アポストロフィ）を忘れずに。
    </div>'''),
    ('t','前回の <span class="en">don&#39;t</span> のときとちがい、<b><span class="en">don&#39;t</span> は使いません</b>。<span class="en">can</span> の文の打ち消しは、いつでも <span class="en">can&#39;t</span> です。'),
  ]),
  ('<span class="en">am</span>・<span class="en">like</span>・<span class="en">can</span> の整理', [
    ('t','ここまでに3つの形を習いました。文のまん中に<b>どれを置くか</b>で意味が決まります。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ am を使う<small>「わたしは <u>どんな人か</u>」</small></span></div>
        <div class="in"><div class="ex">I am a soccer fan.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-run"/></svg>
          <span>✕ am を使わない<small>「<u>する</u>」「<u>できる</u>」</small></span></div>
        <div class="in"><div class="ex">I play soccer.<br>I can play soccer.</div></div>
      </div>
    </div>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：心臓（動詞）は 青かピンクの どちらか1つ</div>
        <p><b class="cb">青＝<span class="en">am</span></b>　<b class="cp">ピンク＝<span class="en">play・like・swim</span></b>　
        <span class="en">can</span> はピンクの<b>助っ人</b>なので、青とはいっしょに使いません。<br>
        <span class="xm">✕ I am can swim ✕</span>　<span class="xm">✕ I can am happy ✕</span></p>
      </div>
    </div>'''),
  ]),
 ],
 'quiz':[
  ('I can swimming.','I can swim.','<span class="en">can</span> のうしろは 原形（もとの形）。<b>ing はつけません</b>。','わたしは 泳ぐことが できます。'),
  ('I can swims.','I can swim.','<b>s もつけません</b>。<span class="en">can</span> のうしろは すっぴんです。','わたしは 泳ぐことが できます。'),
  ('I cant swim.','I can&#39;t swim.','<b>&#39;（アポストロフィ）</b>を忘れています。<span class="en">can&#39;t</span>＝<span class="en">cannot</span>。','わたしは 泳ぐことが できません。'),
  ('I am can swim.','I can swim.','心臓（動詞）が2つ。<b><span class="en">am</span> はいりません</b>。','わたしは 泳ぐことが できます。'),
  ('I don&#39;t can swim.','I can&#39;t swim.','<span class="en">can</span> の文の打ち消しは <b><span class="en">can&#39;t</span></b>。<span class="en">don&#39;t</span> は使いません。','わたしは 泳ぐことが できません。'),
  ('I can to swim.','I can swim.','<b><span class="en">to</span> もいりません</b>。<span class="en">can</span> のすぐあとに動詞がきます。','わたしは 泳ぐことが できます。'),
 ],
 'summary':[
  '「～できます」は <b><span class="en">I can ～.</span></b>　<span class="en">can</span> は動詞の<b>すぐ前</b>。',
  '<b><span class="en">can</span> のうしろは「原形（もとの形）」。</b><span class="en">ing</span> も <span class="en">s</span> もつけない。',
  '「～できません」は <b><span class="en">I can&#39;t ～.</span></b>　<span class="en">can&#39;t</span>＝<span class="en">cannot</span>、&#39; を忘れない。',
  '<span class="en">can</span> の文に <b><span class="en">am</span> も <span class="en">don&#39;t</span> も入れない。</b>',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「わたしは～できます」は <span class="en">I %s ～.</span>　<span class="en">can</span> は動詞の%sに置く。' % (bl('can'), bl('前')),
     '<span class="en">can</span> のうしろの動詞は、かざりのない%sにする。<span class="en">ing</span> も <span class="en">s</span> も%s。' % (bl('原形', False), bl('つけない')),
     '「～できません」は <span class="en">I %s ～.</span>　これは%sを短くした形。' % (bl("can't"), bl('cannot')),
     '<span class="en">can</span> の文を打ち消すときに%sは使わない。' % bl("don't"),
     '1つの文に心臓（動詞）は%sつだけ。だから%sと <span class="en">can</span> はいっしょに使わない。' % (bl('1'), bl('am')),
   ]),
   'words':'語群：<span class="en">can</span> ／ <span class="en">can&#39;t</span> ／ <span class="en">cannot</span> ／ <span class="en">don&#39;t</span> ／ <span class="en">am</span> ／ 原形 ／ 前 ／ つけない ／ 1',
   'exp':'<b>なぜ？</b>　<span class="en">can</span> は「できる」という意味を足すだけの<b>助っ人</b>。文の心臓（動詞）はうしろの動詞なので、<span class="en">can</span> はその前に入ります。<br>'
         '助っ人がついた動詞は<b>すっぴん（原形（もとの形））</b>になる、と覚えておけば迷いません。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--gv);">B　<span class="en">can</span>？ それとも <span class="en">am</span>？<em>（　）に <span class="en">can</span> か <span class="en">am</span> を書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。うしろが動作のことばなら <span class="en">can</span>、「わたし＝それ」になるなら <span class="en">am</span>。',
   'body':grid2([
     '1. <span class="en">I%sswim.</span>' % bl('can'),
     '2. <span class="en">I%sa student.</span>' % bl('am'),
     '3. <span class="en">I%shappy.</span>' % bl('am'),
     '4. <span class="en">I%scook.</span>' % bl('can'),
     '5. <span class="en">I%splay the piano.</span>' % bl('can'),
     '6. <span class="en">I%sfrom Nagano.</span>' % bl('am'),
     '7. <span class="en">I%srun fast.</span>' % bl('can'),
     '8. <span class="en">I%stwelve.</span>' % bl('am'),
     '9. <span class="en">I%ssing well.</span>' % bl('can'),
     '10. <span class="en">I%sa soccer fan.</span>' % bl('am'),
   ]),
   'exp':'<b>見つけ方</b>　（　）のうしろを見よう。<br>'
         '<b>動作のことば</b>（<span class="en">swim・cook・play・run・sing</span>）→ <span class="en">can</span>（1・4・5・7・9）<br>'
         '<b>「わたし＝それ」になる</b>（生徒・うれしい・長野出身・12歳・サッカーファン）→ <span class="en">am</span>（2・3・6・8・10）'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--gv);">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. I can swim.','○'), ('2. I can swimming.','✕'),
     ('3. I can&#39;t swim.','○'), ('4. I cant swim.','✕'),
     ('5. I can play the piano.','○'), ('6. I am can cook.','✕'),
     ('7. I can&#39;t run fast.','○'), ('8. I can sings well.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">I can swim.</span>（ing を取る）　4 → <span class="en">I can&#39;t swim.</span>（&#39;を入れる）<br>'
         '6 → <span class="en">I can cook.</span>（<span class="en">am</span> を消す）　8 → <span class="en">I can sing well.</span>（s を取る）<br>'
         '2と8は<b>うしろの形</b>のまちがい。4は<b>書き方</b>、6は<b>心臓（動詞）が2つ</b>のまちがいです。'},
  {'h':'<h3 class="sec sec2">D　<span class="en">can</span> のうしろの形　正しいほうを選ぼう</h3>',
   'hint':'<span class="en">can</span> のうしろは、かざりのない<b>原形（もとの形）</b>。これだけで全部とけます。',
   'body':grid2([
     '1. <span class="en">I can（ア swim ／イ swimming）.</span>%s' % bl('ア'),
     '2. <span class="en">I can（ア playing ／イ play）the piano.</span>%s' % bl('イ'),
     '3. <span class="en">I can（ア cooks ／イ cook）.</span>%s' % bl('イ'),
     '4. <span class="en">I can（ア run ／イ running）fast.</span>%s' % bl('ア'),
     '5. <span class="en">I can&#39;t（ア eat ／イ eating）natto.</span>%s' % bl('ア'),
     '6. <span class="en">I can（ア sings ／イ sing）well.</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　答えはぜんぶ「原形（もとの形）」です。<span class="en">ing</span> がついた形と <span class="en">s</span> がついた形は、<span class="en">can</span> のうしろには入れません。<br>'
         '5番のように <span class="en">can&#39;t</span> のときも同じルールです。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　「できる」は <span class="en">can</span>、「できない」は <span class="en">can&#39;t</span>。そのうしろは<b>原形（もとの形）</b>。',
   'body':ol([
     ('<span class="jp-cue">わたしは泳ぐことができます。</span>　<span class="en">I%sswim.</span>' % bl('can'),
      '「できます」は <b><span class="en">can</span></b>。うしろは <span class="en">swim</span> のまま。'),
     ('<span class="jp-cue">わたしは泳ぐことができません。</span>　<span class="en">I%sswim.</span>' % bl("can't"),
      '「できません」は <b><span class="en">can&#39;t</span></b>。うしろの形は変えない。'),
     ('<span class="jp-cue">わたしはピアノをひくことができます。</span>　<span class="en">I can%sthe piano.</span>' % bl('play'),
      '楽器を「ひく」は <b><span class="en">play</span></b>。<span class="en">playing</span> にはしない。'),
     ('<span class="jp-cue">わたしは速く走ることができます。</span>　<span class="en">I%s%sfast.</span>' % (bl('can'), bl('run')),
      '（　）が2つ。<b><span class="en">can</span> → <span class="en">run</span></b> の順。'),
     ('<span class="jp-cue">わたしは料理をすることができません。</span>　<span class="en">I%s%s.</span>' % (bl("can't"), bl('cook')),
      '「料理をする」は <b><span class="en">cook</span></b> 1語でOK。'),
     ('<span class="jp-cue">わたしは生徒です。</span>　<span class="en">I%sa student.</span>' % bl('am'),
      '「わたし＝生徒」なので <b><span class="en">am</span></b>。<span class="en">can</span> ではありません。'),
     ('<span class="jp-cue">わたしは上手に歌うことができます。</span>　<span class="en">I can%swell.</span>' % bl('sing'),
      '「歌う」は <b><span class="en">sing</span></b>。<span class="en">sings</span> にしない。'),
     ('<span class="jp-cue">わたしはサッカーが好きです。</span>　<span class="en">I%ssoccer.</span>' % bl('like'),
      '「好きです」だけなので <b><span class="en">like</span></b>。<span class="en">can</span> はいらない。'),
     ('<span class="jp-cue">短くしない形にしよう。</span>　<span class="en">I can&#39;t swim.</span> →　<span class="en">I%sswim.</span>' % bl('cannot', False),
      '<b><span class="en">can&#39;t</span> ＝ <span class="en">cannot</span></b>。1語で書きます。'),
     ('<span class="jp-cue">わたしはサッカーをすることができます。</span>　<span class="en">I%s%ssoccer.</span>' % (bl('can'), bl('play')),
      '4番と同じ形。<b><span class="en">can</span> → 動詞</b> の順。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群に <span class="en">can</span> か <span class="en">can&#39;t</span> があれば、それを<b>動詞のすぐ前</b>に置きます。',
   'body':ol([
     ('<span class="jp-cue">わたしは泳ぐことができます。</span>　<span class="paren en">（ swim / I / can ）</span>' + line('I can swim.'),
      '「だれが → できる → どうする」の順。<b>はじめは大文字、終わりにピリオド。</b>'),
     ('<span class="jp-cue">わたしはピアノをひくことができます。</span>　<span class="paren en">（ the piano / can / I / play ）</span>' + line('I can play the piano.'),
      '<span class="en">can</span> は <span class="en">play</span> の<b>すぐ前</b>。<span class="x">✕ I play can the piano.</span>'),
     ('<span class="jp-cue">わたしは料理をすることができません。</span>　<span class="paren en">（ cook / I / can&#39;t ）</span>' + line('I can&#39;t cook.'),
      '<span class="en">can&#39;t</span> のうしろも <b>原形（もとの形）</b>。'),
     ('<span class="jp-cue">わたしは生徒です。</span>　<span class="paren en">（ a / I / student / am ）</span>' + line('I am a student.'),
      '語群に <span class="en">am</span> がある。<b>語群を見ればどちらの文か分かる。</b>'),
     ('<span class="jp-cue">わたしは速く走ることができます。</span>　<span class="paren en">（ fast / can / run / I ）</span>' + line('I can run fast.'),
      '<span class="en">fast</span>（速く）は<b>いちばん後ろ</b>。'),
     ('<span class="jp-cue">わたしは納豆を食べることができません。</span>　<span class="paren en">（ natto / I / eat / can&#39;t ）</span>' + line('I can&#39;t eat natto.'),
      '<span class="en">can&#39;t</span> → <span class="en">eat</span> → <span class="en">natto</span> の順。'),
     ('<span class="jp-cue">わたしはテニスが好きです。</span>　<span class="paren en">（ tennis / like / I ）</span>' + line('I like tennis.'),
      '語群に <span class="en">can</span> がない。<b>ないものは使えません。</b>'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしは泳ぐことができます。' + wline('I can swim.'),
      'たった3語。<span class="en">swim</span> に <span class="en">ing</span> をつけないこと。'),
     ('わたしは泳ぐことができません。' + wline('I can&#39;t swim.'),
      '<span class="en">cannot</span> でも正解。&#39;（アポストロフィ）を忘れない。'),
     ('わたしはピアノをひくことができます。' + wline('I can play the piano.'),
      '楽器には <b><span class="en">the</span></b> をつけて <span class="en">play the piano</span>。'),
     ('わたしは速く走ることができます。' + wline('I can run fast.'),
      '「速く」は <span class="en">fast</span>。いちばん後ろに置きます。'),
     ('わたしは料理をすることができません。' + wline('I can&#39;t cook.'),
      '<span class="en">cook</span> 1語で「料理をする」。'),
     ('わたしはサッカーファンです。' + wline('I am a soccer fan.'),
      '<span class="en">I&#39;m a soccer fan.</span> でも正解。これは <span class="en">can</span> の文ではありません。'),
   ]),
   'words':'<span class="en">swim ／ play the piano ／ run fast ／ cook ／ soccer fan</span>'},
  'l4':{'sub':'じぶんの「できること・できないこと」を書こう',
   'cond':['<span class="en">I can ～.</span> の文を <b>2つ以上</b>',
           '<span class="en">I can&#39;t ～.</span> の文を <b>1つ以上</b>',
           '<span class="en">I am ～.</span> の文も <b>1つ</b> 入れる'],
   'example':['I can swim. I can play soccer.','I can&#39;t cook. I am a soccer fan.'],
   'note':'これは例です。同じでなくてかまいません。思いつかないときは、スポーツ・楽器・料理・外国語 の4つから選んでみよう。',
   'check':['can のうしろを 原形（もとの形）にした','can&#39;t のアポストロフィ','am と can を同じ文に入れていない','文の終わりにピリオド'],
   'review':'じぶんの文の <span class="en">can</span> のうしろに○をつけよう。<span class="en">ing</span> や <span class="en">s</span> がついていたら、そこがまちがい。'},
 },
}
