# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, copybox, gmap

S = {
 'id':'u4-1', 'unit':'4 − 1', 'unit_plain':'4-1', 'title':'He is ～. / She is ～.',
 'pages':'p.62〜63',
 'hero_big':'He is my friend. ／ She is my sister.',
 'hero_jp':'彼は わたしの 友だち です ／ 彼女は わたしの 姉妹 です',
 'motto':'<span class="en">I</span>→<span class="en">am</span>、<span class="en">you</span>→<span class="en">are</span>、それ以外の1人→<span class="en">is</span>。主語で be動詞が決まる。',
 'kana':{'he':'ヒー','she':'シー','is':'イズ',"he's":'ヒーズ',"she's":'シーズ',
         'my':'マイ','friend':'フレンド','brother':'ブラザー','sister':'スィスター',
         'father':'ファーザー','mother':'マザー','teacher':'ティーチャー',
         'kind':'カインド','tall':'トール','nice':'ナイス','cute':'キュート',
         'mike':'マイク','emma':'エマ','saki':'サキ','that':'ザット','this':'ズィス'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>彼は わたしの友だちです</b>」のように、<b>自分でも相手でもない人</b>の話をする文です。'),
    ('t','男の人は <span class="en">he</span>（彼）、女の人は <span class="en">she</span>（彼女）。be動詞は <span class="en">is</span> を使います。'),
    ('h', gmap('<b>彼は</b> 友だち <b>です</b>', '<b>He is</b> my friend.',
               '<span class="en">I am</span>、<span class="en">You are</span>、そして <b><span class="en">He／She is</span></b>。主語で be動詞が決まります。')),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">He is my friend.</span><span class="t">彼は わたしの 友だち です。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">She is my sister.</span><span class="t">彼女は わたしの 姉妹 です。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">He is kind.</span><span class="t">彼は 親切 です。</span></div>
    </div>'''),
    ('t','be動詞が <span class="en">am</span> でも <span class="en">are</span> でもなく、<b><span class="en">is</span></b> になっています。ここが今回のポイントです。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜主語で be動詞が決まる', [
    ('t','ここが今回のヤマです。be動詞は<b>3種類</b>あって、<b>主語（だれの話か）だけ</b>で決まります。'),
    ('h','''<table class="kind">
      <thead><tr><th>だれが</th><th>be動詞</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k"><span class="en">I</span>（わたし）</td><td class="k" style="color:var(--key);font-weight:700;">am</td><td class="e">I <u>am</u> a student.</td></tr>
        <tr><td class="k"><span class="en">you</span>（あなた）</td><td class="k" style="color:var(--key);font-weight:700;">are</td><td class="e">You <u>are</u> a student.</td></tr>
        <tr><td class="k"><span class="en">he / she</span>（彼・彼女）</td><td class="k" style="color:var(--key);font-weight:700;">is</td><td class="e">He <u>is</u> a student.</td></tr>
      </tbody>
    </table>'''),
    ('t','おぼえ方は<b>「わたしは <span class="en">am</span>、あなたは <span class="en">are</span>、ほかは <span class="en">is</span>」</b>。声に出して3回となえてみましょう。'),
    ('t','<span class="en">He are ～.</span> や <span class="en">She am ～.</span> とは言いません。主語を見たら、be動詞はもう決まっています。'),
  ]),
  ('人の名前も <span class="en">is</span>', [
    ('t','<span class="en">he・she</span> のかわりに<b>人の名前</b>が来ても、同じく <span class="en">is</span> です。「わたし」でも「あなた」でもないからです。'),
    ('h','''<div class="eqbox">
      <span class="eq">Mike is my friend.</span>（マイクは わたしの友だちです）<br>
      <span class="eq">Emma is kind.</span>（エマは 親切です）　<b>名前 → <span class="en">is</span></b>
    </div>'''),
    ('t','一度その人のことを言ったあとは、<b><span class="en">he</span> や <span class="en">she</span> に言いかえる</b>のがふつうです。<span class="en">Mike is my friend. He is kind.</span> のように使います。'),
  ]),
  ('<span class="en">He is</span> → <span class="en">He&#39;s</span> と短くできる', [
    ('t','<span class="en">I am → I&#39;m</span>、<span class="en">You are → You&#39;re</span> と同じしくみで、短い形があります。'),
    ('h','''<table class="kind">
      <thead><tr><th>原形（もとの形）</th><th>短い形</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k">He is</td><td class="k" style="color:var(--key);font-weight:700;">He&#39;s</td><td class="e">He&#39;s my friend.</td></tr>
        <tr><td class="k">She is</td><td class="k" style="color:var(--key);font-weight:700;">She&#39;s</td><td class="e">She&#39;s my sister.</td></tr>
      </tbody>
    </table>'''),
    ('t','<b>&#39;（アポストロフィ）を忘れない</b>のは今までと同じです。<span class="en">Hes</span> や <span class="en">Shes</span> と書くとバツになります。'),
  ]),
  ('be動詞の文に 動作のことばは入らない', [
    ('t','これまでと同じルールです。<b><span class="en">is</span> と動作のことばは いっしょに使いません</b>。'),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：心臓（動詞）は 青かピンクの どちらか1つ</div>
        <p><b class="cb">青＝<span class="en">am・are・is</span></b>　<b class="cp">ピンク＝<span class="en">like・play・have</span></b>　
        青が3つに増えましたが、ルールは同じです。<br>
        <span class="xm">✕ He is like soccer ✕</span>　<span class="xm">✕ She is play tennis ✕</span></p>
      </div>
    </div>'''),
  ]),
 ],
 'quiz':[
  ('He are my friend.','He is my friend.','<span class="en">he</span> のときの be動詞は <b><span class="en">is</span></b>。<span class="en">are</span> は <span class="en">you</span> 用です。','彼は わたしの 友だち です。'),
  ('She am my sister.','She is my sister.','<span class="en">she</span> も <b><span class="en">is</span></b>。<span class="en">am</span> は <span class="en">I</span> 専用です。','彼女は わたしの 姉妹 です。'),
  ('Mike are kind.','Mike is kind.','人の名前も「わたし・あなた」ではないので <b><span class="en">is</span></b>。','マイクは やさしいです。'),
  ('Hes my friend.','He&#39;s my friend.','<b>&#39;（アポストロフィ）</b>を忘れています。<span class="en">He is</span> → <span class="en">He&#39;s</span>。','彼は わたしの 友だち です。'),
  ('He is like soccer.','He likes soccer.','心臓（動詞）が2つ。<b><span class="en">is</span> はいりません</b>（<span class="en">likes</span> の <span class="en">s</span> は 6-1 で習います）。','彼は サッカーが 好きです。'),
  ('he is my friend.','He is my friend.','文のはじめは<b>大文字</b>。<span class="en">He</span> の <span class="en">H</span> を大文字にします。','彼は わたしの 友だち です。'),
 ],
 'summary':[
  '「彼は～です」は <b><span class="en">He is ～.</span></b>、「彼女は～です」は <b><span class="en">She is ～.</span></b>',
  '<b>わたしは <span class="en">am</span>、あなたは <span class="en">are</span>、ほかは <span class="en">is</span>。</b>主語で決まる。',
  '<b>人の名前も <span class="en">is</span>。</b>一度言ったあとは <span class="en">he / she</span> に言いかえる。',
  '短い形は <b><span class="en">He&#39;s / She&#39;s</span></b>。&#39; を忘れない。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '主語が <span class="en">I</span> なら%s、<span class="en">you</span> なら%s、<span class="en">he</span> や <span class="en">she</span> なら%s。' % (bl('am'), bl('are'), bl('is')),
     '男の人は%s、女の人は%sと言う。' % (bl('he'), bl('she')),
     '人の%sが主語のときも <span class="en">is</span> を使う。' % bl('名前'),
     '<span class="en">He is</span> を短くすると%sになる。' % bl("He's", False),
     'be動詞の文に%sのことばは入れない。心臓（動詞）は1つだけ。' % bl('動作'),
   ]),
   'words':'語群：<span class="en">am</span> ／ <span class="en">are</span> ／ <span class="en">is</span> ／ <span class="en">he</span> ／ <span class="en">she</span> ／ <span class="en">He&#39;s</span> ／ 名前 ／ 動作',
   'exp':'<b>なぜ？</b>　be動詞は「＝」のしるしですが、<b>だれの話かによって形を変える</b>という決まりがあります。<br>'
         '日本語にはないしくみなので、<b>「わたしは am、あなたは are、ほかは is」</b>と口でおぼえてしまうのが一番速いです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--key);">B　<span class="en">am</span>？ <span class="en">are</span>？ <span class="en">is</span>？<em>（　）に正しい be動詞を書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。（　）の<b>前にある主語だけ</b>を見ましょう。',
   'body':grid2([
     '1. <span class="en">He%smy friend.</span>' % bl('is'),
     '2. <span class="en">I%sa student.</span>' % bl('am'),
     '3. <span class="en">She%skind.</span>' % bl('is'),
     '4. <span class="en">You%stall.</span>' % bl('are'),
     '5. <span class="en">Mike%smy brother.</span>' % bl('is'),
     '6. <span class="en">I%sfrom Nagano.</span>' % bl('am'),
     '7. <span class="en">She%smy teacher.</span>' % bl('is'),
     '8. <span class="en">You%sa soccer fan.</span>' % bl('are'),
     '9. <span class="en">Emma%snice.</span>' % bl('is'),
     '10. <span class="en">He%stwelve.</span>' % bl('is'),
   ]),
   'exp':'<b>見つけ方</b>　主語を見るだけ。<br>'
         '<span class="en">I</span> → <span class="en">am</span>（2・6）　<span class="en">you</span> → <span class="en">are</span>（4・8）<br>'
         '<span class="en">he・she・人の名前</span> → <span class="en">is</span>（1・3・5・7・9・10）'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--key);">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. He is my friend.','○'), ('2. He are my friend.','✕'),
     ('3. She&#39;s kind.','○'), ('4. She am kind.','✕'),
     ('5. Mike is my brother.','○'), ('6. Mike are my brother.','✕'),
     ('7. He is a student.','○'), ('8. Hes a student.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">He is my friend.</span>（<span class="en">he</span> には <span class="en">is</span>）<br>'
         '4 → <span class="en">She is kind.</span>（<span class="en">she</span> にも <span class="en">is</span>）　6 → <span class="en">Mike is my brother.</span>（名前も <span class="en">is</span>）<br>'
         '8 → <span class="en">He&#39;s a student.</span>（&#39;を入れる）'},
  {'h':'<h3 class="sec sec2">D　<span class="en">he</span>？ それとも <span class="en">she</span>？<em>言いかえるとどちらになるか、記号で答えよう</em></h3>',
   'hint':'<span class="chip">ア</span> <span class="en">he</span>（男の人）　<span class="chip" style="background:var(--gv);">イ</span> <span class="en">she</span>（女の人）',
   'body':grid2([
     '1. <span class="en">Mike</span>（男の子の名前）%s' % bl('ア'),
     '2. <span class="en">Emma</span>（女の子の名前）%s' % bl('イ'),
     '3. <span class="en">my sister</span>（わたしの姉妹）%s' % bl('イ'),
     '4. <span class="en">my brother</span>（わたしの兄弟）%s' % bl('ア'),
     '5. <span class="en">my mother</span>（わたしの母）%s' % bl('イ'),
     '6. <span class="en">my father</span>（わたしの父）%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　<span class="en">he</span> は男の人、<span class="en">she</span> は女の人。どちらも be動詞は <span class="en">is</span> です。<br>'
         '<span class="en">brother</span>（兄弟）と <span class="en">sister</span>（姉妹）、<span class="en">father</span>（父）と <span class="en">mother</span>（母）は、セットでおぼえましょう。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　主語を見るだけ。<span class="en">I</span>→<span class="en">am</span>、<span class="en">you</span>→<span class="en">are</span>、それ以外→<span class="en">is</span>。',
   'body':ol([
     ('<span class="jp-cue">彼はわたしの友だちです。</span>　<span class="en">He%smy friend.</span>' % bl('is'),
      '<span class="en">he</span> なので <b><span class="en">is</span></b>。'),
     ('<span class="jp-cue">彼女はわたしの姉妹です。</span>　<span class="en">She%smy sister.</span>' % bl('is'),
      '<span class="en">she</span> も <b><span class="en">is</span></b>。'),
     ('<span class="jp-cue">わたしは生徒です。</span>　<span class="en">I%sa student.</span>' % bl('am'),
      '<span class="en">I</span> なので <b><span class="en">am</span></b>。'),
     ('<span class="jp-cue">あなたは背が高いです。</span>　<span class="en">You%stall.</span>' % bl('are'),
      '<span class="en">you</span> なので <b><span class="en">are</span></b>。'),
     ('<span class="jp-cue">マイクはわたしの兄弟です。</span>　<span class="en">Mike%smy brother.</span>' % bl('is'),
      '人の名前も <b><span class="en">is</span></b>。'),
     ('<span class="jp-cue">彼は親切です。</span>　<span class="en">%s%skind.</span>' % (bl('He'), bl('is')),
      '（　）が2つ。<b><span class="en">He</span> → <span class="en">is</span></b>。'),
     ('<span class="jp-cue">彼女は先生です。</span>　<span class="en">She is%steacher.</span>' % bl('a'),
      '職業には <b><span class="en">a</span></b> をつける。'),
     ('<span class="jp-cue">短い形にしよう。</span>　<span class="en">He is my friend.</span> →　<span class="en">%smy friend.</span>' % bl("He's", False),
      '<b><span class="en">He is</span> ＝ <span class="en">He&#39;s</span></b>。&#39; を忘れずに。'),
     ('<span class="jp-cue">短くしない形にしよう。</span>　<span class="en">She&#39;s kind.</span> →　<span class="en">%s%skind.</span>' % (bl('She'), bl('is')),
      '<span class="en">She&#39;s</span> をもどすと <b><span class="en">She is</span></b>。'),
     ('<span class="jp-cue">彼は12歳です。</span>　<span class="en">He%stwelve.</span>' % bl('is'),
      '年れいも <span class="en">is</span> のうしろ。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　主語がどれかを先に決めると、be動詞もすぐ決まります。',
   'body':ol([
     ('<span class="jp-cue">彼はわたしの友だちです。</span>　<span class="paren en">（ my friend / He / is ）</span>' + line('He is my friend.'),
      '<span class="en">my friend</span> でひとかたまり。'),
     ('<span class="jp-cue">彼女は親切です。</span>　<span class="paren en">（ kind / is / She ）</span>' + line('She is kind.'),
      '<span class="en">she</span> → <span class="en">is</span> → ようす の順。'),
     ('<span class="jp-cue">マイクはわたしの兄弟です。</span>　<span class="paren en">（ brother / is / my / Mike ）</span>' + line('Mike is my brother.'),
      '<span class="en">my brother</span> でひとかたまり。'),
     ('<span class="jp-cue">わたしは生徒です。</span>　<span class="paren en">（ a / student / am / I ）</span>' + line('I am a student.'),
      '語群に <span class="en">am</span> がある。主語は <span class="en">I</span>。'),
     ('<span class="jp-cue">彼女はわたしの先生です。</span>　<span class="paren en">（ teacher / my / She&#39;s ）</span>' + line('She&#39;s my teacher.'),
      '語群に <span class="en">is</span> がなく <span class="en">She&#39;s</span> がある。<b>語群を見れば形が分かる。</b>'),
     ('<span class="jp-cue">あなたは背が高いです。</span>　<span class="paren en">（ tall / You / are ）</span>' + line('You are tall.'),
      '語群に <span class="en">are</span> がある。主語は <span class="en">you</span>。'),
     ('<span class="jp-cue">彼は親切です。</span>　<span class="paren en">（ kind / He&#39;s ）</span>' + line('He&#39;s kind.'),
      '2語だけ。<span class="en">He&#39;s</span> が <span class="en">He is</span> の代わりです。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('彼はわたしの友だちです。' + wline('He is my friend.'),
      '<span class="en">He&#39;s my friend.</span> でも正解。'),
     ('彼女はわたしの姉妹です。' + wline('She is my sister.'),
      '<span class="en">She&#39;s my sister.</span> でも正解。'),
     ('マイクは親切です。' + wline('Mike is kind.'),
      '人の名前も <span class="en">is</span>。名前は大文字ではじめる。'),
     ('彼女はわたしの先生です。' + wline('She is my teacher.'),
      '職業に <span class="en">my</span> がつくときは <span class="en">a</span> はいりません。'),
     ('わたしは生徒です。' + wline('I am a student.'),
      '主語が <span class="en">I</span> にもどったので <span class="en">am</span>。'),
     ('あなたは背が高いです。' + wline('You are tall.'),
      '主語が <span class="en">you</span> なので <span class="en">are</span>。3つそろいました。'),
   ]),
   'words':'<span class="en">my friend ／ my sister ／ kind ／ my teacher ／ a student ／ tall</span>'},
  'l4':{'sub':'じぶんの家族や友だちをしょうかいしよう',
   'cond':['<span class="en">He is ～.</span> か <span class="en">She is ～.</span> の文を <b>3つ以上</b>',
           'はじめに<b>名前や関係</b>を書く（<span class="en">Mike is my friend.</span> など）',
           '<span class="en">I am ～.</span> の文も <b>1つ</b> 入れる'],
   'example':['Mike is my friend. He is kind.','Saki is my sister. She is twelve.','I am a soccer fan.'],
   'note':'これは例です。同じでなくてかまいません。友だち・家族・先生 のだれかをしょうかいしてみよう。',
   'check':['he / she には is','I には am、you には are','He&#39;s / She&#39;s のアポストロフィ','名前は大文字ではじめる'],
   'review':'じぶんの文の be動詞に○をつけよう。<span class="en">he</span> や <span class="en">she</span> のそばに <span class="en">am</span> や <span class="en">are</span> があったら、そこがまちがい。'},
 },
}
