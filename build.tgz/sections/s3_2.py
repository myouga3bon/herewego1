# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, copybox, gmap

S = {
 'id':'u3-2', 'unit':'3 − 2', 'unit_plain':'3-2', 'title':'動詞の -ing 形',
 'pages':'p.50〜51',
 'hero_big':'I like dancing.',
 'hero_jp':'わたしは おどることが 好きです',
 'motto':'動詞を「～すること」にするには <span class="en">ing</span> をつける。<span class="en">can</span> のうしろは 原形（もとの形）のまま。',
 'kana':{'dancing':'ダンスィング','dance':'ダンス','singing':'スィンギング','sing':'スィング',
         'swimming':'スウィミング','swim':'スウィム','running':'ラニング','cooking':'クッキング',
         'cook':'クック','reading':'リーディング','read':'リード','playing':'プレイイング',
         'watching':'ウォッチング','studying':'スタディイング','study':'スタディ',
         'eating':'イーティング','eat':'イート','good':'グッド','at':'アット','enjoy':'エンジョイ'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>おどること</b>が 好きです」のように、動作を「<b>～すること</b>」に変えて言うやり方です。'),
    ('t','動詞のうしろに <span class="en">ing</span> をつけるだけで、ものの名前のようなことばになります。'),
    ('h', gmap('おどる<b>こと</b>', 'danc<b>ing</b>',
               '<b>ing</b> が「～すること」にあたります。<span class="en">dance → dancing</span>、<span class="en">sing → singing</span>。')),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I like dancing.</span><span class="t">わたしは おどることが 好きです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I like singing.</span><span class="t">わたしは 歌うことが 好きです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I&#39;m good at cooking.</span><span class="t">わたしは 料理をすることが 得意です。</span></div>
    </div>'''),
    ('t','<span class="en">dancing</span>（おどること）、<span class="en">singing</span>（歌うこと）。<b><span class="en">ing</span> がつくと「～すること」という名前のことば</b>になります。'),
    ('h', copybox()),
  ]),
  ('<span class="en">ing</span> のつけ方は3パターン', [
    ('t','ほとんどは<b>そのまま <span class="en">ing</span> をつける</b>だけ。ただし2つだけ例外があります。'),
    ('h','''<table class="kind">
      <thead><tr><th>パターン</th><th>やり方</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k">ふつう</td><td class="k">そのまま <span class="en">ing</span></td><td class="e">play → play<u>ing</u>　sing → sing<u>ing</u></td></tr>
        <tr><td class="k"><span class="en">e</span> で終わる</td><td class="k"><span class="en">e</span> を消して <span class="en">ing</span></td><td class="e">dance → danc<u>ing</u>　take → tak<u>ing</u></td></tr>
        <tr><td class="k">短くて最後が1字</td><td class="k">最後の字を<b>重ねて</b> <span class="en">ing</span></td><td class="e">swim → swi<u>mm</u>ing　run → ru<u>nn</u>ing</td></tr>
      </tbody>
    </table>'''),
    ('t','まずは<b>ふつうのパターン</b>をしっかり。<span class="en">dance → dancing</span> と <span class="en">swim → swimming</span> の2つは、よく出るので形ごとおぼえてしまいましょう。'),
  ]),
  ('かなり大事｜<span class="en">can</span> のうしろは <span class="en">ing</span> をつけない', [
    ('t','ここが今回のヤマです。<span class="en">ing</span> を習ったとたんに、<b><span class="en">can</span> のうしろにも <span class="en">ing</span> をつけてしまう人</b>がとても多くなります。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-smile"/></svg>
          <span>◯ ing をつける<small>「～すること」と言うとき</small></span></div>
        <div class="in"><div class="ex">I like swimming.<br>I&#39;m good at cooking.</div>
          <div class="memo"><span class="en">like</span> や <span class="en">good at</span> のうしろ。</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-run"/></svg>
          <span>✕ ing をつけない<small>「～できる」と言うとき</small></span></div>
        <div class="in"><div class="ex">I can swim.<br>I can cook.</div>
          <div class="memo"><span class="en">can</span> のうしろは<b>原形（もとの形）</b>。</div></div>
      </div>
    </div>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：<span class="en">can</span> のうしろは すっぴん</div>
        <p><b class="cb"><span class="en">like + ing</span></b>　<b class="cp"><span class="en">can + 原形（もとの形）</span></b>　
        前にあることばを見て決めます。<br>
        <span class="xm">✕ I can swimming ✕</span>　<span class="xm">✕ I like swim ✕</span></p>
      </div>
    </div>'''),
    ('t','見分け方は<b>前にあることば</b>を見るだけ。<span class="en">can</span> なら 原形（もとの形）、<span class="en">like・good at</span> なら <span class="en">ing</span> です。'),
  ]),
  ('<span class="en">ing</span> が使えるのはこんなとき', [
    ('t','<span class="en">ing</span> の形は「～すること」という<b>名前のことば</b>なので、<span class="en">music</span> や <span class="en">soccer</span> と同じ場所に入れられます。'),
    ('h','''<div class="eqbox">
      <span class="eq">I like music.</span>（音楽が好き）　→　<span class="eq">I like singing.</span>（歌うことが好き）<br>
      <span class="en">music</span> の場所に <span class="en">singing</span> を入れただけ。<b>場所は同じ</b>です。
    </div>'''),
    ('t','<span class="en">I&#39;m good at ～.</span>（～が得意です）のうしろにも入ります。<span class="en">I&#39;m good at soccer.</span> / <span class="en">I&#39;m good at cooking.</span> のように使えます。'),
  ]),
 ],
 'quiz':[
  ('I can swimming.','I can swim.','<span class="en">can</span> のうしろは <b>原形（もとの形）</b>。<span class="en">ing</span> はつけません。','わたしは 泳ぐことが できます。'),
  ('I like swim.','I like swimming.','「泳ぐこと」と言いたいので <b><span class="en">swimming</span></b>。<span class="en">ing</span> が必要です。','わたしは 泳ぐことが 好きです。'),
  ('I like danceing.','I like dancing.','<span class="en">dance</span> は <span class="en">e</span> で終わるので、<b><span class="en">e</span> を消して <span class="en">ing</span></b>。','わたしは おどることが 好きです。'),
  ('I like swiming.','I like swimming.','<span class="en">swim</span> は<b>最後の <span class="en">m</span> を重ねて</b> <span class="en">swimming</span>。','わたしは 泳ぐことが 好きです。'),
  ('I am like dancing.','I like dancing.','心臓（動詞）が2つ。<b><span class="en">am</span> はいりません</b>。','わたしは おどることが 好きです。'),
  ('I&#39;m good at cook.','I&#39;m good at cooking.','<span class="en">good at</span> のうしろは <b><span class="en">ing</span> の形</b>。','わたしは 料理を するのが 得意です。'),
 ],
 'summary':[
  '動詞に <b><span class="en">ing</span></b> をつけると「<b>～すること</b>」という名前のことばになる。',
  '<span class="en">e</span> で終わる語は <span class="en">e</span> を消して（<span class="en">dance → dancing</span>）、短い語は最後を重ねて（<span class="en">swim → swimming</span>）。',
  '<b><span class="en">like</span>・<span class="en">good at</span> のうしろは <span class="en">ing</span>。</b>',
  '<b><span class="en">can</span> のうしろは 原形（もとの形）。</b><span class="en">ing</span> をつけない。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '動詞に%sをつけると「～すること」という意味になる。' % bl('ing'),
     '<span class="en">dance</span> のように <span class="en">e</span> で終わる語は、<span class="en">e</span> を%sして <span class="en">ing</span> をつける。' % bl('消'),
     '<span class="en">swim</span> のように短い語は、最後の字を%sて <span class="en">ing</span> をつける。' % bl('重ね'),
     '<span class="en">like</span> や <span class="en">good at</span> のうしろは%sの形。' % bl('ing'),
     '%sのうしろは%sにする。<span class="en">ing</span> はつけない。' % (bl('can'), bl('原形', False)),
   ]),
   'words':'語群：<span class="en">ing</span> ／ <span class="en">can</span> ／ 原形 ／ 消 ／ 重ね',
   'exp':'<b>なぜ？</b>　<span class="en">ing</span> がついた形は、もう「動作」ではなく<b>「ものの名前」</b>になります。だから <span class="en">music</span> と同じ場所に入れられるのです。<br>'
         '<span class="en">can</span> のうしろに必要なのは<b>動作のことば</b>なので、名前になってしまった <span class="en">ing</span> の形は入れられません。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--gv);">B　<span class="en">ing</span> をつける？ つけない？<em>（　）に正しい形を書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。（　）の<b>前にあることば</b>を見ましょう。<span class="en">can</span> なら 原形（もとの形）、<span class="en">like</span> なら <span class="en">ing</span>。',
   'body':grid2([
     '1. <span class="en">I like%s.</span>（swim）' % bl('swimming', False),
     '2. <span class="en">I can%s.</span>（swim）' % bl('swim'),
     '3. <span class="en">I like%s.</span>（dance）' % bl('dancing', False),
     '4. <span class="en">I can%s.</span>（cook）' % bl('cook'),
     '5. <span class="en">I&#39;m good at%s.</span>（sing）' % bl('singing', False),
     '6. <span class="en">I can%sfast.</span>（run）' % bl('run'),
     '7. <span class="en">I like%s.</span>（read）' % bl('reading', False),
     '8. <span class="en">I can%sthe piano.</span>（play）' % bl('play'),
     '9. <span class="en">I like%ssoccer.</span>（play）' % bl('playing', False),
     '10. <span class="en">I can&#39;t%s.</span>（dance）' % bl('dance'),
   ]),
   'exp':'<b>見つけ方</b>　（　）のすぐ前を見るだけ。<br>'
         '<span class="en">like</span>・<span class="en">good at</span> → <b><span class="en">ing</span></b>（1・3・5・7・9）　<span class="en">can</span>・<span class="en">can&#39;t</span> → <b>原形（もとの形）</b>（2・4・6・8・10）<br>'
         '1は <span class="en">m</span> を重ねて <span class="en">swimming</span>、3は <span class="en">e</span> を消して <span class="en">dancing</span>。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--gv);">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. I like swimming.','○'), ('2. I can swimming.','✕'),
     ('3. I like dancing.','○'), ('4. I like danceing.','✕'),
     ('5. I can swim.','○'), ('6. I like swim.','✕'),
     ('7. I&#39;m good at cooking.','○'), ('8. I like swiming.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">I can swim.</span>（ing を取る）　4 → <span class="en">I like dancing.</span>（e を消す）<br>'
         '6 → <span class="en">I like swimming.</span>（ing をつける）　8 → <span class="en">I like swimming.</span>（m を重ねる）<br>'
         '2と6は<b>つけるか つけないか</b>のまちがい。4と8は<b>つけ方</b>のまちがいです。'},
  {'h':'<h3 class="sec sec2">D　<span class="en">ing</span> のつけ方　正しいほうを選ぼう</h3>',
   'hint':'つけ方は3パターン。そのまま／<span class="en">e</span> を消す／最後を重ねる。',
   'body':grid2([
     '1. <span class="en">sing →（ア singing ／イ singging）</span>%s' % bl('ア'),
     '2. <span class="en">dance →（ア danceing ／イ dancing）</span>%s' % bl('イ'),
     '3. <span class="en">swim →（ア swiming ／イ swimming）</span>%s' % bl('イ'),
     '4. <span class="en">play →（ア playing ／イ plaing）</span>%s' % bl('ア'),
     '5. <span class="en">run →（ア running ／イ runing）</span>%s' % bl('ア'),
     '6. <span class="en">read →（ア readding ／イ reading）</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　ふつうはそのまま（1・4・6）。<span class="en">e</span> で終わる語は <span class="en">e</span> を消す（2）。短くて最後が1字の語は重ねる（3・5）。<br>'
         '<span class="en">read</span> は <span class="en">ea</span> と母音が2つ並んでいるので、重ねません。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　（　）の<b>前</b>を見る。<span class="en">like</span>・<span class="en">good at</span> なら <span class="en">ing</span>、<span class="en">can</span> なら 原形（もとの形）。',
   'body':ol([
     ('<span class="jp-cue">わたしはおどることが好きです。</span>　<span class="en">I like%s.</span>' % bl('dancing', False),
      '<span class="en">dance</span> の <span class="en">e</span> を消して <b><span class="en">dancing</span></b>。'),
     ('<span class="jp-cue">わたしは泳ぐことが好きです。</span>　<span class="en">I like%s.</span>' % bl('swimming', False),
      '<span class="en">m</span> を重ねて <b><span class="en">swimming</span></b>。'),
     ('<span class="jp-cue">わたしは泳ぐことができます。</span>　<span class="en">I can%s.</span>' % bl('swim'),
      '<span class="en">can</span> のうしろは <b>原形（もとの形）</b>。2番とくらべよう。'),
     ('<span class="jp-cue">わたしは歌うことが好きです。</span>　<span class="en">I like%s.</span>' % bl('singing', False),
      'そのまま <span class="en">ing</span> をつけて <b><span class="en">singing</span></b>。'),
     ('<span class="jp-cue">わたしは料理をすることが得意です。</span>　<span class="en">I&#39;m good at%s.</span>' % bl('cooking', False),
      '<span class="en">good at</span> のうしろも <b><span class="en">ing</span></b>。'),
     ('<span class="jp-cue">わたしは料理をすることができます。</span>　<span class="en">I can%s.</span>' % bl('cook'),
      '5番とくらべよう。<span class="en">can</span> なら <b>原形（もとの形）</b>。'),
     ('<span class="jp-cue">わたしは本を読むことが好きです。</span>　<span class="en">I like%sbooks.</span>' % bl('reading', False),
      'そのまま <span class="en">ing</span>。<span class="en">books</span> は そのうしろ。'),
     ('<span class="jp-cue">わたしはサッカーをすることが好きです。</span>　<span class="en">I like%ssoccer.</span>' % bl('playing', False),
      '<b><span class="en">playing soccer</span></b> で「サッカーをすること」。'),
     ('<span class="jp-cue">わたしは速く走ることができます。</span>　<span class="en">I can%sfast.</span>' % bl('run'),
      '<span class="en">can</span> のうしろ。<span class="en">running</span> にしない。'),
     ('<span class="jp-cue">わたしはおどることができません。</span>　<span class="en">I can&#39;t%s.</span>' % bl('dance'),
      '<span class="en">can&#39;t</span> のうしろも <b>原形（もとの形）</b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群にある形をよく見る。<span class="en">ing</span> がついた形が入っていれば、それを使います。',
   'body':ol([
     ('<span class="jp-cue">わたしはおどることが好きです。</span>　<span class="paren en">（ dancing / I / like ）</span>' + line('I like dancing.'),
      '語群が <span class="en">dancing</span>。<b>形はもう決まっています。</b>'),
     ('<span class="jp-cue">わたしは泳ぐことができます。</span>　<span class="paren en">（ swim / can / I ）</span>' + line('I can swim.'),
      '語群が <span class="en">swim</span>（原形（もとの形））。<span class="en">can</span> とセット。'),
     ('<span class="jp-cue">わたしは歌うことが好きです。</span>　<span class="paren en">（ singing / like / I ）</span>' + line('I like singing.'),
      '1番と同じ形。'),
     ('<span class="jp-cue">わたしは料理をすることが得意です。</span>　<span class="paren en">（ cooking / good at / I&#39;m ）</span>' + line('I&#39;m good at cooking.'),
      '<span class="en">good at</span> でひとかたまり。そのうしろに <span class="en">ing</span>。'),
     ('<span class="jp-cue">わたしはサッカーをすることが好きです。</span>　<span class="paren en">（ soccer / I / playing / like ）</span>' + line('I like playing soccer.'),
      '<span class="en">playing</span> → <span class="en">soccer</span> の順。'),
     ('<span class="jp-cue">わたしは料理をすることができません。</span>　<span class="paren en">（ cook / can&#39;t / I ）</span>' + line('I can&#39;t cook.'),
      '語群が <span class="en">cook</span>。<span class="en">can&#39;t</span> とセット。'),
     ('<span class="jp-cue">わたしは本を読むことが好きです。</span>　<span class="paren en">（ books / reading / I / like ）</span>' + line('I like reading books.'),
      '<span class="en">reading books</span> で「本を読むこと」。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしはおどることが好きです。' + wline('I like dancing.'),
      '<span class="en">e</span> を消して <span class="en">dancing</span>。'),
     ('わたしは泳ぐことが好きです。' + wline('I like swimming.'),
      '<span class="en">m</span> を重ねて <span class="en">swimming</span>。'),
     ('わたしは泳ぐことができます。' + wline('I can swim.'),
      '<span class="en">can</span> のうしろは 原形（もとの形）。2番とまちがえないこと。'),
     ('わたしは料理をすることが得意です。' + wline('I&#39;m good at cooking.'),
      '<span class="en">I am good at cooking.</span> でも正解。'),
     ('わたしは歌うことが好きです。' + wline('I like singing.'),
      'そのまま <span class="en">ing</span>。'),
     ('わたしはサッカーをすることが好きです。' + wline('I like playing soccer.'),
      '<span class="en">I like soccer.</span> も通じますが、ここは「すること」なので <span class="en">playing</span>。'),
   ]),
   'words':'<span class="en">dancing ／ swimming ／ swim ／ cooking ／ singing ／ playing soccer</span>'},
  'l4':{'sub':'じぶんの「好きなこと・得意なこと」を書こう',
   'cond':['<span class="en">I like ～ing.</span> の文を <b>2つ以上</b>',
           '<span class="en">I&#39;m good at ～ing.</span> の文を <b>1つ以上</b>',
           '<span class="en">I can ～.</span> の文も <b>1つ</b> 入れる（<span class="en">ing</span> をつけない）'],
   'example':['I like singing. I like playing soccer.','I&#39;m good at cooking.','I can swim.'],
   'note':'これは例です。同じでなくてかまいません。スポーツ・音楽・料理・読書 から選ぶと書きやすいです。',
   'check':['like のうしろは ing','can のうしろは 原形（もとの形）','dance は e を消す、swim は m を重ねる','文の終わりにピリオド'],
   'review':'じぶんの文の <span class="en">can</span> のうしろに○をつけよう。<span class="en">ing</span> がついていたら、そこがまちがい。'},
 },
}
