# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'u5-1', 'unit':'5 − 1', 'unit_plain':'5-1', 'title':"命令文 / Don't ～. / Let's ～.",
 'pages':'p.74〜75',
 'hero_big':'Look at this. ／ Don&#39;t run. ／ Let&#39;s go.',
 'hero_jp':'これを見て ／ 走らないで ／ 行きましょう',
 'motto':'命令文は<b>主語をつけず、動詞の原形（もとの形）で始める</b>。<span class="en">Don&#39;t</span> も <span class="en">Let&#39;s</span> も そのうしろは 原形（もとの形）。',
 'kana':{'look':'ルック','at':'アット','this':'ズィス','open':'オウプン',
         'close':'クロウズ','listen':'リスン','stand':'スタンド','up':'アップ',
         'sit':'シット','down':'ダウン','run':'ラン','go':'ゴウ',
         "let's":'レッツ','lets':'レッツ','come':'カム','here':'ヒア',
         'please':'プリーズ','door':'ドア','window':'ウィンドウ','book':'ブック',
         'eat':'イート','touch':'タッチ','quiet':'クワイエット','be':'ビー'},
 'blocks':[
  ('きほんの文', [
    ('t','今回は<b>相手に何かをたのむ・さそう文</b>です。大きな特ちょうは、<b>主語（<span class="en">You</span>）をつけない</b>ことです。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Look at this.</span><span class="t">これを 見て ください。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Don&#39;t run here.</span><span class="t">ここで 走らないで ください。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Let&#39;s go.</span><span class="t">行きましょう。</span></div>
    </div>'''),
    ('t','3つとも <span class="en">I</span> も <span class="en">You</span> もありません。<b>動詞から文が始まっている</b>のが分かりますか。ここが今回のポイントです。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜主語をつけず、動詞から始める', [
    ('t','ここが今回のヤマです。相手に直接言う文なので、<b>「あなたは」を言わなくても分かる</b>のです。だから省略します。'),
    ('h','''<div class="eqbox">
      <span class="eq">You look at this.</span>（あなたはこれを見ます）<br>
      → <span class="eq">Look at this.</span>（これを見て）　<b><span class="en">You</span> を取って、動詞から始める</b>
    </div>'''),
    ('h','''<div class="blocks">
      <div class="blk line" style="border-color:#BDB7AA;color:#9A948A;"><div class="w">You</div><div class="r">つけない</div></div>
      <div class="plus">→</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">Look</div><div class="r">原形（もとの形）で始める</div></div>
      <div class="plus">＋</div>
      <div class="blk line" style="border-color:var(--gv);color:var(--gv);"><div class="w">そのあと</div><div class="r">at this / the door …</div></div>
    </div>'''),
    ('t','動詞は<b>かざりのない「原形（もとの形）」</b>。<span class="en">Looks</span> や <span class="en">Looking</span> にはしません。<span class="en">can</span> のうしろと同じルールです。'),
    ('t','やさしく言いたいときは <b><span class="en">please</span></b> をつけます。<span class="en">Please look at this.</span> または <span class="en">Look at this, please.</span> のどちらでもよいです。'),
  ]),
  ('「～しないで」は <span class="en">Don&#39;t</span> を前に置く', [
    ('t','やめてほしいことを言うときは、<b>文の前に <span class="en">Don&#39;t</span> を置く</b>だけ。うしろは そのままです。'),
    ('h','''<table class="kind">
      <thead><tr><th>意味</th><th>たのむ文</th><th>やめてもらう文</th></tr></thead>
      <tbody>
        <tr><td class="k">走る</td><td class="e">Run.</td><td class="e" style="color:var(--ng);"><u>Don&#39;t</u> run.</td></tr>
        <tr><td class="k">開ける</td><td class="e">Open the door.</td><td class="e" style="color:var(--ng);"><u>Don&#39;t</u> open the door.</td></tr>
        <tr><td class="k">食べる</td><td class="e">Eat here.</td><td class="e" style="color:var(--ng);"><u>Don&#39;t</u> eat here.</td></tr>
      </tbody>
    </table>'''),
    ('t','1-2 で習った <span class="en">don&#39;t</span> と同じことばですが、<b>命令文では文のいちばん前</b>に来ます。<span class="en">I don&#39;t ～.</span> のときは <span class="en">I</span> のうしろでしたね。'),
  ]),
  ('「～しましょう」は <span class="en">Let&#39;s</span>', [
    ('t','相手をさそうときは <b><span class="en">Let&#39;s</span></b> を前に置きます。「いっしょに～しよう」という意味になります。'),
    ('h','''<div class="eqbox" style="border-left-color:#7A4FBF;background:rgba(122,79,191,.07);">
      <span class="eq" style="color:#7A4FBF;">Let&#39;s go.</span>（行きましょう）　<span class="eq" style="color:#7A4FBF;">Let&#39;s play soccer.</span>（サッカーをしましょう）<br>
      <span class="en">Let&#39;s</span> のうしろも <b>原形（もとの形）</b>。&#39;（アポストロフィ）を忘れずに。
    </div>'''),
    ('t','答えるときは <span class="en">Yes, let&#39;s.</span>（そうしましょう）や <span class="en">OK.</span>、<span class="en">Sure.</span> などを使います。'),
  ]),
  ('3つの形をくらべる', [
    ('t','どれも<b>主語をつけず、うしろは 原形（もとの形）</b>。ちがうのは<b>先頭のことば</b>だけです。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-smile"/></svg>
          <span>◯ 原形（もとの形）<small>命令文・Don&#39;t・Let&#39;s のうしろ</small></span></div>
        <div class="in"><div class="ex">Look at this.<br>Don&#39;t run.<br>Let&#39;s go.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-run"/></svg>
          <span>✕ 主語をつけない<small>You はいらない</small></span></div>
        <div class="in"><div class="ex">You look at this.<br>You don&#39;t run.</div>
          <div class="memo">これは「あなたは～します」というふつうの文になってしまいます。</div></div>
      </div>
    </div>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：命令文は 動詞から始めて、うしろは すっぴん</div>
        <p><b class="cb">主語なし</b>　<b class="cp">動詞は 原形（もとの形）</b>　
        <span class="en">Don&#39;t</span> も <span class="en">Let&#39;s</span> も、このルールのままです。<br>
        <span class="xm">✕ You look at this ✕</span>　<span class="xm">✕ Let&#39;s going ✕</span></p>
      </div>
    </div>'''),
  ]),
 ],
 'quiz':[
  ('You look at this.','Look at this.','命令文は<b>主語をつけません</b>。<span class="en">You</span> を取って動詞から始めます。','これを 見て ください。'),
  ('Looks at this.','Look at this.','動詞は <b>原形（もとの形）</b>。<span class="en">s</span> はつけません。','これを 見て ください。'),
  ('Don&#39;t running here.','Don&#39;t run here.','<span class="en">Don&#39;t</span> のうしろは <b>原形（もとの形）</b>。<span class="en">ing</span> はつけません。','ここで 走らないで ください。'),
  ('Dont run here.','Don&#39;t run here.','<b>&#39;（アポストロフィ）</b>を忘れています。','ここで 走らないで ください。'),
  ('Let&#39;s going.','Let&#39;s go.','<span class="en">Let&#39;s</span> のうしろも <b>原形（もとの形）</b>。','行きましょう。'),
  ('Run don&#39;t here.','Don&#39;t run here.','<span class="en">Don&#39;t</span> は文の<b>いちばん前</b>。動詞のうしろではありません。','ここで 走らないで ください。'),
 ],
 'summary':[
  '命令文は <b>主語をつけず、動詞の原形（もとの形）で始める</b>。（<span class="en">Look at this.</span>）',
  '「～しないで」は <b><span class="en">Don&#39;t</span> を文のいちばん前</b>に置く。',
  '「～しましょう」は <b><span class="en">Let&#39;s</span></b>。&#39; を忘れない。',
  '<b><span class="en">Don&#39;t</span> も <span class="en">Let&#39;s</span> も、うしろは 原形（もとの形）。</b><span class="en">ing</span> も <span class="en">s</span> もつけない。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '命令文は%sをつけず、動詞の%sで始める。' % (bl('主語'), bl('原形', False)),
     '「～しないで」は%sを文のいちばん%sに置く。' % (bl("Don't"), bl('前')),
     '「～しましょう」は%sを前に置く。' % bl("Let's"),
     'やさしく言いたいときは%sをつける。' % bl('please'),
     '<span class="en">Don&#39;t</span> や <span class="en">Let&#39;s</span> のうしろの動詞も%sにする。' % bl('原形', False),
   ]),
   'words':'語群：<span class="en">Don&#39;t</span> ／ <span class="en">Let&#39;s</span> ／ <span class="en">please</span> ／ 原形 ／ 主語 ／ 前',
   'exp':'<b>なぜ？</b>　命令文は<b>目の前の相手に直接言う文</b>です。「あなたは」と言わなくても、だれに言っているかは分かります。だから主語を省くのです。<br>'
         '動詞が 原形（もとの形）になるのは、<span class="en">can</span> や <span class="en">want to</span> のうしろと同じ考え方です。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--gv);">B　<span class="en">Don&#39;t</span>？ <span class="en">Let&#39;s</span>？ それとも 動詞だけ？<em>（　）に入るものを書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。日本語の終わりを見ましょう。「しないで」→<span class="en">Don&#39;t</span>／「しましょう」→<span class="en">Let&#39;s</span>／「して」→動詞だけ。',
   'body':grid2([
     '1. <span class="en">%srun here.</span>（走らないで）' % bl("Don't"),
     '2. <span class="en">%sgo.</span>（行きましょう）' % bl("Let's"),
     '3. <span class="en">%sat this.</span>（これを見て）' % bl('Look'),
     '4. <span class="en">%seat here.</span>（食べないで）' % bl("Don't"),
     '5. <span class="en">%splay soccer.</span>（しましょう）' % bl("Let's"),
     '6. <span class="en">%sthe door.</span>（開けて）' % bl('Open'),
     '7. <span class="en">%stouch this.</span>（さわらないで）' % bl("Don't"),
     '8. <span class="en">%ssing together.</span>（歌いましょう）' % bl("Let's"),
     '9. <span class="en">%shere.</span>（来て）' % bl('Come'),
     '10. <span class="en">%sopen the window.</span>（開けないで）' % bl("Don't"),
   ]),
   'exp':'<b>見つけ方</b>　日本語の終わりを見るだけ。<br>'
         '「<b>～しないで</b>」→ <span class="en">Don&#39;t</span>（1・4・7・10）　「<b>～しましょう</b>」→ <span class="en">Let&#39;s</span>（2・5・8）<br>'
         '「<b>～して</b>」→ 動詞から始める（3・6・9）　どの場合も、動詞は<b>原形（もとの形）</b>です。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--gv);">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. Look at this.','○'), ('2. You look at this.','✕'),
     ('3. Don&#39;t run here.','○'), ('4. Don&#39;t running here.','✕'),
     ('5. Let&#39;s go.','○'), ('6. Let&#39;s going.','✕'),
     ('7. Please open the door.','○'), ('8. Opens the door.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">Look at this.</span>（<span class="en">You</span> を取る）　4 → <span class="en">Don&#39;t run here.</span>（ing を取る）<br>'
         '6 → <span class="en">Let&#39;s go.</span>（ing を取る）　8 → <span class="en">Open the door.</span>（s を取る）<br>'
         '2は<b>主語</b>のまちがい。4・6・8は<b>動詞の形</b>のまちがいです。'},
  {'h':'<h3 class="sec sec2">D　うしろの形　正しいほうを選ぼう</h3>',
   'hint':'命令文・<span class="en">Don&#39;t</span>・<span class="en">Let&#39;s</span> のうしろは、ぜんぶ<b>原形（もとの形）</b>です。',
   'body':grid2([
     '1. <span class="en">Don&#39;t（ア run ／イ running）here.</span>%s' % bl('ア'),
     '2. <span class="en">Let&#39;s（ア going ／イ go）.</span>%s' % bl('イ'),
     '3. <span class="en">（ア Opens ／イ Open）the door.</span>%s' % bl('イ'),
     '4. <span class="en">Don&#39;t（ア eat ／イ eating）here.</span>%s' % bl('ア'),
     '5. <span class="en">Let&#39;s（ア play ／イ playing）soccer.</span>%s' % bl('ア'),
     '6. <span class="en">（ア Looking ／イ Look）at this.</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　答えはぜんぶ<b>原形（もとの形）</b>です。<span class="en">ing</span> がついた形と <span class="en">s</span> がついた形は使いません。<br>'
         '3・6は<b>文のはじめなので大文字</b>になっているだけ。形は 原形（もとの形）のままです。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　「しないで」は <span class="en">Don&#39;t</span>、「しましょう」は <span class="en">Let&#39;s</span>、「して」は動詞から。うしろは 原形（もとの形）。',
   'body':ol([
     ('<span class="jp-cue">これを見てください。</span>　<span class="en">%sat this.</span>' % bl('Look'),
      '動詞から始める。<b>主語はつけない</b>。'),
     ('<span class="jp-cue">ここで走らないでください。</span>　<span class="en">%srun here.</span>' % bl("Don't"),
      '「しないで」は <b><span class="en">Don&#39;t</span></b>。いちばん前。'),
     ('<span class="jp-cue">行きましょう。</span>　<span class="en">%sgo.</span>' % bl("Let's"),
      '「しましょう」は <b><span class="en">Let&#39;s</span></b>。'),
     ('<span class="jp-cue">ドアを開けてください。</span>　<span class="en">%sthe door.</span>' % bl('Open'),
      '<span class="en">Opens</span> にしない。<b>原形（もとの形）</b>。'),
     ('<span class="jp-cue">サッカーをしましょう。</span>　<span class="en">Let&#39;s%ssoccer.</span>' % bl('play'),
      '<span class="en">Let&#39;s</span> のうしろも <b>原形（もとの形）</b>。'),
     ('<span class="jp-cue">ここで食べないでください。</span>　<span class="en">%s%shere.</span>' % (bl("Don't"), bl('eat')),
      '（　）が2つ。<b><span class="en">Don&#39;t</span> → <span class="en">eat</span></b>。'),
     ('<span class="jp-cue">窓を開けないでください。</span>　<span class="en">Don&#39;t%sthe window.</span>' % bl('open'),
      '<span class="en">Don&#39;t</span> のうしろなので小文字の <span class="en">open</span>。'),
     ('<span class="jp-cue">どうぞ座ってください。</span>　<span class="en">%ssit down.</span>' % bl('Please'),
      'やさしく言うときは <b><span class="en">Please</span></b> を前に。'),
     ('<span class="jp-cue">いっしょに歌いましょう。</span>　<span class="en">%s%stogether.</span>' % (bl("Let's"), bl('sing')),
      '3・5番と同じ形。<b><span class="en">Let&#39;s</span> ＋ 原形（もとの形）</b>。'),
     ('<span class="jp-cue">これにさわらないでください。</span>　<span class="en">Don&#39;t%sthis.</span>' % bl('touch'),
      '「さわる」は <b><span class="en">touch</span></b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群に <span class="en">Don&#39;t</span> か <span class="en">Let&#39;s</span> があれば、それが<b>先頭</b>。なければ動詞が先頭です。',
   'body':ol([
     ('<span class="jp-cue">これを見てください。</span>　<span class="paren en">（ this / Look / at ）</span>' + line('Look at this.'),
      '語群に <span class="en">You</span> がない。<b>主語はつけません。</b>'),
     ('<span class="jp-cue">ここで走らないでください。</span>　<span class="paren en">（ here / run / Don&#39;t ）</span>' + line('Don&#39;t run here.'),
      '<span class="en">Don&#39;t</span> が先頭。<span class="en">here</span> はいちばん後ろ。'),
     ('<span class="jp-cue">サッカーをしましょう。</span>　<span class="paren en">（ soccer / Let&#39;s / play ）</span>' + line('Let&#39;s play soccer.'),
      '<span class="en">Let&#39;s</span> → 動詞 → なにを の順。'),
     ('<span class="jp-cue">ドアを開けてください。</span>　<span class="paren en">（ the door / Open ）</span>' + line('Open the door.'),
      '2語だけ。<span class="en">the door</span> でひとかたまり。'),
     ('<span class="jp-cue">ここで食べないでください。</span>　<span class="paren en">（ eat / here / Don&#39;t ）</span>' + line('Don&#39;t eat here.'),
      '2番と同じ形。'),
     ('<span class="jp-cue">どうぞ座ってください。</span>　<span class="paren en">（ down / Please / sit ）</span>' + line('Please sit down.'),
      '<span class="en">Please</span> が先頭。<span class="en">sit down</span> でひとかたまり。'),
     ('<span class="jp-cue">いっしょに歌いましょう。</span>　<span class="paren en">（ together / sing / Let&#39;s ）</span>' + line('Let&#39;s sing together.'),
      '3番と同じ形。<span class="en">together</span>（いっしょに）はいちばん後ろ。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('これを見てください。' + wline('Look at this.'),
      '<span class="en">You</span> をつけないこと。'),
     ('ここで走らないでください。' + wline('Don&#39;t run here.'),
      '<span class="en">Don&#39;t</span> のアポストロフィを忘れない。'),
     ('行きましょう。' + wline('Let&#39;s go.'),
      '2語だけ。<span class="en">Let&#39;s going.</span> にしない。'),
     ('ドアを開けてください。' + wline('Open the door.'),
      '<span class="en">Please open the door.</span> でも正解。'),
     ('サッカーをしましょう。' + wline('Let&#39;s play soccer.'),
      '<span class="en">Let&#39;s</span> のうしろは 原形（もとの形）。'),
     ('ここで食べないでください。' + wline('Don&#39;t eat here.'),
      '2番と同じ形。<span class="en">eating</span> にしない。'),
   ]),
   'words':'<span class="en">look at ／ run ／ go ／ open the door ／ play soccer ／ eat</span>'},
  'l4':{'sub':'教室のルールや、友だちへのさそいを書こう',
   'cond':['命令文（動詞から始める文）を <b>1つ以上</b>',
           '<span class="en">Don&#39;t ～.</span> の文を <b>2つ以上</b>',
           '<span class="en">Let&#39;s ～.</span> の文を <b>1つ以上</b>'],
   'example':['Look at this.','Don&#39;t run here. Don&#39;t eat in the classroom.','Let&#39;s play soccer together.'],
   'note':'これは例です。同じでなくてかまいません。教室・図書館・体育館 のルールを思い出すと書きやすいです。',
   'check':['主語（You）をつけていない','動詞は 原形（もとの形）','Don&#39;t / Let&#39;s のアポストロフィ','文の終わりにピリオド'],
   'review':'じぶんの文の<b>先頭のことば</b>に○をつけよう。<span class="en">You</span> があったら、そこがまちがい。'},
 },
}
