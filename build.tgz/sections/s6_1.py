# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'u6-1', 'unit':'6 − 1', 'unit_plain':'6-1', 'title':'三単現の肯定文',
 'pages':'p.86〜87',
 'hero_big':'He plays soccer. ／ She likes music.',
 'hero_jp':'彼は サッカーを します ／ 彼女は 音楽が 好きです',
 'motto':'主語が <b>he・she・人の名前</b> のとき、一般動詞に <span class="en">s</span> をつける。<span class="en">I</span>・<span class="en">you</span> にはつけない。',
 'kana':{'he':'ヒー','she':'シー','plays':'プレイズ','likes':'ライクス',
         'has':'ハズ','studies':'スタディーズ','study':'スタディ',
         'watches':'ウォッチズ','goes':'ゴウズ','go':'ゴウ','does':'ダズ',
         'teaches':'ティーチズ','teach':'ティーチ','washes':'ウォッシズ','wash':'ウォッシュ',
         'lives':'リヴズ','live':'リヴ','runs':'ランズ','speaks':'スピークス','speak':'スピーク',
         'cooks':'クックス','sings':'スィングズ','my':'マイ','brother':'ブラザー',
         'sister':'スィスター','mike':'マイク','emma':'エマ','every':'エヴリィ','day':'デイ'},
 'blocks':[
  ('きほんの文', [
    ('t','ここからが中1でいちばんの山場です。<b>主語が「わたし」でも「あなた」でもないとき</b>、一般動詞のうしろに <span class="en">s</span> がつきます。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I play soccer.</span><span class="t">わたしは サッカーを します。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">He plays soccer.</span><span class="t">彼は サッカーを します。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">She likes music.</span><span class="t">彼女は 音楽が 好きです。</span></div>
    </div>'''),
    ('t','1つめは <span class="en">play</span>、2つめは <span class="en">plays</span>。<b>主語が変わっただけで、動詞の形も変わっています</b>。日本語にはないしくみです。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜<span class="en">s</span> がつくのは この3つのときだけ', [
    ('t','ここが今回のヤマです。<span class="en">s</span> をつけるかどうかは、<b>主語だけ</b>で決まります。'),
    ('h','''<table class="kind">
      <thead><tr><th>主語</th><th>動詞</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k"><span class="en">I</span>（わたし）</td><td class="k" style="color:#9A948A;">そのまま</td><td class="e">I <u>play</u> soccer.</td></tr>
        <tr><td class="k"><span class="en">you</span>（あなた）</td><td class="k" style="color:#9A948A;">そのまま</td><td class="e">You <u>play</u> soccer.</td></tr>
        <tr><td class="k"><span class="en">he</span>（彼）</td><td class="k" style="color:var(--gv);font-weight:700;">s をつける</td><td class="e">He <u>plays</u> soccer.</td></tr>
        <tr><td class="k"><span class="en">she</span>（彼女）</td><td class="k" style="color:var(--gv);font-weight:700;">s をつける</td><td class="e">She <u>plays</u> soccer.</td></tr>
        <tr><td class="k">人の名前</td><td class="k" style="color:var(--gv);font-weight:700;">s をつける</td><td class="e">Mike <u>plays</u> soccer.</td></tr>
      </tbody>
    </table>'''),
    ('t','おぼえ方は<b>「わたしとあなた以外は <span class="en">s</span>」</b>。これだけです。4-1 で習った「わたしは <span class="en">am</span>、あなたは <span class="en">are</span>、ほかは <span class="en">is</span>」と同じ分け方です。'),
  ]),
  ('<span class="en">s</span> のつけ方は4パターン', [
    ('t','ほとんどは<b>そのまま <span class="en">s</span></b> です。例外は3つだけおぼえましょう。'),
    ('h','''<table class="kind">
      <thead><tr><th>パターン</th><th>やり方</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k">ふつう</td><td class="k">そのまま <span class="en">s</span></td><td class="e">play → play<u>s</u>　like → like<u>s</u></td></tr>
        <tr><td class="k"><span class="en">o, s, x, ch, sh</span></td><td class="k"><span class="en">es</span> をつける</td><td class="e">go → go<u>es</u>　watch → watch<u>es</u></td></tr>
        <tr><td class="k">子音＋<span class="en">y</span></td><td class="k"><span class="en">y</span> を <span class="en">i</span> にして <span class="en">es</span></td><td class="e">study → stud<u>ies</u></td></tr>
        <tr><td class="k"><span class="en">have</span></td><td class="k" style="color:var(--ng);">特別な形</td><td class="e">have → <u>has</u></td></tr>
      </tbody>
    </table>'''),
    ('t','とくに <b><span class="en">have → has</span></b> は <span class="en">haves</span> と書く人がとても多いところ。<b>形ごとおぼえてしまう</b>のが早いです。'),
    ('t','<span class="en">es</span> になるのは「<b>オ・ス・クス・チ・シュ</b>」で終わる語、と音でおぼえると楽です。'),
  ]),
  ('be動詞と いっしょに使わない', [
    ('t','<span class="en">s</span> を習うと、<span class="en">He is plays soccer.</span> のように be動詞を足してしまう人が出ます。これまでと同じルールです。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ is を使う<small>「彼は <u>どんな人か</u>」</small></span></div>
        <div class="in"><div class="ex">He is a student.<br>He is kind.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-run"/></svg>
          <span>✕ is を使わない<small>「彼は <u>なにをするか</u>」</small></span></div>
        <div class="in"><div class="ex">He plays soccer.<br>He likes music.</div></div>
      </div>
    </div>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：心臓（動詞）は 青かピンクの どちらか1つ</div>
        <p><b class="cb">青＝<span class="en">is</span></b>　<b class="cp">ピンク＝<span class="en">plays・likes・has</span></b>　
        <span class="en">s</span> がついても、ピンクはピンクのままです。<br>
        <span class="xm">✕ He is plays soccer ✕</span>　<span class="xm">✕ He is likes music ✕</span></p>
      </div>
    </div>'''),
  ]),
  ('<span class="en">s</span> は「3人のうちの1人」のしるし', [
    ('t','なぜ <span class="en">he</span> と <span class="en">she</span> だけ特別なのでしょう。英語では、話に出てくる人を<b>3つのグループ</b>に分けて考えます。'),
    ('h','''<div class="blocks">
      <div class="blk fill"><div class="w en">I</div><div class="r">話す人（1人目）</div></div>
      <div class="plus">／</div>
      <div class="blk fill"><div class="w en">you</div><div class="r">聞く人（2人目）</div></div>
      <div class="plus">／</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">he / she</div><div class="r">それ以外（3人目）＝ s</div></div>
    </div>'''),
    ('t','この<b>3人目で、しかも1人</b>のときに <span class="en">s</span> がつきます。これを「三人称単数」と呼びます。むずかしい名前ですが、<b>中身は「わたしとあなた以外の1人」</b>というだけです。'),
  ]),
 ],
 'quiz':[
  ('He play soccer.','He plays soccer.','主語が <span class="en">he</span> なので <b><span class="en">s</span> が必要</b>。','彼は サッカーを します。'),
  ('He is play soccer.','He plays soccer.','心臓（動詞）が2つ。<b><span class="en">is</span> はいりません</b>。','彼は サッカーを します。'),
  ('He haves a dog.','He has a dog.','<span class="en">have</span> は特別で <b><span class="en">has</span></b> に変わります。','彼は 犬を 飼って います。'),
  ('He studys math.','He studies math.','子音＋<span class="en">y</span> なので、<b><span class="en">y</span> を <span class="en">i</span> にして <span class="en">es</span></b>。','彼は 数学を 勉強します。'),
  ('He watchs TV.','He watches TV.','<span class="en">ch</span> で終わるので <b><span class="en">es</span></b> をつけます。','彼は テレビを 見ます。'),
  ('I likes music.','I like music.','主語が <span class="en">I</span> なので <b><span class="en">s</span> はつけません</b>。','わたしは 音楽が 好きです。'),
 ],
 'summary':[
  '主語が <b><span class="en">he</span>・<span class="en">she</span>・人の名前</b> のとき、一般動詞に <span class="en">s</span> をつける。',
  '<b><span class="en">I</span> と <span class="en">you</span> にはつけない。</b>「わたしとあなた以外は <span class="en">s</span>」。',
  '<span class="en">o・s・x・ch・sh</span> で終わる語は <b><span class="en">es</span></b>、子音＋<span class="en">y</span> は <b><span class="en">ies</span></b>。',
  '<b><span class="en">have → has</span></b> は特別な形。<span class="en">haves</span> とは書かない。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '主語が <span class="en">he</span>・<span class="en">she</span>・人の名前のとき、一般動詞に%sをつける。' % bl('s'),
     '主語が <span class="en">I</span> や <span class="en">you</span> のときは%s。' % bl('つけない'),
     '<span class="en">go</span> や <span class="en">watch</span> のように <span class="en">o・ch</span> で終わる語は%sをつける。' % bl('es'),
     '<span class="en">study</span> のように子音＋<span class="en">y</span> で終わる語は、<span class="en">y</span> を%sにして <span class="en">es</span> をつける。' % bl('i'),
     '<span class="en">have</span> は特別で%sになる。' % bl('has'),
   ]),
   'words':'語群：<span class="en">s</span> ／ <span class="en">es</span> ／ <span class="en">i</span> ／ <span class="en">has</span> ／ つけない',
   'exp':'<b>なぜ？</b>　英語では、人を「話す人（<span class="en">I</span>）」「聞く人（<span class="en">you</span>）」「それ以外（<span class="en">he・she</span>）」の3つに分けます。<br>'
         '<b>3つめのグループで1人のとき</b>だけ、動詞に <span class="en">s</span> をつけるという決まりがあるのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--gv);">B　<span class="en">s</span> をつける？ つけない？<em>（　）に正しい形を書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>主語だけ</b>を見ましょう。<span class="en">I</span>・<span class="en">you</span> ならそのまま、それ以外なら <span class="en">s</span>。',
   'body':grid2([
     '1. <span class="en">He%ssoccer.</span>（play）' % bl('plays'),
     '2. <span class="en">I%ssoccer.</span>（play）' % bl('play'),
     '3. <span class="en">She%smusic.</span>（like）' % bl('likes'),
     '4. <span class="en">You%smusic.</span>（like）' % bl('like'),
     '5. <span class="en">Mike%sa dog.</span>（have）' % bl('has'),
     '6. <span class="en">I%sa dog.</span>（have）' % bl('have'),
     '7. <span class="en">She%smath.</span>（study）' % bl('studies'),
     '8. <span class="en">You%smath.</span>（study）' % bl('study'),
     '9. <span class="en">He%sTV.</span>（watch）' % bl('watches'),
     '10. <span class="en">Emma%sto school.</span>（go）' % bl('goes'),
   ]),
   'exp':'<b>見つけ方</b>　主語を見るだけ。<br>'
         '<span class="en">I</span>・<span class="en">you</span> → <b>そのまま</b>（2・4・6・8）　<span class="en">he・she</span>・名前 → <b><span class="en">s</span> をつける</b>（1・3・5・7・9・10）<br>'
         '5は <span class="en">has</span>、7は <span class="en">studies</span>、9は <span class="en">watches</span>、10は <span class="en">goes</span>。<b>つけ方の例外</b>に注意。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--gv);">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. He plays soccer.','○'), ('2. He play soccer.','✕'),
     ('3. She has a dog.','○'), ('4. She haves a dog.','✕'),
     ('5. I like music.','○'), ('6. I likes music.','✕'),
     ('7. He watches TV.','○'), ('8. He is plays soccer.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">He plays soccer.</span>（s をつける）　4 → <span class="en">She has a dog.</span>（<span class="en">has</span> に）<br>'
         '6 → <span class="en">I like music.</span>（s を取る）　8 → <span class="en">He plays soccer.</span>（<span class="en">is</span> を消す）<br>'
         '2・4・6は<b>s のつけ方</b>のまちがい。8は<b>心臓（動詞）が2つ</b>のまちがいです。'},
  {'h':'<h3 class="sec sec2">D　<span class="en">s</span> のつけ方　正しいほうを選ぼう</h3>',
   'hint':'そのまま <span class="en">s</span>／<span class="en">es</span>／<span class="en">ies</span>／特別な形、の4パターンです。',
   'body':grid2([
     '1. <span class="en">play →（ア plays ／イ playes）</span>%s' % bl('ア'),
     '2. <span class="en">go →（ア gos ／イ goes）</span>%s' % bl('イ'),
     '3. <span class="en">study →（ア studys ／イ studies）</span>%s' % bl('イ'),
     '4. <span class="en">have →（ア has ／イ haves）</span>%s' % bl('ア'),
     '5. <span class="en">watch →（ア watches ／イ watchs）</span>%s' % bl('ア'),
     '6. <span class="en">like →（ア likees ／イ likes）</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　ふつうはそのまま <span class="en">s</span>（1・6）。<span class="en">o・ch</span> で終わる語は <span class="en">es</span>（2・5）。<br>'
         '子音＋<span class="en">y</span> は <span class="en">ies</span>（3）。<span class="en">have</span> だけは <span class="en">has</span> という特別な形（4）です。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　主語を先に見る。<span class="en">I</span>・<span class="en">you</span> ならそのまま、<span class="en">he</span>・<span class="en">she</span>・名前なら <span class="en">s</span>。',
   'body':ol([
     ('<span class="jp-cue">彼はサッカーをします。</span>　<span class="en">He%ssoccer.</span>' % bl('plays'),
      '主語が <span class="en">he</span> なので <b><span class="en">plays</span></b>。'),
     ('<span class="jp-cue">わたしはサッカーをします。</span>　<span class="en">I%ssoccer.</span>' % bl('play'),
      '主語が <span class="en">I</span> なので <b>そのまま</b>。1番とくらべよう。'),
     ('<span class="jp-cue">彼女は音楽が好きです。</span>　<span class="en">She%smusic.</span>' % bl('likes'),
      '<span class="en">she</span> なので <b><span class="en">likes</span></b>。'),
     ('<span class="jp-cue">マイクは犬を飼っています。</span>　<span class="en">Mike%sa dog.</span>' % bl('has'),
      '人の名前も <span class="en">s</span> の仲間。<span class="en">have</span> は <b><span class="en">has</span></b>。'),
     ('<span class="jp-cue">彼女は数学を勉強します。</span>　<span class="en">She%smath.</span>' % bl('studies'),
      '子音＋<span class="en">y</span> なので <b><span class="en">studies</span></b>。'),
     ('<span class="jp-cue">彼はテレビを見ます。</span>　<span class="en">He%sTV.</span>' % bl('watches'),
      '<span class="en">ch</span> で終わるので <b><span class="en">watches</span></b>。'),
     ('<span class="jp-cue">彼は学校へ行きます。</span>　<span class="en">He%sto school.</span>' % bl('goes'),
      '<span class="en">o</span> で終わるので <b><span class="en">goes</span></b>。'),
     ('<span class="jp-cue">彼は生徒です。</span>　<span class="en">He%sa student.</span>' % bl('is'),
      '「どんな人か」なので <b><span class="en">is</span></b>。動作ではありません。'),
     ('<span class="jp-cue">あなたは音楽が好きです。</span>　<span class="en">You%smusic.</span>' % bl('like'),
      '<span class="en">you</span> なので <b>そのまま</b>。3番とくらべよう。'),
     ('<span class="jp-cue">エマは毎日料理をします。</span>　<span class="en">Emma%severy day.</span>' % bl('cooks'),
      '名前が主語。<b><span class="en">cooks</span></b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群の動詞に <span class="en">s</span> がついているかを見る。ついていれば主語は <span class="en">he</span>・<span class="en">she</span>・名前です。',
   'body':ol([
     ('<span class="jp-cue">彼はサッカーをします。</span>　<span class="paren en">（ soccer / He / plays ）</span>' + line('He plays soccer.'),
      '「だれが → どうする → なにを」の順。<b>はじめは大文字、終わりにピリオド。</b>'),
     ('<span class="jp-cue">彼女は音楽が好きです。</span>　<span class="paren en">（ music / likes / She ）</span>' + line('She likes music.'),
      '語群が <span class="en">likes</span>。<b>形はもう決まっています。</b>'),
     ('<span class="jp-cue">わたしはサッカーをします。</span>　<span class="paren en">（ soccer / play / I ）</span>' + line('I play soccer.'),
      '語群が <span class="en">play</span>（s なし）。主語は <span class="en">I</span>。'),
     ('<span class="jp-cue">マイクは犬を飼っています。</span>　<span class="paren en">（ a dog / Mike / has ）</span>' + line('Mike has a dog.'),
      '<span class="en">a dog</span> でひとかたまり。'),
     ('<span class="jp-cue">彼女は数学を勉強します。</span>　<span class="paren en">（ math / She / studies ）</span>' + line('She studies math.'),
      '語群が <span class="en">studies</span>。'),
     ('<span class="jp-cue">彼は生徒です。</span>　<span class="paren en">（ a / student / He / is ）</span>' + line('He is a student.'),
      '語群に <span class="en">is</span> がある。<b>be動詞の文</b>です。'),
     ('<span class="jp-cue">彼は毎日テレビを見ます。</span>　<span class="paren en">（ TV / every day / He / watches ）</span>' + line('He watches TV every day.'),
      '<span class="en">every day</span>（毎日）はいちばん後ろ。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('彼はサッカーをします。' + wline('He plays soccer.'),
      '<span class="en">s</span> を忘れない。'),
     ('彼女は音楽が好きです。' + wline('She likes music.'),
      '<span class="en">likes</span> と <span class="en">s</span> をつける。'),
     ('マイクは犬を飼っています。' + wline('Mike has a dog.'),
      '<span class="en">haves</span> ではなく <b><span class="en">has</span></b>。'),
     ('彼女は数学を勉強します。' + wline('She studies math.'),
      '<span class="en">y</span> を <span class="en">i</span> にして <span class="en">es</span>。'),
     ('わたしはサッカーをします。' + wline('I play soccer.'),
      '主語が <span class="en">I</span> なので <span class="en">s</span> はつけない。'),
     ('彼は生徒です。' + wline('He is a student.'),
      '動作ではないので <span class="en">is</span>。混ぜないこと。'),
   ]),
   'words':'<span class="en">plays ／ likes ／ has ／ studies ／ play ／ is a student</span>'},
  'l4':{'sub':'友だちや家族のことを、しょうかいしよう',
   'cond':['主語が <span class="en">He</span> か <span class="en">She</span> の文を <b>3つ以上</b>（動詞に <span class="en">s</span> をつける）',
           '<span class="en">has</span> を使った文を <b>1つ</b> 入れる',
           '<span class="en">I</span> で始まる文も <b>1つ</b> 入れる（<span class="en">s</span> をつけない）'],
   'example':['Mike is my friend. He plays soccer.','He has a dog. He likes music.','I play tennis.'],
   'note':'これは例です。同じでなくてかまいません。友だち・家族のすきなもの・やっていること・ペット を書いてみよう。',
   'check':['he / she の動詞に s をつけた','have は has にした','I・you の動詞に s をつけていない','is と動作のことばを混ぜていない'],
   'review':'じぶんの文の主語と動詞に○をつけよう。<span class="en">he</span>・<span class="en">she</span> なのに動詞に <span class="en">s</span> がなければ、そこがまちがい。'},
 },
}
