# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox, gmap

S = {
 'id':'u5-2', 'unit':'5 − 2', 'unit_plain':'5-2', 'title':'Where ～?',
 'pages':'p.76〜77',
 'hero_big':'Where is my bag? ／ Where do you play?',
 'hero_jp':'わたしの かばんは どこ ですか ／ あなたは どこで しますか',
 'motto':'<span class="en">Where</span> は「どこ」。答えは <b>場所</b>で言う。<span class="en">Yes / No</span> は使わない。',
 'kana':{'where':'ウェア','is':'イズ','do':'ドゥー','in':'イン','on':'オン',
         'under':'アンダー','near':'ニア','my':'マイ','your':'ユア',
         'bag':'バッグ','desk':'デスク','table':'テイブル','room':'ルーム',
         'school':'スクール','library':'ライブラリィ','park':'パーク',
         'station':'ステイション','live':'リヴ','play':'プレイ','study':'スタディ',
         "it's":'イッツ','it':'イット','the':'ザ','cat':'キャット'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>かばんは どこですか</b>」「<b>どこで サッカーを しますか</b>」のように、<b>場所</b>をたずねるときの形です。'),
    ('t','使うのは <span class="en">Where</span>（どこ）。たずねたい中身で、うしろの形が<b>2通り</b>に分かれます。'),
    ('h', gitem('❶', '「～は どこですか」', 'ものや人が ある場所',
                'かばんは どこ ですか', 'Where is my bag?',
                [('Where is my bag?','わたしの かばんは どこ ですか。'),
                 ('— It&#39;s on the desk.','— それは 机の 上に あります。')],
                '<b>Where ＋ is ～?</b> の形。答えるときは <span class="en">on・in・under</span> などで場所を言います。')),
    ('h', gitem('❷', '「どこで ～ しますか」', 'することをする場所',
                'どこで サッカーを しますか', 'Where do you play soccer?',
                [('Where do you play soccer?','あなたは どこで サッカーを しますか。'),
                 ('— I play soccer in the park.','— わたしは 公園で サッカーを します。')],
                '<b>Where ＋ do you ～?</b> の形。2-2 でならった <span class="en">Do you ～?</span> の前に <span class="en">Where</span> を置くだけ。', b2=True)),
    ('t','どちらも <span class="en">Where</span> は<b>いちばん前</b>。そのうしろは、これまで習った形のままです。'),
    ('h', copybox()),
  ]),
  ('2つのパターンがある', [
    ('t','<span class="en">Where</span> のうしろは、<b>be動詞の文なら <span class="en">is</span>、動作の文なら <span class="en">do you</span></b> になります。'),
    ('h','''<table class="kind">
      <thead><tr><th>たずねたいこと</th><th>形</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k">ものが どこに あるか</td><td class="k" style="color:var(--key);font-weight:700;">Where is ～?</td><td class="e">Where <u>is</u> my bag?</td></tr>
        <tr><td class="k">どこで するのか</td><td class="k" style="color:var(--gv);font-weight:700;">Where do you ～?</td><td class="e">Where <u>do you</u> play soccer?</td></tr>
      </tbody>
    </table>'''),
    ('t','見分け方は今までと同じ。<b>動作のことばがあるかどうか</b>です。<span class="en">play・live・study</span> があれば <span class="en">do you</span> を使います。'),
    ('t','<span class="en">Where is</span> は <span class="en">Where&#39;s</span> と短くできます。<span class="en">Who&#39;s</span> と同じしくみです。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>2つの形 <span class="en">Where is ～? / Where do you ～?</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('かなり大事｜答えは場所。<span class="en">Yes / No</span> は使わない', [
    ('t','ここが今回のヤマです。<span class="en">Where</span> は「どこ？」と聞いているので、<b>場所を答えます</b>。<span class="en">What</span>・<span class="en">Who</span> と同じ考え方です。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>◯ 場所で答える<small>Where で聞かれたとき</small></span></div>
        <div class="in"><div class="ex">Where is my bag?<br>— It&#39;s on the desk.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>✕ はい／いいえ<small>Where には合わない</small></span></div>
        <div class="in"><div class="ex">Where is my bag?<br>— Yes, it is.</div></div>
      </div>
    </div>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：<span class="en">What・Who・Where</span> は 中身で答える</div>
        <p><b class="cb"><span class="en">Is this ～?</span> → <span class="en">Yes / No</span></b>　<b class="cp"><span class="en">Where is ～?</span> → 場所</b>　
        先頭を見れば、答え方が決まります。<br>
        <span class="xm">✕ Where is my bag? — Yes, it is ✕</span></p>
      </div>
    </div>'''),
  ]),
  ('場所を表すことば', [
    ('t','答えるときは、<b>場所を表すことば</b>を使います。よく使う4つをおぼえましょう。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">in</span></td><td class="k">～の中に</td><td class="e">It&#39;s <u>in</u> my bag.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">on</span></td><td class="k">～の上に</td><td class="e">It&#39;s <u>on</u> the desk.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">under</span></td><td class="k">～の下に</td><td class="e">It&#39;s <u>under</u> the table.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">near</span></td><td class="k">～の近くに</td><td class="e">It&#39;s <u>near</u> the station.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>場所のことば <span class="en">in / on / under / near</span> を3回ずつ書き写そう！</div>
    </div>'''),
    ('t','答えの主語は <b><span class="en">it</span></b>（それ）。<span class="en">Where is my bag?</span> → <span class="en">It&#39;s on the desk.</span> のように言います。'),
  ]),
  ('<span class="en">Where do you ～?</span> の答え方', [
    ('t','「どこで するのか」を聞かれたときは、<b>ふつうの文で答えます</b>。場所のことばを文の最後に置きます。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">Where do you play soccer?</span><br>
      — <span class="eq" style="color:var(--gv);">I play soccer in the park.</span>（公園でします）　<b>場所はいちばん後ろ</b>
    </div>'''),
    ('t','短く <span class="en">In the park.</span> だけでも答えになります。どちらでもよいです。'),
  ]),
 ],
 'quiz':[
  ('Where my bag is?','Where is my bag?','<span class="en">Where</span> のうしろは <b><span class="en">is</span> → 主語</b> の順。順番を入れかえます。','わたしの かばんは どこ ですか。'),
  ('Where is my bag? — Yes, it is.','It&#39;s on the desk.','<span class="en">Where</span> で聞かれたら <b>場所で答える</b>。<span class="en">Yes / No</span> は使いません。','それは 机の 上に あります。'),
  ('Where you do play soccer?','Where do you play soccer?','<span class="en">Where</span> のうしろは <b><span class="en">do you</span></b> の順。','あなたは どこで サッカーを しますか。'),
  ('Where is you play soccer?','Where do you play soccer?','<span class="en">play</span> は動作のことば。<b>動作の文は <span class="en">do you</span></b>。','あなたは どこで サッカーを しますか。'),
  ('Where is my bag.','Where is my bag?','終わりが<b>ピリオド</b>です。たずねる文の終わりは <b>?</b>。','わたしの かばんは どこ ですか。'),
  ('Its on the desk.','It&#39;s on the desk.','<b>&#39;（アポストロフィ）</b>を忘れています。<span class="en">It is</span> → <span class="en">It&#39;s</span>。','それは 机の 上に あります。'),
 ],
 'summary':[
  '「～はどこですか」は <b><span class="en">Where is ～?</span></b>　<span class="en">Where&#39;s</span> と短くもできる。',
  '「どこで～しますか」は <b><span class="en">Where do you ～?</span></b>　動作のことばがあるときはこちら。',
  '<b>答えは場所。<span class="en">Yes / No</span> は使わない。</b>主語は <span class="en">it</span>。',
  '場所のことばは <b><span class="en">in</span>（中）・<span class="en">on</span>（上）・<span class="en">under</span>（下）・<span class="en">near</span>（近く）</b>。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～はどこですか」は%sを文の前に置く。そのうしろは <span class="en">%s</span> ＋ 主語。' % (bl('Where'), bl('is')),
     '「どこで するのか」をたずねるときは <span class="en">Where%s</span> ～? の形を使う。' % bl('do you', False),
     '<span class="en">Where</span> で聞かれたら、答えに%sは使わず、%sを答える。' % (bl('Yes / No', False), bl('場所')),
     '答えの主語は%sを使う。<span class="en">%s</span> on the desk.' % (bl('it'), bl("It's", False)),
     '「～の上に」は%s、「～の中に」は%s。' % (bl('on'), bl('in')),
   ]),
   'words':'語群：<span class="en">Where</span> ／ <span class="en">is</span> ／ <span class="en">do you</span> ／ <span class="en">it</span> ／ <span class="en">It&#39;s</span> ／ <span class="en">in</span> ／ <span class="en">on</span> ／ <span class="en">Yes / No</span> ／ 場所',
   'exp':'<b>なぜ？</b>　<span class="en">What</span>（なに）・<span class="en">Who</span>（だれ）・<span class="en">Where</span>（どこ）は、ぜんぶ<b>「知りたいところ」</b>を表すことば。だから いちばん前に立ちます。<br>'
         '知りたい中身を聞いているので、<span class="en">Yes / No</span> では答えになりません。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">is</span>？ それとも <span class="en">do you</span>？<em>（　）に入るものを書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>動作のことばがあるか</b>だけを見ましょう。',
   'body':grid2([
     '1. <span class="en">Where%smy bag?</span>' % bl('is'),
     '2. <span class="en">Where%splay soccer?</span>' % bl('do you', False),
     '3. <span class="en">Where%syour school?</span>' % bl('is'),
     '4. <span class="en">Where%slive?</span>' % bl('do you', False),
     '5. <span class="en">Where%sthe station?</span>' % bl('is'),
     '6. <span class="en">Where%sstudy?</span>' % bl('do you', False),
     '7. <span class="en">Where%smy cat?</span>' % bl('is'),
     '8. <span class="en">Where%seat lunch?</span>' % bl('do you', False),
     '9. <span class="en">Where%sthe library?</span>' % bl('is'),
     '10. <span class="en">Where%sthe park?</span>' % bl('is'),
   ]),
   'exp':'<b>見つけ方</b>　<span class="en">Where</span> のうしろを見よう。<br>'
         '<b>動作のことばがある</b>（<span class="en">play・live・study・eat</span>）→ <span class="en">do you</span>（2・4・6・8）<br>'
         '<b>ものや場所の名前だけ</b>（かばん・学校・駅・ねこ・図書館・公園）→ <span class="en">is</span>（1・3・5・7・9・10）'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. Where is my bag?','○'), ('2. Where my bag is?','✕'),
     ('3. Where do you live?','○'), ('4. Where you do live?','✕'),
     ('5. It&#39;s on the desk.','○'), ('6. Its on the desk.','✕'),
     ('7. Where&#39;s the station?','○'), ('8. Where is you play soccer?','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">Where is my bag?</span>（<span class="en">is</span> → 主語 の順に）<br>'
         '4 → <span class="en">Where do you live?</span>（<span class="en">do you</span> の順に）　6 → <span class="en">It&#39;s on the desk.</span>（&#39;を入れる）<br>'
         '8 → <span class="en">Where do you play soccer?</span>（動作の文は <span class="en">do you</span>）'},
  {'h':'<h3 class="sec sec2">D　答え方　正しいほうを選ぼう</h3>',
   'hint':'<span class="en">Where</span> なら<b>場所</b>。<span class="en">Is</span>・<span class="en">Do</span> なら <span class="en">Yes / No</span>。',
   'body':grid2([
     '1. <span class="en">Where is my bag?</span>　—（ア <span class="en">It&#39;s on the desk.</span> ／イ <span class="en">Yes, it is.</span>）%s' % bl('ア'),
     '2. <span class="en">Is this your bag?</span>　—（ア <span class="en">It&#39;s on the desk.</span> ／イ <span class="en">Yes, it is.</span>）%s' % bl('イ'),
     '3. <span class="en">Where do you live?</span>　—（ア <span class="en">Yes, I do.</span> ／イ <span class="en">I live in Nagano.</span>）%s' % bl('イ'),
     '4. <span class="en">Where is the station?</span>　—（ア <span class="en">It&#39;s near the park.</span> ／イ <span class="en">No, it isn&#39;t.</span>）%s' % bl('ア'),
     '5. <span class="en">Do you play soccer?</span>　—（ア <span class="en">In the park.</span> ／イ <span class="en">Yes, I do.</span>）%s' % bl('イ'),
     '6. <span class="en">Where is my cat?</span>　—（ア <span class="en">It&#39;s under the table.</span> ／イ <span class="en">Yes, it is.</span>）%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　<span class="en">Where</span> の文に <span class="en">Yes / No</span> で答えると、答えになりません（1・4・6）。<br>'
         '<span class="en">Is</span>（2）・<span class="en">Do</span>（5）で聞かれたときだけ <span class="en">Yes / No</span> を使います。3は場所をふつうの文で答えています。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　<span class="en">Where</span> のうしろは、動作のことばがあれば <span class="en">do you</span>、なければ <span class="en">is</span>。',
   'body':ol([
     ('<span class="jp-cue">わたしのかばんはどこですか。</span>　<span class="en">Where%smy bag?</span>' % bl('is'),
      '「ものが どこに あるか」なので <b><span class="en">is</span></b>。'),
     ('<span class="jp-cue">それは机の上にあります。</span>　<span class="en">It&#39;s%sthe desk.</span>' % bl('on'),
      '「～の上に」は <b><span class="en">on</span></b>。'),
     ('<span class="jp-cue">あなたはどこに住んでいますか。</span>　<span class="en">Where%syou live?</span>' % bl('do'),
      '<span class="en">live</span> は動作のことば。<b><span class="en">do you</span></b>。'),
     ('<span class="jp-cue">それはかばんの中にあります。</span>　<span class="en">It&#39;s%smy bag.</span>' % bl('in'),
      '「～の中に」は <b><span class="en">in</span></b>。'),
     ('<span class="jp-cue">駅はどこですか。</span>　<span class="en">%sis the station?</span>' % bl('Where'),
      '「どこ」なので <b><span class="en">Where</span></b>。文のはじめだから大文字。'),
     ('<span class="jp-cue">それはテーブルの下にあります。</span>　<span class="en">It&#39;s%sthe table.</span>' % bl('under'),
      '「～の下に」は <b><span class="en">under</span></b>。'),
     ('<span class="jp-cue">あなたはどこでサッカーをしますか。</span>　<span class="en">Where%s%splay soccer?</span>' % (bl('do'), bl('you')),
      '（　）が2つ。<b><span class="en">do</span> → <span class="en">you</span></b> の順。'),
     ('<span class="jp-cue">それは駅の近くにあります。</span>　<span class="en">It&#39;s%sthe station.</span>' % bl('near'),
      '「～の近くに」は <b><span class="en">near</span></b>。'),
     ('<span class="jp-cue">短い形にしよう。</span>　<span class="en">Where is my bag?</span> →　<span class="en">%smy bag?</span>' % bl("Where's", False),
      '<b><span class="en">Where is</span> ＝ <span class="en">Where&#39;s</span></b>。'),
     ('<span class="jp-cue">わたしは公園でサッカーをします。</span>　<span class="en">I play soccer%sthe park.</span>' % bl('in'),
      '7番の答え。場所は<b>いちばん後ろ</b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　<span class="en">Where</span> が先頭。そのうしろは <span class="en">is</span> ＋ 主語、または <span class="en">do</span> ＋ <span class="en">you</span> ＋ 動詞。',
   'body':ol([
     ('<span class="jp-cue">わたしのかばんはどこですか。</span>　<span class="paren en">（ my bag / Where / is ）</span>' + line('Where is my bag?'),
      '<span class="en">Where</span> → <span class="en">is</span> → 主語 の順。終わりは <b>?</b>。'),
     ('<span class="jp-cue">それは机の上にあります。</span>　<span class="paren en">（ the desk / It&#39;s / on ）</span>' + line('It&#39;s on the desk.'),
      '<span class="en">on the desk</span> でひとかたまり。'),
     ('<span class="jp-cue">あなたはどこに住んでいますか。</span>　<span class="paren en">（ live / you / Where / do ）</span>' + line('Where do you live?'),
      '<span class="en">Where</span> → <span class="en">do</span> → <span class="en">you</span> → 動詞。'),
     ('<span class="jp-cue">駅はどこですか。</span>　<span class="paren en">（ the station / is / Where ）</span>' + line('Where is the station?'),
      '1番と同じ形。'),
     ('<span class="jp-cue">それはテーブルの下にあります。</span>　<span class="paren en">（ the table / under / It&#39;s ）</span>' + line('It&#39;s under the table.'),
      '2番と同じ形。<span class="en">under</span> が場所のことば。'),
     ('<span class="jp-cue">あなたはどこでサッカーをしますか。</span>　<span class="paren en">（ soccer / do / Where / play / you ）</span>' + line('Where do you play soccer?'),
      '3番と同じ形。<span class="en">soccer</span> はいちばん後ろ。'),
     ('<span class="jp-cue">わたしは公園でサッカーをします。</span>　<span class="paren en">（ in the park / soccer / play / I ）</span>' + line('I play soccer in the park.'),
      '語群に <span class="en">Where</span> がない。<b>ふつうの文</b>です。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしのかばんはどこですか。' + wline('Where is my bag?'),
      '<span class="en">Where&#39;s my bag?</span> でも正解。'),
     ('それは机の上にあります。' + wline('It&#39;s on the desk.'),
      '<span class="en">It is on the desk.</span> でも正解。'),
     ('あなたはどこに住んでいますか。' + wline('Where do you live?'),
      '動作のことばなので <span class="en">do you</span>。'),
     ('それはテーブルの下にあります。' + wline('It&#39;s under the table.'),
      '「下に」は <span class="en">under</span>。'),
     ('駅はどこですか。' + wline('Where is the station?'),
      '<span class="en">the station</span> に <span class="en">the</span> をつける。'),
     ('あなたはどこでサッカーをしますか。' + wline('Where do you play soccer?'),
      '3番と同じ形。<span class="en">Where is</span> にしないこと。'),
   ]),
   'words':'<span class="en">my bag ／ on the desk ／ live ／ under the table ／ the station ／ play soccer</span>'},
  'l4':{'sub':'教室や自分の部屋のものについて、場所をたずねよう',
   'cond':['<span class="en">Where is ～?</span> の文を <b>2つ以上</b>',
           'それぞれの答えを <span class="en">It&#39;s ～.</span> で書く（場所のことばを使う）',
           '<span class="en">Where do you ～?</span> の文も <b>1つ</b> 入れる'],
   'example':['Where is my pen? — It&#39;s on the desk.','Where is my cat? — It&#39;s under the table.','Where do you study? — I study in my room.'],
   'note':'これは例です。同じでなくてかまいません。<span class="en">in・on・under・near</span> の4つを使い分けてみよう。',
   'check':['Where のうしろは is か do you','答えは場所で言う','Yes / No を使っていない','It&#39;s のアポストロフィ'],
   'review':'じぶんの文の答えに○をつけよう。<span class="en">Where</span> の文の答えが <span class="en">Yes</span> や <span class="en">No</span> なら、そこがまちがい。'},
 },
}
