# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox, gmap

S = {
 'id':'u7-1', 'unit':'7 − 1', 'unit_plain':'7-1', 'title':'一般動詞の過去形（肯定文）',
 'pages':'p.102〜103',
 'hero_big':'I played soccer yesterday.',
 'hero_jp':'わたしは きのう サッカーを しました',
 'motto':'過去形は <span class="en">ed</span> をつける。<b>主語がだれでも同じ形</b>。<span class="en">s</span> はつけない。',
 'kana':{'played':'プレイド','studied':'スタディド','liked':'ライクト',
         'watched':'ウォッチト','cooked':'クックト','visited':'ヴィズィティド',
         'visit':'ヴィズィット','enjoyed':'エンジョイド','enjoy':'エンジョイ',
         'went':'ウェント','go':'ゴウ','saw':'ソー','see':'スィー',
         'ate':'エイト','eat':'イート','had':'ハッド','got':'ガット','get':'ゲット',
         'made':'メイド','make':'メイク','yesterday':'イエスタデイ',
         'last':'ラスト','week':'ウィーク','park':'パーク','stopped':'スタップト','stop':'スタップ'},
 'blocks':[
  ('きほんの文', [
    ('t','「きのう <b>サッカーを した</b>」のように、<b>もう終わったこと</b>を言うときの形です。'),
    ('t','変えるのは<b>動詞だけ</b>。ただし、変え方が<b>2種類</b>あります。'),
    ('h', gitem('❶', '<span class="en">ed</span> を つけるだけ', 'ほとんどの動詞',
                'サッカーを <b>した</b>', 'play<b>ed</b> soccer',
                [('I played soccer yesterday.','わたしは きのう サッカーを しました。'),
                 ('He played soccer yesterday.','彼は きのう サッカーを しました。')],
                'うしろに <b>ed</b> をつけます。<b>主語がちがっても 形は同じ</b>。三単現の <span class="en">s</span> はもう考えません。')),
    ('h', gitem('❷', '形ごと 変わってしまう', 'よく使う動詞',
                '公園へ <b>行った</b>', '<b>went</b> to the park',
                [('I went to the park.','わたしは 公園へ 行きました。'),
                 ('I saw a dog.','わたしは 犬を 見ました。')],
                '<span class="en">go → went</span>、<span class="en">see → saw</span> のように<b>形ごと変わります</b>。<span class="en">goed</span> とは書きません。', b2=True)),
    ('t','ここがうれしいところ。<b>主語がだれでも、過去形は同じ形</b>です。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜過去形に <span class="en">s</span> はつけない', [
    ('t','ここが今回のヤマです。Unit 6 でさんざん <span class="en">s</span> を練習しましたが、<b>過去形では <span class="en">s</span> のことは忘れてよい</b>のです。'),
    ('h','''<table class="kind">
      <thead><tr><th>主語</th><th>今のこと（現在）</th><th>きのうのこと（過去）</th></tr></thead>
      <tbody>
        <tr><td class="k"><span class="en">I</span></td><td class="e">I play soccer.</td><td class="e" style="color:#7A4FBF;">I play<u>ed</u> soccer.</td></tr>
        <tr><td class="k"><span class="en">you</span></td><td class="e">You play soccer.</td><td class="e" style="color:#7A4FBF;">You play<u>ed</u> soccer.</td></tr>
        <tr><td class="k"><span class="en">he / she</span></td><td class="e">He play<u>s</u> soccer.</td><td class="e" style="color:#7A4FBF;">He play<u>ed</u> soccer.</td></tr>
      </tbody>
    </table>'''),
    ('t','右の列は<b>ぜんぶ同じ形</b>ですね。<b>「過去形になったら、主語のことは気にしなくていい」</b>とおぼえてください。'),
    ('t','<span class="en">He playeds ～.</span> のように <span class="en">s</span> を足す人がいますが、そんな形はありません。'),
  ]),
  ('<span class="en">ed</span> のつけ方は4パターン', [
    ('t','ほとんどは<b>そのまま <span class="en">ed</span></b>。例外は3つです。'),
    ('h','''<table class="kind">
      <thead><tr><th>パターン</th><th>やり方</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k">ふつう</td><td class="k">そのまま <span class="en">ed</span></td><td class="e">play → play<u>ed</u>　watch → watch<u>ed</u></td></tr>
        <tr><td class="k"><span class="en">e</span> で終わる</td><td class="k"><span class="en">d</span> だけ</td><td class="e">like → like<u>d</u>　live → live<u>d</u></td></tr>
        <tr><td class="k">子音＋<span class="en">y</span></td><td class="k"><span class="en">y</span> を <span class="en">i</span> にして <span class="en">ed</span></td><td class="e">study → stud<u>ied</u></td></tr>
        <tr><td class="k">短くて最後が1字</td><td class="k">最後の字を<b>重ねて</b> <span class="en">ed</span></td><td class="e">stop → sto<u>pp</u>ed</td></tr>
      </tbody>
    </table>'''),
    ('t','3-2 の <span class="en">ing</span> のときとよく似ていますね。<b><span class="en">e</span> で終わる語と、子音＋<span class="en">y</span> の語</b>に気をつけるのは同じです。'),
  ]),
  ('形が変わる動詞（不規則動詞）', [
    ('t','よく使う動詞には、<span class="en">ed</span> がつかず<b>形ごと変わるもの</b>があります。数は多くないので、<b>セットで声に出して</b>おぼえましょう。'),
    ('h','''<table class="kind">
      <thead><tr><th>今の形</th><th>過去の形</th><th>意味</th></tr></thead>
      <tbody>
        <tr><td class="k"><span class="en">go</span></td><td class="k" style="color:#7A4FBF;font-weight:700;">went</td><td class="j">行く → 行った</td></tr>
        <tr><td class="k"><span class="en">see</span></td><td class="k" style="color:#7A4FBF;font-weight:700;">saw</td><td class="j">見る → 見た</td></tr>
        <tr><td class="k"><span class="en">eat</span></td><td class="k" style="color:#7A4FBF;font-weight:700;">ate</td><td class="j">食べる → 食べた</td></tr>
        <tr><td class="k"><span class="en">have</span></td><td class="k" style="color:#7A4FBF;font-weight:700;">had</td><td class="j">持つ → 持った</td></tr>
        <tr><td class="k"><span class="en">get</span></td><td class="k" style="color:#7A4FBF;font-weight:700;">got</td><td class="j">手に入れる → 手に入れた</td></tr>
        <tr><td class="k"><span class="en">make</span></td><td class="k" style="color:#7A4FBF;font-weight:700;">made</td><td class="j">作る → 作った</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">goed</span> や <span class="en">eated</span> という形はありません。<b>「<span class="en">go</span> ウェント、<span class="en">see</span> ソー」</b>とリズムでおぼえるのがいちばん速いです。'),
  ]),
  ('be動詞と いっしょに使わない', [
    ('t','これまでと同じルールです。<b>過去形になっても、心臓（動詞）は1つだけ</b>。'),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：心臓（動詞）は 青かピンクの どちらか1つ</div>
        <p><b class="cb">青＝<span class="en">was・were</span></b>　<b class="cp">ピンク＝<span class="en">played・went</span></b>　
        <span class="en">ed</span> がついても、ピンクはピンクのままです。<br>
        <span class="xm">✕ I was played soccer ✕</span>　<span class="xm">✕ I was went to the park ✕</span></p>
      </div>
    </div>'''),
    ('t','<span class="en">was</span> は 7-4 で習う be動詞の過去形です。<b>動作の文には いりません</b>。'),
  ]),
  ('「いつのことか」を言うことば', [
    ('t','過去の文には、<b>いつのことかを表すことば</b>をいっしょに使うと意味がはっきりします。'),
    ('h','''<div class="eqbox" style="border-left-color:#7A4FBF;background:rgba(122,79,191,.07);">
      <span class="eq" style="color:#7A4FBF;">yesterday</span>（きのう）　<span class="eq" style="color:#7A4FBF;">last week</span>（先週）　<span class="eq" style="color:#7A4FBF;">last Sunday</span>（この前の日曜日）<br>
      置く場所は<b>文のいちばん後ろ</b>。<span class="en">I played soccer yesterday.</span>
    </div>'''),
    ('t','これらのことばが文にあったら、<b>動詞は過去形にする</b>という合図です。見つけたらすぐ形を変えましょう。'),
  ]),
 ],
 'quiz':[
  ('I play soccer yesterday.','I played soccer yesterday.','<span class="en">yesterday</span> があるので<b>過去形</b>にします。','わたしは きのう サッカーを しました。'),
  ('I studyed math.','I studied math.','子音＋<span class="en">y</span> なので、<b><span class="en">y</span> を <span class="en">i</span> にして <span class="en">ed</span></b>。','わたしは 数学を 勉強しました。'),
  ('I goed to the park.','I went to the park.','<span class="en">go</span> は形ごと変わって <b><span class="en">went</span></b>。','わたしは 公園へ 行きました。'),
  ('He playeds soccer.','He played soccer.','<b>過去形に <span class="en">s</span> はつけません</b>。主語がだれでも同じ形。','彼は サッカーを しました。'),
  ('I was played soccer.','I played soccer.','心臓（動詞）が2つ。<b><span class="en">was</span> はいりません</b>。','わたしは サッカーを しました。'),
  ('I likeed music.','I liked music.','<span class="en">e</span> で終わる語は <b><span class="en">d</span> だけ</b>つけます。','わたしは 音楽が 好きでした。'),
 ],
 'summary':[
  '過去の文は動詞に <b><span class="en">ed</span></b> をつける。（<span class="en">play → played</span>）',
  '<b>主語がだれでも同じ形。</b><span class="en">s</span> はつけない。',
  '<span class="en">e</span> で終わる語は <b><span class="en">d</span> だけ</b>、子音＋<span class="en">y</span> は <b><span class="en">ied</span></b>。',
  '<b>形ごと変わる動詞</b>がある。<span class="en">go→went</span>、<span class="en">see→saw</span>、<span class="en">eat→ate</span>、<span class="en">have→had</span>。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '過去の文は、動詞のうしろに%sをつける。' % bl('ed'),
     '過去形は主語がだれでも%s。<span class="en">s</span> は%s。' % (bl('同じ形', False), bl('つけない')),
     '<span class="en">like</span> のように <span class="en">e</span> で終わる語は%sだけつける。' % bl('d'),
     '<span class="en">study</span> のように子音＋<span class="en">y</span> の語は、<span class="en">y</span> を%sにして <span class="en">ed</span>。' % bl('i'),
     '<span class="en">go</span> の過去形は%s、<span class="en">see</span> の過去形は%s。' % (bl('went'), bl('saw')),
   ]),
   'words':'語群：<span class="en">ed</span> ／ <span class="en">d</span> ／ <span class="en">i</span> ／ <span class="en">went</span> ／ <span class="en">saw</span> ／ 同じ形 ／ つけない',
   'exp':'<b>なぜ？</b>　<span class="en">s</span> は「今のこと」を言うときだけのしるしです。<b>過去形には別のしるし（<span class="en">ed</span>）がある</b>ので、<span class="en">s</span> はいりません。<br>'
         'おかげで過去形は、主語を気にせず1つの形ですみます。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#7A4FBF;">B　過去形に直そう<em>（　）に正しい形を書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。まず<b>形ごと変わる動詞か</b>を確かめ、そうでなければ <span class="en">ed</span> のつけ方を考えます。',
   'body':grid2([
     '1. <span class="en">I%ssoccer.</span>（play）' % bl('played'),
     '2. <span class="en">I%sto the park.</span>（go）' % bl('went'),
     '3. <span class="en">I%smusic.</span>（like）' % bl('liked'),
     '4. <span class="en">I%sa dog.</span>（see）' % bl('saw'),
     '5. <span class="en">I%smath.</span>（study）' % bl('studied'),
     '6. <span class="en">I%snatto.</span>（eat）' % bl('ate'),
     '7. <span class="en">He%sTV.</span>（watch）' % bl('watched'),
     '8. <span class="en">He%sa dog.</span>（have）' % bl('had'),
     '9. <span class="en">She%sdinner.</span>（cook）' % bl('cooked'),
     '10. <span class="en">She%sKyoto.</span>（visit）' % bl('visited'),
   ]),
   'exp':'<b>見つけ方</b>　<b>形ごと変わる動詞</b>（2・4・6・8）は、おぼえているかどうかだけ。<span class="en">went・saw・ate・had</span>。<br>'
         'それ以外は <span class="en">ed</span> をつけます。3は <span class="en">e</span> で終わるので <span class="en">d</span> だけ、5は <span class="en">y</span> を <span class="en">i</span> にして <span class="en">ied</span>。<br>'
         '7・8・9・10は主語が <span class="en">he / she</span> ですが、<b>過去形なので <span class="en">s</span> はつきません</b>。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#7A4FBF;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. I played soccer yesterday.','○'), ('2. I play soccer yesterday.','✕'),
     ('3. I went to the park.','○'), ('4. I goed to the park.','✕'),
     ('5. He played soccer.','○'), ('6. He playeds soccer.','✕'),
     ('7. I liked music.','○'), ('8. I likeed music.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">I played soccer yesterday.</span>（<span class="en">yesterday</span> があるので過去形）<br>'
         '4 → <span class="en">I went to the park.</span>（<span class="en">go</span> は <span class="en">went</span>）　6 → <span class="en">He played soccer.</span>（s を取る）<br>'
         '8 → <span class="en">I liked music.</span>（<span class="en">e</span> のあとは <span class="en">d</span> だけ）'},
  {'h':'<h3 class="sec sec2">D　過去形　正しいほうを選ぼう</h3>',
   'hint':'そのまま <span class="en">ed</span>／<span class="en">d</span> だけ／<span class="en">ied</span>／形ごと変わる、の4パターンです。',
   'body':grid2([
     '1. <span class="en">play →（ア played ／イ plaied）</span>%s' % bl('ア'),
     '2. <span class="en">like →（ア likeed ／イ liked）</span>%s' % bl('イ'),
     '3. <span class="en">study →（ア studyed ／イ studied）</span>%s' % bl('イ'),
     '4. <span class="en">go →（ア went ／イ goed）</span>%s' % bl('ア'),
     '5. <span class="en">eat →（ア ate ／イ eated）</span>%s' % bl('ア'),
     '6. <span class="en">watch →（ア watchd ／イ watched）</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　ふつうはそのまま <span class="en">ed</span>（1・6）。<span class="en">e</span> で終わる語は <span class="en">d</span> だけ（2）。子音＋<span class="en">y</span> は <span class="en">ied</span>（3）。<br>'
         '4・5は<b>形ごと変わる動詞</b>。こればかりは、おぼえるしかありません。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　<span class="en">yesterday</span> や <span class="en">last ～</span> があれば過去形の合図。形ごと変わる動詞に注意。',
   'body':ol([
     ('<span class="jp-cue">わたしはきのうサッカーをしました。</span>　<span class="en">I%ssoccer yesterday.</span>' % bl('played', False),
      'そのまま <span class="en">ed</span> で <b><span class="en">played</span></b>。'),
     ('<span class="jp-cue">わたしは公園へ行きました。</span>　<span class="en">I%sto the park.</span>' % bl('went'),
      '<span class="en">go</span> は形ごと変わって <b><span class="en">went</span></b>。'),
     ('<span class="jp-cue">わたしは音楽が好きでした。</span>　<span class="en">I%smusic.</span>' % bl('liked'),
      '<span class="en">e</span> で終わるので <b><span class="en">d</span> だけ</b>。'),
     ('<span class="jp-cue">わたしは数学を勉強しました。</span>　<span class="en">I%smath.</span>' % bl('studied', False),
      '<span class="en">y</span> を <span class="en">i</span> にして <b><span class="en">studied</span></b>。'),
     ('<span class="jp-cue">彼はきのうサッカーをしました。</span>　<span class="en">He%ssoccer yesterday.</span>' % bl('played', False),
      '主語が <span class="en">he</span> でも <b><span class="en">s</span> はつけません</b>。1番と同じ形。'),
     ('<span class="jp-cue">わたしは犬を見ました。</span>　<span class="en">I%sa dog.</span>' % bl('saw'),
      '<span class="en">see</span> の過去形は <b><span class="en">saw</span></b>。'),
     ('<span class="jp-cue">わたしは納豆を食べました。</span>　<span class="en">I%snatto.</span>' % bl('ate'),
      '<span class="en">eat</span> の過去形は <b><span class="en">ate</span></b>。'),
     ('<span class="jp-cue">彼女はテレビを見ました。</span>　<span class="en">She%sTV.</span>' % bl('watched', False),
      'そのまま <span class="en">ed</span>。<span class="en">watches</span> ではありません。'),
     ('<span class="jp-cue">わたしは犬を飼っていました。</span>　<span class="en">I%sa dog.</span>' % bl('had'),
      '<span class="en">have</span> の過去形は <b><span class="en">had</span></b>。'),
     ('<span class="jp-cue">彼は先週 京都を訪れました。</span>　<span class="en">He%sKyoto last week.</span>' % bl('visited', False),
      'そのまま <span class="en">ed</span>。<span class="en">last week</span> が過去の合図。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群の動詞が<b>過去形になっているか</b>を見る。<span class="en">yesterday</span> などはいちばん後ろに置きます。',
   'body':ol([
     ('<span class="jp-cue">わたしはきのうサッカーをしました。</span>　<span class="paren en">（ soccer / played / yesterday / I ）</span>' + line('I played soccer yesterday.'),
      '「だれが → どうした → なにを → いつ」の順。'),
     ('<span class="jp-cue">わたしは公園へ行きました。</span>　<span class="paren en">（ to the park / I / went ）</span>' + line('I went to the park.'),
      '<span class="en">to the park</span> でひとかたまり。'),
     ('<span class="jp-cue">彼はきのうテレビを見ました。</span>　<span class="paren en">（ TV / He / yesterday / watched ）</span>' + line('He watched TV yesterday.'),
      '語群が <span class="en">watched</span>。主語が <span class="en">he</span> でも同じ形。'),
     ('<span class="jp-cue">わたしは数学を勉強しました。</span>　<span class="paren en">（ math / studied / I ）</span>' + line('I studied math.'),
      '語群が <span class="en">studied</span>。<b>形はもう決まっています。</b>'),
     ('<span class="jp-cue">わたしは納豆を食べました。</span>　<span class="paren en">（ natto / ate / I ）</span>' + line('I ate natto.'),
      '語群が <span class="en">ate</span>（<span class="en">eat</span> の過去形）。'),
     ('<span class="jp-cue">彼女は先週 京都を訪れました。</span>　<span class="paren en">（ Kyoto / last week / She / visited ）</span>' + line('She visited Kyoto last week.'),
      '<span class="en">last week</span> はいちばん後ろ。'),
     ('<span class="jp-cue">わたしはサッカーをします。</span>　<span class="paren en">（ soccer / play / I ）</span>' + line('I play soccer.'),
      '語群が <span class="en">play</span>（<span class="en">ed</span> なし）。<b>今のことの文</b>です。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしはきのうサッカーをしました。' + wline('I played soccer yesterday.'),
      '<span class="en">yesterday</span> はいちばん後ろ。'),
     ('わたしは公園へ行きました。' + wline('I went to the park.'),
      '<span class="en">goed</span> という形はありません。'),
     ('彼はきのうテレビを見ました。' + wline('He watched TV yesterday.'),
      '主語が <span class="en">he</span> でも <span class="en">s</span> はつけない。'),
     ('わたしは数学を勉強しました。' + wline('I studied math.'),
      '<span class="en">y</span> を <span class="en">i</span> にして <span class="en">ied</span>。'),
     ('わたしは納豆を食べました。' + wline('I ate natto.'),
      '<span class="en">eat</span> の過去形は <span class="en">ate</span>。'),
     ('わたしは音楽が好きでした。' + wline('I liked music.'),
      '<span class="en">e</span> のあとは <span class="en">d</span> だけ。'),
   ]),
   'words':'<span class="en">played ／ went ／ watched ／ studied ／ ate ／ liked</span>'},
  'l4':{'sub':'きのう（または先週）したことを書こう',
   'cond':['過去形の文を <b>4つ以上</b>',
           '<span class="en">yesterday</span> か <span class="en">last ～</span> を <b>1つ以上</b> 使う',
           '<b>形ごと変わる動詞</b>（<span class="en">went・saw・ate・had</span>）を <b>1つ以上</b> 入れる'],
   'example':['I played soccer yesterday. I watched TV.','I went to the park. I ate lunch there.','I studied math last week.'],
   'note':'これは例です。同じでなくてかまいません。きのうの朝・昼・夕方・夜 の順に思い出すと書きやすいです。',
   'check':['動詞を過去形にした','過去形に s をつけていない','go は went、eat は ate','was と動作のことばを混ぜていない'],
   'review':'じぶんの文の動詞に○をつけよう。<span class="en">ed</span> も形の変化もなければ、そこがまちがい。'},
 },
}
