# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'u2-1', 'unit':'2 − 1', 'unit_plain':'2-1', 'title':'You are ～. / Are you ～?',
 'pages':'p.38〜39',
 'hero_big':'You are Ken. ／ Are you Ken?',
 'hero_jp':'あなたは ケン です ／ あなたは ケン ですか',
 'motto':'<span class="en">I</span> には <span class="en">am</span>、<span class="en">you</span> には <span class="en">are</span>。たずねる文は be動詞を<b>前に出す</b>。',
 'kana':{'you':'ユー','are':'アー','yes':'イエス','no':'ノウ',"you're":'ユア',
         "aren't":'アーント','too':'トゥー','new':'ニュー','here':'ヒア',
         'ok':'オウケイ','free':'フリー','busy':'ビズィ','sleepy':'スリーピィ'},
 'blocks':[
  ('きほんの文', [
    ('t','前回までは <span class="en">I</span>（わたし）の文でした。今回は <span class="en">you</span>（あなた）の文です。<b><span class="en">you</span> のときの be動詞は <span class="en">are</span></b> になります。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">You are Ken.</span><span class="t">あなたは ケン です。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">You are from Japan.</span><span class="t">あなたは 日本出身 です。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Are you Ken?</span><span class="t">あなたは ケン ですか。</span></div>
    </div>'''),
    ('t','3つめだけ、<span class="en">are</span> が<b>前に出て</b>、終わりが <b>?</b> になっていますね。ここが今回のポイントです。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('だれの話かで be動詞が変わる', [
    ('t','be動詞は<b>主語（だれの話か）によって形が変わります</b>。今おぼえるのは2つだけです。'),
    ('h','''<table class="kind">
      <thead><tr><th>だれが</th><th>be動詞</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k"><span class="en">I</span>（わたし）</td><td class="k" style="color:var(--key);font-weight:700;">am</td><td class="e">I <u>am</u> a student.</td></tr>
        <tr><td class="k"><span class="en">you</span>（あなた）</td><td class="k" style="color:var(--key);font-weight:700;">are</td><td class="e">You <u>are</u> a student.</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">You am ～.</span> とは言いません。<b><span class="en">I</span> なら <span class="en">am</span>、<span class="en">you</span> なら <span class="en">are</span></b>。セットでおぼえてしまいましょう。'),
    ('t','<span class="en">You are</span> は <span class="en">You&#39;re</span> と短くできます。<span class="en">I am</span> → <span class="en">I&#39;m</span> と同じしくみです。'),
  ]),
  ('かなり大事｜たずねる文は be動詞を<b>前に出す</b>', [
    ('t','「あなたは～ですか」とたずねるときは、<b><span class="en">are</span> を文のいちばん前に動かす</b>だけ。ことばを足したりはしません。'),
    ('h','''<div class="eqbox">
      <span class="eq">You are Ken.</span>　→　<span class="eq">Are you Ken?</span><br>
      ① <span class="en">are</span> を<b>前に出す</b>　② 終わりのピリオドを <b>?</b> に変える　③ <span class="en">Are</span> は文のはじめだから<b>大文字</b>
    </div>'''),
    ('t','やることはこの3つだけです。<b>順番を入れかえるだけ</b>なので、新しい単語はいりません。'),
    ('h','''<div class="blocks">
      <div class="blk fill"><div class="w en">Are</div><div class="r">be動詞を前に</div></div>
      <div class="plus">＋</div>
      <div class="blk fill"><div class="w en">you</div><div class="r">だれが</div></div>
      <div class="plus">＋</div>
      <div class="blk line"><div class="w">そのあと</div><div class="r">Ken / a student / from Japan …</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--ng);"><div class="w">?</div><div class="r">わすれない</div></div>
    </div>'''),
  ]),
  ('答え方は <span class="en">Yes, I am.</span> ／ <span class="en">No, I&#39;m not.</span>', [
    ('t','<span class="en">Are you ～?</span> と聞かれたら、<b>答えるのは自分のこと</b>です。だから <span class="en">you</span> ではなく <span class="en">I</span> を使います。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-smile"/></svg>
          <span>◯ そうです<small>みとめるとき</small></span></div>
        <div class="in"><div class="ex">Yes, I am.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>✕ ちがいます<small>打ち消すとき</small></span></div>
        <div class="in"><div class="ex">No, I&#39;m not.</div></div>
      </div>
    </div>'''),
    ('t','聞かれたのは「<b>あなた</b>は～ですか」。それに答えるのは「<b>わたし</b>は～です」なので、<span class="en">Yes, you are.</span> ではありません。ここをまちがえる人がとても多いところです。'),
  ]),
  ('<span class="en">Are you ～?</span> に <span class="en">do</span> は使わない', [
    ('t','「どんな人か」をたずねるときは <span class="en">Are you ～?</span>、「なにをするか」をたずねるときは次の 2-2 で習う形を使います。今回は<b>be動詞の文だけ</b>です。'),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：心臓（動詞）は 青かピンクの どちらか1つ</div>
        <p><b class="cb">青＝<span class="en">am・are</span></b>　<b class="cp">ピンク＝<span class="en">like・play・have</span></b>　
        青の文に <span class="en">do</span> やピンクの語はまじりません。<br>
        <span class="xm">✕ Do you a student ✕</span>　<span class="xm">✕ Are you like soccer ✕</span></p>
      </div>
    </div>'''),
  ]),
 ],
 'quiz':[
  ('You am Ken.','You are Ken.','<span class="en">you</span> のときの be動詞は <b><span class="en">are</span></b>。<span class="en">am</span> は <span class="en">I</span> 専用です。','あなたは ケン です。'),
  ('You are Ken?','Are you Ken?','たずねる文は <b><span class="en">are</span> を前に出す</b>。順番を変えないとたずねる文になりません。','あなたは ケン ですか。'),
  ('Are you a student.','Are you a student?','終わりが<b>ピリオド</b>になっています。たずねる文の終わりは <b>?</b>。','あなたは 学生 ですか。'),
  ('are you Ken?','Are you Ken?','文のはじめは<b>大文字</b>。前に出した <span class="en">Are</span> も大文字にします。','あなたは ケン ですか。'),
  ('Yes, you are.','Yes, I am.','聞かれたのは「あなたは～ですか」。答えるのは<b>自分のこと</b>なので <span class="en">I am</span>。','はい、そうです。'),
  ('No, I amn&#39;t.','No, I&#39;m not.','<span class="en">amn&#39;t</span> という形は<b>ありません</b>。<span class="en">I&#39;m not</span> と言います。','いいえ、ちがいます。'),
 ],
 'summary':[
  '「あなたは～です」は <b><span class="en">You are ～.</span></b>　<span class="en">I</span> なら <span class="en">am</span>、<span class="en">you</span> なら <span class="en">are</span>。',
  'たずねる文は <b><span class="en">are</span> を前に出して、終わりを ? にする</b>だけ。',
  '答えは <b><span class="en">Yes, I am.</span> ／ <span class="en">No, I&#39;m not.</span></b>　<span class="en">you</span> ではなく <span class="en">I</span>。',
  'be動詞の文に <b><span class="en">do</span> は使わない。</b>心臓（動詞）は1つだけ。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '<span class="en">I</span> のときの be動詞は%s、<span class="en">you</span> のときは%s。' % (bl('am'), bl('are')),
     '「あなたは～です」は <span class="en">You%s～.</span>　短くすると <span class="en">%s</span>。' % (bl('are'), bl("You're", False)),
     'たずねる文は be動詞を文の%sに出して、終わりを%sに変える。' % (bl('前'), bl('?')),
     '<span class="en">Are you ～?</span> への答えは <span class="en">Yes, I%s.</span> か <span class="en">No, I%snot.</span>' % (bl('am'), bl("'m")),
     'be動詞の文をたずねるときに%sは使わない。' % bl('do'),
   ]),
   'words':'語群：<span class="en">am</span> ／ <span class="en">are</span> ／ <span class="en">You&#39;re</span> ／ <span class="en">&#39;m</span> ／ <span class="en">do</span> ／ 前 ／ ?',
   'exp':'<b>なぜ？</b>　be動詞は「＝」のしるし。だれの話かによって <span class="en">am</span>／<span class="en">are</span> と形が変わります。<br>'
         'たずねる文で前に出すのは<b>be動詞だけ</b>。あとのことばの順番はそのままです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--key);">B　<span class="en">am</span>？ それとも <span class="en">are</span>？<em>（　）に <span class="en">am</span> か <span class="en">are</span> を書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。主語（だれの話か）だけを見ましょう。<span class="en">I</span> → <span class="en">am</span>、<span class="en">you</span> → <span class="en">are</span>。',
   'body':grid2([
     '1. <span class="en">I%sa student.</span>' % bl('am'),
     '2. <span class="en">You%sa student.</span>' % bl('are'),
     '3. <span class="en">You%sfrom Japan.</span>' % bl('are'),
     '4. <span class="en">I%shappy.</span>' % bl('am'),
     '5. <span class="en">%syou Ken?</span>' % bl('Are'),
     '6. <span class="en">I%stwelve.</span>' % bl('am'),
     '7. <span class="en">You%ssleepy.</span>' % bl('are'),
     '8. <span class="en">%syou free?</span>' % bl('Are'),
     '9. <span class="en">I%snot busy.</span>' % bl('am'),
     '10. <span class="en">You%sa soccer fan.</span>' % bl('are'),
   ]),
   'exp':'<b>見つけ方</b>　（　）のすぐ前（たずねる文なら すぐ後ろ）の主語を見るだけ。<br>'
         '<span class="en">I</span> → <span class="en">am</span>（1・4・6・9）　<span class="en">you</span> → <span class="en">are</span>（2・3・7・10）<br>'
         '5・8は<b>たずねる文</b>なので <span class="en">Are</span> が前に出ています。文のはじめなので大文字です。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--key);">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. You are from Japan.','○'), ('2. You am from Japan.','✕'),
     ('3. Are you a student?','○'), ('4. You are a student?','✕'),
     ('5. Are you Ken.','✕'), ('6. You&#39;re happy.','○'),
     ('7. Yes, I am.','○'), ('8. No, I amn&#39;t.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">You are from Japan.</span>（<span class="en">you</span> には <span class="en">are</span>）<br>'
         '4 → <span class="en">Are you a student?</span>（<span class="en">are</span> を前に出す）　5 → <span class="en">Are you Ken?</span>（終わりを ? に）<br>'
         '8 → <span class="en">No, I&#39;m not.</span>（<span class="en">amn&#39;t</span> はない）'},
  {'h':'<h3 class="sec sec2">D　答え方　正しいほうを選ぼう</h3>',
   'hint':'聞かれているのは「あなた」。答えるのは「<b>わたし</b>」です。',
   'body':grid2([
     '1. <span class="en">Are you Ken?</span>　—（ア <span class="en">Yes, I am.</span> ／イ <span class="en">Yes, you are.</span>）%s' % bl('ア'),
     '2. <span class="en">Are you a student?</span>　—（ア <span class="en">No, you&#39;re not.</span> ／イ <span class="en">No, I&#39;m not.</span>）%s' % bl('イ'),
     '3. <span class="en">Are you from Japan?</span>　—（ア <span class="en">Yes, you am.</span> ／イ <span class="en">Yes, I am.</span>）%s' % bl('イ'),
     '4. <span class="en">Are you happy?</span>　—（ア <span class="en">No, I&#39;m not.</span> ／イ <span class="en">No, I amn&#39;t.</span>）%s' % bl('ア'),
     '5. <span class="en">Are you twelve?</span>　—（ア <span class="en">Yes, I do.</span> ／イ <span class="en">Yes, I am.</span>）%s' % bl('イ'),
     '6. <span class="en">Are you busy?</span>　—（ア <span class="en">No, I&#39;m not.</span> ／イ <span class="en">No, I don&#39;t.</span>）%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　<span class="en">Are</span> で聞かれたら <b><span class="en">am</span> で答える</b>。これがルールです。<br>'
         '5・6のように <span class="en">do</span> を使った答えは、<span class="en">Are</span> の文には合いません（<span class="en">do</span> の答えは次の 2-2 で習います）。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　主語が <span class="en">I</span> なら <span class="en">am</span>、<span class="en">you</span> なら <span class="en">are</span>。たずねる文は be動詞が<b>前</b>に来ます。',
   'body':ol([
     ('<span class="jp-cue">あなたはケンです。</span>　<span class="en">You%sKen.</span>' % bl('are'),
      '<span class="en">you</span> なので <b><span class="en">are</span></b>。'),
     ('<span class="jp-cue">あなたは日本出身です。</span>　<span class="en">You%sfrom Japan.</span>' % bl('are'),
      '「～出身」は <span class="en">from</span>。be動詞は <b><span class="en">are</span></b>。'),
     ('<span class="jp-cue">あなたはケンですか。</span>　<span class="en">%syou Ken?</span>' % bl('Are'),
      'たずねる文は <b><span class="en">Are</span> を前に</b>。文のはじめだから大文字。'),
     ('<span class="jp-cue">わたしは生徒です。</span>　<span class="en">I%sa student.</span>' % bl('am'),
      '主語が <span class="en">I</span> なので <b><span class="en">am</span></b>。'),
     ('<span class="jp-cue">あなたは生徒ですか。</span>　<span class="en">%syou%sstudent?</span>' % (bl('Are'), bl('a')),
      '（　）が2つ。<b><span class="en">Are</span></b> と、「1人」の <b><span class="en">a</span></b>。'),
     ('<span class="jp-cue">はい、そうです。</span>　<span class="en">Yes, %s%s.</span>' % (bl('I'), bl('am')),
      '答えるのは<b>自分のこと</b>。<span class="en">you</span> ではありません。'),
     ('<span class="jp-cue">いいえ、ちがいます。</span>　<span class="en">No, I%s%s.</span>' % (bl("'m"), bl('not')),
      '<b><span class="en">I&#39;m not</span></b> の形でおぼえる。'),
     ('<span class="jp-cue">あなたはうれしいです。</span>　<span class="en">%shappy.</span>' % bl("You're", False),
      '<span class="en">You are</span> を短くすると <b><span class="en">You&#39;re</span></b>。'),
     ('<span class="jp-cue">短くしない形にしよう。</span>　<span class="en">You&#39;re a student.</span> →　<span class="en">%s%sa student.</span>' % (bl('You'), bl('are')),
      '<span class="en">You&#39;re</span> をもどすと <b><span class="en">You are</span></b>。'),
     ('<span class="jp-cue">あなたは長野出身ですか。</span>　<span class="en">%syou%sNagano?</span>' % (bl('Are'), bl('from')),
      '3番と5番の組み合わせ。<b><span class="en">Are</span></b> と <b><span class="en">from</span></b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群の<b>いちばん前に来るもの</b>を先に決める。<span class="en">Are</span> があれば、それが先頭です。',
   'body':ol([
     ('<span class="jp-cue">あなたはケンです。</span>　<span class="paren en">（ Ken / you / are ）</span>' + line('You are Ken.'),
      '<span class="en">you</span> → <span class="en">are</span> → なにか の順。'),
     ('<span class="jp-cue">あなたはケンですか。</span>　<span class="paren en">（ Ken / Are / you ）</span>' + line('Are you Ken?'),
      '語群の <span class="en">Are</span> が<b>大文字</b>。だから先頭です。終わりは <b>?</b>。'),
     ('<span class="jp-cue">あなたは生徒ですか。</span>　<span class="paren en">（ a / you / student / Are ）</span>' + line('Are you a student?'),
      '<span class="en">a student</span> でひとかたまり。'),
     ('<span class="jp-cue">わたしは長野出身です。</span>　<span class="paren en">（ from / I / Nagano / am ）</span>' + line('I am from Nagano.'),
      '語群に <span class="en">am</span> がある。主語は <span class="en">I</span>。'),
     ('<span class="jp-cue">あなたは日本出身ですか。</span>　<span class="paren en">（ Japan / you / from / Are ）</span>' + line('Are you from Japan?'),
      '<span class="en">from Japan</span> でひとかたまり。'),
     ('<span class="jp-cue">はい、そうです。</span>　<span class="paren en">（ am / I / Yes, ）</span>' + line('Yes, I am.'),
      '<span class="en">Yes,</span> のうしろにコンマがついたまま使います。'),
     ('<span class="jp-cue">あなたはサッカーファンです。</span>　<span class="paren en">（ fan / a / You&#39;re / soccer ）</span>' + line('You&#39;re a soccer fan.'),
      '語群に <span class="en">are</span> がなく <span class="en">You&#39;re</span> がある。<b>語群を見れば形が分かる。</b>'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('あなたはケンです。' + wline('You are Ken.'),
      '<span class="en">You&#39;re Ken.</span> でも正解。'),
     ('あなたは生徒ですか。' + wline('Are you a student?'),
      '<span class="en">Are</span> を前に、<span class="en">a</span> を忘れず、終わりは <b>?</b>。'),
     ('あなたは日本出身ですか。' + wline('Are you from Japan?'),
      '「～出身」は <span class="en">from</span>。国名は大文字ではじめる。'),
     ('はい、そうです。' + wline('Yes, I am.'),
      '<span class="en">Yes, you are.</span> ではありません。答えは<b>自分のこと</b>。'),
     ('いいえ、ちがいます。' + wline('No, I&#39;m not.'),
      '<span class="en">No, I am not.</span> でも正解。'),
     ('わたしはサッカーファンです。' + wline('I am a soccer fan.'),
      '主語が <span class="en">I</span> にもどったので <span class="en">am</span>。'),
   ]),
   'words':'<span class="en">Ken ／ a student ／ from Japan ／ Yes ／ No ／ a soccer fan</span>'},
  'l4':{'sub':'はじめて会った友だちに、たずねたり答えたりしてみよう',
   'cond':['<span class="en">Are you ～?</span> の文を <b>2つ以上</b>',
           'その答え（<span class="en">Yes, I am.</span> か <span class="en">No, I&#39;m not.</span>）を <b>それぞれ書く</b>',
           '<span class="en">You are ～.</span> の文も <b>1つ</b> 入れる'],
   'example':['Are you a soccer fan? — Yes, I am.','Are you from Tokyo? — No, I&#39;m not.','You are a new student.'],
   'note':'これは例です。同じでなくてかまいません。「出身・学年・すきなもの・今の気もち」のどれかを聞いてみよう。',
   'check':['you には are、I には am','たずねる文の終わりは ?','答えは I で言う','文のはじめは大文字'],
   'review':'じぶんの文の be動詞に○をつけよう。<span class="en">you</span> のそばに <span class="en">am</span> がついていたら、そこがまちがい。'},
 },
}
