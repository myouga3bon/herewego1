# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'u8-2', 'unit':'8 − 2', 'unit_plain':'8-2', 'title':'現在進行形の疑問文 / What are you doing?',
 'pages':'p.118〜119',
 'hero_big':'Are you playing? ／ What are you doing?',
 'hero_jp':'あなたは しているところですか ／ なにを しているところですか',
 'motto':'進行形は <b>be動詞の文</b>。たずねる文は be動詞を前に出す。<span class="en">Do</span> は使わない。',
 'kana':{'doing':'ドゥーイング','playing':'プレイイング','running':'ラニング',
         'swimming':'スウィミング','studying':'スタディイング','watching':'ウォッチング',
         'eating':'イーティング','cooking':'クッキング','reading':'リーディング',
         'what':'ワット','are':'アー','is':'イズ','am':'アム','he':'ヒー','she':'シー',
         'yes':'イエス','no':'ノウ','now':'ナウ',"isn't":'イズント',"aren't":'アーント'},
 'blocks':[
  ('きほんの文', [
    ('t','進行形の<b>たずねる文</b>です。進行形は be動詞の文なので、やり方は 2-1 の <span class="en">Are you ～?</span> とまったく同じ。<b>be動詞を前に出す</b>だけです。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Are you playing soccer?</span><span class="t">あなたは サッカーを しているところですか。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Yes, I am. / No, I&#39;m not.</span><span class="t">はい、しています。／ いいえ、していません。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">What are you doing?</span><span class="t">あなたは なにを しているところですか。</span></div>
    </div>'''),
    ('t','答えも <span class="en">am</span> を使います。<b>聞かれたことばで答える</b>というルールは、ずっと同じです。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜進行形に <span class="en">Do</span> は使わない', [
    ('t','ここが今回のヤマです。<span class="en">playing</span> のような動作のことばがあるので、つい <span class="en">Do</span> を使いたくなります。でも<b>進行形は be動詞の文</b>です。'),
    ('h','''<div class="eqbox">
      <span class="eq">You are playing soccer.</span>　→　<span class="eq">Are you playing soccer?</span><br>
      ① <span class="en">are</span> を<b>前に出す</b>　② 終わりを <b>?</b> に　③ <span class="en">playing</span> は<b>そのまま</b>
    </div>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ Are you ～ing?<small>今していること</small></span></div>
        <div class="in"><div class="ex">Are you playing soccer?<br>— Yes, I am.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-run"/></svg>
          <span>◯ Do you ～?<small>ふだんすること</small></span></div>
        <div class="in"><div class="ex">Do you play soccer?<br>— Yes, I do.</div></div>
      </div>
    </div>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：<span class="en">ing</span> があれば be動詞の文</div>
        <p><b class="cb">青＝<span class="en">Are you ～ing?</span></b>　<b class="cp">ピンク＝<span class="en">Do you ～?</span></b>　
        <span class="en">ing</span> を見つけたら、青だと判断します。<br>
        <span class="xm">✕ Do you playing soccer ✕</span>　<span class="xm">✕ Are you play soccer ✕</span></p>
      </div>
    </div>'''),
    ('t','見分け方はかんたん。<b><span class="en">ing</span> の形があれば be動詞</b>。なければ <span class="en">Do</span> です。'),
  ]),
  ('打ち消しは be動詞のうしろに <span class="en">not</span>', [
    ('t','4-3 で習ったとおりです。<b>be動詞のすぐうしろに <span class="en">not</span></b> を置きます。'),
    ('h','''<table class="kind">
      <thead><tr><th>ふつうの文</th><th>打ち消しの文</th><th>短い形</th></tr></thead>
      <tbody>
        <tr><td class="e">I am playing soccer.</td><td class="e" style="color:var(--ng);">I am <u>not</u> playing soccer.</td><td class="e">I&#39;m not</td></tr>
        <tr><td class="e">He is playing soccer.</td><td class="e" style="color:var(--ng);">He is <u>not</u> playing soccer.</td><td class="e">isn&#39;t</td></tr>
        <tr><td class="e">You are playing soccer.</td><td class="e" style="color:var(--ng);">You are <u>not</u> playing soccer.</td><td class="e">aren&#39;t</td></tr>
      </tbody>
    </table>'''),
    ('t'," <span class=\"en\">I don&#39;t playing ～.</span> とは言いません。<b>be動詞の文には <span class=\"en\">don&#39;t</span> を使わない</b>、これも 4-3 と同じです。"),
  ]),
  ('<span class="en">What are you doing?</span> はまるごとおぼえる', [
    ('t','「今なにしてるの？」という、<b>会話でとてもよく使う文</b>です。<span class="en">doing</span> は <span class="en">do</span>（する）の <span class="en">ing</span> 形です。'),
    ('h','''<div class="eqbox" style="border-left-color:#D98400;background:rgba(217,132,0,.07);">
      <span class="eq" style="color:#D98400;">What are you doing?</span>（なにをしているところですか）<br>
      — <span class="eq" style="color:#D98400;">I am studying English.</span>　答えは<b>進行形のふつうの文</b>で言います。
    </div>'''),
    ('t','<span class="en">What</span> で聞かれているので、<b>答えに <span class="en">Yes / No</span> は使いません</b>。3-1 で習ったとおりです。'),
    ('t','<span class="en">What do you do?</span> だと「ふだんなにをしていますか（職業は？）」という別の意味になります。<b><span class="en">are ～ doing</span> で「今」</b>と覚えましょう。'),
  ]),
  ('主語が変われば be動詞も変わる', [
    ('t','たずねる文でも、使う be動詞は<b>主語で決まります</b>。'),
    ('h','''<div class="blocks">
      <div class="blk fill"><div class="w en">Are</div><div class="r">you のとき</div></div>
      <div class="plus">／</div>
      <div class="blk fill"><div class="w en">Is</div><div class="r">he / she のとき</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w">動詞ing</div><div class="r">そのまま</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--ng);"><div class="w">?</div><div class="r">わすれない</div></div>
    </div>'''),
    ('t','答えも <span class="en">Yes, he is.</span>／<span class="en">No, he isn&#39;t.</span> のように、<b>主語に合わせて</b>答えます。'),
  ]),
 ],
 'quiz':[
  ('Do you playing soccer?','Are you playing soccer?','<span class="en">ing</span> があるので <b>be動詞の文</b>。<span class="en">Do</span> は使いません。','あなたは サッカーを しているところですか。'),
  ('Are you play soccer?','Are you playing soccer?','<b><span class="en">ing</span> が抜けています</b>。be動詞だけでは進行形になりません。','あなたは サッカーを しているところですか。'),
  ('Are you playing soccer? — Yes, I do.','Yes, I am.','<span class="en">Are</span> で聞かれたら <b><span class="en">am</span></b> で答える。','はい、そうです。'),
  ('What are you do?','What are you doing?','<span class="en">do</span> も <b><span class="en">ing</span> の形</b>にします。','あなたは なにを しているところですか。'),
  ('What do you doing?','What are you doing?','<span class="en">ing</span> があるので <b><span class="en">are</span></b>。<span class="en">do</span> は使いません。','あなたは なにを しているところですか。'),
  ('I don&#39;t playing soccer.','I am not playing soccer.','be動詞の文の打ち消しは <b><span class="en">not</span></b>。<span class="en">don&#39;t</span> は使いません。','わたしは サッカーを しているところでは ありません。'),
 ],
 'summary':[
  '進行形のたずねる文は <b>be動詞を前に出す</b>。<span class="en">Are you playing ～?</span>',
  '<b><span class="en">Do</span> は使わない。</b><span class="en">ing</span> があれば be動詞の文。',
  '答えは <b><span class="en">Yes, I am.</span> ／ <span class="en">No, I&#39;m not.</span></b>',
  '打ち消しは <b>be動詞のうしろに <span class="en">not</span></b>。「なにしてるの？」は <span class="en">What are you doing?</span>',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '進行形のたずねる文は、%sを文の前に出す。' % bl('be動詞', False),
     '進行形に%sは使わない。<span class="en">ing</span> があれば be動詞の文。' % bl('Do'),
     '答えは <span class="en">Yes, I%s.</span> ／ <span class="en">No, I&#39;m%s.</span>' % (bl('am'), bl('not')),
     '打ち消しは be動詞のうしろに%sを置く。' % bl('not'),
     '「なにをしているところですか」は <span class="en">What are you%s?</span>' % bl('doing'),
   ]),
   'words':'語群：<span class="en">be動詞</span> ／ <span class="en">Do</span> ／ <span class="en">am</span> ／ <span class="en">not</span> ／ <span class="en">doing</span>',
   'exp':'<b>なぜ？</b>　進行形は <span class="en">I ＝ playing</span>（わたし＝している最中）という<b>be動詞の文</b>です。<br>'
         'だから、たずね方も打ち消し方も、2-1・4-3 で習った be動詞のルールがそのまま使えます。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--key);">B　<span class="en">Are</span>／<span class="en">Is</span>？ それとも <span class="en">Do</span>／<span class="en">Does</span>？<em>（　）に入るものを書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b><span class="en">ing</span> があるか</b>だけを見ましょう。',
   'body':grid2([
     '1. <span class="en">%syou playing soccer?</span>' % bl('Are'),
     '2. <span class="en">%syou play soccer?</span>' % bl('Do'),
     '3. <span class="en">%she running now?</span>' % bl('Is'),
     '4. <span class="en">%she run every day?</span>' % bl('Does'),
     '5. <span class="en">%syou watching TV?</span>' % bl('Are'),
     '6. <span class="en">%sshe cooking now?</span>' % bl('Is'),
     '7. <span class="en">%syou like music?</span>' % bl('Do'),
     '8. <span class="en">%sMike studying math?</span>' % bl('Is'),
     '9. <span class="en">%sshe like music?</span>' % bl('Does'),
     '10. <span class="en">%syou eating lunch?</span>' % bl('Are'),
   ]),
   'exp':'<b>見つけ方</b>　2段階で決めます。<br>'
         '① <b><span class="en">ing</span> がある</b> → be動詞。主語が <span class="en">you</span> なら <span class="en">Are</span>（1・5・10）、<span class="en">he・she</span>・名前なら <span class="en">Is</span>（3・6・8）<br>'
         '② <b><span class="en">ing</span> がない</b> → <span class="en">Do</span>（2・7）か <span class="en">Does</span>（4・9）'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--key);">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. Are you playing soccer?','○'), ('2. Do you playing soccer?','✕'),
     ('3. What are you doing?','○'), ('4. What do you doing?','✕'),
     ('5. Yes, I am.','○'), ('6. Are you playing soccer? — Yes, I do.','✕'),
     ('7. I am not playing soccer.','○'), ('8. I don&#39;t playing soccer.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">Are you playing soccer?</span>（<span class="en">ing</span> があるので be動詞）<br>'
         '4 → <span class="en">What are you doing?</span>（同じく be動詞）　6 → <span class="en">Yes, I am.</span>（聞かれたことばで答える）<br>'
         '8 → <span class="en">I am not playing soccer.</span>（be動詞の文は <span class="en">not</span>）'},
  {'h':'<h3 class="sec sec2">D　答え方　正しいほうを選ぼう</h3>',
   'hint':'先頭のことばと、答えのことばを<b>そろえる</b>だけです。',
   'body':grid2([
     '1. <span class="en">Are you playing soccer?</span>　—（ア <span class="en">Yes, I am.</span> ／イ <span class="en">Yes, I do.</span>）%s' % bl('ア'),
     '2. <span class="en">Do you play soccer?</span>　—（ア <span class="en">Yes, I am.</span> ／イ <span class="en">Yes, I do.</span>）%s' % bl('イ'),
     '3. <span class="en">Is he running?</span>　—（ア <span class="en">Yes, he does.</span> ／イ <span class="en">Yes, he is.</span>）%s' % bl('イ'),
     '4. <span class="en">What are you doing?</span>　—（ア <span class="en">I am studying.</span> ／イ <span class="en">Yes, I am.</span>）%s' % bl('ア'),
     '5. <span class="en">Are you watching TV?</span>　—（ア <span class="en">No, I&#39;m not.</span> ／イ <span class="en">No, I don&#39;t.</span>）%s' % bl('ア'),
     '6. <span class="en">Does she like music?</span>　—（ア <span class="en">Yes, she is.</span> ／イ <span class="en">Yes, she does.</span>）%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　<span class="en">Are/Is</span> → <span class="en">am/is</span>（1・3・5）、<span class="en">Do/Does</span> → <span class="en">do/does</span>（2・6）。<br>'
         '4は <span class="en">What</span> で聞かれているので、<b><span class="en">Yes / No</span> では答えません</b>。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　<span class="en">ing</span> があれば be動詞の文。<span class="en">now</span> があれば進行形の合図です。',
   'body':ol([
     ('<span class="jp-cue">あなたはサッカーをしているところですか。</span>　<span class="en">%syou playing soccer?</span>' % bl('Are'),
      '<span class="en">ing</span> があるので <b><span class="en">Are</span></b>。'),
     ('<span class="jp-cue">はい、しています。</span>　<span class="en">Yes, I%s.</span>' % bl('am'),
      '<span class="en">Are</span> で聞かれたから <b><span class="en">am</span></b>。'),
     ('<span class="jp-cue">いいえ、していません。</span>　<span class="en">No, I&#39;m%s.</span>' % bl('not'),
      '<b><span class="en">I&#39;m not</span></b> の形でおぼえる。'),
     ('<span class="jp-cue">あなたはふだんサッカーをしますか。</span>　<span class="en">%syou play soccer?</span>' % bl('Do'),
      '<span class="en">ing</span> がないので <b><span class="en">Do</span></b>。1番とくらべよう。'),
     ('<span class="jp-cue">彼は今走っているところですか。</span>　<span class="en">%she running now?</span>' % bl('Is'),
      '主語が <span class="en">he</span> なので <b><span class="en">Is</span></b>。'),
     ('<span class="jp-cue">あなたはなにをしているところですか。</span>　<span class="en">What%syou%s?</span>' % (bl('are'), bl('doing')),
      '（　）が2つ。<b><span class="en">are</span> ＋ <span class="en">doing</span></b>。'),
     ('<span class="jp-cue">わたしは英語を勉強しているところです。</span>　<span class="en">I am%sEnglish.</span>' % bl('studying', False),
      '6番の答え。<b>進行形のふつうの文</b>で答える。'),
     ('<span class="jp-cue">わたしはサッカーをしていません。</span>　<span class="en">I am%splaying soccer.</span>' % bl('not'),
      'be動詞のうしろに <b><span class="en">not</span></b>。'),
     ('<span class="jp-cue">彼女は今料理をしているところですか。</span>　<span class="en">Is she%snow?</span>' % bl('cooking', False),
      '<span class="en">Is</span> のうしろは <b><span class="en">ing</span> の形</b>。'),
     ('<span class="jp-cue">はい、しています。</span>（<span class="en">Is she ～?</span> の答え）　<span class="en">Yes, she%s.</span>' % bl('is'),
      '主語に合わせて <b><span class="en">is</span></b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群の<b>大文字で始まることば</b>が先頭。<span class="en">ing</span> の形があれば be動詞を選びます。',
   'body':ol([
     ('<span class="jp-cue">あなたはサッカーをしているところですか。</span>　<span class="paren en">（ soccer / playing / Are / you ）</span>' + line('Are you playing soccer?'),
      '<span class="en">Are</span> → <span class="en">you</span> → <span class="en">ing</span> → なにを の順。終わりは <b>?</b>。'),
     ('<span class="jp-cue">あなたはなにをしているところですか。</span>　<span class="paren en">（ doing / you / What / are ）</span>' + line('What are you doing?'),
      '<span class="en">What</span> → <span class="en">are</span> → <span class="en">you</span> → <span class="en">doing</span>。<b>形ごとおぼえよう。</b>'),
     ('<span class="jp-cue">はい、しています。</span>　<span class="paren en">（ am / I / Yes, ）</span>' + line('Yes, I am.'),
      '<span class="en">Yes,</span> のコンマはそのまま。'),
     ('<span class="jp-cue">彼は今走っているところですか。</span>　<span class="paren en">（ running / he / now / Is ）</span>' + line('Is he running now?'),
      '<span class="en">now</span> はいちばん後ろ。'),
     ('<span class="jp-cue">わたしはサッカーをしていません。</span>　<span class="paren en">（ playing / not / soccer / I am ）</span>' + line('I am not playing soccer.'),
      '<span class="en">I am</span> のうしろに <span class="en">not</span>。'),
     ('<span class="jp-cue">あなたはふだんサッカーをしますか。</span>　<span class="paren en">（ soccer / play / Do / you ）</span>' + line('Do you play soccer?'),
      '語群に <span class="en">ing</span> がない。<b>ふだんのことの文</b>です。'),
     ('<span class="jp-cue">わたしは英語を勉強しているところです。</span>　<span class="paren en">（ English / studying / I / am ）</span>' + line('I am studying English.'),
      'be動詞と <span class="en">ing</span> が2つそろっています。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('あなたはサッカーをしているところですか。' + wline('Are you playing soccer?'),
      '<span class="en">Do</span> は使わない。'),
     ('はい、しています。' + wline('Yes, I am.'),
      '<span class="en">Yes, I do.</span> ではありません。'),
     ('あなたはなにをしているところですか。' + wline('What are you doing?'),
      '4語。<b>形ごとおぼえよう。</b>'),
     ('わたしは英語を勉強しているところです。' + wline('I am studying English.'),
      '<span class="en">I&#39;m studying English.</span> でも正解。'),
     ('彼は今走っているところですか。' + wline('Is he running now?'),
      '主語が <span class="en">he</span> なので <span class="en">Is</span>。'),
     ('わたしはサッカーをしていません。' + wline('I am not playing soccer.'),
      '<span class="en">I&#39;m not playing soccer.</span> でも正解。'),
   ]),
   'words':'<span class="en">Are you ／ playing ／ doing ／ studying ／ running ／ not</span>'},
  'l4':{'sub':'電話で「今なにしてる？」と聞く会話を書こう',
   'cond':['<span class="en">What are you doing?</span> を <b>1つ</b> 使う',
           '<span class="en">Are you ～ing?</span> の文を <b>1つ以上</b>',
           'それぞれの答えも <b>いっしょに書く</b>'],
   'example':['What are you doing? — I am studying math.','Are you watching TV? — No, I&#39;m not.','I am not free now.'],
   'note':'これは例です。同じでなくてかまいません。勉強・テレビ・ごはん・ゲーム など、今していそうなことで作ってみよう。',
   'check':['ing があれば be動詞を使った','Do を進行形に使っていない','答えを am / is でそろえた','What の答えに Yes / No を使っていない'],
   'review':'じぶんの文の先頭に○をつけよう。<span class="en">ing</span> の文なのに <span class="en">Do</span> で始まっていたら、そこがまちがい。'},
 },
}
