# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'u4-3', 'unit':'4 − 3', 'unit_plain':'4-3', 'title':'Is this ～? / be動詞の否定文',
 'pages':'p.66〜67',
 'hero_big':'Is this your bag? ／ This is not my bag.',
 'hero_jp':'これは あなたの かばん ですか ／ これは わたしの かばん では ありません',
 'motto':'be動詞の打ち消しは <b>be動詞のすぐうしろに <span class="en">not</span></b>。<span class="en">don&#39;t</span> は使わない。',
 'kana':{'this':'ズィス','that':'ザット','is':'イズ','not':'ノット',
         "isn't":'イズント',"aren't":'アーント',"it's":'イッツ','it':'イット',
         'bag':'バッグ','pen':'ペン','book':'ブック','cap':'キャップ',
         'bike':'バイク','camera':'キャメラ','your':'ユア','my':'マイ',
         'yes':'イエス','no':'ノウ','he':'ヒー','she':'シー'},
 'blocks':[
  ('きほんの文', [
    ('t','今回は<b>「もの」をさす文</b>と、be動詞の<b>打ち消しの文</b>を習います。近いものは <span class="en">this</span>（これ）、遠いものは <span class="en">that</span>（あれ）です。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">This is my bag.</span><span class="t">これは わたしの かばん です。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Is this your bag?</span><span class="t">これは あなたの かばん ですか。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">This is not my bag.</span><span class="t">これは わたしの かばん ではありません。</span></div>
    </div>'''),
    ('t','「ですか」は <span class="en">is</span> を前に出す。「ではありません」は <span class="en">is</span> のうしろに <span class="en">not</span>。<b>どちらも <span class="en">is</span> が中心</b>です。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('たずねる文は <span class="en">is</span> を前に出す', [
    ('t','2-1 の <span class="en">Are you ～?</span> と同じやり方です。<b><span class="en">is</span> を文のいちばん前に出す</b>だけ。'),
    ('h','''<div class="eqbox">
      <span class="eq">This is your bag.</span>　→　<span class="eq">Is this your bag?</span><br>
      ① <span class="en">is</span> を<b>前に出す</b>　② 終わりを <b>?</b> に変える　③ 答えは <span class="en">Yes, it is.</span> ／ <span class="en">No, it isn&#39;t.</span>
    </div>'''),
    ('t','答えの主語は <span class="en">this</span> ではなく <b><span class="en">it</span></b>（それ）を使います。<span class="en">Yes, this is.</span> とは言いません。'),
  ]),
  ('かなり大事｜打ち消しは be動詞のうしろに <span class="en">not</span>', [
    ('t','ここが今回のヤマです。be動詞の文を打ち消すときは、<b>be動詞のすぐうしろに <span class="en">not</span> を置く</b>だけ。'),
    ('h','''<table class="kind">
      <thead><tr><th>ふつうの文</th><th>打ち消しの文</th><th>短い形</th></tr></thead>
      <tbody>
        <tr><td class="e">I am a student.</td><td class="e" style="color:var(--ng);">I am <u>not</u> a student.</td><td class="e">I&#39;m not</td></tr>
        <tr><td class="e">You are tall.</td><td class="e" style="color:var(--ng);">You are <u>not</u> tall.</td><td class="e">aren&#39;t</td></tr>
        <tr><td class="e">This is my bag.</td><td class="e" style="color:var(--ng);">This is <u>not</u> my bag.</td><td class="e">isn&#39;t</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：青は <span class="en">not</span>、ピンクは <span class="en">don&#39;t</span></div>
        <p><b class="cb">青＝be動詞 ＋ <span class="en">not</span></b>　<b class="cp">ピンク＝<span class="en">don&#39;t</span> ＋ 動詞</b>　
        打ち消し方も、青とピンクでちがいます。<br>
        <span class="xm">✕ This don&#39;t my bag ✕</span>　<span class="xm">✕ I don&#39;t a student ✕</span></p>
      </div>
    </div>'''),
    ('t','1-2 で習った <span class="en">don&#39;t</span> は<b>動作のことば専用</b>です。be動詞の文には使いません。ここを混ぜる人がとても多いところです。'),
  ]),
  ('短い形は <span class="en">isn&#39;t</span> ／ <span class="en">aren&#39;t</span>', [
    ('t','<span class="en">is not</span> は <span class="en">isn&#39;t</span>、<span class="en">are not</span> は <span class="en">aren&#39;t</span> と短くできます。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--ng);background:rgba(181,39,63,.06);">
      <span class="eq">is not</span> → <span class="eq" style="color:var(--ng);">isn&#39;t</span>　／　<span class="eq">are not</span> → <span class="eq" style="color:var(--ng);">aren&#39;t</span><br>
      ただし <span class="en">am not</span> は <b><span class="en">amn&#39;t</span> にはできません</b>。<span class="en">I&#39;m not</span> を使います。
    </div>'''),
    ('t','<span class="en">am</span> だけ例外というのは、2-1 でも出てきました。<b><span class="en">I&#39;m not</span> はそのまま形でおぼえる</b>のが早いです。'),
  ]),
  ('<span class="en">this</span> と <span class="en">that</span>', [
    ('t','近くのものは <span class="en">this</span>（これ）、遠くのものは <span class="en">that</span>（あれ）。どちらも be動詞は <b><span class="en">is</span></b> です。'),
    ('h','''<div class="blocks">
      <div class="blk fill"><div class="w en">This</div><div class="r">これ（近い）</div></div>
      <div class="plus">／</div>
      <div class="blk fill"><div class="w en">That</div><div class="r">あれ（遠い）</div></div>
      <div class="plus">＋</div>
      <div class="blk fill"><div class="w en">is</div><div class="r">＝（です）</div></div>
      <div class="plus">＋</div>
      <div class="blk line"><div class="w">なにか</div><div class="r">my bag / a pen …</div></div>
    </div>'''),
    ('t','4-2 で出てきた <span class="en">that girl</span>（あの女の子）の <span class="en">that</span> と同じことばです。'),
  ]),
 ],
 'quiz':[
  ('This don&#39;t my bag.','This is not my bag.','be動詞の打ち消しは <b><span class="en">is not</span></b>。<span class="en">don&#39;t</span> は動作のことば専用です。','これは わたしの かばんでは ありません。'),
  ('This not is my bag.','This is not my bag.','<span class="en">not</span> は be動詞の<b>すぐうしろ</b>。前ではありません。','これは わたしの かばんでは ありません。'),
  ('This is your bag?','Is this your bag?','たずねる文は <b><span class="en">is</span> を前に出す</b>。順番を変えます。','これは あなたの かばん ですか。'),
  ('Is this your bag? — Yes, this is.','Yes, it is.','答えの主語は <b><span class="en">it</span></b>。<span class="en">this</span> は使いません。','はい、そうです。'),
  ('This isnt my bag.','This isn&#39;t my bag.','<b>&#39;（アポストロフィ）</b>を忘れています。<span class="en">is not</span> → <span class="en">isn&#39;t</span>。','これは わたしの かばんでは ありません。'),
  ('I amn&#39;t a student.','I&#39;m not a student.','<span class="en">amn&#39;t</span> という形は<b>ありません</b>。<span class="en">I&#39;m not</span> と言います。','わたしは 学生では ありません。'),
 ],
 'summary':[
  '「これは～ですか」は <b><span class="en">Is this ～?</span></b>　<span class="en">is</span> を前に出して、終わりを ? にする。',
  '答えは <b><span class="en">Yes, it is.</span> ／ <span class="en">No, it isn&#39;t.</span></b>　主語は <span class="en">it</span>。',
  '<b>打ち消しは be動詞のすぐうしろに <span class="en">not</span>。</b><span class="en">don&#39;t</span> は使わない。',
  '短い形は <b><span class="en">isn&#39;t</span> ／ <span class="en">aren&#39;t</span></b>。<span class="en">amn&#39;t</span> はないので <span class="en">I&#39;m not</span>。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     'be動詞の文を打ち消すときは、be動詞の%sに%sを置く。' % (bl('うしろ'), bl('not')),
     '「これは～ですか」は%sを文の前に出して、終わりを%sにする。' % (bl('is'), bl('?')),
     '答えの主語は%sを使う。<span class="en">Yes, %s is.</span> ／ <span class="en">No, it isn&#39;t.</span>' % (bl('it'), bl('it')),
     '<span class="en">is not</span> の短い形は%s、<span class="en">are not</span> は%s。' % (bl("isn't"), bl("aren't")),
     '動作のことばを打ち消すときは%sを使う。be動詞の文には使わない。' % bl("don't"),
   ]),
   'words':'語群：<span class="en">is</span> ／ <span class="en">not</span> ／ <span class="en">it</span> ／ <span class="en">isn&#39;t</span> ／ <span class="en">aren&#39;t</span> ／ <span class="en">don&#39;t</span> ／ うしろ ／ ?',
   'exp':'<b>なぜ？</b>　be動詞は「＝」のしるし。その「＝」を打ち消すので、<b>すぐうしろに <span class="en">not</span></b> を置いて「＝ではない」と表します。<br>'
         '動作のことばには「＝」がないので、<span class="en">don&#39;t</span> という別の打ち消し役が必要になるのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--key);">B　<span class="en">not</span>？ それとも <span class="en">don&#39;t</span>？<em>（　）に <span class="en">not</span> か <span class="en">don&#39;t</span> を書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。be動詞（<span class="en">am・are・is</span>）があれば <span class="en">not</span>、なければ <span class="en">don&#39;t</span>。',
   'body':grid2([
     '1. <span class="en">This is%smy bag.</span>' % bl('not'),
     '2. <span class="en">I%slike natto.</span>' % bl("don't"),
     '3. <span class="en">I am%sa student.</span>' % bl('not'),
     '4. <span class="en">I%splay tennis.</span>' % bl("don't"),
     '5. <span class="en">You are%stall.</span>' % bl('not'),
     '6. <span class="en">I%shave a dog.</span>' % bl("don't"),
     '7. <span class="en">He is%smy friend.</span>' % bl('not'),
     '8. <span class="en">I%sstudy math.</span>' % bl("don't"),
     '9. <span class="en">That is%sa pen.</span>' % bl('not'),
     '10. <span class="en">She is%skind.</span>' % bl('not'),
   ]),
   'exp':'<b>見つけ方</b>　文の中に be動詞があるかだけを見ます。<br>'
         '<b>be動詞がある</b>（<span class="en">is・am・are</span>）→ <span class="en">not</span>（1・3・5・7・9・10）<br>'
         '<b>動作のことばだけ</b>（<span class="en">like・play・have・study</span>）→ <span class="en">don&#39;t</span>（2・4・6・8）'},
  {'h':'<h3 class="sec sec2" style="border-left-color:var(--key);">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. This is not my bag.','○'), ('2. This don&#39;t my bag.','✕'),
     ('3. Is this your bag?','○'), ('4. This is your bag?','✕'),
     ('5. This isn&#39;t my bag.','○'), ('6. This not is my bag.','✕'),
     ('7. No, it isn&#39;t.','○'), ('8. I amn&#39;t a student.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">This is not my bag.</span>（be動詞の文は <span class="en">not</span>）<br>'
         '4 → <span class="en">Is this your bag?</span>（<span class="en">is</span> を前に出す）　6 → <span class="en">This is not my bag.</span>（<span class="en">not</span> をうしろへ）<br>'
         '8 → <span class="en">I&#39;m not a student.</span>（<span class="en">amn&#39;t</span> はない）'},
  {'h':'<h3 class="sec sec2">D　答え方　正しいほうを選ぼう</h3>',
   'hint':'<span class="en">Is this ～?</span> の答えは <b><span class="en">it</span></b> で言います。',
   'body':grid2([
     '1. <span class="en">Is this your bag?</span>　—（ア <span class="en">Yes, it is.</span> ／イ <span class="en">Yes, this is.</span>）%s' % bl('ア'),
     '2. <span class="en">Is this your pen?</span>　—（ア <span class="en">No, it don&#39;t.</span> ／イ <span class="en">No, it isn&#39;t.</span>）%s' % bl('イ'),
     '3. <span class="en">Are you a student?</span>　—（ア <span class="en">No, it isn&#39;t.</span> ／イ <span class="en">No, I&#39;m not.</span>）%s' % bl('イ'),
     '4. <span class="en">Is that your bike?</span>　—（ア <span class="en">Yes, it is.</span> ／イ <span class="en">Yes, that is.</span>）%s' % bl('ア'),
     '5. <span class="en">Do you like natto?</span>　—（ア <span class="en">No, I&#39;m not.</span> ／イ <span class="en">No, I don&#39;t.</span>）%s' % bl('イ'),
     '6. <span class="en">Is this a pen?</span>　—（ア <span class="en">Yes, it is.</span> ／イ <span class="en">Yes, I am.</span>）%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　<span class="en">Is this ～?</span> と聞かれたら、答えの主語は <b><span class="en">it</span></b>（1・2・4・6）。<br>'
         '<span class="en">Are you ～?</span> なら <span class="en">I</span>（3）、<span class="en">Do you ～?</span> なら <span class="en">I ＋ don&#39;t</span>（5）。<b>先頭を見て決める</b>のは今までと同じです。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　be動詞があれば <span class="en">not</span>、動作のことばだけなら <span class="en">don&#39;t</span>。たずねる文は be動詞が前。',
   'body':ol([
     ('<span class="jp-cue">これはわたしのかばんではありません。</span>　<span class="en">This is%smy bag.</span>' % bl('not'),
      'be動詞があるので <b><span class="en">not</span></b>。'),
     ('<span class="jp-cue">これはあなたのかばんですか。</span>　<span class="en">%sthis your bag?</span>' % bl('Is'),
      '<b><span class="en">Is</span></b> を前に出す。文のはじめだから大文字。'),
     ('<span class="jp-cue">はい、そうです。</span>　<span class="en">Yes, %sis.</span>' % bl('it'),
      '答えの主語は <b><span class="en">it</span></b>。<span class="en">this</span> ではない。'),
     ('<span class="jp-cue">いいえ、ちがいます。</span>　<span class="en">No, it%s.</span>' % bl("isn't"),
      '<b><span class="en">isn&#39;t</span></b>。&#39;（アポストロフィ）を忘れずに。'),
     ('<span class="jp-cue">わたしは納豆が好きではありません。</span>　<span class="en">I%slike natto.</span>' % bl("don't"),
      '動作のことばなので <b><span class="en">don&#39;t</span></b>。1番とくらべよう。'),
     ('<span class="jp-cue">わたしは生徒ではありません。</span>　<span class="en">I%s%sa student.</span>' % (bl('am'), bl('not')),
      '（　）が2つ。<b><span class="en">am</span> → <span class="en">not</span></b> の順。'),
     ('<span class="jp-cue">あれはわたしの自転車ではありません。</span>　<span class="en">That%snot my bike.</span>' % bl('is'),
      '<span class="en">that</span> も be動詞は <b><span class="en">is</span></b>。'),
     ('<span class="jp-cue">短い形にしよう。</span>　<span class="en">This is not my bag.</span> →　<span class="en">This%smy bag.</span>' % bl("isn't", False),
      '<b><span class="en">is not</span> ＝ <span class="en">isn&#39;t</span></b>。'),
     ('<span class="jp-cue">彼はわたしの友だちではありません。</span>　<span class="en">He%s%smy friend.</span>' % (bl('is'), bl('not')),
      '6番と同じ形。主語が <span class="en">he</span> なので <span class="en">is</span>。'),
     ('<span class="jp-cue">あれはあなたのペンですか。</span>　<span class="en">%s%syour pen?</span>' % (bl('Is'), bl('that')),
      '「あれ」は <b><span class="en">that</span></b>。<span class="en">Is</span> が前。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　<span class="en">not</span> は be動詞の<b>すぐうしろ</b>に置きます。語群に大文字の語があれば、それが先頭。',
   'body':ol([
     ('<span class="jp-cue">これはわたしのかばんではありません。</span>　<span class="paren en">（ my bag / not / This / is ）</span>' + line('This is not my bag.'),
      '<span class="en">This</span> → <span class="en">is</span> → <span class="en">not</span> → なにか の順。'),
     ('<span class="jp-cue">これはあなたのかばんですか。</span>　<span class="paren en">（ your bag / this / Is ）</span>' + line('Is this your bag?'),
      '語群の <span class="en">Is</span> が大文字。だから先頭です。'),
     ('<span class="jp-cue">はい、そうです。</span>　<span class="paren en">（ is / it / Yes, ）</span>' + line('Yes, it is.'),
      '<span class="en">Yes,</span> のコンマはそのまま。'),
     ('<span class="jp-cue">わたしは生徒ではありません。</span>　<span class="paren en">（ a student / am / I / not ）</span>' + line('I am not a student.'),
      '<span class="en">am</span> → <span class="en">not</span> の順。<span class="en">a student</span> でひとかたまり。'),
     ('<span class="jp-cue">わたしは納豆が好きではありません。</span>　<span class="paren en">（ natto / like / don&#39;t / I ）</span>' + line('I don&#39;t like natto.'),
      '語群に <span class="en">don&#39;t</span> がある。<b>動作の文</b>です。'),
     ('<span class="jp-cue">これはわたしのペンではありません。</span>　<span class="paren en">（ my pen / isn&#39;t / This ）</span>' + line('This isn&#39;t my pen.'),
      '語群が <span class="en">isn&#39;t</span>。短い形で書きます。'),
     ('<span class="jp-cue">あれはあなたの自転車ですか。</span>　<span class="paren en">（ your bike / that / Is ）</span>' + line('Is that your bike?'),
      '2番と同じ形。<span class="en">this</span> が <span class="en">that</span> になっただけ。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('これはわたしのかばんではありません。' + wline('This is not my bag.'),
      '<span class="en">This isn&#39;t my bag.</span> でも正解。'),
     ('これはあなたのかばんですか。' + wline('Is this your bag?'),
      '<span class="en">Is</span> を前に、終わりは <b>?</b>。'),
     ('はい、そうです。' + wline('Yes, it is.'),
      '<span class="en">Yes, this is.</span> ではありません。'),
     ('わたしは生徒ではありません。' + wline('I am not a student.'),
      '<span class="en">I&#39;m not a student.</span> でも正解。'),
     ('わたしは納豆が好きではありません。' + wline('I don&#39;t like natto.'),
      '動作のことばなので <span class="en">don&#39;t</span>。1番とまちがえないこと。'),
     ('あれはわたしの自転車ではありません。' + wline('That is not my bike.'),
      '<span class="en">That isn&#39;t my bike.</span> でも正解。'),
   ]),
   'words':'<span class="en">my bag ／ your bag ／ it is ／ a student ／ natto ／ my bike</span>'},
  'l4':{'sub':'机の上のものについて、たずねたり打ち消したりしよう',
   'cond':['<span class="en">Is this ～?</span> か <span class="en">Is that ～?</span> の文を <b>2つ以上</b>',
           'それぞれの答え（<span class="en">Yes, it is.</span> ／ <span class="en">No, it isn&#39;t.</span>）を書く',
           '<span class="en">This is not ～.</span> の文も <b>1つ</b> 入れる'],
   'example':['Is this your pen? — Yes, it is.','Is that your bag? — No, it isn&#39;t.','This is not my book.'],
   'note':'これは例です。同じでなくてかまいません。かばん・ペン・本・ぼうし・自転車 のどれかで書いてみよう。',
   'check':['be動詞の打ち消しは not','don&#39;t を be動詞の文に使っていない','答えの主語は it','isn&#39;t のアポストロフィ'],
   'review':'じぶんの文の打ち消しのことばに○をつけよう。be動詞の文に <span class="en">don&#39;t</span> があったら、そこがまちがい。'},
 },
}
