# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, copybox, gmap

S = {
 'id':'u3-3', 'unit':'3 − 3', 'unit_plain':'3-3', 'title':'want to ＋動詞の原形',
 'pages':'p.52〜53',
 'hero_big':'I want to go to America.',
 'hero_jp':'わたしは アメリカに 行きたいです',
 'motto':'<span class="en">want to</span> のうしろは<b>原形（もとの形）</b>。<span class="en">to</span> を忘れない。<span class="en">can</span> には <span class="en">to</span> をつけない。',
 'kana':{'want':'ウォント','to':'トゥ','go':'ゴウ','see':'スィー','be':'ビー',
         'visit':'ヴィズィット','buy':'バイ','drink':'ドリンク','water':'ウォーター',
         'america':'アメリカ','paris':'パリス','doctor':'ダクター','teacher':'ティーチャー',
         'singer':'スィンガー','eat':'イート','sushi':'スーシ','someday':'サムデイ'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>アメリカに 行きたい</b>」のように、<b>これからしたいこと</b>を言う形です。'),
    ('t','使うのは <span class="en">want to</span>。そのうしろは<b>かざりのない原形（もとの形）</b>です。'),
    ('h', gmap('アメリカに <b>行きたい</b>', '<b>want to</b> go to America',
               '<b>want to</b> が「～したい」。うしろは <span class="en">go・see・be</span> のように<b>原形（もとの形）</b>。')),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I want to go to America.</span><span class="t">わたしは アメリカに 行きたいです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I want to see pandas.</span><span class="t">わたしは パンダを 見たいです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I want to be a doctor.</span><span class="t">わたしは 医者に なりたいです。</span></div>
    </div>'''),
    ('t','3つとも <span class="en">want to</span> のうしろが <span class="en">go・see・be</span> と<b>原形（もとの形）</b>になっていますね。ここがポイントです。'),
    ('h', copybox()),
  ]),
  ('<span class="en">want to</span> は2語セットでおぼえる', [
    ('t','<span class="en">want</span> だけでは「ほしい」という意味です。<b><span class="en">to</span> をつけて <span class="en">want to</span> にすると「～したい」</b>になります。'),
    ('h','''<div class="blocks">
      <div class="blk fill" style="background:var(--gv);"><div class="w en">I</div><div class="r">だれが</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:#D98400;"><div class="w en">want to</div><div class="r">～したい</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">go</div><div class="r">原形（もとの形）</div></div>
      <div class="plus">＋</div>
      <div class="blk line" style="border-color:var(--gv);color:var(--gv);"><div class="w">どこへ・なにを</div><div class="r">to America / pandas …</div></div>
    </div>'''),
    ('t','<span class="en">want to</span> は<b>いつも2語セット</b>。<span class="en">to</span> を落として <span class="en">I want go ～.</span> とすると通じません。'),
  ]),
  ('かなり大事｜<span class="en">to</span> をつけるか つけないか', [
    ('t','ここが今回のヤマです。1-3 の <span class="en">can</span> と、今回の <span class="en">want to</span> で、<b>まったく逆</b>になります。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-smile"/></svg>
          <span>◯ to が必要<small>「～したい」</small></span></div>
        <div class="in"><div class="ex">I want <u>to</u> swim.</div>
          <div class="memo"><span class="en">want</span> のあとに <b><span class="en">to</span></b>。</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-run"/></svg>
          <span>✕ to はいらない<small>「～できる」</small></span></div>
        <div class="in"><div class="ex">I can swim.</div>
          <div class="memo"><span class="en">can</span> のあとに <span class="en">to</span> は<b>つけない</b>。</div></div>
      </div>
    </div>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：<span class="en">want</span> には <span class="en">to</span>、<span class="en">can</span> には <span class="en">to</span> なし</div>
        <p><b class="cb"><span class="en">want to ＋ 原形（もとの形）</span></b>　<b class="cp"><span class="en">can ＋ 原形（もとの形）</span></b>　
        <b>どちらも「原形（もとの形）」</b>というところは同じです。<br>
        <span class="xm">✕ I can to swim ✕</span>　<span class="xm">✕ I want swim ✕</span></p>
      </div>
    </div>'''),
    ('t','おぼえ方は<b>「<span class="en">to</span> がつくのは <span class="en">want</span> だけ」</b>。うしろが 原形（もとの形）になるのは、どちらも同じです。'),
  ]),
  ('<span class="en">ing</span> との区別', [
    ('t','3-2 で習った <span class="en">ing</span> とも混ざりやすいところです。<b>前にあることばで決まります</b>。'),
    ('h''','''<table class="kind">
      <thead><tr><th>前にあることば</th><th>うしろの形</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k"><span class="en">like</span>（好き）</td><td class="k" style="color:var(--gv);font-weight:700;">～ing</td><td class="e">I like <u>swimming</u>.</td></tr>
        <tr><td class="k"><span class="en">can</span>（できる）</td><td class="k" style="color:#7A4FBF;font-weight:700;">原形（もとの形）</td><td class="e">I can <u>swim</u>.</td></tr>
        <tr><td class="k"><span class="en">want to</span>（したい）</td><td class="k" style="color:#D98400;font-weight:700;">原形（もとの形）</td><td class="e">I want to <u>swim</u>.</td></tr>
      </tbody>
    </table>'''),
    ('t','<b><span class="en">ing</span> になるのは <span class="en">like</span> のうしろだけ</b>と考えておけば、しばらくは困りません。'),
  ]),
  ('<span class="en">want to be</span> で「～になりたい」', [
    ('t','「医者に<b>なりたい</b>」のように、しょうらいの夢を言うときは <span class="en">want to be</span> を使います。'),
    ('h','''<div class="eqbox" style="border-left-color:#D98400;background:rgba(217,132,0,.07);">
      <span class="eq" style="color:#D98400;">I want to be a doctor.</span>　わたしは 医者に なりたいです。<br>
      <span class="en">be</span> は <span class="en">am・are・is</span> の<b>原形（もとの形）</b>です。<span class="en">I want to am ～.</span> とは言いません。
    </div>'''),
    ('t','職業には <b><span class="en">a</span></b> をつけます（<span class="en">a doctor・a teacher・a singer</span>）。「1人」だからです。'),
  ]),
 ],
 'quiz':[
  ('I want go to America.','I want to go to America.','<span class="en">want</span> と <span class="en">to</span> は<b>2語セット</b>。<span class="en">to</span> を落とさない。','わたしは アメリカに 行きたいです。'),
  ('I want to going to America.','I want to go to America.','<span class="en">to</span> のうしろは <b>原形（もとの形）</b>。<span class="en">ing</span> はつけません。','わたしは アメリカに 行きたいです。'),
  ('I can to swim.','I can swim.','<span class="en">can</span> のうしろに <b><span class="en">to</span> はいりません</b>。<span class="en">to</span> がつくのは <span class="en">want</span> だけ。','わたしは 泳ぐことが できます。'),
  ('I want to am a doctor.','I want to be a doctor.','<span class="en">am</span> の原形（もとの形）は <b><span class="en">be</span></b>。<span class="en">to</span> のうしろは 原形（もとの形）です。','わたしは 医者に なりたいです。'),
  ('I want to be doctor.','I want to be a doctor.','職業には <b><span class="en">a</span></b> が必要。「1人」だからです。','わたしは 医者に なりたいです。'),
  ('I am want to swim.','I want to swim.','心臓（動詞）が2つ。<b><span class="en">am</span> はいりません</b>。','わたしは 泳ぎたいです。'),
 ],
 'summary':[
  '「～したい」は <b><span class="en">I want to ＋ 原形（もとの形）</span></b>。<span class="en">want to</span> は2語セット。',
  '<b><span class="en">to</span> のうしろは 原形（もとの形）。</b><span class="en">ing</span> も <span class="en">s</span> もつけない。',
  '<b><span class="en">can</span> のうしろに <span class="en">to</span> はつけない。</b><span class="en">to</span> がつくのは <span class="en">want</span> だけ。',
  '「～になりたい」は <b><span class="en">want to be</span></b>。職業には <span class="en">a</span> をつける。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～したい」は <span class="en">I want%s＋ 動詞.</span>　<span class="en">want</span> と <span class="en">to</span> は%sセット。' % (bl('to'), bl('2語')),
     '<span class="en">to</span> のうしろの動詞は%sにする。' % bl('原形', False),
     '%sのうしろには <span class="en">to</span> をつけない。' % bl('can'),
     '「～になりたい」は <span class="en">want to%s</span>。これは <span class="en">am・are・is</span> の原形（もとの形）。' % bl('be'),
     '<span class="en">like</span> のうしろは%sの形になる。<span class="en">want to</span> のうしろとはちがう。' % bl('ing'),
   ]),
   'words':'語群：<span class="en">to</span> ／ <span class="en">be</span> ／ <span class="en">can</span> ／ <span class="en">ing</span> ／ 原形 ／ 2語',
   'exp':'<b>なぜ？</b>　<span class="en">to</span> は「これから～へ向かう」というイメージのことば。<b>これからしたいこと</b>を表すので <span class="en">want</span> と相性がよいのです。<br>'
         '<span class="en">can</span> は「できる力を持っている」という意味で、これから向かうわけではないので <span class="en">to</span> がいりません。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">to</span> はいる？ いらない？<em>（　）に <span class="en">to</span> か <span class="en">×</span> を書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。（　）の<b>前</b>を見ましょう。<span class="en">want</span> なら <span class="en">to</span>、<span class="en">can</span> なら <span class="en">×</span>。',
   'body':grid2([
     '1. <span class="en">I want%sswim.</span>' % bl('to'),
     '2. <span class="en">I can%sswim.</span>' % bl('×'),
     '3. <span class="en">I want%sgo to Paris.</span>' % bl('to'),
     '4. <span class="en">I can%scook.</span>' % bl('×'),
     '5. <span class="en">I want%sbe a doctor.</span>' % bl('to'),
     '6. <span class="en">I can&#39;t%sdance.</span>' % bl('×'),
     '7. <span class="en">I want%ssee pandas.</span>' % bl('to'),
     '8. <span class="en">I can%srun fast.</span>' % bl('×'),
     '9. <span class="en">I want%seat sushi.</span>' % bl('to'),
     '10. <span class="en">I can%ssing well.</span>' % bl('×'),
   ]),
   'exp':'<b>見つけ方</b>　（　）のすぐ前を見るだけ。<br>'
         '<span class="en">want</span> → <b><span class="en">to</span></b>（1・3・5・7・9）　<span class="en">can</span>・<span class="en">can&#39;t</span> → <b><span class="en">×</span></b>（2・4・6・8・10）<br>'
         'どちらの場合も、そのうしろの動詞は<b>原形（もとの形）</b>です。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. I want to swim.','○'), ('2. I want swim.','✕'),
     ('3. I can swim.','○'), ('4. I can to swim.','✕'),
     ('5. I want to be a doctor.','○'), ('6. I want to am a doctor.','✕'),
     ('7. I want to see pandas.','○'), ('8. I want to going to Paris.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">I want to swim.</span>（<span class="en">to</span> を足す）　4 → <span class="en">I can swim.</span>（<span class="en">to</span> を消す）<br>'
         '6 → <span class="en">I want to be a doctor.</span>（<span class="en">am</span> → <span class="en">be</span>）　8 → <span class="en">I want to go to Paris.</span>（ing を取る）'},
  {'h':'<h3 class="sec sec2">D　うしろの形　正しいほうを選ぼう</h3>',
   'hint':'<span class="en">like</span> → <span class="en">ing</span>／<span class="en">can</span> → 原形（もとの形）／<span class="en">want to</span> → 原形（もとの形）。',
   'body':grid2([
     '1. <span class="en">I want to（ア swim ／イ swimming）.</span>%s' % bl('ア'),
     '2. <span class="en">I like（ア swim ／イ swimming）.</span>%s' % bl('イ'),
     '3. <span class="en">I can（ア swimming ／イ swim）.</span>%s' % bl('イ'),
     '4. <span class="en">I want to（ア be ／イ am）a doctor.</span>%s' % bl('ア'),
     '5. <span class="en">I like（ア dancing ／イ dance）.</span>%s' % bl('ア'),
     '6. <span class="en">I want to（ア going ／イ go）to Paris.</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　<span class="en">ing</span> になるのは <span class="en">like</span> のうしろだけ（2・5）。<br>'
         '<span class="en">can</span>（3）も <span class="en">want to</span>（1・4・6）も、うしろは<b>原形（もとの形）</b>です。4の <span class="en">be</span> は <span class="en">am</span> の原形（もとの形）。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　「～したい」なら <span class="en">want to</span>、「～できる」なら <span class="en">can</span>、「～が好き」なら <span class="en">like ～ing</span>。',
   'body':ol([
     ('<span class="jp-cue">わたしは泳ぎたいです。</span>　<span class="en">I want%sswim.</span>' % bl('to'),
      '<b><span class="en">want to</span></b> で2語セット。'),
     ('<span class="jp-cue">わたしはアメリカに行きたいです。</span>　<span class="en">I want to%sto America.</span>' % bl('go'),
      '<span class="en">to</span> のうしろは <b>原形（もとの形）</b>の <span class="en">go</span>。'),
     ('<span class="jp-cue">わたしは医者になりたいです。</span>　<span class="en">I want to%sa doctor.</span>' % bl('be'),
      '「～になる」は <b><span class="en">be</span></b>。<span class="en">am</span> ではありません。'),
     ('<span class="jp-cue">わたしは泳ぐことができます。</span>　<span class="en">I%sswim.</span>' % bl('can'),
      '「できます」は <b><span class="en">can</span></b>。<span class="en">to</span> はいりません。'),
     ('<span class="jp-cue">わたしは泳ぐことが好きです。</span>　<span class="en">I like%s.</span>' % bl('swimming', False),
      '「好きです」なので <b><span class="en">ing</span></b> の形。1・4番とくらべよう。'),
     ('<span class="jp-cue">わたしはパンダを見たいです。</span>　<span class="en">I%s%ssee pandas.</span>' % (bl('want'), bl('to')),
      '（　）が2つ。<b><span class="en">want</span> → <span class="en">to</span></b>。'),
     ('<span class="jp-cue">わたしは先生になりたいです。</span>　<span class="en">I want to be%steacher.</span>' % bl('a'),
      '職業には <b><span class="en">a</span></b> をつける。'),
     ('<span class="jp-cue">わたしはすしを食べたいです。</span>　<span class="en">I want to%ssushi.</span>' % bl('eat'),
      '<b>原形（もとの形）</b>の <span class="en">eat</span>。<span class="en">eating</span> にしない。'),
     ('<span class="jp-cue">わたしは料理をすることができません。</span>　<span class="en">I%scook.</span>' % bl("can't"),
      '「できません」は <b><span class="en">can&#39;t</span></b>。<span class="en">to</span> はつけない。'),
     ('<span class="jp-cue">わたしはパリに行きたいです。</span>　<span class="en">I%s%sgo to Paris.</span>' % (bl('want'), bl('to')),
      '6番と同じ形。<b><span class="en">want to</span> ＋ 原形（もとの形）</b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群に <span class="en">to</span> があれば <span class="en">want</span> のすぐうしろに置きます。',
   'body':ol([
     ('<span class="jp-cue">わたしは泳ぎたいです。</span>　<span class="paren en">（ swim / to / I / want ）</span>' + line('I want to swim.'),
      '<span class="en">I</span> → <span class="en">want</span> → <span class="en">to</span> → 動詞 の順。'),
     ('<span class="jp-cue">わたしはアメリカに行きたいです。</span>　<span class="paren en">（ to America / want / I / go / to ）</span>' + line('I want to go to America.'),
      '<span class="en">to</span> が2回出てきます。1つめは <span class="en">want</span> のうしろ。'),
     ('<span class="jp-cue">わたしは医者になりたいです。</span>　<span class="paren en">（ a doctor / be / I / want / to ）</span>' + line('I want to be a doctor.'),
      '<span class="en">a doctor</span> でひとかたまり。'),
     ('<span class="jp-cue">わたしは泳ぐことができます。</span>　<span class="paren en">（ swim / I / can ）</span>' + line('I can swim.'),
      '語群に <span class="en">to</span> がない。<b>ないものは使えません。</b>'),
     ('<span class="jp-cue">わたしはパンダを見たいです。</span>　<span class="paren en">（ pandas / to / see / I / want ）</span>' + line('I want to see pandas.'),
      '1番と同じ形。'),
     ('<span class="jp-cue">わたしはおどることが好きです。</span>　<span class="paren en">（ dancing / like / I ）</span>' + line('I like dancing.'),
      '語群が <span class="en">dancing</span>。<span class="en">like</span> とセットです。'),
     ('<span class="jp-cue">わたしはすしを食べたいです。</span>　<span class="paren en">（ sushi / want / eat / I / to ）</span>' + line('I want to eat sushi.'),
      '<span class="en">want</span> → <span class="en">to</span> → <span class="en">eat</span> → <span class="en">sushi</span>。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしは泳ぎたいです。' + wline('I want to swim.'),
      '<span class="en">to</span> を落とさないこと。'),
     ('わたしはアメリカに行きたいです。' + wline('I want to go to America.'),
      '<span class="en">to</span> が2回。国名は大文字ではじめる。'),
     ('わたしは医者になりたいです。' + wline('I want to be a doctor.'),
      '<span class="en">be</span> と <span class="en">a</span> の2つを忘れない。'),
     ('わたしは泳ぐことができます。' + wline('I can swim.'),
      '<span class="en">to</span> はいりません。1番とまちがえないこと。'),
     ('わたしはすしを食べたいです。' + wline('I want to eat sushi.'),
      '<span class="en">eat</span> は原形（もとの形）。'),
     ('わたしはおどることが好きです。' + wline('I like dancing.'),
      '「好きです」なので <span class="en">ing</span>。3つの形がそろいました。'),
   ]),
   'words':'<span class="en">want to ／ go to America ／ be a doctor ／ can ／ eat sushi ／ dancing</span>'},
  'l4':{'sub':'じぶんの「したいこと・なりたいもの」を書こう',
   'cond':['<span class="en">I want to ～.</span> の文を <b>2つ以上</b>',
           '<span class="en">I want to be ～.</span> の文を <b>1つ</b>',
           '<span class="en">I can ～.</span> の文も <b>1つ</b> 入れる（<span class="en">to</span> をつけない）'],
   'example':['I want to go to America. I want to see pandas.','I want to be a teacher.','I can swim.'],
   'note':'これは例です。同じでなくてかまいません。行きたい場所・見たいもの・食べたいもの・なりたい職業 から選ぼう。',
   'check':['want のうしろに to がある','to のうしろは 原形（もとの形）','can に to をつけていない','職業には a をつけた'],
   'review':'じぶんの文の <span class="en">to</span> に○をつけよう。<span class="en">can</span> のうしろに <span class="en">to</span> がついていたら、そこがまちがい。'},
 },
}
