# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, copybox, gmap

S = {
 'id':'u6-2', 'unit':'6 − 2', 'unit_plain':'6-2', 'title':'Does ～?',
 'pages':'p.88〜89',
 'hero_big':'Does he play soccer?',
 'hero_jp':'彼は サッカーを しますか',
 'motto':'主語が <span class="en">he・she</span>・名前なら <span class="en">Does</span>。<b><span class="en">Does</span> のあとの動詞は 原形（もとの形）</b>（<span class="en">s</span> を取る）。',
 'kana':{'does':'ダズ',"doesn't":'ダズント','he':'ヒー','she':'シー',
         'play':'プレイ','like':'ライク','have':'ハヴ','study':'スタディ',
         'watch':'ウォッチ','go':'ゴウ','live':'リヴ','cook':'クック',
         'yes':'イエス','no':'ノウ','mike':'マイク','emma':'エマ',
         'brother':'ブラザー','sister':'スィスター','math':'マス','school':'スクール'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>彼は サッカーを しますか</b>」のように、<b>he・she がすること</b>をたずねる文です。'),
    ('t','2-2 の <span class="en">Do you ～?</span> の <span class="en">Do</span> が、<b><span class="en">Does</span></b> に変わります。'),
    ('h', gmap('<b>彼は</b> サッカーを しますか', '<b>Does</b> he play soccer?',
               '<b>Does</b> を前に置くと、動詞は <b><span class="en">plays</span> → <span class="en">play</span></b> と原形（もとの形）にもどります。')),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Does he play soccer?</span><span class="t">彼は サッカーを しますか。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Yes, he does.</span><span class="t">はい、します。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">No, he doesn&#39;t.</span><span class="t">いいえ、しません。</span></div>
    </div>'''),
    ('t','よく見てください。<span class="en">He plays soccer.</span> だったのに、たずねる文では <b><span class="en">play</span> にもどっています</b>。ここが今回のポイントです。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜<span class="en">s</span> は <span class="en">Does</span> に引っこす', [
    ('t','ここが今回のヤマです。<b><span class="en">s</span> は1つの文に1回だけ</b>。たずねる文では、その <span class="en">s</span> が先頭の <span class="en">Does</span> に移動します。'),
    ('h','''<div class="eqbox">
      <span class="eq">He play<b style="color:var(--ng);">s</b> soccer.</span>　→　<span class="eq">Doe<b style="color:var(--ng);">s</b> he play soccer?</span><br>
      <b><span class="en">s</span> が先頭に引っこして、動詞は 原形（もとの形）にもどる</b>。2か所に <span class="en">s</span> は置けません。
    </div>'''),
    ('h','''<div class="blocks">
      <div class="blk fill" style="background:#7A4FBF;"><div class="w en">Does</div><div class="r">s はここ</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">he</div><div class="r">だれが</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--gv);"><div class="w en">play</div><div class="r">原形（もとの形）</div></div>
      <div class="plus">＋</div>
      <div class="blk fill" style="background:var(--ng);"><div class="w">?</div><div class="r">わすれない</div></div>
    </div>'''),
    ('t','おぼえ方は<b>「<span class="en">Does</span> が <span class="en">s</span> を持っていく」</b>。<span class="en">can</span> や <span class="en">Do</span> のうしろが 原形（もとの形）になるのと、まったく同じしくみです。'),
  ]),
  ('<span class="en">Do</span> と <span class="en">Does</span> の使い分け', [
    ('t','どちらを使うかは、<b>主語だけ</b>で決まります。6-1 の <span class="en">s</span> と同じ分け方です。'),
    ('h','''<table class="kind">
      <thead><tr><th>主語</th><th>たずねる文</th><th>答え</th></tr></thead>
      <tbody>
        <tr><td class="k"><span class="en">I / you</span></td><td class="e" style="color:var(--gv);">Do you play ～?</td><td class="e">Yes, I do. / No, I don&#39;t.</td></tr>
        <tr><td class="k"><span class="en">he / she</span>・名前</td><td class="e" style="color:#7A4FBF;">Does he play ～?</td><td class="e">Yes, he does. / No, he doesn&#39;t.</td></tr>
      </tbody>
    </table>'''),
    ('t','答えも<b>聞かれたことばでそろえます</b>。<span class="en">Does</span> で聞かれたら <span class="en">does</span> で答える。これは 2-3 で習ったルールのままです。'),
  ]),
  ('be動詞の文には <span class="en">Does</span> を使わない', [
    ('t','「彼は生徒ですか」のように<b>動作のことばがない文</b>は、<span class="en">Is he ～?</span> を使います。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ Is he ～?<small>「彼は <u>どんな人か</u>」</small></span></div>
        <div class="in"><div class="ex">Is he a student?<br>— Yes, he is.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-run"/></svg>
          <span>◯ Does he ～?<small>「彼は <u>なにをするか</u>」</small></span></div>
        <div class="in"><div class="ex">Does he play soccer?<br>— Yes, he does.</div></div>
      </div>
    </div>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：聞かれたことばで 答える</div>
        <p><b class="cb"><span class="en">Is</span> → <span class="en">is</span></b>　<b class="cp"><span class="en">Does</span> → <span class="en">does</span></b>　
        先頭と答えがそろっていなければ、そこがまちがい。<br>
        <span class="xm">✕ Does he a student ✕</span>　<span class="xm">✕ Does he play soccer? — Yes, he is ✕</span></p>
      </div>
    </div>'''),
  ]),
  ('<span class="en">What does he ～?</span> も同じしくみ', [
    ('t','3-1 の <span class="en">What</span> と組み合わせることもできます。<b><span class="en">What</span> を前に置くだけ</b>で、うしろは変わりません。'),
    ('h','''<div class="eqbox" style="border-left-color:#D98400;background:rgba(217,132,0,.07);">
      <span class="eq" style="color:#D98400;">What does he like?</span>（彼はなにが好きですか）<br>
      — <span class="eq" style="color:#D98400;">He likes music.</span>　答えはふつうの文なので、<b><span class="en">s</span> がもどってきます</b>。
    </div>'''),
    ('t','たずねる文では <span class="en">s</span> が <span class="en">does</span> に移り、答えの文では動詞にもどる。<b>行ったり来たり</b>すると考えると分かりやすいです。'),
  ]),
 ],
 'quiz':[
  ('Do he play soccer?','Does he play soccer?','主語が <span class="en">he</span> なので <b><span class="en">Does</span></b>。','彼は サッカーを しますか。'),
  ('Does he plays soccer?','Does he play soccer?','<span class="en">Does</span> が <span class="en">s</span> を持っているので、動詞は <b>原形（もとの形）</b>。','彼は サッカーを しますか。'),
  ('Does he play soccer? — Yes, he do.','Yes, he does.','<span class="en">Does</span> で聞かれたら <b><span class="en">does</span></b> で答える。','はい、します。'),
  ('Does you like music?','Do you like music?','主語が <span class="en">you</span> なので <b><span class="en">Do</span></b>。','あなたは 音楽が 好きですか。'),
  ('Does he a student?','Is he a student?','動作のことばがないので <b><span class="en">Is</span></b>。<span class="en">Does</span> は使いません。','彼は 学生 ですか。'),
  ('Does he play soccer.','Does he play soccer?','終わりが<b>ピリオド</b>です。たずねる文の終わりは <b>?</b>。','彼は サッカーを しますか。'),
 ],
 'summary':[
  '主語が <b><span class="en">he</span>・<span class="en">she</span>・名前</b> のたずねる文は <span class="en">Does</span> で始める。',
  '<b><span class="en">Does</span> のあとの動詞は 原形（もとの形）。</b><span class="en">s</span> は <span class="en">Does</span> に引っこす。',
  '答えは <b><span class="en">Yes, he does.</span> ／ <span class="en">No, he doesn&#39;t.</span></b>',
  '動作のことばがない文は <b><span class="en">Is he ～?</span></b>。<span class="en">Does</span> は使わない。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '主語が <span class="en">he</span>・<span class="en">she</span>・名前のときのたずねる文は%sで始める。' % bl('Does'),
     '主語が <span class="en">I</span> や <span class="en">you</span> のときは%sで始める。' % bl('Do'),
     '<span class="en">Does</span> のあとの動詞は%sにする。<span class="en">s</span> は%s。' % (bl('原形', False), bl('つけない')),
     '答えは <span class="en">Yes, he%s.</span> ／ <span class="en">No, he%s.</span>' % (bl('does'), bl("doesn't")),
     '動作のことばがない文をたずねるときは%sを使う。' % bl('Is'),
   ]),
   'words':'語群：<span class="en">Do</span> ／ <span class="en">Does</span> ／ <span class="en">does</span> ／ <span class="en">doesn&#39;t</span> ／ <span class="en">Is</span> ／ 原形 ／ つけない',
   'exp':'<b>なぜ？</b>　<span class="en">s</span> は「主語が3人目で1人」というしるし。<b>1つの文に1回あればじゅうぶん</b>です。<br>'
         'たずねる文では先頭の <span class="en">Does</span> がそのしるしを持つので、動詞のほうは 原形（もとの形）にもどります。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#7A4FBF;">B　<span class="en">Do</span>？ <span class="en">Does</span>？ それとも <span class="en">Is</span>？<em>（　）に入るものを書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。まず主語、つぎに動作のことばがあるかを見ましょう。',
   'body':grid2([
     '1. <span class="en">%she play soccer?</span>' % bl('Does'),
     '2. <span class="en">%syou play soccer?</span>' % bl('Do'),
     '3. <span class="en">%sshe like music?</span>' % bl('Does'),
     '4. <span class="en">%she a student?</span>' % bl('Is'),
     '5. <span class="en">%sMike have a dog?</span>' % bl('Does'),
     '6. <span class="en">%syou like music?</span>' % bl('Do'),
     '7. <span class="en">%sshe kind?</span>' % bl('Is'),
     '8. <span class="en">%she study math?</span>' % bl('Does'),
     '9. <span class="en">%syou have a dog?</span>' % bl('Do'),
     '10. <span class="en">%sEmma from Japan?</span>' % bl('Is'),
   ]),
   'exp':'<b>見つけ方</b>　2段階で決めます。<br>'
         '① <b>動作のことばがない</b>（生徒・親切・日本出身）→ <span class="en">Is</span>（4・7・10）<br>'
         '② 動作のことばがあるとき、主語が <span class="en">you</span> → <span class="en">Do</span>（2・6・9）、<span class="en">he・she</span>・名前 → <span class="en">Does</span>（1・3・5・8）'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#7A4FBF;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. Does he play soccer?','○'), ('2. Do he play soccer?','✕'),
     ('3. Does she like music?','○'), ('4. Does she likes music?','✕'),
     ('5. Yes, he does.','○'), ('6. Yes, he do.','✕'),
     ('7. Is he a student?','○'), ('8. Does he a student?','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">Does he play soccer?</span>（主語が <span class="en">he</span>）<br>'
         '4 → <span class="en">Does she like music?</span>（s を取る）　6 → <span class="en">Yes, he does.</span>（<span class="en">does</span> で答える）<br>'
         '8 → <span class="en">Is he a student?</span>（動作のことばがないので <span class="en">Is</span>）'},
  {'h':'<h3 class="sec sec2">D　答え方　正しいほうを選ぼう</h3>',
   'hint':'先頭のことばと、答えのことばを<b>そろえる</b>だけです。',
   'body':grid2([
     '1. <span class="en">Does he play soccer?</span>　—（ア <span class="en">Yes, he does.</span> ／イ <span class="en">Yes, he do.</span>）%s' % bl('ア'),
     '2. <span class="en">Do you like music?</span>　—（ア <span class="en">Yes, I does.</span> ／イ <span class="en">Yes, I do.</span>）%s' % bl('イ'),
     '3. <span class="en">Is he a student?</span>　—（ア <span class="en">Yes, he does.</span> ／イ <span class="en">Yes, he is.</span>）%s' % bl('イ'),
     '4. <span class="en">Does she have a dog?</span>　—（ア <span class="en">No, she doesn&#39;t.</span> ／イ <span class="en">No, she don&#39;t.</span>）%s' % bl('ア'),
     '5. <span class="en">Does Mike study math?</span>　—（ア <span class="en">No, he isn&#39;t.</span> ／イ <span class="en">No, he doesn&#39;t.</span>）%s' % bl('イ'),
     '6. <span class="en">Does he like music?</span>　—（ア <span class="en">Yes, he does.</span> ／イ <span class="en">Yes, he likes.</span>）%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　<span class="en">Does</span> → <span class="en">does</span>（1・4・5・6）、<span class="en">Do</span> → <span class="en">do</span>（2）、<span class="en">Is</span> → <span class="en">is</span>（3）。<br>'
         '6のイのように動詞をくりかえす必要はありません。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　主語が <span class="en">he</span>・<span class="en">she</span>・名前なら <span class="en">Does</span>。そのあとの動詞は<b>原形（もとの形）</b>。',
   'body':ol([
     ('<span class="jp-cue">彼はサッカーをしますか。</span>　<span class="en">%she play soccer?</span>' % bl('Does'),
      '主語が <span class="en">he</span> なので <b><span class="en">Does</span></b>。'),
     ('<span class="jp-cue">はい、します。</span>　<span class="en">Yes, he%s.</span>' % bl('does'),
      '<span class="en">Does</span> で聞かれたから <b><span class="en">does</span></b>。'),
     ('<span class="jp-cue">いいえ、しません。</span>　<span class="en">No, he%s.</span>' % bl("doesn't"),
      '<b><span class="en">doesn&#39;t</span></b>。&#39;（アポストロフィ）を忘れずに。'),
     ('<span class="jp-cue">彼女は音楽が好きですか。</span>　<span class="en">Does she%smusic?</span>' % bl('like'),
      '<span class="en">Does</span> のあとは <b>原形（もとの形）</b>。<span class="en">likes</span> にしない。'),
     ('<span class="jp-cue">あなたはサッカーをしますか。</span>　<span class="en">%syou play soccer?</span>' % bl('Do'),
      '主語が <span class="en">you</span> なので <b><span class="en">Do</span></b>。1番とくらべよう。'),
     ('<span class="jp-cue">マイクは犬を飼っていますか。</span>　<span class="en">%sMike%sa dog?</span>' % (bl('Does'), bl('have')),
      '（　）が2つ。<b><span class="en">Does</span> → <span class="en">have</span></b>（<span class="en">has</span> にしない）。'),
     ('<span class="jp-cue">彼は生徒ですか。</span>　<span class="en">%she a student?</span>' % bl('Is'),
      '動作のことばがないので <b><span class="en">Is</span></b>。'),
     ('<span class="jp-cue">彼女は数学を勉強しますか。</span>　<span class="en">Does she%smath?</span>' % bl('study'),
      '<span class="en">studies</span> にしない。<b>原形（もとの形）</b>。'),
     ('<span class="jp-cue">彼はなにが好きですか。</span>　<span class="en">What%she like?</span>' % bl('does'),
      '<span class="en">What</span> のうしろは <b><span class="en">does he</span></b> の順。'),
     ('<span class="jp-cue">彼は音楽が好きです。</span>　<span class="en">He%smusic.</span>' % bl('likes'),
      '9番の答え。<b>ふつうの文にもどると <span class="en">s</span> が返ってくる</b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　語群の<b>大文字で始まることば</b>が先頭。動詞に <span class="en">s</span> がついていないことを確かめよう。',
   'body':ol([
     ('<span class="jp-cue">彼はサッカーをしますか。</span>　<span class="paren en">（ soccer / he / Does / play ）</span>' + line('Does he play soccer?'),
      '<span class="en">Does</span> → <span class="en">he</span> → 動詞 → なにを の順。終わりは <b>?</b>。'),
     ('<span class="jp-cue">彼女は音楽が好きですか。</span>　<span class="paren en">（ music / like / she / Does ）</span>' + line('Does she like music?'),
      '語群が <span class="en">like</span>（s なし）。<b>語群を見れば形が分かる。</b>'),
     ('<span class="jp-cue">はい、します。</span>　<span class="paren en">（ does / he / Yes, ）</span>' + line('Yes, he does.'),
      '<span class="en">Yes,</span> のコンマはそのまま。'),
     ('<span class="jp-cue">あなたはサッカーをしますか。</span>　<span class="paren en">（ soccer / Do / play / you ）</span>' + line('Do you play soccer?'),
      '語群が <span class="en">Do</span>。主語は <span class="en">you</span>。'),
     ('<span class="jp-cue">マイクは犬を飼っていますか。</span>　<span class="paren en">（ a dog / Mike / Does / have ）</span>' + line('Does Mike have a dog?'),
      '<span class="en">a dog</span> でひとかたまり。<span class="en">has</span> にしない。'),
     ('<span class="jp-cue">彼は生徒ですか。</span>　<span class="paren en">（ a / student / he / Is ）</span>' + line('Is he a student?'),
      '語群が <span class="en">Is</span>。be動詞の文です。'),
     ('<span class="jp-cue">彼はなにが好きですか。</span>　<span class="paren en">（ like / he / What / does ）</span>' + line('What does he like?'),
      '<span class="en">What</span> が先頭、そのあと <span class="en">does he</span>。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('彼はサッカーをしますか。' + wline('Does he play soccer?'),
      '<span class="en">play</span> に <span class="en">s</span> をつけないこと。'),
     ('はい、します。' + wline('Yes, he does.'),
      '<span class="en">Yes, he do.</span> ではありません。'),
     ('彼女は音楽が好きですか。' + wline('Does she like music?'),
      '<span class="en">likes</span> にしない。'),
     ('いいえ、好きではありません。' + wline('No, she doesn&#39;t.'),
      '<span class="en">doesn&#39;t</span> のアポストロフィを忘れない。'),
     ('マイクは犬を飼っていますか。' + wline('Does Mike have a dog?'),
      '<span class="en">has</span> ではなく <span class="en">have</span>。'),
     ('彼は生徒ですか。' + wline('Is he a student?'),
      '動作のことばがないので <span class="en">Is</span>。'),
   ]),
   'words':'<span class="en">play soccer ／ like music ／ have a dog ／ a student ／ Yes ／ No</span>'},
  'l4':{'sub':'友だちのことを、ほかの友だちにたずねよう',
   'cond':['<span class="en">Does he ～?</span> か <span class="en">Does she ～?</span> の文を <b>2つ以上</b>',
           'それぞれの答えを <span class="en">Yes, he does.</span> ／ <span class="en">No, she doesn&#39;t.</span> などで書く',
           '<span class="en">Is he ～?</span> か <span class="en">Is she ～?</span> の文も <b>1つ</b> 入れる'],
   'example':['Does he play soccer? — Yes, he does.','Does she like music? — No, she doesn&#39;t.','Is he a student? — Yes, he is.'],
   'note':'これは例です。同じでなくてかまいません。部活・すきな教科・ペット・住んでいる場所 を聞いてみよう。',
   'check':['Does のあとは 原形（もとの形）','主語が you なら Do','答えを先頭のことばとそろえた','終わりは ?'],
   'review':'じぶんの文の <span class="en">Does</span> のうしろに○をつけよう。動詞に <span class="en">s</span> がついていたら、そこがまちがい。'},
 },
}
