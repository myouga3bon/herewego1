# -*- coding: utf-8 -*-
"""Here We Go! 1 オンライン文法ページ（4ページ）ジェネレータ"""
import os, re, json

BASE = os.path.dirname(os.path.abspath(__file__))
HEAD = open(os.path.join(BASE, 'shell_head.html'), encoding='utf-8').read()
TAIL = open(os.path.join(BASE, 'shell_tail.html'), encoding='utf-8').read()

SECBAR = '    <div class="secbar"><button class="sbtn" onclick="toggleSec(this)">答えを見る</button></div>\n'
ANSBAR = ('  <div class="ansbar"><span class="msg">ぜんぶ終わったら押そう</span>'
          '<button class="abtn" onclick="toggleSheet(this)">全体の答えを見る</button></div>\n')
TOOLBAR = '  <div class="toolbar"><button class="kbtn" onclick="toggleKana(this)">カタカナ</button></div>\n'
NAME = ''


def hintwrap(html):
    if not html:
        return ''
    return ('  <div class="hintwrap"><button class="hbtn" onclick="toggleHint(this)">'
            'どうしてもわからない時のヒント</button>\n'
            '    <div class="faint">%s</div></div>\n' % html)


def head(unit, small, pagelabel, sub2):
    return ('  <div class="head">\n'
            '    <div class="tag">Unit %s <small>%s</small></div>\n'
            '    <div class="sub"><b>%s</b><br>%s</div>\n'
            '  </div>\n' % (unit, small, pagelabel, sub2))


def foot(S, n, label):
    return ('  <div class="foot"><span>Here We Go! %d ／ Unit %s　%s</span>'
            '<span>%d / 4　%s</span></div>\n'
            % (S.get('grade', 1), S['unit_plain'], S['title'], n, label))


def talk(t):
    """。ごとに改行＋字下げ"""
    t = re.sub(r'。(?!\s*</)(?!<br)(?=\S)', '。<br>　', t)
    return '    <p class="talk">%s</p>\n' % t


# ---------- page 1 ----------
def page1(S):
    o = ['<section class="sheet">\n', TOOLBAR]
    o.append(head(S['unit'], 'Here We Go!', '① 文法わかるページ', '教科書 ' + S['pages']))
    o.append('\n  <div class="hero">\n'
             '    <div class="star"><svg><use href="#i-star"/></svg><span>主役</span></div>\n'
             '    <div class="mid">\n'
             '      <div class="lbl"><svg class="lblpen"><use href="#i-pen"/></svg>今回の文法テーマ！</div>\n'
             '      <div class="big">%s</div>\n'
             '      <div class="jp">%s</div>\n'
             '    </div>\n  </div>\n\n' % (S['hero_big'], S['hero_jp']))

    for n, (hd, parts) in enumerate(S['blocks'], 1):
        o.append('  <div class="blk-sec">\n')
        o.append('    <h3 class="st"><span class="stepnum">%d</span>%s</h3>\n' % (n, hd))
        for kind, val in parts:
            if kind == 't':
                o.append(talk(val))
            else:
                o.append('    ' + val.strip() + '\n')
        o.append('  </div>\n\n')

    # クイズ
    o.append('  <div class="quiz">\n')
    o.append('    <div class="qzh">✕ よくある間違いさがしクイズ！<span class="qzs">'
             'どこがまちがい？　ノートに直してから答えを押そう</span></div>\n')
    for n, q in enumerate(S['quiz'], 1):
        bad, good, pt = q[0], q[1], q[2]
        jp = q[3] if len(q) > 3 else ''
        o.append('    <div class="qzi">\n')
        o.append('      <div class="qzq"><span class="no">%d.</span><span class="xm">✕ %s ✕</span>'
                 '<button class="qzb" onclick="toggleQz(this)">答え</button></div>\n' % (n, bad))
        o.append('      <div class="qza"><span class="good en">○ %s</span>%s'
                 '<span class="qzp"><b>ポイント</b>　%s</span></div>\n'
                 % (good, ('<span class="gjp">%s</span>' % jp) if jp else '', pt))
        o.append('    </div>\n')
    o.append('  </div>\n\n')

    # まとめ
    o.append('  <div class="copy sum">\n    <svg><use href="#i-pen"/></svg>\n'
             '    <div>今回のまとめ　ノートに写す<span class="min">目安 2分</span>\n'
             '      <ul class="sumlist">\n')
    for li in S['summary']:
        o.append('        <li>%s</li>\n' % li)
    o.append('      </ul>\n    </div>\n  </div>\n')
    o.append('  <div class="cheer">読み終わったら、②文法たしかめページへ！</div>\n\n')
    o.append(foot(S, 1, '文法わかる'))
    o.append('</section>\n\n')
    return ''.join(o)


# ---------- page 2 ----------
def page2(S):
    o = ['<section class="sheet">\n', TOOLBAR]
    o.append(head(S['unit'], '基本事項チェック', '② 文法たしかめページ', NAME))
    o.append('\n')
    for sec in S['p2']:
        o.append('  <div class="qsec">\n')
        o.append('  ' + sec['h'].strip() + '\n')
        if sec.get('hint'):
            o.append('  <div class="hint">%s</div>\n' % sec['hint'])
        o.append(sec['body'].rstrip('\n') + '\n')
        if sec.get('words'):
            o.append(hintwrap(sec['words']))
        o.append('  <div class="expbox">%s</div>\n' % sec['exp'])
        o.append(SECBAR)
        o.append('  </div>\n\n')
    o.append('  <div class="ribbon">\n'
             '    <svg class="ic-l beat"><use href="#i-heart"/></svg>\n'
             '    <b>合言葉</b><span class="s">%s</span>\n  </div>\n' % S['motto'])
    o.append(ANSBAR)
    o.append('\n')
    o.append(foot(S, 2, '文法たしかめ'))
    o.append('</section>\n\n')
    return ''.join(o)


# ---------- page 3 / 4 ----------
def half(S, which, cfg, title, sub):
    cls = 'half qsec' if which == 'top' else 'half bottom qsec'
    o = ['  <div class="%s">\n' % cls]
    o.append('    <h3 class="sec">%s<em>%s</em></h3>\n' % (title, sub))
    if cfg.get('hint'):
        o.append('    <div class="hint">%s</div>\n' % cfg['hint'])
    o.append(cfg['body'].rstrip('\n') + '\n')
    if cfg.get('words'):
        o.append(hintwrap(cfg['words']).replace('  <div class="hintwrap"', '    <div class="hintwrap"'))
    o.append(SECBAR)
    o.append('  </div>\n\n')
    return ''.join(o)


def page3(S):
    o = ['<section class="sheet">\n', TOOLBAR]
    o.append(head(S['unit'], 'レベル 1・2', '③ 文法かるく使えるページ', NAME))
    o.append('\n')
    o.append(half(S, 'top', S['p3']['l1'], 'レベル1チェック　文法あなうめ',
                  '日本語に合うように、（　）に1語ずつ入れよう。'))
    o.append(half(S, 'bottom', S['p3']['l2'], 'レベル2チェック　並べかえ',
                  '（　）の語を正しい順にならべよう。文の最初は大文字、終わりにピリオドを。'))
    o.append(ANSBAR)
    o.append('\n')
    o.append(foot(S, 3, '文法かるく使える'))
    o.append('</section>\n\n')
    return ''.join(o)


def page4(S):
    o = ['<section class="sheet">\n', TOOLBAR]
    o.append(head(S['unit'], 'レベル 3・4', '④ 文法しっかり使えるページ', NAME))
    o.append('\n')
    o.append(half(S, 'top', S['p4']['l3'], 'レベル3チェック　和文英訳', '次の日本語を英語にしよう。'))

    l4 = S['p4']['l4']
    o.append('  <div class="half bottom qsec">\n')
    o.append('    <h3 class="sec">レベル4チェック　自由英作文<em>%s</em></h3>\n' % l4['sub'])
    o.append('    <div class="cond">\n'
             '      <div class="h"><svg class="ic"><use href="#i-pen"/></svg> 条件</div>\n      <ul>\n')
    for c in l4['cond']:
        o.append('        <li>%s</li>\n' % c)
    o.append('      </ul>\n    </div>\n')
    o.append('    <div class="lines">\n')
    for k, ln in enumerate(l4['example']):
        lab = '<span class="exlab">書き方の例</span>' if k == 0 else ''
        o.append('      <div><span class="fill2">%s%s</span></div>\n' % (lab, ln))
    for _ in range(max(0, 5 - len(l4['example']))):
        o.append('      <div></div>\n')
    o.append('    </div>\n')
    o.append('    <div class="modelnote">%s</div>\n' % l4['note'])
    o.append('    <div class="checklist">\n')
    for m, c in enumerate(l4['check']):
        o.append('      <span%s>%s</span>\n' % (' class="key"' if m == 0 else '', c))
    o.append('    </div>\n')
    o.append('    <div class="ribbon">\n'
             '      <svg class="ic-l beat"><use href="#i-heart"/></svg>\n'
             '      <b>書けたら 見直し</b><span class="s">%s</span>\n    </div>\n' % l4['review'])
    o.append(SECBAR)
    o.append('  </div>\n')
    o.append(ANSBAR)
    o.append('\n')
    o.append(foot(S, 4, '文法しっかり使える'))
    o.append('</section>\n\n')
    return ''.join(o)


def build(S, outdir='/home/claude'):
    head_html = HEAD.replace('<title>Unit 1-2｜オンライン版（4ページ）</title>',
                             '<title>Unit %s｜オンライン版（4ページ）</title>' % S['unit_plain'])
    assert 'Unit %s｜' % S['unit_plain'] in head_html
    tail = TAIL
    if S.get('kana'):
        add = ',\n  ' + ','.join('"%s":"%s"' % (k, v) for k, v in S['kana'].items())
        marker = '"don\'t":"ドウント"'
        assert tail.count(marker) == 1
        tail = tail.replace(marker, marker + add)
    out = head_html + page1(S) + page2(S) + page3(S) + page4(S) + tail
    path = os.path.join(outdir, S['id'] + '.html')
    open(path, 'w', encoding='utf-8').write(out)
    return path, len(out.encode('utf-8'))


# ---------- 小さなヘルパ（セクションデータ側で使う） ----------
def ol(items, sp=False):
    """レベル1/3用：(問題html, 解説html) のリスト → ol.q"""
    o = ['    <ol class="q%s">\n' % (' sp' if sp else '')]
    for q, note in items:
        o.append('      <li><div class="row"><div class="qmain">%s</div>'
                 '<div class="qnote">%s</div></div></li>\n' % (q, note))
    o.append('    </ol>\n')
    return ''.join(o)


def bl(ans, short=True):
    return '（<span class="bl%s"><span class="ansfill">%s</span></span>）' % (' s' if short else '', ans)


def line(ans):
    return '<div class="lines tight"><div><span class="fill2">%s</span></div></div>' % ans


def wline(ans):
    return '<div class="lines"><div><span class="fill2">%s</span></div></div>' % ans


def grid2(items):
    o = ['  <div class="grid2">\n']
    for it in items:
        o.append('    <div>%s</div>\n' % it)
    o.append('  </div>\n')
    return ''.join(o)


def olq(items):
    """page2 A用：問題htmlのリスト → ol.q（解説は expbox にまとめる）"""
    o = ['  <ol class="q">\n']
    for it in items:
        o.append('    <li>%s</li>\n' % it)
    o.append('  </ol>\n')
    return ''.join(o)


def tf(items):
    """○✕問題：(文, 答え) のリスト"""
    return grid2(['<span class="en">%s</span><span class="tfbox"><span class="ansmark">%s</span></span>'
                  % (s, a) for s, a in items])
