# -*- coding: utf-8 -*-
"""patch_v11 の不具合修正：
   ブロックを③へ繰り上げたとき、クイズ・まとめ・フッターまで一緒に動いていた。
   末尾へ戻す。"""
import re, sys, os

def fix(path):
    name = os.path.basename(path)
    s = open(path, encoding='utf-8').read()
    head, rest = s.split('<section class="sheet">', 1)
    sheet1, tail = rest.split('</section>', 1)

    qi = sheet1.index('<div class="quiz">')
    blocks = [m.start() for m in re.finditer(r'<div class="blk-sec(?: more)?">', sheet1)]
    if qi > blocks[-1]:
        print('ok (直す必要なし):', name); return False

    # 末尾ブロック群の開始位置＝クイズより後ろの最初の blk-sec
    nxt = next(b for b in blocks if b > qi)
    # 移動する塊は morehint（あれば）から nxt の直前まで
    mh = sheet1.find('<div class="morehint">')
    start = mh if (mh != -1 and mh < qi) else qi
    # 行頭のインデントも含める
    while start > 0 and sheet1[start-1] in ' ':
        start -= 1

    chunk = sheet1[start:nxt]
    sheet1 = sheet1[:start] + sheet1[nxt:]
    if not sheet1.endswith('\n'):
        sheet1 += '\n'
    sheet1 = sheet1.rstrip('\n') + '\n\n' + chunk.rstrip('\n') + '\n'

    s = head + '<section class="sheet">' + sheet1 + '</section>' + tail
    open(path, 'w', encoding='utf-8').write(s)
    print('直しました:', name)
    return True

if __name__ == '__main__':
    n = sum(fix(p) for p in sys.argv[1:])
    print('修正:', n, '件')
