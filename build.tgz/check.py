# -*- coding: utf-8 -*-
import sys
from playwright.sync_api import sync_playwright

EXPECT = dict(sheets=4, qsec=8, sbtn=8, abtn=3, kbtn=4, hbtn=2, exlab=1, modelnote=1)

def check(files):
    bad = 0
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        for f in files:
            p = b.new_page(viewport={'width':1100,'height':1100})
            errs = []
            p.on('pageerror', lambda e: errs.append(str(e)))
            p.goto('file://' + f)
            p.wait_for_timeout(1300)
            got = p.evaluate("""() => ({
              sheets:document.querySelectorAll('.sheet').length,
              qsec:document.querySelectorAll('.qsec').length,
              sbtn:document.querySelectorAll('.sbtn').length,
              abtn:document.querySelectorAll('.abtn').length,
              kbtn:document.querySelectorAll('.kbtn').length,
              hbtn:document.querySelectorAll('.hbtn').length,
              exlab:document.querySelectorAll('.exlab').length,
              modelnote:document.querySelectorAll('.modelnote').length,
              qzi:document.querySelectorAll('.qzi').length,
              ansfill:document.querySelectorAll('.ansfill').length,
              fill2:document.querySelectorAll('.fill2').length,
              ansmark:document.querySelectorAll('.ansmark').length,
              qnote:document.querySelectorAll('.qnote').length,
              ruby:document.querySelectorAll('ruby.rb').length,
              rubyBad:document.querySelectorAll('.bad ruby.rb, .xm ruby.rb, .x ruby.rb').length,
              empties:[...document.querySelectorAll('.ansfill,.fill2,.ansmark')].filter(e=>!e.textContent.trim()).length
            })""")
            # 動作確認：全体ボタン → すべての答えが出る
            p.evaluate("""() => document.querySelectorAll('.sheet').forEach(s=>{
               const a=s.querySelector('.abtn'); if(a) a.click();
               const k=s.querySelector('.kbtn'); if(k) k.click(); })""")
            p.wait_for_timeout(500)
            op = p.evaluate("""() => {
              const es=[...document.querySelectorAll('.qsec .ansfill, .qsec .fill2, .qsec .ansmark')];
              return es.filter(e=>getComputedStyle(e).opacity!=='1').length; }""")
            rt = p.evaluate("""() => {const r=document.querySelector('ruby.rb rt');
              return r? getComputedStyle(r).visibility : 'none'; }""")
            probs = [k for k,v in EXPECT.items() if got[k]!=v]
            if got['rubyBad'] or got['empties'] or op or rt!='visible':
                probs.append('runtime')
            flag = 'NG' if (probs or errs) else 'ok'
            if flag=='NG': bad += 1
            print('%-14s %s  qzi=%d ansfill=%d fill2=%d mark=%d qnote=%d ruby=%d  hidden=%d rt=%s %s%s'
                  % (f.split('/')[-1], flag, got['qzi'], got['ansfill'], got['fill2'],
                     got['ansmark'], got['qnote'], got['ruby'], op, rt,
                     ('PROBLEMS:'+','.join(probs)) if probs else '',
                     (' JS:'+errs[0][:80]) if errs else ''))
            p.close()
        b.close()
    return bad

if __name__ == '__main__':
    sys.exit(1 if check(sys.argv[1:]) else 0)
