# -*- coding: utf-8 -*-
"""v3: ブロックごとのカタカナボタン／オレンジのアナログ時計（20分で赤）／
      まちがえた問題のチェックと解き直しページ"""
import re, sys

CSS = """
  /* ===== v3: 小さなカタカナボタン（ブロックごと） ===== */
  .kbtn{font-size:9pt !important;padding:3px 11px !important;border-width:1.5px !important;}
  .ksm{font-family:"Zen Maru Gothic",sans-serif;font-weight:700;font-size:8.5pt;
    border:1.5px solid #D8C49A;border-radius:6px;padding:1px 8px;cursor:pointer;
    background:#FFFBF2;color:#A8884A;margin-left:auto;flex:none;line-height:1.5;}
  .ksm:hover{border-color:#C88A16;color:#8A5A0B;}
  .ksm.on{background:#C88A16;border-color:#C88A16;color:#fff;}
  h3.sec{display:flex;align-items:center;flex-wrap:wrap;gap:0 4px;}
  h3.sec em{flex:0 1 auto;}
  h3.sec .ksm{order:9;}
  h3.st .ksm{margin-left:auto;}
  @media print{.ksm{display:none;}}

  /* ===== v3: 時計（本体は青／扇形だけ明るいオレンジ／20分で赤） ===== */
  .clock .cf{stroke:var(--key);}
  .clock .cp{fill:#FFA726;fill-opacity:.78;}
  .clock .ct{stroke:var(--key);}
  .clock .ch{stroke:var(--key);}
  .clock .cc{fill:var(--key);}
  .clock .cm{color:var(--key);}
  .clock.over .cf{stroke:var(--ng);}
  .clock.over .cp{fill:#E8485F;fill-opacity:.70;}
  .clock.over .ct{stroke:var(--ng);}
  .clock.over .ch{stroke:var(--ng);}
  .clock.over .cc{fill:var(--ng);}
  .clock.over .cm{color:var(--ng);}

  /* ===== v3: 問題番号を押してチェック ===== */
  .qn{display:inline-flex;align-items:center;justify-content:center;flex:none;
    width:22px;height:22px;padding:0;border-radius:50%;
    border:2px solid #9FC2E8;background:#F2F8FF;color:#4A7FB5;
    font-family:"Lexend",sans-serif;font-weight:700;font-size:10pt;line-height:1;
    cursor:pointer;margin-right:6px;vertical-align:-5px;transition:.12s;}
  .qn:hover{border-color:#5E9BE0;background:#E3F0FF;}
  .qn.on{background:var(--ng);border-color:var(--ng);color:#fff;}
  .qn.qnst{cursor:default;}
  .qn.qnst:hover{border-color:#9FC2E8;background:#F2F8FF;}
  ol.q.numq{list-style:none;padding-left:2.25em;}
  ol.q.numq > li{position:relative;}
  ol.q.numq > li > .qn{position:absolute;left:-2.25em;top:1px;margin-right:0;
    vertical-align:baseline;}
  .cknote{font-size:9pt;color:#7E93A8;margin-right:auto;
    display:inline-flex;align-items:center;gap:5px;}
  .cknote i{display:inline-block;width:15px;height:15px;border:2px solid #9FC2E8;
    border-radius:50%;background:#F2F8FF;}
  .toolbar{align-items:center;gap:8px;}
  @media print{.cknote{display:none;}
    .qn{border-color:#BBB;background:#fff;color:#333;}
    .qn.on{background:#fff;border-color:#333;color:#333;}}

  /* ===== v3: 解き直しボタン ===== */
  .retrybar{display:flex;align-items:center;justify-content:flex-end;gap:10px;
    flex-wrap:wrap;margin:14px 0 0;padding-top:12px;border-top:2px dashed var(--rule);}
  .retrybar .msg{font-size:10pt;color:var(--mut);margin-right:auto;}
  .retrybar .rcount{font-family:"Lexend",sans-serif;font-weight:700;font-size:11pt;
    color:var(--ng);}
  .rbtn{font-family:"Zen Maru Gothic",sans-serif;font-weight:700;font-size:13pt;
    border:none;border-radius:10px;padding:10px 24px;cursor:pointer;
    background:var(--ng);color:#fff;box-shadow:0 3px 0 #8A1B2E;}
  .rbtn:active{transform:translateY(3px);box-shadow:none;}
  .rbtn[disabled]{background:#C9C2B6;box-shadow:0 3px 0 #ADA69A;cursor:default;}
  .rmsg{font-size:10pt;color:var(--ng);flex-basis:100%;text-align:right;}
  @media print{.retrybar{display:none;}}
"""

JS = """
// ===== v3: ブロックごとのカタカナ =====
function toggleKanaBlock(btn){
  const b = btn.closest('.blk-sec, .qsec');
  if(!b) return;
  const on = b.classList.toggle('showkana');
  btn.textContent = on ? 'カタカナを消す' : 'カタカナ';
  btn.classList.toggle('on', on);
}

// ===== v3: 問題番号を押してチェック =====
function toggleQn(btn){
  btn.classList.toggle('on');
  ckCount();
}
function ckCount(){
  const n = document.querySelectorAll('.qn.on').length;
  const c = document.getElementById('rcount');
  const b = document.getElementById('rbtn');
  if(c) c.textContent = n + '問';
  if(b) b.disabled = (n === 0);
}

// ===== v3: まちがえた問題だけの解き直しページを作る =====
function makeRetry(){
  const picked = [...document.querySelectorAll('.qn.on')];
  const msg = document.getElementById('rmsg');
  if(msg) msg.textContent = '';
  if(!picked.length) return;

  const groups = [];
  picked.forEach(cb => {
    const item = cb.closest('li') || cb.closest('.grid2 > div');
    if(!item) return;
    const sec = cb.closest('.qsec');
    const h = sec && sec.querySelector('h3');
    const head = h ? h.cloneNode(true) : null;
    if(head) head.querySelectorAll('.ksm').forEach(x => x.remove());
    const kind = item.tagName === 'LI' ? 'ol' : 'grid2';
    const key = (head ? head.textContent.trim() : '') + '|' + kind;
    let g = groups.find(x => x.key === key);
    if(!g){ g = {key, head: head ? head.outerHTML : '', kind, items: []}; groups.push(g); }
    const c = item.cloneNode(true);
    c.querySelectorAll('.qn').forEach(x => {
      x.classList.remove('on'); x.classList.add('qnst'); x.removeAttribute('onclick');
    });
    g.items.push(c.outerHTML);
  });

  let body = '';
  groups.forEach(g => {
    body += g.head;
    body += (g.kind === 'ol')
      ? '<ol class="q sp numq">' + g.items.join('\\n') + '</ol>'
      : '<div class="grid2">' + g.items.join('\\n') + '</div>';
  });

  const styles = [...document.querySelectorAll('style')].map(s => s.outerHTML).join('\\n');
  const fonts  = [...document.querySelectorAll('link[rel="stylesheet"]')].map(l => l.outerHTML).join('\\n');
  const defs   = (document.querySelector('svg[width="0"]') || {outerHTML:''}).outerHTML;
  const tagEl  = document.querySelector('.head .tag');
  const title  = tagEl ? (tagEl.firstChild.textContent || '').trim() : '';

  const html = '<!DOCTYPE html><html lang="ja"><head><meta charset="UTF-8">'
    + '<meta name="viewport" content="width=device-width, initial-scale=1.0">'
    + '<title>解き直し｜' + title + '</title>' + fonts + styles
    + '<style>.gauge{display:none;}.sheet{min-height:0;}</style></head><body>'
    + defs
    + '<section class="sheet showans-host">'
    + '<div class="toolbar">'
    + '<span class="cknote">まちがえた問題だけを集めました</span>'
    + '<button class="kbtn" onclick="tk(this)">カタカナ</button></div>'
    + '<div class="head"><div class="tag">' + title + ' <small>解き直し</small></div>'
    + '<div class="sub"><b>まちがえた問題</b></div></div>'
    + '<div class="hint">もう一度ノートに解いてから、下の「答えを見る」を押そう。</div>'
    + body
    + '<div class="ansbar"><span class="msg">とけたら押そう</span>'
    + '<button class="abtn" onclick="ta(this)">答えを見る</button></div>'
    + '<div class="foot"><span>' + title + '　解き直し</span>'
    + '<span>まちがえた ' + picked.length + ' 問</span></div>'
    + '</section>'
    + '<script>'
    + 'function tk(b){var s=b.closest(".sheet");var on=s.classList.toggle("showkana");'
    + 'b.textContent=on?"カタカナを消す":"カタカナ";b.classList.toggle("on",on);}'
    + 'function ta(b){var s=b.closest(".sheet");var on=s.classList.toggle("showans");'
    + 'b.textContent=on?"答えをかくす":"答えを見る";b.classList.toggle("on",on);'
    + 's.querySelectorAll(".qsec").forEach(function(q){q.classList.toggle("showans",on);});}'
    + '<\\/script></body></html>';

  const w = window.open('', '_blank');
  if(!w){ if(msg) msg.textContent = '新しいページが開けませんでした。ブラウザのポップアップ許可を確認してください。'; return; }
  w.document.open(); w.document.write(html); w.document.close();
}
"""

RETRY_BAR = """  <div class="retrybar">
    <span class="msg">まちがえた問題の<b>番号</b>を押してから、このボタンを押そう</span>
    <span class="rcount" id="rcount">0問</span>
    <button class="rbtn" id="rbtn" onclick="makeRetry()" disabled>まちがったものを解き直し</button>
    <span class="rmsg" id="rmsg"></span>
  </div>
"""

CKNOTE = ('<span class="cknote"><i></i>まちがえた問題は 番号を押す</span>')


def patch(path):
    s = open(path, encoding='utf-8').read()
    assert 'v2: エネルギーゲージ' in s, 'run patch_v2 first'
    if 'v3: ブロックごとのカタカナ' in s:
        print('already v3:', path); return

    # 1) CSS
    anchor = '  @media print{ .ansbar,.toolbar{display:none;} .sheet{box-shadow:none;margin:0;} }'
    assert s.count(anchor) == 1
    s = s.replace(anchor, CSS + '\n' + anchor)

    # 2) showkana をブロックでも効くようにする
    s = s.replace('.sheet.showkana', '.showkana')

    # 3) 時計：20分で赤
    s = s.replace("box.classList.toggle('over', sec >= FULL);",
                  "box.classList.toggle('over', sec >= WARN);")
    old = "  const FULL = 30 * 60;           // 30分で一周"
    new = ("  const FULL = 30 * 60;           // 30分で一周\n"
           "  const WARN = 20 * 60;           // 20分を越えたら赤く")
    assert s.count(old) == 1, 'clock consts'
    s = s.replace(old, new)

    # 4) ページ全体のカタカナボタン → ブロックをまとめて切り替える
    old_tk = """function toggleKana(btn){
  const s = btn.closest('.sheet');
  const on = s.classList.toggle('showkana');
  btn.textContent = on ? 'カタカナを消す' : 'カタカナ';
  btn.classList.toggle('on', on);
}"""
    new_tk = """function toggleKana(btn){
  const s = btn.closest('.sheet');
  const on = s.classList.toggle('showkana');
  btn.textContent = on ? 'ぜんぶ消す' : 'ぜんぶカタカナ';
  btn.classList.toggle('on', on);
  s.querySelectorAll('.blk-sec, .qsec').forEach(b => {
    b.classList.toggle('showkana', on);
    const x = b.querySelector('.ksm');
    if(x){ x.textContent = on ? 'カタカナを消す' : 'カタカナ';
           x.classList.toggle('on', on); }
  });
}"""
    assert s.count(old_tk) == 1, 'toggleKana'
    s = s.replace(old_tk, new_tk)
    s = s.replace('onclick="toggleKana(this)">カタカナ</button>',
                  'onclick="toggleKana(this)">ぜんぶカタカナ</button>')

    # 5) ブロックごとに小さなカタカナボタン
    ksm = '<button class="ksm" onclick="toggleKanaBlock(this)">カタカナ</button>'
    s, n1 = re.subn(r'(<h3 class="st">.*?)(</h3>)', lambda m: m.group(1) + ksm + m.group(2), s)
    s, n2 = re.subn(r'(<h3 class="sec(?: sec2)?"[^>]*>.*?)(</h3>)',
                    lambda m: m.group(1) + ksm + m.group(2), s)
    print('  kana buttons: blk=%d sec=%d' % (n1, n2))

    # 6) 問題番号を丸ボタンにする（②③④ページのみ）
    QN = '<button class="qn" onclick="toggleQn(this)">%s</button>'
    parts = re.split(r'(?=<section class="sheet">)', s)
    assert len(parts) == 5, len(parts)

    def number_ols(sec):
        def per_ol(m):
            head, body = m.group(1), m.group(2)
            head = head.replace('class="q sp"', 'class="q sp numq"')
            head = head.replace('class="q"', 'class="q numq"')
            i = [0]
            def li(mm):
                i[0] += 1
                return '<li>' + (QN % i[0]) + mm.group(1) + '</li>'
            return head + re.sub(r'<li>(.*?)</li>', li, body, flags=re.S) + '</ol>'
        return re.sub(r'(<ol class="q(?: sp)?">)(.*?)(</ol>)', per_ol, sec, flags=re.S)

    def number_grids(sec):
        def per_grid(m):
            body = m.group(1)
            body = re.sub(r'<div>(\d+)\. <span class="en">',
                          lambda mm: '<div>' + (QN % mm.group(1)) + '<span class="en">', body)
            body = re.sub(r'<div><span class="en">(\d+)\. ',
                          lambda mm: '<div>' + (QN % mm.group(1)) + '<span class="en">', body)
            body = re.sub(r'<div>(\d+)\. ',
                          lambda mm: '<div>' + (QN % mm.group(1)), body)
            return '<div class="grid2">\n' + body + '\n  </div>'
        return re.sub(r'<div class="grid2">\n(.*?)\n  </div>', per_grid, sec, flags=re.S)

    for i in (2, 3, 4):
        sec = number_ols(parts[i])
        sec = number_grids(sec)
        sec = sec.replace('<div class="toolbar">', '<div class="toolbar">' + CKNOTE, 1)
        parts[i] = sec
    s = ''.join(parts)

    # 7) 最後のページに解き直しボタン
    last = s.rindex('<div class="ansbar">')
    s = s[:last] + RETRY_BAR + '\n' + s[last:]

    # 8) JS
    tail = '\nfunction toggleHint(btn){'
    assert s.count(tail) == 1
    s = s.replace(tail, JS + tail)

    open(path, 'w', encoding='utf-8').write(s)
    print('patched v3:', path, len(s.encode('utf-8')), 'bytes')


if __name__ == '__main__':
    for p in sys.argv[1:]:
        patch(p)
