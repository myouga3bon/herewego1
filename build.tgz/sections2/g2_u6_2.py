# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox, gmap

S = {
 'id':'g2-u6-2', 'grade':2, 'unit':'6 − 2', 'unit_plain':'6-2',
 'title':'接続詞 because', 'pages':'p.74〜75',
 'hero_big':'I like dogs because they are kind.',
 'hero_jp':'犬は やさしいので、わたしは 犬が 好きです',
 'motto':'<span class="en">because</span> ＝「～だから」。<b>理由</b>をくっつける。<span class="en">Why ～?</span> の答えにも使う。',
 'kana':{'because':'ビコーズ','learn':'ラーン','basic':'ベイスィック','social':'ソウシャル',
         'rules':'ルールズ','important':'インポータント','talk':'トーク','Mike':'マイク',
         'why':'ワイ','busy':'ビズィ','tired':'タイアド','hungry':'ハングリィ',
         'rain':'レイン','rained':'レインド','like':'ライク','so':'ソウ','also':'オールソウ'},
 'blocks':[
  ('きほんの文', [
    ('t','「犬は <b>やさしいので</b>、犬が好きです」のように、<b>理由</b>を言って2つの文をくっつける形です。'),
    ('t','1-2 の <span class="en">when</span>、3-3 の <span class="en">if</span> に続く<b>3つめの接続詞</b>です。'),
    ('h', gmap('やさしい<b>ので</b>', '<b>because</b> they are kind',
               '<b>because</b> が「～ので・～だから」。うしろに<b>理由の文がまるごと</b>入ります。')),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I like dogs because they are kind.</span><span class="t">犬は やさしいので、わたしは 犬が 好きです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I was happy because I got a letter.</span><span class="t">手紙を もらったので、わたしは うれしかったです。</span></div>
    </div>'''),
    ('t','「<b>なぜ？</b>」とたずねられたときは、<span class="en">Because ～.</span> だけで答えてもかまいません。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜<span class="en">because</span> は<b>うしろ</b>に置くのがふつう', [
    ('t','ここが今回のヤマです。<span class="en">when・if</span> は前にも置けましたが、<b><span class="en">because</span> はうしろに置くのがふつう</b>です。'),
    ('h','''<table class="kind">
      <thead><tr><th>形</th><th>コンマ</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k" style="color:var(--key);font-weight:700;">ふつう（うしろ）</td><td class="k">いらない</td><td class="e">I like dogs <u>because</u> they are kind.</td></tr>
        <tr><td class="k">前に出すこともできる</td><td class="k" style="color:var(--ng);font-weight:700;">いる</td><td class="e"><u>Because</u> they are kind<u>,</u> I like dogs.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ 結果 → 理由<small>英語のふつうの順</small></span></div>
        <div class="in"><div class="ex">I like dogs<br>because they are kind.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ because だけ<small>文が完成しない</small></span></div>
        <div class="in"><div class="ex">Because they are kind.</div></div>
      </div>
    </div>'''),
    ('t','日本語は「やさしい<b>ので</b>、好きです」と理由が先ですが、<b>英語は結果が先</b>です。語順がぎゃくになります。'),
  ]),
  ('テストによく出ることば', [
    ('t','<span class="en">because</span> のうしろは<b>ふつうの文</b>です。たずねる文の形にしません。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味・やくわり</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">because</span></td><td class="k">～だから・～なので</td><td class="e">I like dogs <u>because</u> they are kind.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">Because ～,</span></td><td class="k">前に置いたらコンマ</td><td class="e"><u>Because it rained,</u> I stayed home.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">Why ～?</span></td><td class="k">なぜ～ですか</td><td class="e"><u>Why</u> do you like dogs?</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">Because ～.</span></td><td class="k">～だからです</td><td class="e">— <u>Because</u> they are kind.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">because</span> ・ <span class="en">Why ～?</span> ・ <span class="en">Because ～.</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('<span class="en">Why ～?</span> の答え方は2つ', [
    ('t','6-1 でならった <span class="en">To ～.</span> と、今回の <span class="en">Because ～.</span>。<b>どちらでも答えられます</b>。'),
    ('h','''<div class="eqbox">
      <span class="eq">Why do you study English?</span><br>
      — <span class="eq" style="color:var(--gv);">To talk with Mike.</span>（マイクと話すためです）＝ <b>目的</b><br>
      — <span class="eq" style="color:var(--key);">Because I like it.</span>（好きだからです）＝ <b>理由</b>
    </div>'''),
    ('t','「何のために」なら <span class="en">To ～.</span>、「どうしてか」なら <span class="en">Because ～.</span> と使い分けます。'),
  ]),
  ('3つの接続詞の整理', [
    ('t','ここまでに <span class="en">when・if・because</span> の3つを習いました。<b>うしろに文が入る</b>のは共通です。'),
    ('h','''<table class="kind">
      <thead><tr><th>ことば</th><th>意味</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k" style="color:var(--key);font-weight:700;">when</td><td class="k">～するとき</td><td class="e">I read books <u>when</u> it rains.</td></tr>
        <tr><td class="k" style="color:var(--gv);font-weight:700;">if</td><td class="k">もし～なら</td><td class="e">I&#39;ll stay home <u>if</u> it rains.</td></tr>
        <tr><td class="k" style="color:var(--ng);font-weight:700;">because</td><td class="k">～だから</td><td class="e">I stayed home <u>because</u> it rained.</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">if</span> のうしろだけは「未来でも今の形」でした。<b><span class="en">because</span> にはこの決まりはありません</b>。'),
  ]),
 ],
 'quiz':[
  ('Because they are kind.','I like dogs because they are kind.','<span class="en">because</span> のまとまりだけでは文になりません。','犬は やさしいので、わたしは 犬が 好きです。'),
  ('I like dogs, because they are kind.','I like dogs because they are kind.','<b>うしろに置くときはコンマなし</b>。','犬は やさしいので、わたしは 犬が 好きです。'),
  ('Because they are kind I like dogs.','Because they are kind, I like dogs.','<b>前に置いたらコンマ</b>で区切ります。','やさしいので、わたしは 犬が 好きです。'),
  ('I like dogs because are they kind.','I like dogs because they are kind.','<span class="en">because</span> のうしろは<b>ふつうの文</b>の順です。','犬は やさしいので、わたしは 犬が 好きです。'),
  ('I like dogs because of they are kind.','I like dogs because they are kind.','うしろが文のときは <span class="en">of</span> をつけません。','犬は やさしいので、わたしは 犬が 好きです。'),
  ('Why do you like dogs? — To they are kind.','Why do you like dogs? — Because they are kind.','理由を言うときは <b><span class="en">Because</span></b>。','なぜ 犬が 好きなのですか。— やさしいからです。'),
 ],
 'summary':[
  '<b><span class="en">because</span> ＝「～だから・～なので」</b>。理由の文をくっつける。',
  '<b>うしろに置くのがふつう</b>（コンマなし）。前に置いたらコンマがいる。',
  '<span class="en">because</span> のうしろは <b>主語 → 動詞</b> のふつうの順。',
  '<span class="en">Why ～?</span> には <b><span class="en">Because ～.</span></b>（理由）か <b><span class="en">To ～.</span></b>（目的）で答える。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～だから」と理由を言うときは%sを使う。' % bl('because'),
     'この形は、ふつう文の%sに置く。' % bl('うしろ'),
     'うしろに置くときは、コンマは%s。' % bl('いらない'),
     '<span class="en">because</span> のうしろは、主語 → %s のふつうの順にする。' % bl('動詞'),
     '<span class="en">Why ～?</span> に目的で答えるときは%s～. を使う。' % bl('To'),
   ]),
   'words':'語群：<span class="en">because</span> ／ うしろ ／ いらない ／ 動詞 ／ <span class="en">To</span>',
   'exp':'<b>なぜ？</b>　英語は<b>言いたいことを先に</b>言うことばです。<br>'
         '「犬が好き」が言いたいことで、「やさしいから」はその説明。だから<b>結果が先、理由があと</b>になるのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">because</span> のうしろを書こう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>ふつうの文の順</b>にもどしましょう。',
   'body':grid2([
     '1. <span class="en">I like dogs because they%skind.</span>' % bl('are'),
     '2. <span class="en">I stayed home because it%s.</span>（雨がふった）' % bl('rained', False),
     '3. <span class="en">I&#39;m tired because I%shard.</span>（働いた）' % bl('worked', False),
     '4. <span class="en">He is happy because he%sthe game.</span>（勝った）' % bl('won'),
     '5. <span class="en">I can&#39;t go because I%sbusy.</span>' % bl('am'),
     '6. <span class="en">She likes it because it%seasy.</span>' % bl('is'),
     '7. <span class="en">We went home because it%slate.</span>' % bl('was'),
     '8. <span class="en">I eat a lot because I%shungry.</span>' % bl('am'),
     '9. <span class="en">They learn rules because it%simportant.</span>' % bl('is'),
     '10. <span class="en">I study English because I%sit.</span>' % bl('like'),
   ]),
   'exp':'<b>かくにん</b>　どれも<b>ふつうの文</b>です。主語を見て be動詞か動作のことばかを決めます。<br>'
         '2・3・4・7 は過去のことなので<b>過去形</b>になっていることを確かめよう。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. I like dogs because they are kind.','○'), ('2. I like dogs, because they are kind.','✕'),
     ('3. Because they are kind, I like dogs.','○'), ('4. Because they are kind I like dogs.','✕'),
     ('5. I stayed home because it rained.','○'), ('6. Because it rained.','✕'),
     ('7. Why do you like dogs? — Because they are kind.','○'), ('8. I like dogs because are they kind.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → コンマをとる　4 → コンマを入れる<br>'
         '6 → うしろに文を足す（<span class="en">…, I stayed home.</span>）　8 → <span class="en">they are kind</span>'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'「何のために」なら <span class="en">To</span>、「どうしてか」なら <span class="en">Because</span>。',
   'body':grid2([
     '1. <span class="en">I like dogs （ア , because ／イ because） they are kind.</span>%s' % bl('イ'),
     '2. <span class="en">（ア Because they are kind, I ／イ Because they are kind I） like dogs.</span>%s' % bl('ア'),
     '3. <span class="en">I stayed home because it （ア rained ／イ rain）.</span>%s' % bl('ア'),
     '4. なぜ英語を勉強するの？ — 好きだからです。<span class="en">（ア Because ／イ To） I like it.</span>%s' % bl('ア'),
     '5. なぜ英語を勉強するの？ — マイクと話すためです。<span class="en">（ア Because ／イ To） talk with Mike.</span>%s' % bl('イ'),
     '6. <span class="en">I like dogs because （ア they are ／イ are they） kind.</span>%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　1・2 はコンマ。うしろならなし、前ならあり。<br>'
         '4・5 は答え方の使い分け。<b>うしろに文が続くなら <span class="en">Because</span></b>、<b>動詞の原形（もとの形）が続くなら <span class="en">To</span></b> です。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　まず「言いたいこと」を書き、そのうしろに <span class="en">because</span> ＋ 理由。',
   'body':ol([
     ('<span class="jp-cue">やさしいので、わたしは犬が好きです。</span>　<span class="en">I like dogs%sthey are kind.</span>' % bl('because'),
      'うしろに置くので小文字。'),
     ('<span class="jp-cue">雨がふったので、わたしは家にいました。</span>　<span class="en">I stayed home because it%s.</span>' % bl('rained', False),
      '過去形にする。'),
     ('<span class="jp-cue">やさしいので、わたしは犬が好きです。（前に出して）</span>　<span class="en">Because they are kind%sI like dogs.</span>' % bl('，'),
      '前に置いたのでコンマ。'),
     ('<span class="jp-cue">なぜ犬が好きなのですか。</span>　<span class="en">%sdo you like dogs?</span>' % bl('Why'),
      '「なぜ」は <span class="en">Why</span>。'),
     ('<span class="jp-cue">やさしいからです。</span>　<span class="en">%sthey are kind.</span>' % bl('Because'),
      '文のはじめなので大文字。'),
     ('<span class="jp-cue">忙しいので、わたしは行けません。</span>　<span class="en">I can&#39;t go because I%sbusy.</span>' % bl('am'),
      '<span class="en">I</span> なので <span class="en">am</span>。'),
     ('<span class="jp-cue">大切なので、彼らはルールを学びます。</span>　<span class="en">They learn rules%sit&#39;s important.</span>' % bl('because'),
      '長い文でも作りは同じ。'),
     ('<span class="jp-cue">おなかがすいているので、わたしはたくさん食べます。</span>　<span class="en">I eat a lot%sI%shungry.</span>' % (bl('because'), bl('am')),
      '（　）が2つ。'),
     ('<span class="jp-cue">おそくなったので、わたしたちは家に帰りました。</span>　<span class="en">We went home because it%slate.</span>' % bl('was'),
      '過去なので <span class="en">was</span>。'),
     ('<span class="jp-cue">好きなので、わたしは英語を勉強します。</span>　<span class="en">I study English because I%sit.</span>' % bl('like'),
      '<span class="en">I</span> なので <span class="en">like</span>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　英語は<b>結果が先</b>。日本語とは順番がぎゃくになる。',
   'body':ol([
     ('<span class="jp-cue">やさしいので、わたしは犬が好きです。</span>　<span class="paren en">（ they are kind / I like dogs / because ）</span>' + line('I like dogs because they are kind.'),
      '結果 → 理由 の順。'),
     ('<span class="jp-cue">雨がふったので、わたしは家にいました。</span>　<span class="paren en">（ it rained / I stayed home / because ）</span>' + line('I stayed home because it rained.'),
      '過去形どうし。'),
     ('<span class="jp-cue">やさしいので、わたしは犬が好きです。（前に出して）</span>　<span class="paren en">（ I like dogs / Because / they are kind ）</span>' + line('Because they are kind, I like dogs.'),
      '前に置いたのでコンマ。'),
     ('<span class="jp-cue">忙しいので、わたしは行けません。</span>　<span class="paren en">（ I&#39;m busy / because / I can&#39;t go ）</span>' + line('I can&#39;t go because I&#39;m busy.'),
      '打ち消しは結果の文に。'),
     ('<span class="jp-cue">なぜ犬が好きなのですか。</span>　<span class="paren en">（ you like dogs / Why / do ）</span>' + line('Why do you like dogs?'),
      '<span class="en">Why</span> → <span class="en">do</span> → 主語。'),
     ('<span class="jp-cue">おそくなったので、わたしたちは家に帰りました。</span>　<span class="paren en">（ it was late / We went home / because ）</span>' + line('We went home because it was late.'),
      '<span class="en">it was late</span> が理由。'),
     ('<span class="jp-cue">好きなので、わたしは英語を勉強します。</span>　<span class="paren en">（ I like it / I study English / because ）</span>' + line('I study English because I like it.'),
      '主語が2回出る。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('やさしいので、わたしは犬が好きです。' + wline('I like dogs because they are kind.'),
      'コンマは入れない。'),
     ('雨がふったので、わたしは家にいました。' + wline('I stayed home because it rained.'),
      '両方とも過去形に。'),
     ('忙しいので、わたしは行けません。' + wline('I can&#39;t go because I&#39;m busy.'),
      '<span class="en">I am busy</span> でも正解。'),
     ('なぜ犬が好きなのですか。' + wline('Why do you like dogs?'),
      '<span class="en">Why</span> は文のはじめ。'),
     ('やさしいからです。' + wline('Because they are kind.'),
      '答えなので <span class="en">Because</span> から始めてよい。'),
     ('おそくなったので、わたしたちは家に帰りました。' + wline('We went home because it was late.'),
      '<span class="en">it was late</span> が理由。'),
   ]),
   'words':'<span class="en">because they are kind ／ because it rained ／ because I&#39;m busy ／ Why do you ／ Because ～ ／ because it was late</span>'},
  'l4':{'sub':'自分の好きなもの・したことに、理由をつけて書こう',
   'cond':['<span class="en">because</span> を使った文を <b>2つ以上</b>',
           '過去のことを言う文を <b>1つ</b> 入れる',
           '<span class="en">Why ～?</span> と <span class="en">Because ～.</span> のやりとりを <b>1組</b> 入れる'],
   'example':['I like summer because I can swim in the sea.','I didn&#39;t go out because it rained yesterday.','Why do you like this song? — Because it makes me happy.'],
   'note':'これは例です。同じでなくてかまいません。「好きなもの」「しなかったこと」に理由をつけると書きやすいです。',
   'check':['because のうしろは 主語 → 動詞','うしろに置いたらコンマなし','動詞が2つある','過去なら両方とも過去形'],
   'review':'じぶんの文の <span class="en">because</span> の前を指でかくしてみよう。それだけで文になっていれば正解です。'},
 },
}
