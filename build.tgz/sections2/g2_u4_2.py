# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'g2-u4-2', 'grade':2, 'unit':'4 − 2', 'unit_plain':'4-2',
 'title':'目的語が2つの文', 'pages':'p.52〜53',
 'hero_big':'I gave him a book.',
 'hero_jp':'わたしは 彼に 本を あげました',
 'motto':'<b>「だれに」→「何を」</b>の順。入れかえるときは <span class="en">to</span> か <span class="en">for</span> をつける。',
 'kana':{'show':'ショウ','give':'ギヴ','gave':'ゲイヴ','tell':'テル','send':'センド',
         'teach':'ティーチ','buy':'バイ','bought':'ボート','made':'メイド',
         'notebook':'ノート','message':'メッセィヂ','picture':'ピクチャー',
         'present':'プレゼント','letter':'レター','story':'ストーリィ',
         'me':'ミー','him':'ヒム','her':'ハー','us':'アス','them':'ゼム','to':'トゥー','for':'フォー'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>だれに</b> <b>何を</b> する」と、2つのことがらをならべて言う形です。<span class="en">show・give・tell</span> などで使います。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I gave him a book.</span><span class="t">わたしは 彼に 本を あげました。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Show me your notebook.</span><span class="t">わたしに ノートを 見せてください。</span></div>
    </div>'''),
    ('t','日本語と同じで<b>「だれに」が先</b>です。語順はそのまま置きかえられます。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜「だれに」→「何を」の順', [
    ('t','ここが今回のヤマです。<b>順番がぎゃくになると、意味が変わってしまいます</b>。'),
    ('h','''<div class="eqbox">
      <span class="eq">Show</span> <span class="eq" style="color:var(--key);">me</span>（だれに）<span class="eq" style="color:var(--gv);">your notebook</span>（何を）.<br>
      ✕ <span class="eq">Show your notebook me.</span>　← この順では通じません
    </div>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ だれに → 何を<small>me / your notebook</small></span></div>
        <div class="in"><div class="ex">Show me your notebook.<br>I&#39;ll give you a message.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ 何を → だれに<small>to なしで入れかえる</small></span></div>
        <div class="in"><div class="ex">Show your notebook me.<br>I&#39;ll give a message you.</div></div>
      </div>
    </div>'''),
    ('t','「だれに」の部分には <span class="en">me・you・him・her・us・them</span> という形が入ります。<span class="en">I・he・she</span> ではありません。'),
  ]),
  ('テストによく出ることば', [
    ('t','この形でよく使う動詞と、「だれに」に入る形をおぼえましょう。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">show ～</span></td><td class="k">～に…を見せる</td><td class="e"><u>Show me</u> your notebook.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">give ～</span></td><td class="k">～に…をあげる</td><td class="e">I&#39;ll <u>give you</u> a message.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">tell ～</span></td><td class="k">～に…を話す</td><td class="e"><u>Tell me</u> the story.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">me / him / her</span></td><td class="k">「だれに」に入る形</td><td class="e">Show <u>him</u> the picture.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">show me</span> ・ <span class="en">give you</span> ・ <span class="en">tell me</span> ・ <span class="en">him / her</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('入れかえるときは <span class="en">to</span> か <span class="en">for</span>', [
    ('t','「何を」を先に言いたいときは、<b>「だれに」の前に <span class="en">to</span> か <span class="en">for</span> をつけます</b>。'),
    ('h','''<table class="kind">
      <thead><tr><th>原形（もとの形）</th><th>入れかえた形</th><th>つけることば</th></tr></thead>
      <tbody>
        <tr><td class="e">Show <u>me</u> your notebook.</td><td class="e">Show your notebook <u>to me</u>.</td><td class="k" style="color:var(--key);font-weight:700;">to</td></tr>
        <tr><td class="e">I gave <u>him</u> a present.</td><td class="e">I gave a present <u>to him</u>.</td><td class="k" style="color:var(--key);font-weight:700;">to</td></tr>
        <tr><td class="e">I bought <u>her</u> a book.</td><td class="e">I bought a book <u>for her</u>.</td><td class="k" style="color:var(--gv);font-weight:700;">for</td></tr>
      </tbody>
    </table>'''),
    ('t','相手に<b>届ける</b>感じなら <span class="en">to</span>（<span class="en">show・give・tell・send・teach</span>）、相手の<b>ために</b>する感じなら <span class="en">for</span>（<span class="en">buy・make</span>）です。'),
  ]),
  ('「だれに」に入る形', [
    ('t','「だれに」の位置には、決まった形が入ります。主語に使う形とちがうので注意しましょう。'),
    ('h','''<table class="kind">
      <thead><tr><th>主語のとき</th><th>「だれに」のとき</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k">I ／ you</td><td class="k" style="color:var(--gv);font-weight:700;">me ／ you</td><td class="e">Show <u>me</u> the picture.</td></tr>
        <tr><td class="k">he ／ she</td><td class="k" style="color:var(--gv);font-weight:700;">him ／ her</td><td class="e">Show <u>him</u> the picture.</td></tr>
        <tr><td class="k">we ／ they</td><td class="k" style="color:var(--gv);font-weight:700;">us ／ them</td><td class="e">Show <u>them</u> the picture.</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">you</span> だけは、どちらも同じ形です。'),
  ]),
 ],
 'quiz':[
  ('Show your notebook me.','Show me your notebook.','<b>「だれに」が先</b>。入れかえるなら <span class="en">to me</span> にします。','わたしに ノートを 見せて ください。'),
  ('Show I your notebook.','Show me your notebook.','「だれに」の位置は <b><span class="en">me</span></b>。<span class="en">I</span> は主語のときの形です。','わたしに ノートを 見せて ください。'),
  ('I&#39;ll give a message you.','I&#39;ll give you a message.','順番がぎゃくです。<span class="en">to you</span> をつければ うしろでもよい。','あなたに ことづけを 伝えます。'),
  ('Show your notebook for me.','Show your notebook to me.','<span class="en">show</span> は<b>届ける</b>感じなので <b><span class="en">to</span></b>。','わたしに ノートを 見せて ください。'),
  ('I bought a book to her.','I bought a book for her.','<span class="en">buy</span> は<b>～のために</b>なので <b><span class="en">for</span></b>。','わたしは 彼女に 本を 買いました。'),
  ('Show he the picture.','Show him the picture.','「だれに」の位置は <b><span class="en">him</span></b>。','彼に その写真を 見せて ください。'),
 ],
 'summary':[
  '<b>動詞 ＋「だれに」＋「何を」</b>の順。<span class="en">Show me your notebook.</span>',
  '「だれに」には <b><span class="en">me・you・him・her・us・them</span></b> が入る。',
  '入れかえるときは <b>「だれに」の前に <span class="en">to</span> か <span class="en">for</span></b>。',
  '<span class="en">show・give・tell・send・teach</span> は <b><span class="en">to</span></b>、<span class="en">buy・make</span> は <b><span class="en">for</span></b>。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     'この形では、動詞のうしろに%sを先に置く。' % bl('だれに'),
     'そのあとに%sを置く。' % bl('何を'),
     '「だれに」の位置には、<span class="en">I</span> ではなく%sの形を使う。' % bl('me'),
     '順番を入れかえるときは、「だれに」の前に%sか <span class="en">for</span> をつける。' % bl('to'),
     '<span class="en">buy</span> や <span class="en">make</span> のときは%sを使う。' % bl('for'),
   ]),
   'words':'語群：だれに ／ 何を ／ <span class="en">me</span> ／ <span class="en">to</span> ／ <span class="en">for</span>',
   'exp':'<b>なぜ？</b>　英語は<b>語順で意味が決まる</b>ことばです。前にあるほうが「受けとる人」になります。<br>'
         'だから順番を入れかえたいときは、<span class="en">to・for</span> という「こちらが受けとる人ですよ」というしるしが必要になるのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　「だれに」の形を書こう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>主語に使う形とはちがう</b>ことに注意しましょう。',
   'body':grid2([
     '1. <span class="en">Show%sthe picture.（わたしに）</span>' % bl('me'),
     '2. <span class="en">Show%sthe picture.（彼に）</span>' % bl('him'),
     '3. <span class="en">Show%sthe picture.（彼女に）</span>' % bl('her'),
     '4. <span class="en">Show%sthe picture.（あなたに）</span>' % bl('you'),
     '5. <span class="en">Show%sthe picture.（彼らに）</span>' % bl('them'),
     '6. <span class="en">Show%sthe picture.（わたしたちに）</span>' % bl('us'),
     '7. <span class="en">I gave%sa present.（彼に）</span>' % bl('him'),
     '8. <span class="en">I told%sthe story.（彼女に）</span>' % bl('her'),
     '9. <span class="en">He sent%sa letter.（わたしに）</span>' % bl('me'),
     '10. <span class="en">She bought%sa book.（わたしたちに）</span>' % bl('us'),
   ]),
   'exp':'<b>かくにん</b>　主語のときと形がちがうのは <span class="en">I→me、he→him、she→her、we→us、they→them</span> の5つです。<br>'
         '<span class="en">you</span> だけはどちらも <span class="en">you</span> のままです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. Show me your notebook.','○'), ('2. Show your notebook me.','✕'),
     ('3. Show your notebook to me.','○'), ('4. Show I your notebook.','✕'),
     ('5. I bought a book for her.','○'), ('6. I bought a book to her.','✕'),
     ('7. I&#39;ll give you a message.','○'), ('8. I&#39;ll give a message you.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">Show me your notebook.</span> か <span class="en">Show your notebook to me.</span><br>'
         '4 → <span class="en">me</span>　6 → <span class="en">for her</span>（<span class="en">buy</span> は <span class="en">for</span>）　8 → <span class="en">give you a message</span>'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'「届ける」なら <span class="en">to</span>、「～のために」なら <span class="en">for</span>。',
   'body':grid2([
     '1. <span class="en">Show （ア me ／イ I） your notebook.</span>%s' % bl('ア'),
     '2. <span class="en">I gave a present （ア for ／イ to） him.</span>%s' % bl('イ'),
     '3. <span class="en">I bought a book （ア for ／イ to） her.</span>%s' % bl('ア'),
     '4. <span class="en">Show （ア him ／イ he） the picture.</span>%s' % bl('ア'),
     '5. <span class="en">I&#39;ll give （ア a message you ／イ you a message）.</span>%s' % bl('イ'),
     '6. <span class="en">She told （ア we ／イ us） the story.</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　1・4・6 は「だれに」に入る形。2・3 は <span class="en">to</span> と <span class="en">for</span> の使い分けです。<br>'
         '5 は語順。「だれに」を先に置くか、<span class="en">to</span> をつけてうしろに置くかの2つしかありません。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　「だれに」の位置の形と、<span class="en">to</span> / <span class="en">for</span> の使い分けに注目。',
   'body':ol([
     ('<span class="jp-cue">わたしにノートを見せてください。</span>　<span class="en">Show%syour notebook.</span>' % bl('me'),
      '「だれに」が先。<span class="en">me</span> の形。'),
     ('<span class="jp-cue">あなたにことづけを伝えます。</span>　<span class="en">I&#39;ll give%sa message.</span>' % bl('you'),
      '<span class="en">you</span> はそのまま。'),
     ('<span class="jp-cue">彼に写真を見せてください。</span>　<span class="en">Show%sthe picture.</span>' % bl('him'),
      '<span class="en">he</span> → <span class="en">him</span>。'),
     ('<span class="jp-cue">わたしにノートを見せてください。（入れかえて）</span>　<span class="en">Show your notebook%sme.</span>' % bl('to'),
      '<span class="en">show</span> は <span class="en">to</span>。'),
     ('<span class="jp-cue">わたしは彼女に本を買いました。</span>　<span class="en">I bought a book%sher.</span>' % bl('for'),
      '<span class="en">buy</span> は <span class="en">for</span>。'),
     ('<span class="jp-cue">わたしは彼にプレゼントをあげました。</span>　<span class="en">I%shim a present.</span>' % bl('gave'),
      '<span class="en">give</span> の過去形は <span class="en">gave</span>。'),
     ('<span class="jp-cue">わたしに話を聞かせてください。</span>　<span class="en">%sme the story.</span>' % bl('Tell'),
      '「話す」は <span class="en">tell</span>。'),
     ('<span class="jp-cue">彼はわたしに手紙を送りました。</span>　<span class="en">He sent%s%sletter.</span>' % (bl('me'), bl('a')),
      '（　）が2つ。「だれに」→「何を」。'),
     ('<span class="jp-cue">彼女はわたしたちに話をしました。</span>　<span class="en">She told%sthe story.</span>' % bl('us'),
      '<span class="en">we</span> → <span class="en">us</span>。'),
     ('<span class="jp-cue">わたしは彼らに写真を見せました。</span>　<span class="en">I showed%sthe pictures.</span>' % bl('them'),
      '<span class="en">they</span> → <span class="en">them</span>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　動詞 →「だれに」→「何を」。入れかえるなら <span class="en">to</span> / <span class="en">for</span> を忘れずに。',
   'body':ol([
     ('<span class="jp-cue">わたしにノートを見せてください。</span>　<span class="paren en">（ your notebook / Show / me ）</span>' + line('Show me your notebook.'),
      '命令文なので主語なし。'),
     ('<span class="jp-cue">あなたにことづけを伝えます。</span>　<span class="paren en">（ a message / I&#39;ll give / you ）</span>' + line('I&#39;ll give you a message.'),
      '<span class="en">give you</span> の順。'),
     ('<span class="jp-cue">わたしにノートを見せてください。（入れかえて）</span>　<span class="paren en">（ to me / your notebook / Show ）</span>' + line('Show your notebook to me.'),
      '<span class="en">to me</span> はいちばん後ろ。'),
     ('<span class="jp-cue">わたしは彼にプレゼントをあげました。</span>　<span class="paren en">（ a present / I gave / him ）</span>' + line('I gave him a present.'),
      '<span class="en">gave</span> は過去形。'),
     ('<span class="jp-cue">わたしは彼女に本を買いました。</span>　<span class="paren en">（ for her / a book / I bought ）</span>' + line('I bought a book for her.'),
      '<span class="en">buy</span> は <span class="en">for</span>。'),
     ('<span class="jp-cue">彼はわたしに手紙を送りました。</span>　<span class="paren en">（ a letter / He sent / me ）</span>' + line('He sent me a letter.'),
      '「だれに」が先。'),
     ('<span class="jp-cue">わたしは彼らに写真を見せました。</span>　<span class="paren en">（ the pictures / I showed / them ）</span>' + line('I showed them the pictures.'),
      '<span class="en">them</span> の形に注意。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしにノートを見せてください。' + wline('Show me your notebook.'),
      '<span class="en">Show your notebook to me.</span> でも正解。'),
     ('あなたにことづけを伝えます。' + wline('I&#39;ll give you a message.'),
      '<span class="en">I will</span> でも正解。'),
     ('彼に写真を見せてください。' + wline('Show him the picture.'),
      '<span class="en">he</span> にしない。'),
     ('わたしは彼女に本を買いました。' + wline('I bought a book for her.'),
      '<span class="en">I bought her a book.</span> でも正解。'),
     ('わたしに話を聞かせてください。' + wline('Tell me the story.'),
      '<span class="en">Tell the story to me.</span> でも正解。'),
     ('彼はわたしに手紙を送りました。' + wline('He sent me a letter.'),
      '<span class="en">sent</span> は <span class="en">send</span> の過去形。'),
   ]),
   'words':'<span class="en">Show me ／ give you ／ Show him ／ for her ／ Tell me ／ sent me</span>'},
  'l4':{'sub':'だれかに何かをあげた・見せた経験を書こう',
   'cond':['<span class="en">give</span> か <span class="en">show</span> を使った文を <b>2つ以上</b>',
           '「だれに」に <span class="en">him・her・them</span> のどれかを使う',
           '<span class="en">to</span> か <span class="en">for</span> を使って入れかえた文も <b>1つ</b>'],
   'example':['I gave my friend a birthday present.','I showed her my pictures.','I bought a cake for my mother.'],
   'note':'これは例です。同じでなくてかまいません。誕生日・お土産・手紙などが書きやすいです。',
   'check':['「だれに」→「何を」の順','me・him・her の形になっている','入れかえたら to / for をつけた','過去形にした'],
   'review':'じぶんの文の「だれに」の部分に○をつけよう。<span class="en">I・he・she</span> になっていたら、そこがまちがい。'},
 },
}
