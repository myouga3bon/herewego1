# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'g2-u6-1', 'grade':2, 'unit':'6 − 1', 'unit_plain':'6-1',
 'title':'不定詞（副詞的用法・目的）', 'pages':'p.72〜73',
 'hero_big':'I went to the park to play soccer.',
 'hero_jp':'わたしは サッカーを するために 公園へ 行きました',
 'motto':'<span class="en">to ＋ 原形（もとの形）</span> で <b>「～するために」</b>。<span class="en">Why ～?</span> の答えにも使う。',
 'kana':{'help':'ヘルプ','here':'ヒア','talk':'トーク','Mike':'マイク',
         'study':'スタディ','buy':'バイ','see':'スィー','meet':'ミート',
         'went':'ウェント','came':'ケイム','why':'ワイ','because':'ビコーズ',
         'park':'パーク','store':'ストア','library':'ライブラリィ','english':'イングリッシュ'},
 'blocks':[
  ('きほんの文', [
    ('t','同じ <span class="en">to ＋ 原形（もとの形）</span> ですが、今回は<b>「～するために」</b>と、<b>目的</b>を表します。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I went to the park to play soccer.</span><span class="t">わたしは サッカーを するために 公園へ 行きました。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I got up early to study.</span><span class="t">わたしは 勉強するために 早く 起きました。</span></div>
    </div>'''),
    ('t','文の<b>うしろ</b>にくっつけて、「なぜそうするのか」を足しています。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜3つの <span class="en">to</span> の見分け方', [
    ('t','ここが今回のヤマです。形はぜんぶ同じ <span class="en">to ＋ 原形（もとの形）</span>。<b>どこについているか</b>で意味が決まります。'),
    ('h','''<table class="kind">
      <thead><tr><th>すぐ前にあるもの</th><th>意味</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k">動詞（<span class="en">want・need</span>）</td><td class="k" style="color:var(--key);font-weight:700;">～すること（2-2）</td><td class="e">I <u>want</u> to study.</td></tr>
        <tr><td class="k">名前（<span class="en">something・time</span>）</td><td class="k" style="color:var(--gv);font-weight:700;">～するための（4-3）</td><td class="e">I have <u>time</u> to study.</td></tr>
        <tr><td class="k">文がもう完成している</td><td class="k" style="color:var(--ng);font-weight:700;">～するために（今回）</td><td class="e"><u>I study English</u> to travel.</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">I study English.</span> だけで<b>文として完成しています</b>。そこに足されているので「～するために」になります。'),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：<span class="en">to</span> の<b>すぐ前</b>を見れば意味が分かる</div>
        <p>動詞の直後なら「～すること」、名前の直後なら「～するための」、<b>文が完成していたら「～するために」</b>。<br>
        <span class="xm">✕ to のうしろに s や ing をつける ✕</span></p>
      </div>
    </div>'''),
  ]),
  ('テストによく出ることば', [
    ('t','「～するために」でよく出る形です。<b>文のうしろにつける</b>という位置をおぼえましょう。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">to help</span></td><td class="k">助けるために</td><td class="e">She&#39;s here <u>to help</u> him.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">to talk</span></td><td class="k">話すために</td><td class="e">I study English <u>to travel</u> Mike.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">to see</span></td><td class="k">会うために・見るために</td><td class="e">I went there <u>to see</u> him.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">to buy</span></td><td class="k">買うために</td><td class="e">I went to the store <u>to buy</u> milk.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">to help</span> ・ <span class="en">to talk</span> ・ <span class="en">to see</span> ・ <span class="en">to buy</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('<span class="en">Why ～?</span> の答えに使う', [
    ('t','「なぜ？」と聞かれたとき、<b><span class="en">To ～.</span> だけで答えられます</b>。'),
    ('h','''<div class="eqbox">
      <span class="eq">Why do you study English?</span>（なぜ英語を勉強するのですか）<br>
      — <span class="eq" style="color:var(--gv);">To talk with Mike.</span>（マイクと話すためです）
    </div>'''),
    ('t','<span class="en">Because ～.</span>（～だから）でも答えられますが、<span class="en">To ～.</span> のほうが短くて便利です。'),
  ]),
  ('文のどこに置くか', [
    ('t','「～するために」は、ふつう<b>文のいちばん後ろ</b>に置きます。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq">I went to the park</span> <span class="eq" style="color:var(--gv);">to play soccer.</span><br>
      <span class="eq">I got up early</span> <span class="eq" style="color:var(--gv);">to study.</span>
    </div>'''),
    ('t','前半だけで<b>文として成り立っているか</b>を確かめると、この用法だと見分けられます。'),
  ]),
 ],
 'quiz':[
  ('I study English to talking with Mike.','I study English to talk with Mike.','<span class="en">to</span> のうしろは<b>原形（もとの形）</b>。','わたしは マイクと 話すために 英語を 勉強します。'),
  ('She&#39;s here for help him.','She&#39;s here to help him.','「～するために」は <b><span class="en">to</span></b> を使います。','彼女は 彼を 助けるために ここに います。'),
  ('I study English to talks with Mike.','I study English to talk with Mike.','<span class="en">to</span> のうしろに <span class="en">s</span> はつけません。','わたしは マイクと 話すために 英語を 勉強します。'),
  ('I went to the store buy milk.','I went to the store to buy milk.','<b><span class="en">to</span> が抜けています</b>。','わたしは 牛乳を 買うために 店へ 行きました。'),
  ('To talk with Mike I study English to.','I study English to talk with Mike.','「～するために」は<b>文のうしろ</b>に置きます。','わたしは マイクと 話すために 英語を 勉強します。'),
  ('I got up early to studying.','I got up early to study.','<span class="en">to</span> と <span class="en">ing</span> を<b>両方つけません</b>。','わたしは 勉強するために 早く 起きました。'),
 ],
 'summary':[
  '<b><span class="en">to ＋ 原形（もとの形）</span></b> で「～するために」（目的）を表す。',
  '<b>文のうしろ</b>につける。前半だけで文として成り立っているのが目印。',
  '<span class="en">Why ～?</span> には <b><span class="en">To ～.</span></b> だけで答えられる。',
  '<span class="en">to</span> の<b>すぐ前</b>を見れば、3つの用法を見分けられる。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～するために」は、%s＋ 動詞の原形（もとの形） で表す。' % bl('to'),
     'この形は、ふつう文の%sに置く。' % bl('うしろ'),
     '<span class="en">to</span> のすぐ前が動詞なら「～%s」の意味になる。' % bl('すること', False),
     '<span class="en">to</span> のすぐ前が名前なら「～%s」の意味になる。' % bl('するための', False),
     '<span class="en">Why ～?</span> には、%s～. だけで答えられる。' % bl('To'),
   ]),
   'words':'語群：<span class="en">to</span> ／ うしろ ／ すること ／ するための ／ <span class="en">To</span>',
   'exp':'<b>なぜ？</b>　<span class="en">to</span> は「→（そっちへ向かう）」のしるしでしたね。<br>'
         '文が完成したあとに「→ そこへ向かって」と足すので、<b>行き先＝目的</b>を表すようになるのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">to</span> のうしろの形を書こう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>かざりを全部とった形</b>にしましょう。',
   'body':grid2([
     '1. <span class="en">She&#39;s here to%shim.</span>' % bl('help'),
     '2. <span class="en">I study English to%swith Mike.</span>' % bl('travel'),
     '3. <span class="en">I went there to%shim.</span>' % bl('see'),
     '4. <span class="en">I went to the store to%smilk.</span>' % bl('buy'),
     '5. <span class="en">I got up early to%s.</span>' % bl('study'),
     '6. <span class="en">He came here to%ssoccer.</span>' % bl('play'),
     '7. <span class="en">She went to Japan to%sJapanese.</span>' % bl('learn'),
     '8. <span class="en">I use my phone to%smusic.</span>' % bl('hear'),
     '9. <span class="en">We went to the park to%s.</span>' % bl('run'),
     '10. <span class="en">I called him to%sthank you.</span>' % bl('say'),
   ]),
   'exp':'<b>かくにん</b>　どれも<b>原形（もとの形）</b>です。<span class="en">helps・traveling・saw</span> などにはしません。<br>'
         'どの文も、<span class="en">to</span> の前までで<b>文として完成している</b>ことを確かめよう。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. She&#39;s here to help him.','○'), ('2. She&#39;s here for help him.','✕'),
     ('3. I study English to talk with Mike.','○'), ('4. I study English to talking with Mike.','✕'),
     ('5. I went to the store to buy milk.','○'), ('6. I went to the store buy milk.','✕'),
     ('7. I got up early to study.','○'), ('8. I got up early to studies.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">to help</span>　4 → <span class="en">to talk</span><br>'
         '6 → <span class="en">to buy</span>（<span class="en">to</span> を入れる）　8 → <span class="en">to study</span>'},
  {'h':'<h3 class="sec sec2">D　<span class="en">to</span> の意味はどれ？<em>正しいほうを選ぼう</em></h3>',
   'hint':'<span class="en">to</span> の<b>すぐ前</b>を見よう。動詞か、名前か、完成した文か。',
   'body':grid2([
     '1. <span class="en">I want to study.</span>（ア ～すること ／イ ～するために）%s' % bl('ア'),
     '2. <span class="en">I study English to travel.</span>（ア ～すること ／イ ～するために）%s' % bl('イ'),
     '3. <span class="en">I have time to study.</span>（ア ～するための ／イ ～するために）%s' % bl('ア'),
     '4. <span class="en">I went there to see him.</span>（ア ～するための ／イ ～するために）%s' % bl('イ'),
     '5. <span class="en">I need something to eat.</span>（ア ～するための ／イ ～するために）%s' % bl('ア'),
     '6. <span class="en">I got up early to study.</span>（ア ～すること ／イ ～するために）%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　1 は <span class="en">want</span>（動詞）の直後 → 「～すること」。<br>'
         '3・5 は <span class="en">time・something</span>（名前）の直後 → 「～するための」。<br>'
         '2・4・6 は、<span class="en">to</span> の前までで<b>文が完成</b>している → 「～するために」。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　まず文を完成させてから、うしろに <span class="en">to ～</span> を足そう。',
   'body':ol([
     ('<span class="jp-cue">彼女は彼を助けるためにここにいます。</span>　<span class="en">She&#39;s here%shelp him.</span>' % bl('to'),
      '文のうしろに <span class="en">to</span>。'),
     ('<span class="jp-cue">わたしはマイクと話すために英語を勉強します。</span>　<span class="en">I study English to%swith Mike.</span>' % bl('travel'),
      '原形（もとの形）。'),
     ('<span class="jp-cue">わたしは彼に会うためにそこへ行きました。</span>　<span class="en">I went there to%shim.</span>' % bl('see'),
      '「会う」は <span class="en">see</span>。'),
     ('<span class="jp-cue">わたしは牛乳を買うために店へ行きました。</span>　<span class="en">I went to the store to%smilk.</span>' % bl('buy'),
      '<span class="en">bought</span> にしない。'),
     ('<span class="jp-cue">わたしは勉強するために早く起きました。</span>　<span class="en">I got up early%sstudy.</span>' % bl('to'),
      '<span class="en">to</span> を忘れない。'),
     ('<span class="jp-cue">なぜ英語を勉強するのですか。</span>　<span class="en">%sdo you study English?</span>' % bl('Why'),
      '「なぜ」は <span class="en">Why</span>。'),
     ('<span class="jp-cue">マイクと話すためです。</span>　<span class="en">%stalk with Mike.</span>' % bl('To'),
      '文のはじめなので大文字。'),
     ('<span class="jp-cue">彼はサッカーをするためにここへ来ました。</span>　<span class="en">He came here%s%ssoccer.</span>' % (bl('to'), bl('play')),
      '（　）が2つ。<span class="en">to play</span>。'),
     ('<span class="jp-cue">彼女は日本語を学ぶために日本へ行きました。</span>　<span class="en">She went to Japan to%sJapanese.</span>' % bl('learn'),
      '「学ぶ」は <span class="en">learn</span>。'),
     ('<span class="jp-cue">わたしたちは走るために公園へ行きました。</span>　<span class="en">We went to the park to%s.</span>' % bl('run'),
      '<span class="en">running</span> にしない。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　完成した文 ＋ <span class="en">to ～</span> の順。<span class="en">to ～</span> はいちばん後ろ。',
   'body':ol([
     ('<span class="jp-cue">彼女は彼を助けるためにここにいます。</span>　<span class="paren en">（ to help him / She&#39;s / here ）</span>' + line('She&#39;s here to help him.'),
      '<span class="en">She&#39;s here</span> で文が完成。'),
     ('<span class="jp-cue">わたしはマイクと話すために英語を勉強します。</span>　<span class="paren en">（ to talk with Mike / English / I study ）</span>' + line('I study English to talk with Mike.'),
      '<span class="en">to ～</span> は後ろ。'),
     ('<span class="jp-cue">わたしは彼に会うためにそこへ行きました。</span>　<span class="paren en">（ there / to see him / I went ）</span>' + line('I went there to see him.'),
      '<span class="en">I went there</span> が中心。'),
     ('<span class="jp-cue">わたしは牛乳を買うために店へ行きました。</span>　<span class="paren en">（ to buy milk / to the store / I went ）</span>' + line('I went to the store to buy milk.'),
      '<span class="en">to</span> が2つ出るので注意。'),
     ('<span class="jp-cue">わたしは勉強するために早く起きました。</span>　<span class="paren en">（ to study / early / I got up ）</span>' + line('I got up early to study.'),
      '<span class="en">got up early</span> でひとかたまり。'),
     ('<span class="jp-cue">彼はサッカーをするためにここへ来ました。</span>　<span class="paren en">（ to play soccer / He came / here ）</span>' + line('He came here to play soccer.'),
      '<span class="en">He came here</span> が中心。'),
     ('<span class="jp-cue">彼女は日本語を学ぶために日本へ行きました。</span>　<span class="paren en">（ to learn Japanese / She went / to Japan ）</span>' + line('She went to Japan to learn Japanese.'),
      '目的はいちばん後ろ。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('彼女は彼を助けるためにここにいます。' + wline('She&#39;s here to help him.'),
      '<span class="en">She is</span> でも正解。'),
     ('わたしはマイクと話すために英語を勉強します。' + wline('I study English to talk with Mike.'),
      '<span class="en">to traveling</span> にしない。'),
     ('わたしは彼に会うためにそこへ行きました。' + wline('I went there to see him.'),
      '<span class="en">him</span> の形に注意。'),
     ('わたしは牛乳を買うために店へ行きました。' + wline('I went to the store to buy milk.'),
      '<span class="en">to</span> が2つ出る。'),
     ('わたしは勉強するために早く起きました。' + wline('I got up early to study.'),
      '<span class="en">to</span> を忘れない。'),
     ('なぜ英語を勉強するのですか。— マイクと話すためです。' + wline('Why do you study English? — To talk with Mike.'),
      '<span class="en">To</span> は大文字で始める。'),
   ]),
   'words':'<span class="en">to help ／ to talk with Mike ／ to see him ／ to buy milk ／ to study ／ To talk with Mike</span>'},
  'l4':{'sub':'自分が「何かのためにしていること」を書こう',
   'cond':['「～するために」の <span class="en">to ～</span> を使った文を <b>2つ以上</b>',
           '過去のことを言う文を <b>1つ</b> 入れる',
           '<span class="en">Why ～?</span> と <span class="en">To ～.</span> のやりとりを <b>1組</b> 入れる'],
   'example':['I study English to talk with people from other countries.','I got up early to practice the piano.','Why do you run every day? — To be healthy.'],
   'note':'これは例です。同じでなくてかまいません。部活・勉強・習いごとの「目的」で書くと書きやすいです。',
   'check':['to のうしろは原形（もとの形）','to の前までで文が完成している','to を忘れていない','Why の答えは To ～ で始めた'],
   'review':'じぶんの文の <span class="en">to</span> の前を指でかくしてみよう。それだけで文になっていれば正解です。'},
 },
}
