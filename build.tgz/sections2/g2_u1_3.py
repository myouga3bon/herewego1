# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'g2-u1-3', 'grade':2, 'unit':'1 − 3', 'unit_plain':'1-3',
 'title':'look ／ sound ＋ 形容詞', 'pages':'p.14〜15',
 'hero_big':'You look happy. ／ That sounds fun.',
 'hero_jp':'あなたは うれしそうに 見えます ／ それは 楽しそうに 聞こえます',
 'motto':'<span class="en">look・sound</span> のうしろは <b>ようすのことば</b>。<span class="en">be動詞</span> とは いっしょに使わない。',
 'kana':{'look':'ルック','looks':'ルックス','looked':'ルックト','sound':'サウンド',
         'sounds':'サウンヅ','sounded':'サウンディッド','happy':'ハピィ','sad':'サッド',
         'tired':'タイアド','exciting':'イクサイティング','interesting':'インタレスティング',
         'good':'グッド','great':'グレイト','nice':'ナイス','idea':'アイディア',
         'they':'ゼイ','she':'シー','he':'ヒー','it':'イット','that':'ザット','busy':'ビズィ'},
 'blocks':[
  ('きほんの文', [
    ('t','人やものの<b>ようす</b>を、見た目や聞こえ方から言うときの形です。「～そうに見える」「～そうに聞こえる」と訳します。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">You look happy.</span><span class="t">あなたは うれしそうに 見えます。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">That sounds fun.</span><span class="t">それは 楽しそうに 聞こえます。</span></div>
    </div>'''),
    ('t','<span class="en">look</span> は<b>目で見たようす</b>、<span class="en">sound</span> は<b>耳で聞いたようす</b>です。話を聞いて「楽しそうだね」と言うときは <span class="en">sound</span> を使います。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜うしろは「ようすのことば」', [
    ('t','ここが今回のヤマです。<span class="en">look・sound</span> のうしろには、<b>ようすを表すことば</b>（形容詞）を置きます。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ ようすのことば<small>happy・tired・exciting</small></span></div>
        <div class="in"><div class="ex">They looked happy.<br>It sounds exciting.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ ほかの形<small>happily・a happy</small></span></div>
        <div class="in"><div class="ex">They looked happily.<br>They looked a happy.</div></div>
      </div>
    </div>'''),
    ('t','<span class="en">happily</span>（うれしそうに）のような <span class="en">-ly</span> の形や、<span class="en">a</span> はつけません。<b>そのままの形</b>で置きます。'),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：1つの文に 心臓（動詞）は 1つだけ</div>
        <p><b class="cb">青＝<span class="en">be動詞</span></b>　<b class="cp">ピンク＝<span class="en">look・sound</span></b>　
        <span class="en">look・sound</span> は動作のことばの仲間。be動詞といっしょには使いません。<br>
        <span class="xm">✕ They were looked happy ✕</span></p>
      </div>
    </div>'''),
  ]),
  ('テストによく出ることば', [
    ('t','<b>主語で形が変わる</b>のが、いちばんまちがえるところです。1年生でならった三単現の <span class="en">s</span> がここでも出ます。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味・使うとき</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">look</span></td><td class="k">～に見える（I・you・複数）</td><td class="e">You <u>look</u> tired.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">looks</span></td><td class="k">he・she・it のとき</td><td class="e">He <u>looks</u> tired.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">looked</span></td><td class="k">過去形</td><td class="e">They <u>looked</u> happy.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">sounds</span></td><td class="k">それは～に聞こえる</td><td class="e">It <u>sounds</u> exciting.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">look</span> ・ <span class="en">looks</span> ・ <span class="en">looked</span> ・ <span class="en">sounds</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('<span class="en">is</span> とのちがい', [
    ('t','<span class="en">He is tired.</span> と <span class="en">He looks tired.</span> は、どちらも「つかれている」ですが、<b>言い方の強さ</b>がちがいます。'),
    ('h','''<table class="kind">
      <thead><tr><th>形</th><th>意味</th><th>気もち</th></tr></thead>
      <tbody>
        <tr><td class="k" style="color:var(--key);font-weight:700;">He is tired.</td><td class="k">彼はつかれている</td><td class="e">事実として言う</td></tr>
        <tr><td class="k" style="color:var(--gv);font-weight:700;">He looks tired.</td><td class="k">彼はつかれて<u>見える</u></td><td class="e">見たようすから言う</td></tr>
      </tbody>
    </table>'''),
    ('t','はっきりとは分からないけれど、<b>見た感じでそう思う</b>ときに <span class="en">look</span> を使います。'),
  ]),
  ('会話でよく使う形', [
    ('t','相手の話を聞いて感想を言うとき、<span class="en">That sounds ～.</span> がとてもよく使われます。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">That sounds good.</span>（いいですね）　<span class="eq" style="color:var(--gv);">That sounds fun.</span>（楽しそうですね）<br>
      <span class="eq" style="color:var(--gv);">You look happy.</span>（うれしそうですね）　<span class="eq" style="color:var(--gv);">You look tired.</span>（つかれているようですね）
    </div>'''),
    ('t','<span class="en">Sounds good.</span> と、主語を省いて短く言うこともあります。'),
  ]),
 ],
 'quiz':[
  ('They looked happily.','They looked happy.','うしろは<b>ようすのことば</b>。<span class="en">-ly</span> の形は使いません。','彼らは うれしそうに 見えました。'),
  ('It sound exciting.','It sounds exciting.','主語が <span class="en">It</span> なので <b><span class="en">s</span></b> がつきます。','それは わくわくするように 聞こえます。'),
  ('They were looked happy.','They looked happy.','<span class="en">were</span> と <span class="en">looked</span> で<b>心臓が2つ</b>。<span class="en">were</span> はいりません。','彼らは うれしそうに 見えました。'),
  ('He look tired.','He looks tired.','主語が <span class="en">He</span> なので <b><span class="en">looks</span></b>。','彼は つかれているように 見えます。'),
  ('She looked a happy.','She looked happy.','<b><span class="en">a</span> はつけません</b>。ようすのことばをそのまま置きます。','彼女は うれしそうに 見えました。'),
  ('It sounds excited.','It sounds exciting.','ものが「わくわくさせる」側なので <b><span class="en">exciting</span></b>。<span class="en">excited</span> は人が感じる側。','それは わくわくするように 聞こえます。'),
 ],
 'summary':[
  '<b><span class="en">look ＋ ようすのことば</span></b>＝「～に見える」。<b><span class="en">sound ＋ ようすのことば</span></b>＝「～に聞こえる」。',
  'うしろは <b>そのままの形</b>。<span class="en">-ly</span> をつけたり <span class="en">a</span> を足したりしない。',
  '主語が <span class="en">he・she・it</span> なら <b><span class="en">looks・sounds</span></b>。過去は <b><span class="en">looked・sounded</span></b>。',
  '<b>be動詞とはいっしょに使わない。</b>心臓（動詞）は1つだけ。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～に見える」は%s、「～に聞こえる」は%sを使う。' % (bl('look'), bl('sound')),
     'そのうしろには%sを表すことばを置く。' % bl('ようす'),
     '主語が <span class="en">he・she・it</span> のときは%sをつける。' % bl('s'),
     '過去のことを言うときは%sの形にする。' % bl('looked', False),
     '<span class="en">look・sound</span> は%sといっしょに使わない。' % bl('be動詞', False),
   ]),
   'words':'語群：<span class="en">look</span> ／ <span class="en">sound</span> ／ ようす ／ <span class="en">s</span> ／ <span class="en">looked</span> ／ be動詞',
   'exp':'<b>なぜ？</b>　<span class="en">look・sound</span> は<b>動作のことばの仲間</b>です。だから三単現の <span class="en">s</span> も、過去形の <span class="en">ed</span> もつきます。<br>'
         'be動詞を足したくなるのは、日本語の「～そうに<b>見える</b>」が「です」に近く感じるからです。英語では <span class="en">look</span> だけで足ります。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　正しい形を書こう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>主語</b>と<b>いつのことか</b>を見ましょう。',
   'body':grid2([
     '1. <span class="en">He%stired.</span>' % bl('looks'),
     '2. <span class="en">They%shappy.</span>' % bl('look'),
     '3. <span class="en">It%sexciting.</span>' % bl('sounds'),
     '4. <span class="en">They%shappy yesterday.</span>' % bl('looked', False),
     '5. <span class="en">You%sbusy.</span>' % bl('look'),
     '6. <span class="en">That%sgood.</span>' % bl('sounds'),
     '7. <span class="en">She%ssad.</span>' % bl('looks'),
     '8. <span class="en">It%sinteresting yesterday.</span>' % bl('sounded', False),
     '9. <span class="en">We%stired.</span>' % bl('look'),
     '10. <span class="en">My dog%shappy.</span>' % bl('looks'),
   ]),
   'exp':'<b>見分け方</b>　<span class="en">he・she・it</span>・1つのもの → <span class="en">s</span> がつく（1・3・6・7・10）<br>'
         '<span class="en">I・you・they・we</span>・2人以上 → そのまま（2・5・9）<br>'
         '<span class="en">yesterday</span> がある → 過去形（4・8）'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. They looked happy.','○'), ('2. They looked happily.','✕'),
     ('3. It sounds exciting.','○'), ('4. It sound exciting.','✕'),
     ('5. He looks tired.','○'), ('6. He is looks tired.','✕'),
     ('7. That sounds good.','○'), ('8. She looked a happy.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">happy</span>（<span class="en">-ly</span> をとる）　4 → <span class="en">sounds</span>（<span class="en">s</span> をつける）<br>'
         '6 → <span class="en">He looks tired.</span>（<span class="en">is</span> をとる）　8 → <span class="en">She looked happy.</span>（<span class="en">a</span> をとる）'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'目で見たことなら <span class="en">look</span>、聞いたことなら <span class="en">sound</span>。',
   'body':grid2([
     '1. <span class="en">You （ア look ／イ looks） tired today.</span>%s' % bl('ア'),
     '2. <span class="en">That （ア sound ／イ sounds） fun.</span>%s' % bl('イ'),
     '3. <span class="en">They looked （ア happy ／イ happily）.</span>%s' % bl('ア'),
     '4. <span class="en">He （ア is looks ／イ looks） busy.</span>%s' % bl('イ'),
     '5. <span class="en">They （ア looked ／イ were looked） sad.</span>%s' % bl('ア'),
     '6. <span class="en">Your plan （ア sound ／イ sounds） great.</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　1・3・5 は <span class="en">look</span> の形のまちがい。2・6 は三単現の <span class="en">s</span>。<br>'
         '4・5 は be動詞を足してしまう、いちばん多いまちがいです。<span class="en">look</span> だけで「～に見える」の意味になります。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　主語を見て <span class="en">s</span> をつけるか決め、うしろは<b>そのままの形</b>で置こう。',
   'body':ol([
     ('<span class="jp-cue">彼らはうれしそうに見えました。</span>　<span class="en">They%shappy.</span>' % bl('looked', False),
      '過去なので <b><span class="en">looked</span></b>。'),
     ('<span class="jp-cue">それはわくわくするように聞こえます。</span>　<span class="en">It%sexciting.</span>' % bl('sounds'),
      '<span class="en">It</span> なので <b><span class="en">s</span></b> をつける。'),
     ('<span class="jp-cue">あなたはつかれているように見えます。</span>　<span class="en">You%stired.</span>' % bl('look'),
      '<span class="en">You</span> には <span class="en">s</span> をつけない。'),
     ('<span class="jp-cue">彼は忙しそうに見えます。</span>　<span class="en">He%sbusy.</span>' % bl('looks'),
      '<span class="en">He</span> なので <b><span class="en">looks</span></b>。'),
     ('<span class="jp-cue">それはいいですね。</span>　<span class="en">That sounds%s.</span>' % bl('good'),
      '会話でよく使う形。'),
     ('<span class="jp-cue">彼女は悲しそうに見えました。</span>　<span class="en">She%ssad.</span>' % bl('looked', False),
      '過去なので <span class="en">ed</span> をつける。'),
     ('<span class="jp-cue">わたしたちはうれしそうに見えます。</span>　<span class="en">We%shappy.</span>' % bl('look'),
      '<span class="en">We</span> は2人以上。<span class="en">s</span> なし。'),
     ('<span class="jp-cue">その話はおもしろそうに聞こえました。</span>　<span class="en">The story%sinteresting.</span>' % bl('sounded', False),
      '過去なので <b><span class="en">sounded</span></b>。'),
     ('<span class="jp-cue">あなたの計画はすばらしく聞こえます。</span>　<span class="en">Your plan%sgreat.</span>' % bl('sounds'),
      '<span class="en">Your plan</span> は1つ。<span class="en">s</span> がつく。'),
     ('<span class="jp-cue">わたしの犬はうれしそうに見えます。</span>　<span class="en">My dog%shappy.</span>' % bl('looks'),
      '<span class="en">My dog</span> は1ぴき。<span class="en">s</span> がつく。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　主語 → <span class="en">look / sound</span> → ようすのことば、の順。',
   'body':ol([
     ('<span class="jp-cue">彼らはうれしそうに見えました。</span>　<span class="paren en">（ happy / They / looked ）</span>' + line('They looked happy.'),
      '3語だけ。<span class="en">were</span> は入れない。'),
     ('<span class="jp-cue">それはわくわくするように聞こえます。</span>　<span class="paren en">（ exciting / It / sounds ）</span>' + line('It sounds exciting.'),
      '<span class="en">sounds</span> の <span class="en">s</span> に注意。'),
     ('<span class="jp-cue">あなたは今日つかれているように見えます。</span>　<span class="paren en">（ today / look / You / tired ）</span>' + line('You look tired today.'),
      '「今日」はいちばん後ろ。'),
     ('<span class="jp-cue">それはいいですね。</span>　<span class="paren en">（ good / That / sounds ）</span>' + line('That sounds good.'),
      '会話でそのまま使える形。'),
     ('<span class="jp-cue">彼女は悲しそうに見えました。</span>　<span class="paren en">（ sad / She / looked ）</span>' + line('She looked sad.'),
      '過去形を選ぶ。'),
     ('<span class="jp-cue">あなたの計画はすばらしく聞こえます。</span>　<span class="paren en">（ great / sounds / Your plan ）</span>' + line('Your plan sounds great.'),
      '主語が2語。<span class="en">Your plan</span> でひとかたまり。'),
     ('<span class="jp-cue">その話はおもしろそうに聞こえました。</span>　<span class="paren en">（ interesting / sounded / The story ）</span>' + line('The story sounded interesting.'),
      '過去形は <span class="en">sounded</span>。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('彼らはうれしそうに見えました。' + wline('They looked happy.'),
      '<span class="en">happily</span> にしない。'),
     ('それはわくわくするように聞こえます。' + wline('It sounds exciting.'),
      '<span class="en">s</span> を忘れない。'),
     ('あなたはつかれているように見えます。' + wline('You look tired.'),
      '<span class="en">You</span> に <span class="en">s</span> はつけない。'),
     ('彼は忙しそうに見えます。' + wline('He looks busy.'),
      '<span class="en">He</span> なので <span class="en">looks</span>。'),
     ('それはいいですね。' + wline('That sounds good.'),
      '<span class="en">Sounds good.</span> でも通じる。'),
     ('その話はおもしろそうに聞こえました。' + wline('The story sounded interesting.'),
      '過去形にする。'),
   ]),
   'words':'<span class="en">looked happy ／ sounds exciting ／ look tired ／ looks busy ／ That sounds good ／ sounded interesting</span>'},
  'l4':{'sub':'友だちや家族のようすを、見た感じで書こう',
   'cond':['<span class="en">look</span> を使った文を <b>2つ以上</b>（主語を変えて）',
           '<span class="en">sound</span> を使った文を <b>1つ</b>',
           '過去のことを言う文を <b>1つ</b> 入れる'],
   'example':['My sister looks happy today.','My friends looked tired after the game.','That sounds fun.'],
   'note':'これは例です。同じでなくてかまいません。<span class="en">happy・sad・tired・busy・hungry</span> などが使いやすいです。',
   'check':['うしろはようすのことば','主語が he・she・it なら s','be動詞を足していない','過去なら looked / sounded'],
   'review':'じぶんの文に <span class="en">is・are・was</span> が入っていないか見直そう。入っていたら、そこがまちがい。'},
 },
}
