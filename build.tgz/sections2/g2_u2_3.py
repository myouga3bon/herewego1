# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox, gmap

S = {
 'id':'g2-u2-3', 'grade':2, 'unit':'2 − 3', 'unit_plain':'2-3',
 'title':'接続詞 that', 'pages':'p.24〜25',
 'hero_big':'I think that he is kind.',
 'hero_jp':'わたしは 彼は やさしいと 思います',
 'motto':'<span class="en">think・know・hope</span> のうしろに <b>文がまるごと</b>入る。<span class="en">that</span> は 省いてよい。',
 'kana':{'think':'スィンク','thinks':'スィンクス','thought':'ソート','know':'ノウ',
         'knows':'ノウズ','hope':'ホウプ','sure':'シュア','that':'ザット',
         'great':'グレイト','job':'ジョブ','did':'ディド','kind':'カインド',
         'busy':'ビズィ','rain':'レイン','tomorrow':'トゥモロウ','come':'カム',
         'believe':'ビリーヴ','say':'セイ','true':'トゥルー','right':'ライト'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>彼は やさしい と 思います</b>」のように、<b>自分の考え</b>を言うときの形です。'),
    ('t','<span class="en">think</span> のうしろに、<b>文がまるごと</b>入ります。'),
    ('h', gmap('彼は やさしい <b>と 思います</b>', 'think (that) he is kind',
               '<b>that</b> が「～と」にあたります。あってもなくてもよく、会話では<b>省くことが多い</b>です。')),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I think (that) he is kind.</span><span class="t">わたしは 彼は やさしいと 思います。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I know (that) you are busy.</span><span class="t">わたしは あなたが いそがしいと 知っています。</span></div>
    </div>'''),
    ('t','<span class="en">that</span> のうしろは<b>ふつうの文の形</b>。主語と動詞がそろった文がまるごと入ります。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜うしろに文がまるごと入る', [
    ('t','ここが今回のヤマです。<span class="en">that</span> のうしろは<b>ふつうの文</b>がそのまま入ります。だから<b>動詞が2つ</b>になります。'),
    ('h','''<div class="eqbox">
      <span class="eq">I think</span>（わたしは思う）　＋　<span class="eq">You did a great job.</span>（あなたはよくやった）<br>
      → <span class="eq">I think</span> <span class="eq" style="color:var(--gv);">(that)</span> <span class="eq">you did a great job.</span>
    </div>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ ふつうの文のまま<small>主語 → 動詞 の順</small></span></div>
        <div class="in"><div class="ex">I think you did a great job.<br>I know he is kind.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ たずねる文の形<small>ひっくり返さない</small></span></div>
        <div class="in"><div class="ex">I think did you a great job.<br>I know is he kind.</div></div>
      </div>
    </div>'''),
    ('t','<span class="en">that</span> のうしろは<b>たずねる文ではありません</b>。主語 → 動詞 のふつうの順のままです。'),
  ]),
  ('テストによく出ることば', [
    ('t','うしろに文を置ける動詞は決まっています。よく使う4つをおぼえましょう。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">I think</span></td><td class="k">わたしは～だと思う</td><td class="e"><u>I think</u> you did a great job.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">I know</span></td><td class="k">わたしは～だと知っている</td><td class="e"><u>I know</u> he is kind.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">I hope</span></td><td class="k">わたしは～だといいと思う</td><td class="e"><u>I hope</u> you like it.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">I&#39;m sure</span></td><td class="k">きっと～だと思う</td><td class="e"><u>I&#39;m sure</u> you can do it.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">I think</span> ・ <span class="en">I know</span> ・ <span class="en">I hope</span> ・ <span class="en">I&#39;m sure</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('<span class="en">that</span> は省いてよい', [
    ('t','<span class="en">that</span> は<b>入れても入れなくても、意味は同じ</b>です。教科書でも会話でも、省いた形がよく出ます。'),
    ('h','''<table class="kind">
      <thead><tr><th>形</th><th>れい文</th><th>使う場面</th></tr></thead>
      <tbody>
        <tr><td class="k"><span class="en">that</span> を入れる</td><td class="e">I think <u>that</u> you did a great job.</td><td class="k">書くとき・ていねいに</td></tr>
        <tr><td class="k"><span class="en">that</span> を省く</td><td class="e">I think you did a great job.</td><td class="k">会話でふつう</td></tr>
      </tbody>
    </table>'''),
    ('t','テストでは<b>どちらでも正解</b>になることが多いですが、省いた形でもすぐ読めるようにしておきましょう。'),
  ]),
  ('打ち消すときは前の動詞を打ち消す', [
    ('t','「～ではないと思う」は、英語では<b>前の <span class="en">think</span> のほうを打ち消します</b>。日本語とちがうところです。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      日本語：わたしは 彼が 忙しい <b>とは思いません</b>。<br>
      英語：<span class="eq" style="color:var(--gv);">I don&#39;t think</span> <span class="eq">he is busy.</span>
    </div>'''),
    ('t','<span class="en">I think he isn&#39;t busy.</span> とは、ふつう言いません。<b>打ち消しは前に出す</b>とおぼえましょう。'),
  ]),
 ],
 'quiz':[
  ('I think did you a great job.','I think you did a great job.','<span class="en">that</span> のうしろは<b>ふつうの文</b>。たずねる文の形にしません。','わたしは あなたが よくやったと 思います。'),
  ('I think that.','I think that you did a great job.','<span class="en">that</span> のうしろに<b>文が必要</b>です。','わたしは あなたが よくやったと 思います。'),
  ('I am think you did a great job.','I think you did a great job.','<span class="en">am</span> と <span class="en">think</span> で<b>心臓が2つ</b>。','わたしは あなたが よくやったと 思います。'),
  ('I know is he kind.','I know he is kind.','<b>主語 → 動詞</b> の順にもどします。','わたしは 彼が やさしいと 知って います。'),
  ('He think you did a great job.','He thinks you did a great job.','主語が <span class="en">He</span> なので <b><span class="en">thinks</span></b>。','彼は あなたが よくやったと 思って います。'),
  ('I think he isn&#39;t busy.','I don&#39;t think he is busy.','「～ではないと思う」は<b>前の動詞</b>を打ち消します。','わたしは 彼が いそがしいとは 思いません。'),
 ],
 'summary':[
  '<b><span class="en">think・know・hope・be sure</span> のうしろに、文がまるごと入る。</b>',
  '<span class="en">that</span> は <b>省いてよい</b>。あってもなくても意味は同じ。',
  '<span class="en">that</span> のうしろは <b>主語 → 動詞</b> のふつうの順。たずねる文にしない。',
  '「～ではないと思う」は <b><span class="en">I don&#39;t think ～.</span></b> と、前の動詞を打ち消す。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～だと思う」は <span class="en">I</span>%s のうしろに文を置く。' % bl('think'),
     'そのあいだに入れる%sは、省いてもよい。' % bl('that'),
     '<span class="en">that</span> のうしろは、主語 → %s のふつうの順にする。' % bl('動詞'),
     '文が2つくっつくので、動詞は%sある。' % bl('2つ'),
     '「～ではないと思う」は、%sの動詞を打ち消す。' % bl('前'),
   ]),
   'words':'語群：<span class="en">think</span> ／ <span class="en">that</span> ／ 動詞 ／ 2つ ／ 前',
   'exp':'<b>なぜ？</b>　<span class="en">that</span> は「そのこと」という意味のしるしです。<br>'
         '「わたしは思う → <b>そのことを</b> → あなたはよくやった」という順で並んでいると考えると、語順がつかめます。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">that</span> のうしろを書こう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>ふつうの文の順</b>にもどしましょう。',
   'body':grid2([
     '1. <span class="en">I think he%skind.</span>' % bl('is'),
     '2. <span class="en">I know she%sbusy.</span>' % bl('is'),
     '3. <span class="en">I think you%sa great job.</span>' % bl('did'),
     '4. <span class="en">I hope you%sit.</span>' % bl('like'),
     '5. <span class="en">I&#39;m sure he%scome.</span>' % bl('will'),
     '6. <span class="en">I think they%shappy.</span>' % bl('are'),
     '7. <span class="en">I know it%syesterday.</span>' % bl('rained', False),
     '8. <span class="en">I think she%ssoccer.</span>' % bl('likes'),
     '9. <span class="en">I hope it%ssunny.</span>' % bl('is'),
     '10. <span class="en">I know you%sdo it.</span>' % bl('can'),
   ]),
   'exp':'<b>かくにん</b>　どれも<b>ふつうの文</b>です。主語を見て、be動詞か動作のことばかを決めます。<br>'
         '8 は主語が <span class="en">she</span> なので <span class="en">likes</span>。<b>うしろの文にも三単現の <span class="en">s</span> がつきます</b>。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. I think you did a great job.','○'), ('2. I think did you a great job.','✕'),
     ('3. I know he is kind.','○'), ('4. I know is he kind.','✕'),
     ('5. He thinks she is busy.','○'), ('6. He think she is busy.','✕'),
     ('7. I don&#39;t think he is busy.','○'), ('8. I am think he is busy.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">you did</span>（主語が先）　4 → <span class="en">he is</span><br>'
         '6 → <span class="en">thinks</span>（主語が <span class="en">He</span>）　8 → <span class="en">am</span> をとる（心臓が2つ）'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'うしろの文は<b>ふつうの順</b>。主語に合わせて動詞を決めよう。',
   'body':grid2([
     '1. <span class="en">I think （ア you did ／イ did you） a great job.</span>%s' % bl('ア'),
     '2. <span class="en">He （ア think ／イ thinks） she is busy.</span>%s' % bl('イ'),
     '3. <span class="en">I know he （ア is ／イ are） kind.</span>%s' % bl('ア'),
     '4. <span class="en">I think she （ア like ／イ likes） soccer.</span>%s' % bl('イ'),
     '5. <span class="en">（ア I don&#39;t think ／イ I think not） he is busy.</span>%s' % bl('ア'),
     '6. <span class="en">I&#39;m sure （ア you can ／イ can you） do it.</span>%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　1・6 はたずねる文の形にしないこと。2 は前の動詞、4 はうしろの動詞に <span class="en">s</span> がつきます。<br>'
         '5 は<b>打ち消しは前に出す</b>というルールです。<span class="en">I think not ～</span> とは言いません。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　<span class="en">I think</span> のうしろは、そのまま文を書けばよい。',
   'body':ol([
     ('<span class="jp-cue">わたしはあなたがよくやったと思います。</span>　<span class="en">I%syou did a great job.</span>' % bl('think'),
      '<span class="en">that</span> は省いてよい。'),
     ('<span class="jp-cue">わたしは彼が親切だと知っています。</span>　<span class="en">I%she is kind.</span>' % bl('know'),
      '「知っている」は <span class="en">know</span>。'),
     ('<span class="jp-cue">わたしはあなたがそれを気に入るといいと思います。</span>　<span class="en">I%syou like it.</span>' % bl('hope'),
      '「～だといい」は <span class="en">hope</span>。'),
     ('<span class="jp-cue">わたしはきっと彼が来ると思います。</span>　<span class="en">I&#39;m%she will come.</span>' % bl('sure'),
      '「きっと～」は <span class="en">be sure</span>。'),
     ('<span class="jp-cue">彼はわたしが忙しいと思っています。</span>　<span class="en">He%sI am busy.</span>' % bl('thinks'),
      '<span class="en">He</span> なので <span class="en">thinks</span>。'),
     ('<span class="jp-cue">わたしは彼女がサッカーが好きだと思います。</span>　<span class="en">I think she%ssoccer.</span>' % bl('likes'),
      'うしろの文にも <span class="en">s</span> がつく。'),
     ('<span class="jp-cue">わたしは彼が忙しいとは思いません。</span>　<span class="en">I%sthink he is busy.</span>' % bl("don't"),
      '打ち消しは<b>前</b>に出す。'),
     ('<span class="jp-cue">わたしは彼らがうれしいと思います。</span>　<span class="en">I think they%shappy.</span>' % bl('are'),
      '<span class="en">They</span> なので <span class="en">are</span>。'),
     ('<span class="jp-cue">わたしはあなたがそれをできると知っています。</span>　<span class="en">I know you%sdo it.</span>' % bl('can'),
      '<span class="en">can</span> もそのまま入る。'),
     ('<span class="jp-cue">わたしはきのう雨がふったと思います。</span>　<span class="en">I think it%syesterday.</span>' % bl('rained', False),
      'うしろの文を<b>過去形</b>に。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　まず「わたしは思う」の部分を書き、そのうしろに文をまるごと足そう。',
   'body':ol([
     ('<span class="jp-cue">わたしはあなたがよくやったと思います。</span>　<span class="paren en">（ a great job / I think / you did ）</span>' + line('I think you did a great job.'),
      '<span class="en">I think</span> → ふつうの文 の順。'),
     ('<span class="jp-cue">わたしは彼が親切だと知っています。</span>　<span class="paren en">（ he is kind / I / know ）</span>' + line('I know he is kind.'),
      'うしろは <span class="en">he is kind</span> のまま。'),
     ('<span class="jp-cue">わたしはきっと彼が来ると思います。</span>　<span class="paren en">（ he will come / I&#39;m / sure ）</span>' + line('I&#39;m sure he will come.'),
      '<span class="en">I&#39;m sure</span> でひとかたまり。'),
     ('<span class="jp-cue">彼はわたしが忙しいと思っています。</span>　<span class="paren en">（ I am busy / He / thinks ）</span>' + line('He thinks I am busy.'),
      '前の動詞に <span class="en">s</span>。'),
     ('<span class="jp-cue">わたしは彼が忙しいとは思いません。</span>　<span class="paren en">（ he is busy / think / I don&#39;t ）</span>' + line('I don&#39;t think he is busy.'),
      '打ち消しは前。'),
     ('<span class="jp-cue">わたしはあなたがそれを気に入るといいと思います。</span>　<span class="paren en">（ you like it / hope / I ）</span>' + line('I hope you like it.'),
      '<span class="en">hope</span> のうしろも文。'),
     ('<span class="jp-cue">わたしは彼女がサッカーが好きだと思います。</span>　<span class="paren en">（ soccer / I think / she likes ）</span>' + line('I think she likes soccer.'),
      'うしろの <span class="en">likes</span> の <span class="en">s</span> に注意。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしはあなたがよくやったと思います。' + wline('I think you did a great job.'),
      '<span class="en">that</span> を入れても正解。'),
     ('わたしは彼が親切だと知っています。' + wline('I know he is kind.'),
      'うしろをたずねる文にしない。'),
     ('わたしはきっと彼が来ると思います。' + wline('I&#39;m sure he will come.'),
      '<span class="en">I am sure</span> でも正解。'),
     ('彼はわたしが忙しいと思っています。' + wline('He thinks I am busy.'),
      '<span class="en">thinks</span> の <span class="en">s</span>。'),
     ('わたしは彼が忙しいとは思いません。' + wline('I don&#39;t think he is busy.'),
      '打ち消しを前に出す。'),
     ('わたしは彼女がサッカーが好きだと思います。' + wline('I think she likes soccer.'),
      'うしろの <span class="en">likes</span> も忘れずに。'),
   ]),
   'words':'<span class="en">I think ／ I know ／ I&#39;m sure ／ He thinks ／ I don&#39;t think ／ she likes</span>'},
  'l4':{'sub':'友だちや家族について、自分が思うことを書こう',
   'cond':['<span class="en">I think ～.</span> を使った文を <b>2つ以上</b>',
           '<span class="en">I know ～.</span> か <span class="en">I hope ～.</span> を <b>1つ</b>',
           '<span class="en">I don&#39;t think ～.</span> の文も <b>1つ</b> 入れる'],
   'example':['I think my friend is very kind.','I hope he comes to the party.','I don&#39;t think math is easy.'],
   'note':'これは例です。同じでなくてかまいません。<span class="en">that</span> は入れても省いてもかまいません。',
   'check':['うしろは 主語 → 動詞 の順','動詞が2つある','うしろの文の s や過去形','打ち消しは前に出した'],
   'review':'じぶんの文の動詞2つに○をつけよう。うしろの文がたずねる形になっていないか確かめよう。'},
 },
}
