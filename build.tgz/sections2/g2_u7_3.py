# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'g2-u7-3', 'grade':2, 'unit':'7 − 3', 'unit_plain':'7-3',
 'title':'as ～ as', 'pages':'p.96〜97',
 'hero_big':'Ken is as tall as Tom.',
 'hero_jp':'ケンは トムと 同じくらい 背が 高いです',
 'motto':'<span class="en">as ～ as</span> ＝「同じくらい～」。あいだは <b>原形（もとの形）</b>。打ち消すと「～ほど…ない」。',
 'kana':{'as':'アズ','tired':'タイアド','hard':'ハード','trying':'トライング',
         'tall':'トール','old':'オウルド','busy':'ビズィ','fast':'ファスト',
         'big':'ビッグ','not':'ノット','kota':'トム','me':'ミー','him':'ヒム',
         'her':'ハー','run':'ラン','study':'スタディ','well':'ウェル'},
 'blocks':[
  ('きほんの文', [
    ('t','7-1・7-2 は「どちらかが上」でしたが、今回は<b>同じくらい</b>だと言う形です。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Ken is as tall as Tom.</span><span class="t">ケンは トムと 同じくらい 背が 高いです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Ken is not as tall as Tom.</span><span class="t">ケンは トムほど 背が 高く ありません。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Ken runs as fast as Tom.</span><span class="t">ケンは トムと 同じくらい 速く 走ります。</span></div>
    </div>'''),
    ('t','<span class="en">as</span> ではさむ形です。<b><span class="en">as</span> ＋ ようすのことば ＋ <span class="en">as</span></b> と覚えましょう。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜あいだは<b>原形（もとの形）</b>', [
    ('t','ここが今回のヤマです。<span class="en">as</span> と <span class="en">as</span> のあいだは、<b>かざりのつかない原形（もとの形）</b>です。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ 原形（もとの形）<small>as tall as</small></span></div>
        <div class="in"><div class="ex">He is as tall as me.<br>We&#39;re as tired as Tom.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ くらべる形<small>as taller as</small></span></div>
        <div class="in"><div class="ex">He is as taller as me.<br>He is as more tall as me.</div></div>
      </div>
    </div>'''),
    ('t','「同じくらい」なので、<b>どちらかが上になるしるし（<span class="en">-er・more</span>）はつけません</b>。'),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：<span class="en">as</span> ではさんだら、中はそのまま</div>
        <p><b class="cb">同じくらい → 原形（もとの形）</b>　<b class="cp">どちらかが上 → <span class="en">-er</span> か <span class="en">more</span></b><br>
        <span class="xm">✕ as taller as ✕</span></p>
      </div>
    </div>'''),
  ]),
  ('テストによく出ることば', [
    ('t','よく使う3つの形です。<b>打ち消すと意味が変わる</b>ところが大事です。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">as ～ as</span></td><td class="k">…と同じくらい～</td><td class="e">He is <u>as tall as</u> me.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">not as ～ as</span></td><td class="k">…ほど～ない</td><td class="e">He is <u>not as tall as</u> me.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">as hard as</span></td><td class="k">同じくらい熱心に</td><td class="e">We try <u>as hard as</u> Tom.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">as ～ as me</span></td><td class="k">わたしと同じくらい</td><td class="e">He is as tall <u>as me</u>.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">as tall as</span> ・ <span class="en">not as tall as</span> ・ <span class="en">as hard as</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('打ち消すと「～ほど…ない」', [
    ('t','<span class="en">not as ～ as</span> は、<b>「同じくらいではない」＝「～ほど…ない」</b>という意味になります。'),
    ('h','''<table class="kind">
      <thead><tr><th>形</th><th>意味</th><th>どちらが上か</th></tr></thead>
      <tbody>
        <tr><td class="e">He is <u>as tall as</u> me.</td><td class="k">わたしと同じくらい高い</td><td class="k">同じ</td></tr>
        <tr><td class="e">He is <u>not as tall as</u> me.</td><td class="k">わたしほど高くない</td><td class="k" style="color:var(--ng);font-weight:700;">わたしのほうが高い</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">He is not as tall as me.</span> は <span class="en">I am taller than him.</span> とほぼ同じ意味になります。'),
  ]),
  ('動作のようすにも使える', [
    ('t','「どのくらい～するか」をくらべるときにも使えます。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">I run as fast as him.</span>（彼と同じくらい速く走る）<br>
      <span class="eq" style="color:var(--gv);">We&#39;re trying as hard as Tom.</span>（トムと同じくらいがんばっている）
    </div>'''),
    ('t','<span class="en">as</span> のうしろの「わたし」は <span class="en">me</span>、「彼」は <span class="en">him</span> の形です。'),
  ]),
 ],
 'quiz':[
  ('He is as taller as me.','He is as tall as me.','<span class="en">as</span> のあいだは<b>原形（もとの形）</b>。<span class="en">-er</span> はつけません。','彼は わたしと 同じくらい 背が 高いです。'),
  ('He is as tall me.','He is as tall as me.','<b>うしろの <span class="en">as</span> が抜けています</b>。2つで1セットです。','彼は わたしと 同じくらい 背が 高いです。'),
  ('He is tall as me.','He is as tall as me.','<b>前の <span class="en">as</span> が抜けています</b>。','彼は わたしと 同じくらい 背が 高いです。'),
  ('He is as more tall as me.','He is as tall as me.','<span class="en">more</span> もつけません。','彼は わたしと 同じくらい 背が 高いです。'),
  ('He is not as tall than me.','He is not as tall as me.','うしろも <b><span class="en">as</span></b> です。<span class="en">than</span> ではありません。','彼は わたしほど 背が 高く ありません。'),
  ('He is as tall as I am tall.','He is as tall as me.','うしろは<b>くらべる相手だけ</b>です。','彼は わたしと 同じくらい 背が 高いです。'),
 ],
 'summary':[
  '<b><span class="en">as ＋ 原形（もとの形） ＋ as</span></b> ＝「…と同じくらい～」。',
  'あいだは <b>原形（もとの形）</b>。<span class="en">-er</span> も <span class="en">more</span> もつけない。',
  '<b><span class="en">not as ～ as</span> ＝「…ほど～ない」</b>。相手のほうが上になる。',
  'うしろの <span class="en">as</span> を忘れない。<span class="en">than</span> にしない。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「…と同じくらい～」は、%s～ <span class="en">as</span> の形で表す。' % bl('as'),
     'あいだのことばは%sの形にする。' % bl('もと'),
     'だから <span class="en">-er</span> も%sもつけない。' % bl('more'),
     '打ち消すと「…%s～ない」という意味になる。' % bl('ほど'),
     'うしろの <span class="en">as</span> を%sに変えてはいけない。' % bl('than'),
   ]),
   'words':'語群：<span class="en">as</span> ／ もと ／ <span class="en">more</span> ／ ほど ／ <span class="en">than</span>',
   'exp':'<b>なぜ？</b>　<span class="en">as ～ as</span> は<b>2つを横にならべて、同じ高さだと言う</b>形です。<br>'
         'どちらかが上ではないので、「より上」を表す <span class="en">-er・more</span> は使えないのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　（　）に入るものを書こう<em>1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>あいだは原形（もとの形）</b>です。',
   'body':grid2([
     '1. <span class="en">He is as%sas me.</span>（背が高い）' % bl('tall'),
     '2. <span class="en">We&#39;re as%sas Tom.</span>（つかれている）' % bl('tired'),
     '3. <span class="en">He is%stall as me.</span>' % bl('as'),
     '4. <span class="en">He is as tall%sme.</span>' % bl('as'),
     '5. <span class="en">I run as%sas him.</span>（速く）' % bl('fast'),
     '6. <span class="en">She is as%sas me.</span>（忙しい）' % bl('busy'),
     '7. <span class="en">He is%sas tall as me.</span>（～ほど…ない）' % bl('not'),
     '8. <span class="en">This is as%sas that.</span>（大きい）' % bl('big'),
     '9. <span class="en">We try as%sas Tom.</span>（熱心に）' % bl('hard'),
     '10. <span class="en">He is as tall as%s.</span>（彼女）' % bl('her'),
   ]),
   'exp':'<b>かくにん</b>　あいだはすべて<b>原形（もとの形）</b>（1・2・5・6・8・9）。<span class="en">taller・more tired</span> にしません。<br>'
         '<span class="en">as</span> は2つとも必要（3・4）。うしろは <span class="en">me・him・her</span> の形（10）。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. He is as tall as me.','○'), ('2. He is as taller as me.','✕'),
     ('3. He is not as tall as me.','○'), ('4. He is not as tall than me.','✕'),
     ('5. I run as fast as him.','○'), ('6. I run as fast him.','✕'),
     ('7. We&#39;re as tired as Tom.','○'), ('8. We&#39;re as more tired as Tom.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">as tall as</span>　4 → うしろも <span class="en">as</span><br>'
         '6 → <span class="en">as fast as him</span>　8 → <span class="en">as tired as</span>（<span class="en">more</span> をとる）'},
  {'h':'<h3 class="sec sec2">D　意味はどちら？<em>正しいほうを選ぼう</em></h3>',
   'hint':'<span class="en">not</span> があるかどうかで、意味が変わります。',
   'body':grid2([
     '1. <span class="en">He is as tall as me.</span>（ア 同じくらい ／イ わたしのほうが高い）%s' % bl('ア'),
     '2. <span class="en">He is not as tall as me.</span>（ア 同じくらい ／イ わたしのほうが高い）%s' % bl('イ'),
     '3. <span class="en">He is as （ア tall ／イ taller） as me.</span>%s' % bl('ア'),
     '4. <span class="en">He is as tall （ア than ／イ as） me.</span>%s' % bl('イ'),
     '5. <span class="en">I run as fast as （ア he ／イ him）.</span>%s' % bl('イ'),
     '6. 彼はわたしほど忙しくない。<span class="en">He is （ア as ／イ not as） busy as me.</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　1・2・6 は<b>意味</b>の問題です。<span class="en">not</span> がつくと「～ほど…ない」になり、<b>相手のほうが上</b>になります。<br>'
         '3・4・5 は形のルールです。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　<span class="en">as</span> ではさむ。中は原形（もとの形）。うしろの <span class="en">as</span> を忘れない。',
   'body':ol([
     ('<span class="jp-cue">わたしたちはトムと同じくらいつかれています。</span>　<span class="en">We&#39;re as tired%sTom.</span>' % bl('as'),
      'うしろの <span class="en">as</span>。'),
     ('<span class="jp-cue">わたしたちはトムほどつかれていません。</span>　<span class="en">We&#39;re%sas tired as Tom.</span>' % bl('not'),
      '打ち消しは <span class="en">not</span>。'),
     ('<span class="jp-cue">彼はわたしと同じくらい背が高いです。</span>　<span class="en">He is as%sas me.</span>' % bl('tall'),
      '<span class="en">taller</span> にしない。'),
     ('<span class="jp-cue">わたしは彼と同じくらい速く走ります。</span>　<span class="en">I run%sfast as him.</span>' % bl('as'),
      '前の <span class="en">as</span>。'),
     ('<span class="jp-cue">わたしたちはトムと同じくらいがんばっています。</span>　<span class="en">We&#39;re trying as%sas Tom.</span>' % bl('hard'),
      '「熱心に」は <span class="en">hard</span>。'),
     ('<span class="jp-cue">彼女はわたしと同じくらい忙しいです。</span>　<span class="en">She is as busy as%s.</span>' % bl('me'),
      '<span class="en">I</span> にしない。'),
     ('<span class="jp-cue">これはあれと同じくらい大きいです。</span>　<span class="en">This is%sbig%sthat.</span>' % (bl('as'), bl('as')),
      '（　）が2つ。<span class="en">as ～ as</span>。'),
     ('<span class="jp-cue">彼はわたしほど忙しくありません。</span>　<span class="en">He is not as%sas me.</span>' % bl('busy'),
      '中は原形（もとの形）。'),
     ('<span class="jp-cue">この本はあの本と同じくらいおもしろいです。</span>　<span class="en">This book is as%sas that one.</span>' % bl('interesting', False),
      '長いことばでも、中は原形（もとの形）。'),
     ('<span class="jp-cue">わたしは彼と同じくらいじょうずに歌えます。</span>　<span class="en">I can sing as%sas him.</span>' % bl('well'),
      '「じょうずに」は <span class="en">well</span>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　主語 → 動詞 → <span class="en">as ～ as</span> → 相手、の順。',
   'body':ol([
     ('<span class="jp-cue">わたしたちはトムと同じくらいつかれています。</span>　<span class="paren en">（ as Tom / We&#39;re / as tired ）</span>' + line('We&#39;re as tired as Tom.'),
      '<span class="en">as tired as</span> でひとかたまり。'),
     ('<span class="jp-cue">わたしたちはトムほどつかれていません。</span>　<span class="paren en">（ as Tom / not as tired / We&#39;re ）</span>' + line('We&#39;re not as tired as Tom.'),
      '<span class="en">not</span> は最初の <span class="en">as</span> の前。'),
     ('<span class="jp-cue">彼はわたしと同じくらい背が高いです。</span>　<span class="paren en">（ as me / He is / as tall ）</span>' + line('He is as tall as me.'),
      '<span class="en">me</span> の形。'),
     ('<span class="jp-cue">わたしは彼と同じくらい速く走ります。</span>　<span class="paren en">（ as him / I run / as fast ）</span>' + line('I run as fast as him.'),
      '動作のようすにも使える。'),
     ('<span class="jp-cue">わたしたちはトムと同じくらいがんばっています。</span>　<span class="paren en">（ as hard / We&#39;re trying / as Tom ）</span>' + line('We&#39;re trying as hard as Tom.'),
      '進行形にも足せる。'),
     ('<span class="jp-cue">彼はわたしほど忙しくありません。</span>　<span class="paren en">（ as me / He is / not as busy ）</span>' + line('He is not as busy as me.'),
      '相手のほうが忙しい。'),
     ('<span class="jp-cue">この本はあの本と同じくらいおもしろいです。</span>　<span class="paren en">（ as that one / This book is / as interesting ）</span>' + line('This book is as interesting as that one.'),
      '長い語でも中はそのまま。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしたちはトムと同じくらいつかれています。' + wline('We&#39;re as tired as Tom.'),
      '<span class="en">We are</span> でも正解。'),
     ('わたしたちはトムほどつかれていません。' + wline('We&#39;re not as tired as Tom.'),
      '<span class="en">not</span> の位置に注意。'),
     ('彼はわたしと同じくらい背が高いです。' + wline('He is as tall as me.'),
      '<span class="en">as taller as</span> にしない。'),
     ('わたしは彼と同じくらい速く走ります。' + wline('I run as fast as him.'),
      '<span class="en">he</span> にしない。'),
     ('彼はわたしほど忙しくありません。' + wline('He is not as busy as me.'),
      '<span class="en">than</span> にしない。'),
     ('この本はあの本と同じくらいおもしろいです。' + wline('This book is as interesting as that one.'),
      '中は原形（もとの形）。'),
   ]),
   'words':'<span class="en">as tired as ／ not as tired as ／ as tall as me ／ as fast as him ／ not as busy as ／ as interesting as</span>'},
  'l4':{'sub':'自分と友だち・家族をくらべて書こう',
   'cond':['<span class="en">as ～ as</span> を使った文を <b>2つ以上</b>',
           '<span class="en">not as ～ as</span> を使った文を <b>1つ以上</b>',
           '動作のようすをくらべる文（<span class="en">as fast as</span> など）も <b>1つ</b>'],
   'example':['My brother is as tall as my father.','I&#39;m not as good at math as my friend.','I can run as fast as him.'],
   'note':'これは例です。同じでなくてかまいません。背の高さ・得意なこと・走る速さなどが書きやすいです。',
   'check':['as が2つある','あいだは原形（もとの形）','-er や more をつけていない','うしろは me・him・her の形'],
   'review':'じぶんの文の2つの <span class="en">as</span> に○をつけよう。あいだに <span class="en">-er</span> があったら、そこがまちがい。'},
 },
}
