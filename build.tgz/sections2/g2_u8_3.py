# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox

S = {
 'id':'g2-u8-3', 'grade':2, 'unit':'8 − 3', 'unit_plain':'8-3',
 'title':'受け身（～される）', 'pages':'p.106〜107',
 'hero_big':'This pen is used by Ken.',
 'hero_jp':'このペンは ケンに 使われています',
 'motto':'<b><span class="en">be動詞 ＋ 過去分詞</span></b> ＝「～される・された」。「だれに」は <span class="en">by ～</span>。',
 'kana':{'received':'リスィーブド','receive':'リスィーブ','made':'メイド','used':'ユーズド',
         'use':'ユーズ','loved':'ラブド','written':'リトゥン','write':'ライト','spoken':'スポウクン',
         'speak':'スピーク','built':'ビルト','build':'ビルド','by':'バイ','everyone':'エブリワン',
         'chocolate':'チョコレット','English':'イングリッシュ','many':'メニー','people':'ピープル'},
 'blocks':[
  ('きほんの文', [
    ('t','「このペンは ケンに <b>使われている</b>」のように、<b>される側</b>を主語にして言う形です。これを<b>受け身</b>といいます。'),
    ('t','作りは <b><span class="en">be</span>動詞 ＋ 過去分詞</b> の<b>2語セット</b>。そこに「だれに」を足すこともできます。'),
    ('h', gitem('❶', '「～される・～された」と言う', 'be動詞 ＋ 過去分詞',
                '使われて いる', 'is used',
                [('This pen is used by Ken.','このペンは ケンに 使われて います。'),
                 ('This cake is made in Japan.','このケーキは 日本で 作られて います。')],
                '<b><span class="en">be</span>動詞を忘れない</b>こと。これがないと受け身になりません。「いま」なら <span class="en">is・are</span>、「むかし」なら <span class="en">was・were</span>。')),
    ('h', gitem('❷', '「だれに されたか」を足す', 'by ～',
                'ケンに（使われた）', 'by Ken',
                [('This pen was used by Ken.','このペンは ケンに 使われました。'),
                 ('It is loved by many people.','それは 多くの人に 愛されて います。')],
                '<b><span class="en">by</span> ＋ する人</b> をうしろに足します。言わなくてよいときは<b>はぶけます</b>。', b2=True)),
    ('t','<span class="en">use → used</span>、<span class="en">write → written</span> のように、<b>過去分詞</b>の形はおぼえておきましょう。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜<span class="en">be</span>動詞を<b>ぜったい忘れない</b>', [
    ('t','ここが今回のヤマです。受け身は <b>2語セット</b>。<span class="en">be</span>動詞がないと受け身になりません。'),
    ('h','''<div class="eqbox">
      <span class="eq" style="color:var(--be);">be動詞</span> ＋ <span class="eq" style="color:var(--gv);">過去分詞</span> ＝ 「～される」<br>
      It <span class="eq" style="color:var(--be);">was</span> <span class="eq" style="color:var(--gv);">received</span>. ／ It <span class="eq" style="color:var(--be);">is</span> <span class="eq" style="color:var(--gv);">made</span>.
    </div>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ be動詞あり<small>2語セット</small></span></div>
        <div class="in"><div class="ex">It is used by many people.<br>It was built in 1950.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ be動詞がない<small>過去分詞だけ</small></span></div>
        <div class="in"><div class="ex">It used by many people.<br>It built in 1950.</div></div>
      </div>
    </div>'''),
    ('t','<span class="en">be</span>動詞は、主語と「いつ」で <span class="en">am・is・are・was・were</span> を使い分けます。'),
  ]),
  ('テストによく出ることば', [
    ('t','よく出る過去分詞です。<b>形を見ておぼえる</b>のがいちばん早いです。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>原形（もとの形）</th><th>過去分詞</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">use</span>（使う）</td><td class="k"><span class="en">used</span></td><td class="e">It is <u>used</u> by many people.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">make</span>（作る）</td><td class="k"><span class="en">made</span></td><td class="e">It is <u>made</u> of chocolate.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">write</span>（書く）</td><td class="k"><span class="en">written</span></td><td class="e">It was <u>written</u> in English.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">speak</span>（話す）</td><td class="k"><span class="en">spoken</span></td><td class="e">English is <u>spoken</u> here.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">used</span> ・ <span class="en">made</span> ・ <span class="en">written</span> ・ <span class="en">spoken</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('ふつうの文と受け身の文', [
    ('t','同じことを、<b>する側</b>から言うか、<b>される側</b>から言うかのちがいです。'),
    ('h','''<table class="kind">
      <thead><tr><th>言い方</th><th>主語</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k" style="color:var(--key);font-weight:700;">ふつう</td><td class="k">する側</td><td class="e">Many people use it.</td></tr>
        <tr><td class="k" style="color:var(--gv);font-weight:700;">受け身</td><td class="k">される側</td><td class="e">It is used by many people.</td></tr>
      </tbody>
    </table>'''),
    ('t','「だれに／だれによって」は <b><span class="en">by ～</span></b> で足します。言わなくてもよいときは<b>はぶけます</b>。'),
  ]),
  ('<span class="en">be</span>動詞の使い分け', [
    ('t','「いま」なら <span class="en">am・is・are</span>、「むかし」なら <span class="en">was・were</span> です。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--be);background:rgba(31,78,156,.06);">
      いま：It <span class="eq" style="color:var(--be);">is</span> made of chocolate.（作られています）<br>
      むかし：It <span class="eq" style="color:var(--be);">was</span> made in Japan.（作られました）
    </div>'''),
    ('t','過去分詞は<b>変わりません</b>。<span class="en">be</span>動詞だけを変えれば「いま／むかし」が切りかえられます。'),
  ]),
 ],
 'quiz':[
  ('It used by many people.','It is used by many people.','<b><span class="en">be</span>動詞が抜けています</b>。受け身は2語セット。','それは 多くの人に 使われて います。'),
  ('It is use by many people.','It is used by many people.','<span class="en">be</span>動詞のうしろは<b>過去分詞</b>。','それは 多くの人に 使われて います。'),
  ('This pen were used by Ken.','This pen was used by Ken.','主語が <span class="en">This pen</span>（1つ）なので <b><span class="en">was</span></b>。','このペンは ケンに 使われました。'),
  ('It is made by chocolate.','It is made of chocolate.','材料は <b><span class="en">of</span></b>。<span class="en">by</span> は「だれによって」。','それは チョコレートで 作られて います。'),
  ('It was wrote in English.','It was written in English.','<span class="en">write</span> の過去分詞は <b><span class="en">written</span></b>。','それは 英語で 書かれました。'),
  ('English is speak here.','English is spoken here.','<span class="en">speak</span> の過去分詞は <b><span class="en">spoken</span></b>。','ここでは 英語が 話されます。'),
 ],
 'summary':[
  '受け身は <b><span class="en">be</span>動詞 ＋ 過去分詞</b>＝「～される・された」。',
  '<span class="en">be</span>動詞を<b>ぜったい忘れない</b>。これがないと受け身にならない。',
  '「だれに」は <b><span class="en">by ～</span></b>。言わなくてよいときははぶける。',
  '「いま」は <span class="en">is・are</span>、「むかし」は <span class="en">was・were</span>。過去分詞は変わらない。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～される」は、%s動詞 ＋ 過去分詞 で表す。' % bl('be'),
     '<span class="en">be</span>動詞のうしろにくるのは、動詞の%sである。' % bl('過去分詞', False),
     '「だれによって」を言いたいときは%s～ を足す。' % bl('by'),
     '「いま」のことなら <span class="en">is</span>、「むかし」なら%sを使う。' % bl('was'),
     '<span class="en">be</span>動詞を変えても、過去分詞は%s。' % bl('変わらない', False),
   ]),
   'words':'語群：<span class="en">be</span> ／ 過去分詞 ／ <span class="en">by</span> ／ <span class="en">was</span> ／ 変わらない',
   'exp':'<b>なぜ？</b>　<span class="en">It received</span> だと「それが受け取った」になってしまいます。<br>'
         '<span class="en">be</span>動詞を前に置くことで「<b>それが受け取られた</b>」と、立場をひっくり返しているのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　過去分詞を書こう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<span class="en">be</span>動詞も<b>いっしょに</b>見ましょう。',
   'body':grid2([
     '1. <span class="en">It is%sby many people.</span>（use）' % bl('used'),
     '2. <span class="en">It is%sof chocolate.</span>（make）' % bl('made'),
     '3. <span class="en">It was%sin English.</span>（write）' % bl('written'),
     '4. <span class="en">English is%shere.</span>（speak）' % bl('spoken'),
     '5. <span class="en">It%sreceived by everyone.</span>（過去）' % bl('was'),
     '6. <span class="en">It%smade in Japan.</span>（いま）' % bl('is'),
     '7. <span class="en">They%sloved by everyone.</span>（いま）' % bl('are'),
     '8. <span class="en">It is used%smany people.</span>' % bl('by'),
     '9. <span class="en">It was%sin 1950.</span>（build）' % bl('built'),
     '10. <span class="en">It is%sby everyone.</span>（love）' % bl('loved'),
   ]),
   'exp':'<b>かくにん</b>　6・7 は「いま」なので <span class="en">is・are</span>。主語が <span class="en">They</span> なら <span class="en">are</span>。<br>'
         '3・4・9 は形が大きく変わる過去分詞です。<span class="en">written・spoken・built</span>。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. It is used by many people.','○'), ('2. It used by many people.','✕'),
     ('3. It was written in English.','○'), ('4. It was wrote in English.','✕'),
     ('5. English is spoken here.','○'), ('6. English is speak here.','✕'),
     ('7. It is made of chocolate.','○'), ('8. It is make of chocolate.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">is used</span>　4 → <span class="en">written</span><br>'
         '6 → <span class="en">spoken</span>　8 → <span class="en">made</span>'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'<span class="en">be</span>動詞があるか、過去分詞になっているかを見ます。',
   'body':grid2([
     '1. <span class="en">It （ア is used ／イ used） by many people.</span>%s' % bl('ア'),
     '2. <span class="en">It was （ア wrote ／イ written） in English.</span>%s' % bl('イ'),
     '3. <span class="en">English is （ア speak ／イ spoken） here.</span>%s' % bl('イ'),
     '4. <span class="en">It （ア is ／イ was） made in Japan.</span>（むかし）%s' % bl('イ'),
     '5. <span class="en">They （ア are ／イ is） loved by everyone.</span>%s' % bl('ア'),
     '6. <span class="en">It is used （ア by ／イ of） many people.</span>%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　4 は「むかし」なので <span class="en">was</span>。5 は主語が <span class="en">They</span> なので <span class="en">are</span>。<br>'
         '6 は「人によって」なので <span class="en">by</span>。材料のときだけ <span class="en">of</span> を使います。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　まず <span class="en">be</span>動詞を置き、そのうしろに過去分詞。',
   'body':ol([
     ('<span class="jp-cue">それは多くの人に使われています。</span>　<span class="en">It is%sby many people.</span>' % bl('used'),
      '過去分詞にする。'),
     ('<span class="jp-cue">それはチョコレートで作られています。</span>　<span class="en">It is%sof chocolate.</span>' % bl('made'),
      '<span class="en">make</span> の過去分詞。'),
     ('<span class="jp-cue">それは英語で書かれました。</span>　<span class="en">It was%sin English.</span>' % bl('written'),
      '形が変わる。'),
     ('<span class="jp-cue">ここでは英語が話されます。</span>　<span class="en">English is%shere.</span>' % bl('spoken'),
      '<span class="en">speak</span> の過去分詞。'),
     ('<span class="jp-cue">それはみんなに受け入れられました。</span>　<span class="en">It%sreceived by everyone.</span>' % bl('was'),
      '過去の <span class="en">be</span>動詞。'),
     ('<span class="jp-cue">それは日本で作られています。</span>　<span class="en">It%smade in Japan.</span>' % bl('is'),
      'いまの <span class="en">be</span>動詞。'),
     ('<span class="jp-cue">それらはみんなに愛されています。</span>　<span class="en">They%sloved by everyone.</span>' % bl('are'),
      '主語は <span class="en">They</span>。'),
     ('<span class="jp-cue">それは多くの人に使われています。</span>　<span class="en">It%s%sby many people.</span>' % (bl('is'), bl('used')),
      '（　）が2つ。'),
     ('<span class="jp-cue">それは1950年に建てられました。</span>　<span class="en">It was%sin 1950.</span>' % bl('built'),
      '<span class="en">build</span> の過去分詞。'),
     ('<span class="jp-cue">それはみんなに愛されています。</span>　<span class="en">It is loved%severyone.</span>' % bl('by'),
      '「だれに」を表す語。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　主語 → <span class="en">be</span>動詞 → 過去分詞 → <span class="en">by ～</span> の順。',
   'body':ol([
     ('<span class="jp-cue">それは多くの人に使われています。</span>　<span class="paren en">（ used / by many people / It is ）</span>' + line('It is used by many people.'),
      '<span class="en">be</span>動詞のうしろに過去分詞。'),
     ('<span class="jp-cue">それはチョコレートで作られています。</span>　<span class="paren en">（ of chocolate / It is / made ）</span>' + line('It is made of chocolate.'),
      '材料は <span class="en">of</span>。'),
     ('<span class="jp-cue">それは英語で書かれました。</span>　<span class="paren en">（ in English / written / It was ）</span>' + line('It was written in English.'),
      '過去は <span class="en">was</span>。'),
     ('<span class="jp-cue">ここでは英語が話されます。</span>　<span class="paren en">（ here / English is / spoken ）</span>' + line('English is spoken here.'),
      '主語は <span class="en">English</span>。'),
     ('<span class="jp-cue">それはみんなに受け入れられました。</span>　<span class="paren en">（ by everyone / It was / received ）</span>' + line('It was received by everyone.'),
      '<span class="en">by</span> はうしろ。'),
     ('<span class="jp-cue">それらはみんなに愛されています。</span>　<span class="paren en">（ loved / by everyone / They are ）</span>' + line('They are loved by everyone.'),
      '<span class="en">are</span> を使う。'),
     ('<span class="jp-cue">それは1950年に建てられました。</span>　<span class="paren en">（ in 1950 / It was / built ）</span>' + line('It was built in 1950.'),
      '<span class="en">built</span> の形。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('それは多くの人に使われています。' + wline('It is used by many people.'),
      '<span class="en">be</span>動詞を忘れない。'),
     ('それはチョコレートで作られています。' + wline('It is made of chocolate.'),
      '材料は <span class="en">of</span>。'),
     ('それは英語で書かれました。' + wline('It was written in English.'),
      '<span class="en">wrote</span> にしない。'),
     ('ここでは英語が話されます。' + wline('English is spoken here.'),
      '<span class="en">spoken</span> の形。'),
     ('それはみんなに受け入れられました。' + wline('It was received by everyone.'),
      '過去は <span class="en">was</span>。'),
     ('それらはみんなに愛されています。' + wline('They are loved by everyone.'),
      '主語は <span class="en">They</span>。'),
   ]),
   'words':'<span class="en">is used ／ is made of ／ was written ／ is spoken ／ was received ／ are loved ／ by everyone ／ by many people</span>'},
  'l4':{'sub':'身のまわりのものを受け身で書こう',
   'cond':['受け身（<span class="en">be</span>動詞 ＋ 過去分詞）の文を <b>2つ以上</b>',
           '<span class="en">by ～</span> を使った文を <b>1つ</b>',
           '過去分詞を <b>2種類以上</b>（<span class="en">used・made・loved・spoken</span> など）'],
   'example':['This song is loved by many people.','My bag is made in Japan.','English is spoken in many countries.'],
   'note':'これは例です。同じでなくてかまいません。身につけているもの・すきな曲で書きやすいです。',
   'check':['be動詞を入れた','過去分詞にした','by ～ を使った','いま／むかしでbe動詞を選んだ'],
   'review':'じぶんの文の <span class="en">be</span>動詞に○、過去分詞に△をつけよう。2つそろっていれば受け身。'},
 },
}
