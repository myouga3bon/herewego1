# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'g2-u7-2', 'grade':2, 'unit':'7 − 2', 'unit_plain':'7-2',
 'title':'more / most を使う比較', 'pages':'p.94〜95',
 'hero_big':'Soccer is more popular than tennis.',
 'hero_jp':'サッカーは テニスより 人気が あります',
 'motto':'<b>長いことば</b>は <span class="en">more / most</span> を前に置く。<span class="en">-er</span> と <span class="en">more</span> は <b>両方つけない</b>。',
 'kana':{'more':'モア','most':'モウスト','exciting':'イクサイティング','normal':'ノーマル',
         'space':'スペイス','teamwork':'ティームワーク','important':'インポータント',
         'thing':'スィング','beautiful':'ビューティフル','difficult':'ディフィカルト',
         'interesting':'インタレスティング','popular':'ポピュラー','useful':'ユースフル',
         'better':'ベター','best':'ベスト','good':'グッド','than':'ザン'},
 'blocks':[
  ('きほんの文', [
    ('t','7-1 では <span class="en">-er / -est</span> をつけました。今回は<b>長いことば</b>の場合です。前に <span class="en">more / most</span> を置きます。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Soccer is more popular than tennis.</span><span class="t">サッカーは テニスより 人気が あります。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Soccer is the most popular sport in my class.</span><span class="t">サッカーは クラスで いちばん 人気の スポーツです。</span></div>
    </div>'''),
    ('t','<span class="en">popularer</span> とは言えないので、<b>前に <span class="en">more</span> を置く</b>のです。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜<span class="en">-er</span> と <span class="en">more</span> は どちらか1つ', [
    ('t','ここが今回のヤマです。<b>両方つけてはいけません</b>。くらべる形は<b>1回だけ</b>です。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ どちらか1つ<small>bigger / more exciting</small></span></div>
        <div class="in"><div class="ex">This is bigger than that.<br>This is more exciting than that.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ 両方つける<small>more bigger</small></span></div>
        <div class="in"><div class="ex">This is more bigger than that.<br>This is the most biggest.</div></div>
      </div>
    </div>'''),
    ('t','1年生の「心臓（動詞）は1つだけ」と同じ考え方です。<b>くらべるしるしも1つだけ</b>と覚えましょう。'),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：<span class="en">-er</span> か <span class="en">more</span>、どちらか1つだけ</div>
        <p><b class="cb">短いことば → <span class="en">-er / -est</span></b>　<b class="cp">長いことば → <span class="en">more / most</span></b><br>
        <span class="xm">✕ more bigger than ✕</span></p>
      </div>
    </div>'''),
  ]),
  ('テストによく出ることば', [
    ('t','<span class="en">more / most</span> を使うのは、<b>3音節以上の長いことば</b>です。よく出るものをおぼえましょう。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">more exciting</span></td><td class="k">よりわくわくする</td><td class="e">It&#39;s <u>more exciting</u> than that.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">more important</span></td><td class="k">より大切な</td><td class="e">It&#39;s <u>more important</u> than that.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">the most important</span></td><td class="k">いちばん大切な</td><td class="e">It&#39;s <u>the most important</u> thing.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">better / best</span></td><td class="k">good が変身する形</td><td class="e">This is <u>better</u> than that.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">more exciting</span> ・ <span class="en">the most important</span> ・ <span class="en">better</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('どちらを使うか', [
    ('t','だいたいの目安は<b>ことばの長さ</b>です。耳で聞いた長さで判断できます。'),
    ('h','''<table class="kind">
      <thead><tr><th>ことばの長さ</th><th>使う形</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k">短い（1〜2音節）</td><td class="k" style="color:var(--key);font-weight:700;">-er / -est</td><td class="e">big・tall・easy・long</td></tr>
        <tr><td class="k">長い（3音節以上）</td><td class="k" style="color:var(--gv);font-weight:700;">more / most</td><td class="e">exciting・important・beautiful</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">ex-ci-ting</span>（3つ）、<span class="en">im-por-tant</span>（3つ）のように、<b>手をたたいて数える</b>と分かりやすいです。'),
  ]),
  ('形がまるごと変わることば', [
    ('t','<span class="en">good</span> と <span class="en">well</span> だけは、まったくちがう形になります。<b>おぼえるしかありません</b>。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">good → better → the best</span>（よい → よりよい → いちばんよい）<br>
      <span class="eq" style="color:var(--gv);">well → better → the best</span>（じょうずに → よりじょうずに）
    </div>'''),
    ('t','<span class="en">gooder</span>・<span class="en">more good</span> とは言いません。<b><span class="en">better</span></b> です。'),
  ]),
 ],
 'quiz':[
  ('This is more bigger than that.','This is bigger than that.','<span class="en">-er</span> と <span class="en">more</span> を<b>両方つけません</b>。','これは あれより 大きいです。'),
  ('This is excitinger than that.','This is more exciting than that.','長いことばは <b><span class="en">more</span></b> を前に置きます。','これは あれより わくわくします。'),
  ('Soccer is most popular sport.','Soccer is the most popular sport.','<b><span class="en">the</span> が抜けています</b>。','サッカーは いちばん 人気の スポーツです。'),
  ('This is gooder than that.','This is better than that.','<span class="en">good</span> は <b><span class="en">better</span></b> に変身します。','これは あれより よいです。'),
  ('This is more exciting that.','This is more exciting than that.','<b><span class="en">than</span> が抜けています</b>。','これは あれより わくわくします。'),
  ('This is the most best.','This is the best.','<span class="en">best</span> だけで「いちばんよい」です。','これが いちばん よいです。'),
 ],
 'summary':[
  '<b>長いことば</b>は <b><span class="en">more ＋ 原形（もとの形）</span></b>、いちばんは <b><span class="en">the most ＋ 原形（もとの形）</span></b>。',
  '<b><span class="en">-er</span> と <span class="en">more</span> は 両方つけない。</b>くらべるしるしは1つだけ。',
  '<span class="en">more</span> にも <b><span class="en">than</span></b>、<span class="en">most</span> にも <b><span class="en">the</span></b> が必要。',
  '<span class="en">good</span> は <b><span class="en">better → the best</span></b> と形がまるごと変わる。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '長いことばをくらべるときは、前に%sを置く。' % bl('more'),
     '「いちばん～」と言うときは、前に <span class="en">the</span>%sを置く。' % bl('most'),
     '<span class="en">-er</span> と <span class="en">more</span> は、どちらか%sだけ使う。' % bl('1つ'),
     '<span class="en">more</span> を使うときも、うしろに%sが必要である。' % bl('than'),
     '<span class="en">good</span> をくらべる形にすると%sになる。' % bl('better'),
   ]),
   'words':'語群：<span class="en">more</span> ／ <span class="en">most</span> ／ 1つ ／ <span class="en">than</span> ／ <span class="en">better</span>',
   'exp':'<b>なぜ？</b>　<span class="en">exciting</span> のような長いことばに <span class="en">-er</span> をつけると、<b>発音しにくく</b>なります。<br>'
         'だから前に <span class="en">more</span> を置いて、言いやすくしているのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">-er</span>？ それとも <span class="en">more</span>？<em>（　）に入るものを書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>ことばの長さ</b>で決めましょう。',
   'body':grid2([
     '1. <span class="en">%sexciting</span>（よりわくわくする）' % bl('more'),
     '2. <span class="en">%s</span>（より大きい）' % bl('bigger', False),
     '3. <span class="en">%simportant</span>（より大切な）' % bl('more'),
     '4. <span class="en">%s</span>（より背が高い）' % bl('taller', False),
     '5. <span class="en">%sbeautiful</span>（より美しい）' % bl('more'),
     '6. <span class="en">%s</span>（よりやさしい）' % bl('easier', False),
     '7. <span class="en">%sinteresting</span>（よりおもしろい）' % bl('more'),
     '8. <span class="en">%s</span>（より長い）' % bl('longer', False),
     '9. <span class="en">the %s important</span>（いちばん大切な）' % bl('most'),
     '10. <span class="en">%s</span>（よりよい）' % bl('better', False),
   ]),
   'exp':'<b>見分け方</b>　手をたたいて音の数を数えよう。<br>'
         '<b>3つ以上</b>（<span class="en">ex-ci-ting / im-por-tant / beau-ti-ful / in-ter-est-ing</span>）→ <span class="en">more</span>（1・3・5・7・9）<br>'
         '<b>1〜2つ</b>（<span class="en">big / tall / eas-y / long</span>）→ <span class="en">-er</span>（2・4・6・8）<br>'
         '10 は特別な形です。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. This is more exciting than that.','○'), ('2. This is more bigger than that.','✕'),
     ('3. This is the most important thing.','○'), ('4. This is most important thing.','✕'),
     ('5. This is better than that.','○'), ('6. This is gooder than that.','✕'),
     ('7. This is the best.','○'), ('8. This is excitinger than that.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">bigger</span>（<span class="en">more</span> をとる）　4 → <span class="en">the</span> を入れる<br>'
         '6 → <span class="en">better</span>　8 → <span class="en">more exciting</span>'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'ことばの長さと、<span class="en">than</span> / <span class="en">the</span> がそろっているかを見よう。',
   'body':grid2([
     '1. <span class="en">This is （ア more exciting ／イ excitinger） than that.</span>%s' % bl('ア'),
     '2. <span class="en">This is （ア more bigger ／イ bigger） than that.</span>%s' % bl('イ'),
     '3. <span class="en">It&#39;s （ア the most ／イ most） important thing.</span>%s' % bl('ア'),
     '4. <span class="en">This is （ア gooder ／イ better） than that.</span>%s' % bl('イ'),
     '5. <span class="en">This is more exciting （ア than ／イ of） that.</span>%s' % bl('ア'),
     '6. <span class="en">This is （ア the best ／イ the most best）.</span>%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　2・6 は<b>くらべるしるしを重ねない</b>というルール。<br>'
         '1 は長いことばなので <span class="en">more</span>。3 は <span class="en">the</span>、5 は <span class="en">than</span> が必要です。4 は特別な形です。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　長いことばには <span class="en">more / most</span>、短いことばには <span class="en">-er / -est</span>。',
   'body':ol([
     ('<span class="jp-cue">宇宙の学校はふつうの学校よりわくわくします。</span>　<span class="en">A school in space is%sexciting than a normal one.</span>' % bl('more'),
      '<span class="en">exciting</span> は長い。'),
     ('<span class="jp-cue">チームワークがいちばん大切なことです。</span>　<span class="en">Teamwork is the%simportant thing.</span>' % bl('most'),
      '<span class="en">the most</span> でセット。'),
     ('<span class="jp-cue">これはあれより大きいです。</span>　<span class="en">This is%sthan that.</span>' % bl('bigger', False),
      '短いので <span class="en">-er</span>。'),
     ('<span class="jp-cue">この本はあの本よりおもしろいです。</span>　<span class="en">This book is more%sthan that one.</span>' % bl('interesting', False),
      '<span class="en">more</span> のうしろは原形（もとの形）。'),
     ('<span class="jp-cue">これはあれよりよいです。</span>　<span class="en">This is%sthan that.</span>' % bl('better', False),
      '<span class="en">good</span> の変身した形。'),
     ('<span class="jp-cue">これがいちばんよいです。</span>　<span class="en">This is the%s.</span>' % bl('best'),
      '<span class="en">the best</span> でセット。'),
     ('<span class="jp-cue">この花はあの花より美しいです。</span>　<span class="en">This flower is%sbeautiful than that one.</span>' % bl('more'),
      '<span class="en">beautiful</span> は長い。'),
     ('<span class="jp-cue">数学は英語より大切です。</span>　<span class="en">Math is%s%sthan English.</span>' % (bl('more'), bl('important', False)),
      '（　）が2つ。'),
     ('<span class="jp-cue">これはクラスでいちばん人気のある歌です。</span>　<span class="en">This is the most popular song%smy class.</span>' % bl('in'),
      '場所なので <span class="en">in</span>。'),
     ('<span class="jp-cue">この問題はあの問題よりむずかしいです。</span>　<span class="en">This question is more difficult%sthat one.</span>' % bl('than'),
      '<span class="en">than</span> を忘れない。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　主語 → be動詞 → <span class="en">more ～</span> → <span class="en">than ～</span> の順。',
   'body':ol([
     ('<span class="jp-cue">宇宙の学校はふつうの学校よりわくわくします。</span>　<span class="paren en">（ than a normal one / more exciting / A school in space is ）</span>' + line('A school in space is more exciting than a normal one.'),
      '<span class="en">more exciting</span> でひとかたまり。'),
     ('<span class="jp-cue">チームワークがいちばん大切なことです。</span>　<span class="paren en">（ important thing / Teamwork is / the most ）</span>' + line('Teamwork is the most important thing.'),
      '<span class="en">the most</span> が先。'),
     ('<span class="jp-cue">この本はあの本よりおもしろいです。</span>　<span class="paren en">（ than that one / This book is / more interesting ）</span>' + line('This book is more interesting than that one.'),
      '<span class="en">than</span> は後ろ。'),
     ('<span class="jp-cue">これはあれよりよいです。</span>　<span class="paren en">（ than that / better / This is ）</span>' + line('This is better than that.'),
      '<span class="en">better</span> 1語。'),
     ('<span class="jp-cue">この花はあの花より美しいです。</span>　<span class="paren en">（ more beautiful / than that one / This flower is ）</span>' + line('This flower is more beautiful than that one.'),
      '<span class="en">more beautiful</span> の順。'),
     ('<span class="jp-cue">数学は英語より大切です。</span>　<span class="paren en">（ than English / Math is / more important ）</span>' + line('Math is more important than English.'),
      '主語が1語。'),
     ('<span class="jp-cue">これはクラスでいちばん人気のある歌です。</span>　<span class="paren en">（ in my class / the most popular song / This is ）</span>' + line('This is the most popular song in my class.'),
      '<span class="en">in my class</span> は後ろ。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('宇宙の学校はふつうの学校よりわくわくします。' + wline('A school in space is more exciting than a normal one.'),
      '<span class="en">excitinger</span> にしない。'),
     ('チームワークがいちばん大切なことです。' + wline('Teamwork is the most important thing.'),
      '<span class="en">the</span> を忘れない。'),
     ('この本はあの本よりおもしろいです。' + wline('This book is more interesting than that one.'),
      '<span class="en">than</span> を忘れない。'),
     ('これはあれよりよいです。' + wline('This is better than that.'),
      '<span class="en">gooder</span> にしない。'),
     ('これがいちばんよいです。' + wline('This is the best.'),
      '<span class="en">the most best</span> にしない。'),
     ('数学は英語より大切です。' + wline('Math is more important than English.'),
      '<span class="en">more</span> ＋ 原形（もとの形）。'),
   ]),
   'words':'<span class="en">more exciting ／ the most important ／ more interesting ／ better ／ the best ／ more important</span>'},
  'l4':{'sub':'教科・スポーツ・食べものなどをくらべて書こう',
   'cond':['<span class="en">more ～ than</span> を使った文を <b>2つ以上</b>',
           '<span class="en">the most ～</span> を使った文を <b>1つ以上</b>',
           '<span class="en">better</span> か <span class="en">the best</span> を使った文も <b>1つ</b>'],
   'example':['Science is more interesting than math for me.','Soccer is the most popular sport in my class.','I like summer better than winter.'],
   'note':'これは例です。同じでなくてかまいません。<span class="en">interesting・important・popular・difficult</span> が使いやすいです。',
   'check':['長いことばには more / most','-er と more を重ねていない','more にも than をつけた','most にも the をつけた'],
   'review':'じぶんの文に <span class="en">more</span> と <span class="en">-er</span> が同時に出ていないか見直そう。'},
 },
}
