# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'g2-u7-1', 'grade':2, 'unit':'7 − 1', 'unit_plain':'7-1',
 'title':'比較級・最上級（-er, -est）', 'pages':'p.92〜93',
 'hero_big':'Ken is taller than Tom.',
 'hero_jp':'ケンは トムより 背が 高いです',
 'motto':'<b>2つをくらべる</b>なら <span class="en">-er ＋ than</span>。<b>いちばん</b>なら <span class="en">the ＋ -est</span>。',
 'kana':{'bigger':'ビガー','biggest':'ビゲスト','than':'ザン','festival':'フェスティヴァル',
         'summer':'サマー','event':'イヴェント','year':'イヤー','taller':'トーラー',
         'tallest':'トーレスト','older':'オウルダー','oldest':'オウルデスト',
         'longer':'ロンガー','longest':'ロンゲスト','easier':'イーズィアー',
         'easiest':'イーズィエスト','the':'ザ','in':'イン','of':'オヴ'},
 'blocks':[
  ('きほんの文', [
    ('t','ものをくらべる言い方です。<b>2つをくらべる</b>ときと、<b>いちばんだと言う</b>ときで形が変わります。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Ken is taller than Tom.</span><span class="t">ケンは トムより 背が 高いです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Ken is the tallest in his class.</span><span class="t">ケンは クラスで いちばん 背が 高いです。</span></div>
    </div>'''),
    ('t','<span class="en">tall</span> という形が、<span class="en">taller</span>（より高い）、<span class="en">tallest</span>（いちばん高い）と<b>変身</b>しています。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜<span class="en">than</span> と <span class="en">the</span> がセット', [
    ('t','ここが今回のヤマです。<b><span class="en">-er</span> には <span class="en">than</span>、<span class="en">-est</span> には <span class="en">the</span></b> がセットでつきます。'),
    ('h','''<table class="kind">
      <thead><tr><th>言いたいこと</th><th>形</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k">2つをくらべる</td><td class="k" style="color:var(--key);font-weight:700;">-er ＋ than</td><td class="e">This is <u>bigger than</u> that.</td></tr>
        <tr><td class="k">いちばんだと言う</td><td class="k" style="color:var(--gv);font-weight:700;">the ＋ -est</td><td class="e">This is <u>the biggest</u>.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ セットで使う<small>-er than / the -est</small></span></div>
        <div class="in"><div class="ex">bigger than that<br>the biggest event</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ 片方だけ<small>than や the を忘れる</small></span></div>
        <div class="in"><div class="ex">bigger that<br>biggest event</div></div>
      </div>
    </div>'''),
    ('t','<span class="en">than</span> は「～より」、<span class="en">the</span> は「その1つに決まる」という意味です。<b>いちばんは1つしかない</b>ので <span class="en">the</span> がつきます。'),
  ]),
  ('テストによく出ることば', [
    ('t','<span class="en">-er / -est</span> のつけ方は4パターンです。<b>つづりの変化</b>がいちばんまちがえるところです。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>つけ方</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">taller / tallest</span></td><td class="k">そのまま er / est</td><td class="e">He is <u>taller</u> than me.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">bigger / biggest</span></td><td class="k">g をかさねる</td><td class="e">This is <u>bigger</u>.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">easier / easiest</span></td><td class="k">y を i にして er</td><td class="e">This is <u>easier</u>.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">larger / largest</span></td><td class="k">e のあとは r / st だけ</td><td class="e">This is <u>larger</u>.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">taller</span> ・ <span class="en">bigger</span> ・ <span class="en">easier</span> ・ <span class="en">the biggest</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('「～の中で」の言い方', [
    ('t','いちばんだと言うときは、<b>どの範囲で</b>いちばんかを足すことが多いです。'),
    ('h','''<table class="kind">
      <thead><tr><th>ことば</th><th>うしろに来るもの</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k" style="color:var(--key);font-weight:700;">in</td><td class="k">場所・集団</td><td class="e">the biggest <u>in Japan</u>（日本で）</td></tr>
        <tr><td class="k" style="color:var(--gv);font-weight:700;">of</td><td class="k">数・まとまり</td><td class="e">the biggest <u>of the year</u>（その年で）</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">in my class</span>（クラスで）、<span class="en">of the three</span>（3つの中で）のように使い分けます。'),
  ]),
  ('くらべる相手の形', [
    ('t','<span class="en">than</span> のうしろには、<b>くらべる相手</b>を置きます。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">bigger than that festival</span>（あの祭りより）<br>
      <span class="eq" style="color:var(--gv);">taller than me</span>（わたしより）　<span class="eq" style="color:var(--gv);">older than my brother</span>（兄より）
    </div>'''),
    ('t','<span class="en">than</span> のうしろの「わたし」は <span class="en">me</span> の形です。4-2 でならった形と同じです。'),
  ]),
 ],
 'quiz':[
  ('This bag is bigger that bag.','This bag is bigger than that bag.','<b><span class="en">than</span> が抜けています</b>。<span class="en">-er</span> とセットです。','この かばんは あの かばんより 大きいです。'),
  ('He is tallest in his class.','He is the tallest in his class.','<b><span class="en">the</span> が抜けています</b>。<span class="en">-est</span> とセットです。','彼は クラスで いちばん 背が 高いです。'),
  ('This is more bigger than that.','This is bigger than that.','<span class="en">-er</span> と <span class="en">more</span> を<b>両方つけません</b>。','これは あれより 大きいです。'),
  ('He is more tall than me.','He is taller than me.','短い語は <span class="en">-er</span> をつけます。','彼は わたしより 背が 高いです。'),
  ('This is easyer than that.','This is easier than that.','<b>子音＋y</b> は <span class="en">y</span> を <span class="en">i</span> にして <span class="en">er</span>。','これは あれより かんたんです。'),
  ('He is taller than I am taller.','He is taller than me.','<span class="en">than</span> のうしろは<b>くらべる相手だけ</b>です。','彼は わたしより 背が 高いです。'),
 ],
 'summary':[
  '<b>2つをくらべる</b>なら <b><span class="en">-er ＋ than</span></b>。「～より…だ」。',
  '<b>いちばん</b>だと言うなら <b><span class="en">the ＋ -est</span></b>。<span class="en">the</span> を忘れない。',
  'つけ方は4パターン。<b>字をかさねる・<span class="en">y</span> を <span class="en">i</span> に・<span class="en">e</span> のあとは <span class="en">r</span> だけ</b>。',
  '「～の中で」は <b><span class="en">in</span>（場所）</b>と <b><span class="en">of</span>（数）</b>を使い分ける。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '2つをくらべるときは、ようすのことばに%sをつける。' % bl('er'),
     'そのうしろには%sを置いて、くらべる相手を言う。' % bl('than'),
     '「いちばん～」と言うときは%sをつける。' % bl('est'),
     'そのときは前に%sをつける。' % bl('the'),
     '「日本で」のように場所をいうときは%sを使う。' % bl('in'),
   ]),
   'words':'語群：<span class="en">er</span> ／ <span class="en">than</span> ／ <span class="en">est</span> ／ <span class="en">the</span> ／ <span class="en">in</span>',
   'exp':'<b>なぜ？</b>　<span class="en">the</span> は「どれのことか決まっている」というしるしです。<br>'
         '「いちばん大きいもの」は<b>1つに決まります</b>。だから <span class="en">the</span> が必要になるのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　形を変えよう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>つづりの変化</b>に気をつけましょう。',
   'body':grid2([
     '1. <span class="en">tall → %s</span>（より高い）' % bl('taller', False),
     '2. <span class="en">big → %s</span>（より大きい）' % bl('bigger', False),
     '3. <span class="en">easy → %s</span>（よりやさしい）' % bl('easier', False),
     '4. <span class="en">large → %s</span>（より広い）' % bl('larger', False),
     '5. <span class="en">old → %s</span>（いちばん古い）' % bl('oldest', False),
     '6. <span class="en">big → %s</span>（いちばん大きい）' % bl('biggest', False),
     '7. <span class="en">easy → %s</span>（いちばんやさしい）' % bl('easiest', False),
     '8. <span class="en">long → %s</span>（より長い）' % bl('longer', False),
     '9. <span class="en">hot → %s</span>（より暑い）' % bl('hotter', False),
     '10. <span class="en">nice → %s</span>（いちばんすてきな）' % bl('nicest', False),
   ]),
   'exp':'<b>見分け方</b>　そのまま <span class="en">er / est</span> → 1・5・8<br>'
         '<b>字をかさねる</b>（短い語で 子音1つで終わる）→ 2・6・9<br>'
         '<b><span class="en">y</span> を <span class="en">i</span> に</b> → 3・7　　<b><span class="en">e</span> のあとは <span class="en">r / st</span> だけ</b> → 4・10'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. This is bigger than that.','○'), ('2. This is bigger that.','✕'),
     ('3. This is the biggest event.','○'), ('4. This is biggest event.','✕'),
     ('5. He is taller than me.','○'), ('6. He is more tall than me.','✕'),
     ('7. This is easier than that.','○'), ('8. This is easyer than that.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">than</span> を入れる　4 → <span class="en">the</span> を入れる<br>'
         '6 → <span class="en">taller</span>（短い語に <span class="en">more</span> はつけない）　8 → <span class="en">easier</span>'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'「～より」なら <span class="en">than</span>、「いちばん」なら <span class="en">the</span>。',
   'body':grid2([
     '1. <span class="en">This is bigger （ア than ／イ of） that.</span>%s' % bl('ア'),
     '2. <span class="en">This is （ア the ／イ 　） biggest event.</span>%s' % bl('ア'),
     '3. <span class="en">He is （ア taller ／イ more tall） than me.</span>%s' % bl('ア'),
     '4. <span class="en">This is the biggest （ア in ／イ of） Japan.</span>%s' % bl('ア'),
     '5. <span class="en">This is the biggest （ア in ／イ of） the three.</span>%s' % bl('イ'),
     '6. <span class="en">He is taller than （ア I ／イ me）.</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　4・5 は <span class="en">in</span> と <span class="en">of</span> の使い分け。<b>場所なら <span class="en">in</span>、数なら <span class="en">of</span></b>。<br>'
         '6 は <span class="en">than</span> のうしろの形です。4-2 でならった <span class="en">me</span> の形を使います。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　「～より」か「いちばん」かを先に決めてから、形を変えよう。',
   'body':ol([
     ('<span class="jp-cue">この祭りはあの祭りより大きいです。</span>　<span class="en">This festival is%sthan that festival.</span>' % bl('bigger', False),
      '<span class="en">g</span> をかさねる。'),
     ('<span class="jp-cue">この祭りはその年でいちばん大きな行事です。</span>　<span class="en">This festival is%sbiggest event of the year.</span>' % bl('the'),
      '<span class="en">the</span> を忘れない。'),
     ('<span class="jp-cue">彼はわたしより背が高いです。</span>　<span class="en">He is taller%sme.</span>' % bl('than'),
      '「～より」は <span class="en">than</span>。'),
     ('<span class="jp-cue">これはあれよりやさしいです。</span>　<span class="en">This is%sthan that.</span>' % bl('easier', False),
      '<span class="en">y</span> を <span class="en">i</span> に。'),
     ('<span class="jp-cue">これは日本でいちばん古い寺です。</span>　<span class="en">This is the%stemple in Japan.</span>' % bl('oldest', False),
      'そのまま <span class="en">est</span>。'),
     ('<span class="jp-cue">これは3つの中でいちばん大きいです。</span>　<span class="en">This is the biggest%sthe three.</span>' % bl('of'),
      '数なので <span class="en">of</span>。'),
     ('<span class="jp-cue">これは日本でいちばん長い川です。</span>　<span class="en">This is the longest river%sJapan.</span>' % bl('in'),
      '場所なので <span class="en">in</span>。'),
     ('<span class="jp-cue">今日はきのうより暑いです。</span>　<span class="en">Today is%s%syesterday.</span>' % (bl('hotter', False), bl('than')),
      '（　）が2つ。<span class="en">t</span> をかさねる。'),
     ('<span class="jp-cue">彼はクラスでいちばん背が高いです。</span>　<span class="en">He is the%sin my class.</span>' % bl('tallest', False),
      'そのまま <span class="en">est</span>。'),
     ('<span class="jp-cue">この部屋はあの部屋より広いです。</span>　<span class="en">This room is%sthan that room.</span>' % bl('larger', False),
      '<span class="en">e</span> のあとは <span class="en">r</span> だけ。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　主語 → be動詞 → くらべる形 → <span class="en">than ～</span> の順。',
   'body':ol([
     ('<span class="jp-cue">この祭りはあの祭りより大きいです。</span>　<span class="paren en">（ than that festival / bigger / This festival is ）</span>' + line('This festival is bigger than that festival.'),
      '<span class="en">than ～</span> はいちばん後ろ。'),
     ('<span class="jp-cue">この祭りはその年でいちばん大きな行事です。</span>　<span class="paren en">（ of the year / the biggest event / This festival is ）</span>' + line('This festival is the biggest event of the year.'),
      '<span class="en">of the year</span> は後ろ。'),
     ('<span class="jp-cue">彼はわたしより背が高いです。</span>　<span class="paren en">（ than me / taller / He is ）</span>' + line('He is taller than me.'),
      '<span class="en">me</span> の形に注意。'),
     ('<span class="jp-cue">これはあれよりやさしいです。</span>　<span class="paren en">（ than that / This is / easier ）</span>' + line('This is easier than that.'),
      '<span class="en">easier</span> のつづり。'),
     ('<span class="jp-cue">これは日本でいちばん長い川です。</span>　<span class="paren en">（ in Japan / the longest river / This is ）</span>' + line('This is the longest river in Japan.'),
      '場所は <span class="en">in</span>。'),
     ('<span class="jp-cue">今日はきのうより暑いです。</span>　<span class="paren en">（ than yesterday / hotter / Today is ）</span>' + line('Today is hotter than yesterday.'),
      '<span class="en">hotter</span> の <span class="en">t</span> に注意。'),
     ('<span class="jp-cue">彼はクラスでいちばん背が高いです。</span>　<span class="paren en">（ in my class / the tallest / He is ）</span>' + line('He is the tallest in my class.'),
      '<span class="en">the</span> を忘れない。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('この祭りはあの祭りより大きいです。' + wline('This festival is bigger than that festival.'),
      '<span class="en">than</span> を忘れない。'),
     ('この祭りはその年でいちばん大きな行事です。' + wline('This festival is the biggest event of the year.'),
      '<span class="en">the</span> を忘れない。'),
     ('彼はわたしより背が高いです。' + wline('He is taller than me.'),
      '<span class="en">more tall</span> にしない。'),
     ('これはあれよりやさしいです。' + wline('This is easier than that.'),
      '<span class="en">easyer</span> にしない。'),
     ('これは日本でいちばん長い川です。' + wline('This is the longest river in Japan.'),
      '場所は <span class="en">in</span>。'),
     ('彼はクラスでいちばん背が高いです。' + wline('He is the tallest in my class.'),
      '<span class="en">the</span> ＋ <span class="en">est</span>。'),
   ]),
   'words':'<span class="en">bigger than ／ the biggest ／ taller than me ／ easier than ／ the longest ／ the tallest</span>'},
  'l4':{'sub':'身のまわりのものをくらべて書こう',
   'cond':['<span class="en">-er than</span> を使った文を <b>2つ以上</b>',
           '<span class="en">the -est</span> を使った文を <b>1つ以上</b>',
           '<span class="en">in</span> か <span class="en">of</span> を使って「～の中で」を書く'],
   'example':['My brother is taller than me.','This book is easier than that one.','Mt. Fuji is the highest mountain in Japan.'],
   'note':'これは例です。同じでなくてかまいません。家族・教科・季節などをくらべると書きやすいです。',
   'check':['-er には than をつけた','-est には the をつけた','つづりの変化（bigger・easier）','in と of を使い分けた'],
   'review':'じぶんの文の <span class="en">-er</span> と <span class="en">-est</span> に○をつけよう。<span class="en">than</span> か <span class="en">the</span> が近くにあるか確かめよう。'},
 },
}
