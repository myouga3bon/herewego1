# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox

S = {
 'id':'g2-u3-3', 'grade':2, 'unit':'3 − 3', 'unit_plain':'3-3',
 'title':'接続詞 if', 'pages':'p.36〜37',
 'hero_big':'If it is sunny, I will play tennis.',
 'hero_jp':'もし 晴れたら、わたしは テニスを します',
 'motto':'<span class="en">if</span> ＝「もし～なら」。<b>前に置いたらコンマ</b>。<span class="en">if</span> のうしろは <b>未来のことでも今の形</b>。',
 'kana':{'if':'イフ','tired':'タイアド','straight':'ストレイト','home':'ホウム',
         'rain':'レイン','rains':'レインズ','busy':'ビズィ','free':'フリー',
         'hungry':'ハングリィ','cold':'コウルド','sunny':'サニィ','stay':'ステイ',
         'go':'ゴウ','come':'カム','eat':'イート','tomorrow':'トゥモロウ',
         'we':'ウィー','can':'キャン','will':'ウィル'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>もし 晴れたら</b>、テニスをします」のように、<b>条件</b>を言って2つの文をくっつける形です。'),
    ('t','1-2 の <span class="en">when</span> と作りは同じ。<span class="en">if</span> も<b>前でも うしろでも</b>置けます。'),
    ('h', gitem('❶', '<span class="en">if</span> のまとまりを<b>前</b>に置く', 'コンマで区切る',
                'もし 晴れたら、テニスをします', 'If it is sunny, I will play tennis.',
                [('If it is sunny, I will play tennis.','もし 晴れたら、わたしは テニスを します。'),
                 ('If you are tired, you can go home.','もし つかれているなら、家に 帰って いいですよ。')],
                '前に置いたときは <b>コンマ（, ）</b>を入れます。')),
    ('h', gitem('❷', '<span class="en">if</span> のまとまりを<b>うしろ</b>に置く', 'コンマはいらない',
                'テニスをします、もし晴れたら', 'I will play tennis if it is sunny.',
                [('I will play tennis if it is sunny.','晴れたら わたしは テニスを します。'),
                 ('You can go home if you are tired.','つかれているなら 家に 帰って いいですよ。')],
                'うしろに置いたときは <b>コンマはいりません</b>。意味は ❶ と同じです。', b2=True)),
    ('t','ここが大事。<span class="en">if</span> のうしろは、これからのことでも <b><span class="en">will</span> を使わず いまの形</b>で書きます。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜<span class="en">if</span> のうしろは「今の形」', [
    ('t','ここが今回のヤマです。<b>これからのこと</b>を言うときでも、<span class="en">if</span> のうしろは<b>今の形</b>のまま書きます。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ 今の形<small>if it rains</small></span></div>
        <div class="in"><div class="ex">If it rains tomorrow,<br>I will stay home.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ will を入れる<small>if it will rain</small></span></div>
        <div class="in"><div class="ex">If it will rain tomorrow,<br>I will stay home.</div></div>
      </div>
    </div>'''),
    ('t','日本語では「もしあした雨が<b>ふったら</b>」と未来のように言いますが、英語の <span class="en">if</span> のうしろには <span class="en">will</span> を入れません。'),
    ('h','''<div class="eqbox">
      <span class="eq" style="color:var(--gv);">If it rains tomorrow,</span>（<span class="en">will</span> なし）　<span class="eq" style="color:var(--key);">I will stay home.</span>（<span class="en">will</span> あり）<br>
      <b><span class="en">will</span> が入るのは、うしろの文だけ</b>
    </div>'''),
  ]),
  ('テストによく出ることば', [
    ('t','<span class="en">when</span> のときと同じで、<b>コンマを打つかどうか</b>がいちばんまちがえるところです。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味・やくわり</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">if</span></td><td class="k">もし～なら</td><td class="e">I&#39;ll stay home <u>if</u> it rains.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">If ～,</span></td><td class="k">前に置いたらコンマ</td><td class="e"><u>If it rains,</u> I&#39;ll stay home.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">if it rains</span></td><td class="k">未来でも今の形</td><td class="e">if it <u>rains</u> tomorrow</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">if you&#39;re</span></td><td class="k">もしあなたが～なら</td><td class="e"><u>if you&#39;re</u> tired</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">If it rains,</span> と <span class="en">if you&#39;re tired</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('<span class="en">when</span> とのちがい', [
    ('t','形は同じですが、<b>起こるかどうか</b>がちがいます。'),
    ('h','''<table class="kind">
      <thead><tr><th>ことば</th><th>意味</th><th>起こるか</th></tr></thead>
      <tbody>
        <tr><td class="k" style="color:var(--key);font-weight:700;">when</td><td class="k">～するとき</td><td class="e">かならず起こる（朝が来る、など）</td></tr>
        <tr><td class="k" style="color:var(--gv);font-weight:700;">if</td><td class="k">もし～なら</td><td class="e">起こるかどうか分からない</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">When I get up,</span>（起きたとき＝かならず起きる）と <span class="en">If it rains,</span>（もし雨なら＝ふるか分からない）のちがいです。'),
  ]),
  ('うしろの文には <span class="en">will</span> や <span class="en">can</span> を使える', [
    ('t','<span class="en">if</span> のまとまりではないほうの文は、ふつうに <span class="en">will</span> や <span class="en">can</span> が使えます。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">If you&#39;re tired,</span> <span class="eq">we <b>can</b> go straight home.</span><br>
      <span class="eq" style="color:var(--gv);">If it rains tomorrow,</span> <span class="eq">I <b>will</b> stay home.</span>
    </div>'''),
    ('t','<b>助っ人のことばは、<span class="en">if</span> の外側だけ</b>とおぼえましょう。'),
  ]),
 ],
 'quiz':[
  ('If it will rain tomorrow, I will stay home.','If it rains tomorrow, I will stay home.','<span class="en">if</span> のうしろに <span class="en">will</span> は入れません。<b>今の形</b>にします。','もし あした 雨が ふったら、わたしは 家に います。'),
  ('If you&#39;re tired we can go home.','If you&#39;re tired, we can go home.','<span class="en">if</span> を<b>前に置いたらコンマ</b>で区切ります。','もし あなたが つかれているなら、家に 帰れます。'),
  ('We can go home, if you&#39;re tired.','We can go home if you&#39;re tired.','<b>うしろに置くときはコンマなし</b>。','あなたが つかれているなら、家に 帰れます。'),
  ('If it rains tomorrow.','If it rains tomorrow, I will stay home.','<span class="en">if</span> のまとまりだけでは文になりません。','もし あした 雨が ふったら、わたしは 家に います。'),
  ('If it rain tomorrow, I will stay home.','If it rains tomorrow, I will stay home.','主語が <span class="en">it</span> なので <b><span class="en">rains</span></b>。','もし あした 雨が ふったら、わたしは 家に います。'),
  ('If do you are tired, we can go home.','If you&#39;re tired, we can go home.','<span class="en">if</span> のうしろは<b>ふつうの文の形</b>。<span class="en">do</span> は使いません。','もし あなたが つかれているなら、家に 帰れます。'),
 ],
 'summary':[
  '<b><span class="en">if</span> ＝「もし～なら」</b>。<span class="en">when</span> と同じく、文を2つくっつけることば。',
  '<b>前に置いたらコンマ</b>（<span class="en">If ～, ～.</span>）、<b>うしろならコンマなし</b>。',
  '<b><span class="en">if</span> のうしろは、未来のことでも今の形</b>。<span class="en">will</span> を入れない。',
  '<span class="en">will・can</span> は、<span class="en">if</span> の<b>外側の文</b>で使う。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「もし～なら」は%sを使って、文を2つくっつける。' % bl('if'),
     '<span class="en">if</span> のまとまりを前に置いたら、うしろに%sを打つ。' % bl('コンマ'),
     '<span class="en">if</span> のうしろは、未来のことでも%sの形で書く。' % bl('今'),
     'だから <span class="en">if</span> のうしろに%sは入れない。' % bl('will'),
     '<span class="en">will</span> や <span class="en">can</span> は、<span class="en">if</span> の%sの文で使う。' % bl('外側'),
   ]),
   'words':'語群：<span class="en">if</span> ／ コンマ ／ 今 ／ <span class="en">will</span> ／ 外側',
   'exp':'<b>なぜ？</b>　<span class="en">if</span> のまとまりは「そういう場合には」という<b>条件</b>を示すだけで、未来の話そのものではありません。<br>'
         'だから未来のしるし（<span class="en">will</span>）は、実際に起こることを言う<b>外側の文</b>につけます。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">if</span> のうしろの形を書こう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b><span class="en">will</span> を入れない</b>ことに注意しましょう。',
   'body':grid2([
     '1. <span class="en">If it%stomorrow, I&#39;ll stay home.</span>' % bl('rains'),
     '2. <span class="en">If you%stired, we can go home.</span>' % bl('are'),
     '3. <span class="en">If I%sfree, I&#39;ll help you.</span>' % bl('am'),
     '4. <span class="en">If he%sbusy, he won&#39;t come.</span>' % bl('is'),
     '5. <span class="en">If it%ssunny, we&#39;ll go out.</span>' % bl('is'),
     '6. <span class="en">If you%shungry, eat this.</span>' % bl('are'),
     '7. <span class="en">If they%stime, they&#39;ll come.</span>' % bl('have'),
     '8. <span class="en">If she%ssoccer, she&#39;ll be happy.</span>' % bl('plays'),
     '9. <span class="en">If it%scold, stay home.</span>' % bl('is'),
     '10. <span class="en">If we%searly, we can walk.</span>' % bl('leave'),
   ]),
   'exp':'<b>かくにん</b>　どれも<b>今の形</b>です。<span class="en">will rain・will be</span> とは書きません。<br>'
         '主語が <span class="en">it・he・she</span> のときは、三単現の <span class="en">s</span> がつきます（1・8）。<br>'
         '外側の文のほうには <span class="en">&#39;ll</span>（＝<span class="en">will</span>）や <span class="en">can</span> が入っていることを確かめよう。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. If it rains, I&#39;ll stay home.','○'), ('2. If it will rain, I&#39;ll stay home.','✕'),
     ('3. If you&#39;re tired, we can go home.','○'), ('4. If you&#39;re tired we can go home.','✕'),
     ('5. We can go home if you&#39;re tired.','○'), ('6. We can go home, if you&#39;re tired.','✕'),
     ('7. If it rains tomorrow, I&#39;ll stay home.','○'), ('8. If it rain tomorrow, I&#39;ll stay home.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">If it rains,</span>（<span class="en">will</span> をとる）　4 → コンマを入れる<br>'
         '6 → コンマをとる　8 → <span class="en">rains</span>（主語が <span class="en">it</span>）'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'<span class="en">if</span> の<b>内側</b>か<b>外側</b>かを、まず見分けよう。',
   'body':grid2([
     '1. <span class="en">If it （ア will rain ／イ rains）, I&#39;ll stay home.</span>%s' % bl('イ'),
     '2. <span class="en">If it rains, I （ア will ／イ 　） stay home.</span>%s' % bl('ア'),
     '3. <span class="en">（ア If you&#39;re tired, we ／イ If you&#39;re tired we） can go home.</span>%s' % bl('ア'),
     '4. <span class="en">We can go home （ア , if ／イ if） you&#39;re tired.</span>%s' % bl('イ'),
     '5. <span class="en">If he （ア is ／イ will be） busy, he won&#39;t come.</span>%s' % bl('ア'),
     '6. <span class="en">If it rains, we （ア can&#39;t ／イ don&#39;t can） go out.</span>%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　1・5 は <span class="en">if</span> の内側なので <span class="en">will</span> を入れません。<br>'
         '2 は外側なので <span class="en">will</span> が必要です。3・4 はコンマ、6 は <span class="en">can</span> の打ち消しの形です。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　<span class="en">if</span> のまとまりの中に <span class="en">will</span> を入れないこと。',
   'body':ol([
     ('<span class="jp-cue">もしあなたがつかれているなら、まっすぐ家に帰れます。</span>　<span class="en">%syou&#39;re tired, we can go straight home.</span>' % bl('If'),
      '文のはじめなので<b>大文字</b>。'),
     ('<span class="jp-cue">もしあした雨がふったら、わたしは家にいます。</span>　<span class="en">If it%stomorrow, I&#39;ll stay home.</span>' % bl('rains'),
      '<span class="en">will</span> を入れず、<span class="en">s</span> をつける。'),
     ('<span class="jp-cue">もしあした雨がふったら、わたしは家にいます。</span>　<span class="en">If it rains tomorrow, I%sstay home.</span>' % bl('will'),
      '外側の文には <span class="en">will</span> が入る。'),
     ('<span class="jp-cue">もしひまなら、手伝います。</span>　<span class="en">If I%sfree, I&#39;ll help you.</span>' % bl('am'),
      '<span class="en">I</span> なので <span class="en">am</span>。'),
     ('<span class="jp-cue">あなたがつかれているなら、家に帰れます。</span>　<span class="en">We can go home%syou&#39;re tired.</span>' % bl('if'),
      'うしろに置くので<b>小文字</b>。コンマなし。'),
     ('<span class="jp-cue">もし彼が忙しいなら、彼は来ないでしょう。</span>　<span class="en">If he is busy, he%scome.</span>' % bl("won't"),
      '外側は <span class="en">won&#39;t</span>。'),
     ('<span class="jp-cue">もし晴れたら、出かけましょう。</span>　<span class="en">If it%ssunny, let&#39;s go out.</span>' % bl('is'),
      '<span class="en">it is sunny</span> のまま。'),
     ('<span class="jp-cue">もしおなかがすいているなら、これを食べて。</span>　<span class="en">If you%shungry, eat this.</span>' % bl('are'),
      '<span class="en">you</span> なので <span class="en">are</span>。'),
     ('<span class="jp-cue">もし時間があれば、彼らは来るでしょう。</span>　<span class="en">If they%stime, they&#39;ll come.</span>' % bl('have'),
      '<span class="en">They</span> なので <span class="en">have</span>。'),
     ('<span class="jp-cue">もし雨なら、わたしたちは出かけられません。</span>　<span class="en">If it rains, we%sgo out.</span>' % bl("can't"),
      '外側は <span class="en">can&#39;t</span>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　まず <span class="en">if</span> のまとまりを作り、それから外側の文をくっつけよう。',
   'body':ol([
     ('<span class="jp-cue">もしあなたがつかれているなら、まっすぐ家に帰れます。</span>　<span class="paren en">（ we can go straight home / you&#39;re tired / If ）</span>' + line('If you&#39;re tired, we can go straight home.'),
      '前に置いたので<b>コンマ</b>。'),
     ('<span class="jp-cue">あなたがつかれているなら、まっすぐ家に帰れます。</span>　<span class="paren en">（ if you&#39;re tired / go straight home / We can ）</span>' + line('We can go straight home if you&#39;re tired.'),
      'うしろに置いたのでコンマなし。'),
     ('<span class="jp-cue">もしあした雨がふったら、わたしは家にいます。</span>　<span class="paren en">（ I&#39;ll stay home / it rains tomorrow / If ）</span>' + line('If it rains tomorrow, I&#39;ll stay home.'),
      '<span class="en">if</span> の中に <span class="en">will</span> はない。'),
     ('<span class="jp-cue">もしひまなら、手伝います。</span>　<span class="paren en">（ I&#39;ll help you / I&#39;m free / If ）</span>' + line('If I&#39;m free, I&#39;ll help you.'),
      '外側だけ <span class="en">&#39;ll</span>。'),
     ('<span class="jp-cue">もし彼が忙しいなら、彼は来ないでしょう。</span>　<span class="paren en">（ he won&#39;t come / he is busy / If ）</span>' + line('If he is busy, he won&#39;t come.'),
      '打ち消しは外側の文。'),
     ('<span class="jp-cue">もし晴れたら、わたしたちは出かけます。</span>　<span class="paren en">（ we&#39;ll go out / it is sunny / If ）</span>' + line('If it is sunny, we&#39;ll go out.'),
      '<span class="en">it is</span> のまま。'),
     ('<span class="jp-cue">もし雨なら、わたしたちは出かけられません。</span>　<span class="paren en">（ we can&#39;t go out / it rains / If ）</span>' + line('If it rains, we can&#39;t go out.'),
      '<span class="en">rains</span> の <span class="en">s</span> に注意。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('もしあなたがつかれているなら、まっすぐ家に帰れます。' + wline('If you&#39;re tired, we can go straight home.'),
      'コンマを忘れない。'),
     ('もしあした雨がふったら、わたしは家にいます。' + wline('If it rains tomorrow, I will stay home.'),
      '<span class="en">if it will rain</span> にしない。'),
     ('もしひまなら、手伝います。' + wline('If I&#39;m free, I will help you.'),
      '<span class="en">I am free</span> でも正解。'),
     ('もし彼が忙しいなら、彼は来ないでしょう。' + wline('If he is busy, he won&#39;t come.'),
      '外側だけ打ち消す。'),
     ('あなたがつかれているなら、家に帰れます。' + wline('We can go home if you&#39;re tired.'),
      'うしろに置くのでコンマなし。'),
     ('もし雨なら、わたしたちは出かけられません。' + wline('If it rains, we can&#39;t go out.'),
      '<span class="en">rains</span> の <span class="en">s</span>。'),
   ]),
   'words':'<span class="en">If you&#39;re tired ／ If it rains tomorrow ／ If I&#39;m free ／ If he is busy ／ if you&#39;re tired ／ can&#39;t go out</span>'},
  'l4':{'sub':'「もし～なら、…します」を自分のことで書こう',
   'cond':['<span class="en">If ～,</span> を<b>前</b>に置いた文を <b>1つ以上</b>',
           '<span class="en">～ if ～.</span> と<b>うしろ</b>に置いた文も <b>1つ</b>',
           '外側の文に <span class="en">will</span> か <span class="en">can</span> を使う'],
   'example':['If it is sunny tomorrow, I will play soccer.','If I have time, I&#39;ll read a book.','We can go to the park if the weather is good.'],
   'note':'これは例です。同じでなくてかまいません。天気・時間・体調など、「分からないこと」を条件にすると書きやすいです。',
   'check':['if のうしろに will を入れていない','前に置いたらコンマ','外側に will か can がある','動詞が2つある'],
   'review':'じぶんの文の <span class="en">if</span> のまとまりに○をつけよう。その中に <span class="en">will</span> があったら、そこがまちがい。'},
 },
}
