# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox

S = {
 'id':'g2-u1-1', 'grade':2, 'unit':'1 − 1', 'unit_plain':'1-1',
 'title':'動詞の過去形', 'pages':'p.10〜11',
 'hero_big':'I played soccer yesterday.',
 'hero_jp':'わたしは きのう サッカーを しました',
 'motto':'過去の文は <b>動詞を過去形にするだけ</b>。<span class="en">was・were</span> と 一般動詞は いっしょに使わない。',
 'kana':{'went':'ウェント','visited':'ヴィズィティッド','grandparents':'グランペアレンツ',
         'trip':'トリップ','store':'ストア','interested':'インタレスティッド',
         'yesterday':'イエスタデイ','last':'ラスト','ago':'アゴウ','studied':'スタディド',
         'played':'プレイド','enjoyed':'インヂョイド','saw':'ソー','ate':'エイト',
         'was':'ワズ','were':'ワー','really':'リーアリィ','week':'ウィーク','summer':'サマー',
         'movie':'ムーヴィー','lunch':'ランチ','how':'ハウ','they':'ゼイ','we':'ウィー'},
 'blocks':[
  ('きほんの文', [
    ('t','「きのう <b>サッカーをした</b>」「ゆうべ <b>英語を勉強した</b>」のように、<b>もう終わったこと</b>を言うときの形です。'),
    ('t','変えるのは<b>動詞だけ</b>。ただし、変え方が<b>2種類</b>あります。'),
    ('h', gitem('❶', '<span class="en">ed</span> をつけるだけ', 'ほとんどの動詞',
                'サッカーを した', 'played soccer',
                [('I played soccer yesterday.','わたしは きのう サッカーを しました。'),
                 ('I studied English last night.','わたしは ゆうべ 英語を 勉強しました。')],
                'うしろに <b>ed</b> をつけます。<span class="en">study</span> のように <b>子音＋y</b> で終わる語は <span class="en">y</span> を <span class="en">i</span> にして <b>ed</b>。')),
    ('h', gitem('❷', '形ごと 変わってしまう', 'よく使う動詞',
                '公園へ 行った', 'went to the park',
                [('I went to the park.','わたしは 公園へ 行きました。'),
                 ('I had lunch at noon.','わたしは お昼に 昼食を 食べました。')],
                '<span class="en">go → went</span>、<span class="en">have → had</span> のように、<b>形ごと変わります</b>。<span class="en">goed</span> とは書きません。おぼえるしかない仲間です。', b2=True)),
    ('t','どちらも<b>主語は変わりません</b>。<span class="en">I・He・They</span> のどれでも、過去形は同じ形です。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜2つの過去形を混ぜない', [
    ('t','過去形には<b>2種類</b>あります。<span class="en">was・were</span> と、一般動詞の過去形です。この2つを<b>いっしょに使ってはいけません</b>。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ どちらか1つ<small>心臓（動詞）は1つだけ</small></span></div>
        <div class="in"><div class="ex">I visited my grandparents.<br>They were interested in Japan.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ 2つ重ねる<small>was ＋ 動作のことば</small></span></div>
        <div class="in"><div class="ex">I was visited my grandparents.<br>I was went to the store.</div></div>
      </div>
    </div>'''),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：1つの文に 心臓（動詞）は 1つだけ</div>
        <p><b class="cb">青＝<span class="en">was・were</span></b>　<b class="cp">ピンク＝動作のことば（<span class="en">went・visited</span>）</b>　
        1年生のときと同じルールが、過去形でもそのまま使えます。<br>
        <span class="xm">✕ I was played soccer ✕</span></p>
      </div>
    </div>'''),
  ]),
  ('テストによく出ることば', [
    ('t','この4つが書ければ、過去の文はつくれます。<b>形がまるごと変わるもの</b>に気をつけましょう。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">visited</span></td><td class="k">たずねた（ed をつける）</td><td class="e">I <u>visited</u> my grandparents.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">went</span></td><td class="k">行った（go が変わる形）</td><td class="e">I <u>went</u> to the store.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">was</span></td><td class="k">～だった（I・he・she）</td><td class="e">How <u>was</u> your trip?</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">were</span></td><td class="k">～だった（you・2人以上）</td><td class="e">They <u>were</u> interested.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">visited</span> ・ <span class="en">went</span> ・ <span class="en">was</span> ・ <span class="en">were</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('一般動詞の過去形　ed をつける・形が変わる', [
    ('t','ほとんどの動詞は <span class="en">ed</span> をつけるだけです。でも、よく使う動詞ほど<b>形がまるごと変わります</b>。'),
    ('h','''<table class="kind">
      <thead><tr><th>パターン</th><th>やり方</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k">ふつう</td><td class="k">そのまま ed</td><td class="e">visit → visit<u>ed</u>　play → play<u>ed</u></td></tr>
        <tr><td class="k">e で終わる</td><td class="k">d だけ</td><td class="e">like → like<u>d</u>　live → live<u>d</u></td></tr>
        <tr><td class="k">子音＋y</td><td class="k" style="color:var(--ng);font-weight:700;">y を i にして ed</td><td class="e">study → stud<u>ied</u></td></tr>
        <tr><td class="k">形が変わる</td><td class="k" style="color:var(--ng);font-weight:700;">おぼえるしかない</td><td class="e">go → <u>went</u>　see → <u>saw</u>　eat → <u>ate</u></td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">goed</span>・<span class="en">seed</span> とは書きません。形が変わるものは、<b>声に出しておぼえる</b>のがいちばん早いです。'),
  ]),
  ('<span class="en">was</span> と <span class="en">were</span> の使い分け', [
    ('t','<span class="en">am・is</span> が <span class="en">was</span> に、<span class="en">are</span> が <span class="en">were</span> に変わります。<b>主語で決まります</b>。'),
    ('h','''<table class="kind">
      <thead><tr><th>主語</th><th>今のこと</th><th>過去のこと</th></tr></thead>
      <tbody>
        <tr><td class="k">I（わたし）</td><td class="e">I <u>am</u> happy.</td><td class="e">I <u>was</u> happy.</td></tr>
        <tr><td class="k">he / she・名前</td><td class="e">He <u>is</u> happy.</td><td class="e">He <u>was</u> happy.</td></tr>
        <tr><td class="k">you・they・we</td><td class="e">They <u>are</u> happy.</td><td class="e">They <u>were</u> happy.</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">How was ～?</span> は「～はどうでしたか」と感想をたずねる形です。よく出ます。'),
  ]),
  ('「いつのことか」を表すことば', [
    ('t','過去の文には、<b>いつのことか</b>を表すことばがよくいっしょに出てきます。これが見えたら、動詞は過去形です。'),
    ('h','''<div class="eqbox">
      <span class="eq">yesterday</span>（きのう）　<span class="eq">last week</span>（先週）　<span class="eq">last summer</span>（去年の夏）　<span class="eq">two days ago</span>（2日前）
    </div>'''),
    ('t','<span class="en">last</span> は「この前の」、<span class="en">ago</span> は「～前に」という意味です。<span class="en">ago</span> は数のうしろに置きます。'),
  ]),
 ],
 'quiz':[
  ('I play soccer yesterday.','I played soccer yesterday.','<span class="en">yesterday</span> があるので過去の文。<span class="en">play</span> → <b><span class="en">played</span></b>。','わたしは きのう サッカーを しました。'),
  ('I was visited my grandparents.','I visited my grandparents.','<span class="en">was</span> と <span class="en">visited</span> で<b>心臓が2つ</b>。<span class="en">was</span> はいりません。','わたしは 祖父母を たずねました。'),
  ('How were your trip?','How was your trip?','主語は <span class="en">your trip</span>（1つ）。<b><span class="en">was</span></b> を使います。','あなたの 旅行は どうでしたか。'),
  ('They was happy.','They were happy.','<span class="en">They</span> は2人以上。<b><span class="en">were</span></b> を使います。','彼らは うれしかったです。'),
  ('I goed to the park.','I went to the park.','<span class="en">go</span> は<b>形が変わる</b>動詞。<span class="en">goed</span> とは書きません。','わたしは 公園へ 行きました。'),
  ('I studyed English.','I studied English.','<b>子音＋y</b> は <span class="en">y</span> を <span class="en">i</span> にして <span class="en">ed</span>。','わたしは 英語を 勉強しました。'),
 ],
 'summary':[
  '過去の文は <b>動詞を過去形にするだけ</b>。主語は変えない。',
  '一般動詞は <b><span class="en">ed</span> をつける</b>。ただし <span class="en">go → went</span> のように<b>形が変わる</b>ものがある。',
  'be動詞は <b><span class="en">am・is → was</span>、<span class="en">are → were</span></b>。主語で決まる。',
  '<b><span class="en">was・were</span> と 動作のことばは いっしょに使わない。</b>心臓（動詞）は1つだけ。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '過去の文は、主語を変えずに%sを過去形にする。' % bl('動詞'),
     'ふつうの動詞は%sをつけるが、<span class="en">go</span> は%sになる。' % (bl('ed'), bl('went')),
     '子音＋<span class="en">y</span> で終わる語は、<span class="en">y</span> を%sにして <span class="en">ed</span>。' % bl('i'),
     '<span class="en">am・is</span> の過去形は%s、<span class="en">are</span> の過去形は%s。' % (bl('was'), bl('were')),
     '<span class="en">was・were</span> と 動作のことばは%s使わない。' % bl('いっしょに', False),
   ]),
   'words':'語群：動詞 ／ <span class="en">ed</span> ／ <span class="en">went</span> ／ <span class="en">i</span> ／ <span class="en">was</span> ／ <span class="en">were</span> ／ いっしょに',
   'exp':'<b>なぜ？</b>　日本語では「行く→行った」「です→でした」と<b>語尾</b>が変わります。英語も同じで、変わるのは<b>動詞だけ</b>。<br>'
         '主語（<span class="en">I・They</span>）はそのままなので、動詞に集中すれば過去の文はつくれます。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　過去形に直そう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>ed をつけるか、形ごと変わるか</b>を見分けましょう。',
   'body':grid2([
     '1. <span class="en">visit → %s</span>' % bl('visited', False),
     '2. <span class="en">go → %s</span>' % bl('went'),
     '3. <span class="en">play → %s</span>' % bl('played', False),
     '4. <span class="en">see → %s</span>' % bl('saw'),
     '5. <span class="en">study → %s</span>' % bl('studied', False),
     '6. <span class="en">eat → %s</span>' % bl('ate'),
     '7. <span class="en">like → %s</span>' % bl('liked'),
     '8. <span class="en">am → %s</span>' % bl('was'),
     '9. <span class="en">enjoy → %s</span>' % bl('enjoyed', False),
     '10. <span class="en">are → %s</span>' % bl('were'),
   ]),
   'exp':'<b>見分け方</b>　<span class="en">ed</span> をつけるだけ → 1・3・9　　<span class="en">e</span> のあとは <span class="en">d</span> だけ → 7<br>'
         '<b>子音＋y</b> は <span class="en">y</span> を <span class="en">i</span> に → 5　　<b>形が変わる</b> → 2・4・6<br>'
         'be動詞 → 8（<span class="en">was</span>）・10（<span class="en">were</span>）'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. I went to the store.','○'), ('2. I was went to the store.','✕'),
     ('3. They were happy.','○'), ('4. They was happy.','✕'),
     ('5. I studied English.','○'), ('6. I studyed English.','✕'),
     ('7. How was your trip?','○'), ('8. I visit my grandparents yesterday.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">I went to the store.</span>（<span class="en">was</span> をとる）<br>'
         '4 → <span class="en">They were happy.</span>（<span class="en">They</span> は <span class="en">were</span>）　6 → <span class="en">I studied English.</span>（<span class="en">y</span> → <span class="en">i</span>）<br>'
         '8 → <span class="en">I visited my grandparents yesterday.</span>（<span class="en">yesterday</span> があるので過去形）'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'<b>動作のことば</b>なら一般動詞の過去形。<b>「～だった」</b>なら <span class="en">was・were</span>。',
   'body':grid2([
     '1. <span class="en">I （ア went ／イ was went） to the park.</span>%s' % bl('ア'),
     '2. <span class="en">They （ア was ／イ were） really interested.</span>%s' % bl('イ'),
     '3. <span class="en">I （ア studyed ／イ studied） English.</span>%s' % bl('イ'),
     '4. <span class="en">How （ア was ／イ were） your trip?</span>%s' % bl('ア'),
     '5. <span class="en">We （ア ate ／イ eated） lunch.</span>%s' % bl('ア'),
     '6. <span class="en">He （ア were ／イ was） busy last week.</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　1・5 は動作のことば。<span class="en">was</span> を足したり <span class="en">ed</span> をつけたりしません。<br>'
         '2・4・6 は「～だった」。主語で <span class="en">was</span>（1人・1つ）と <span class="en">were</span>（2人以上・<span class="en">you</span>）を分けます。<br>'
         '3 は <b>子音＋y</b> のつづりの変化です。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　「した」は一般動詞の過去形、「だった」は <span class="en">was・were</span>。',
   'body':ol([
     ('<span class="jp-cue">わたしは店へ行きました。</span>　<span class="en">I%sto the store.</span>' % bl('went'),
      '<span class="en">go</span> は形が変わる。<b><span class="en">went</span></b>。'),
     ('<span class="jp-cue">わたしは祖父母をたずねました。</span>　<span class="en">I%smy grandparents.</span>' % bl('visited', False),
      '<span class="en">visit</span> はそのまま <b><span class="en">ed</span></b>。'),
     ('<span class="jp-cue">旅行はどうでしたか。</span>　<span class="en">How%syour trip?</span>' % bl('was'),
      '<span class="en">your trip</span> は1つ。<b><span class="en">was</span></b>。'),
     ('<span class="jp-cue">彼らは興味がありました。</span>　<span class="en">They%sinterested.</span>' % bl('were'),
      '<span class="en">They</span> は2人以上。<b><span class="en">were</span></b>。'),
     ('<span class="jp-cue">わたしは英語を勉強しました。</span>　<span class="en">I%sEnglish.</span>' % bl('studied', False),
      '<span class="en">y</span> を <span class="en">i</span> にして <span class="en">ed</span>。'),
     ('<span class="jp-cue">わたしはきのう忙しかったです。</span>　<span class="en">I%sbusy yesterday.</span>' % bl('was'),
      '「忙しかった」は <b><span class="en">was busy</span></b>。'),
     ('<span class="jp-cue">わたしたちは昼食を食べました。</span>　<span class="en">We%slunch.</span>' % bl('ate'),
      '<span class="en">eat</span> → <b><span class="en">ate</span></b>。形が変わる。'),
     ('<span class="jp-cue">わたしは先週、映画を見ました。</span>　<span class="en">I%sa movie%sweek.</span>' % (bl('saw'), bl('last')),
      '（　）が2つ。<span class="en">see</span> → <b><span class="en">saw</span></b>、「先週」は <b><span class="en">last week</span></b>。'),
     ('<span class="jp-cue">彼は2日前、ここにいました。</span>　<span class="en">He%shere two days%s.</span>' % (bl('was'), bl('ago')),
      '「～前に」は数のうしろに <b><span class="en">ago</span></b>。'),
     ('<span class="jp-cue">わたしはサッカーを楽しみました。</span>　<span class="en">I%ssoccer.</span>' % bl('enjoyed', False),
      '<span class="en">enjoy</span> はそのまま <span class="en">ed</span>。<span class="en">y</span> の前が母音なので <span class="en">i</span> にしない。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　主語 → 動詞（過去形）→ そのほか、の順。文の終わりはピリオド。',
   'body':ol([
     ('<span class="jp-cue">わたしは店へ行きました。</span>　<span class="paren en">（ to the store / went / I ）</span>' + line('I went to the store.'),
      '主語 <span class="en">I</span> → 動詞 <span class="en">went</span> の順。'),
     ('<span class="jp-cue">わたしは祖父母をたずねました。</span>　<span class="paren en">（ my grandparents / I / visited ）</span>' + line('I visited my grandparents.'),
      '<span class="en">visited</span> のうしろに「だれを」。'),
     ('<span class="jp-cue">あなたの旅行はどうでしたか。</span>　<span class="paren en">（ your trip / How / was ）</span>' + line('How was your trip?'),
      '<span class="en">How</span> → <span class="en">was</span> → 主語 の順。終わりは <b>?</b>。'),
     ('<span class="jp-cue">彼らは日本にとても興味がありました。</span>　<span class="paren en">（ interested in Japan / They / really / were ）</span>' + line('They were really interested in Japan.'),
      '<span class="en">really</span> は <span class="en">interested</span> の前に置く。'),
     ('<span class="jp-cue">わたしはきのう英語を勉強しました。</span>　<span class="paren en">（ English / studied / yesterday / I ）</span>' + line('I studied English yesterday.'),
      '「いつ」はいちばん後ろ。'),
     ('<span class="jp-cue">わたしたちは先週、映画を見ました。</span>　<span class="paren en">（ last week / a movie / We / saw ）</span>' + line('We saw a movie last week.'),
      '<span class="en">saw</span> → 「何を」 → 「いつ」の順。'),
     ('<span class="jp-cue">彼は2日前、忙しかったです。</span>　<span class="paren en">（ two days ago / He / busy / was ）</span>' + line('He was busy two days ago.'),
      '<span class="en">was</span> のうしろは「どんなか」。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしは店へ行きました。' + wline('I went to the store.'),
      '<span class="en">go</span> → <span class="en">went</span>。'),
     ('わたしは祖父母をたずねました。' + wline('I visited my grandparents.'),
      '<span class="en">was</span> を足さないこと。'),
     ('旅行はどうでしたか。' + wline('How was your trip?'),
      '<span class="en">How were</span> にしない。'),
     ('彼らは日本に興味がありました。' + wline('They were interested in Japan.'),
      '<span class="en">They</span> は <span class="en">were</span>。'),
     ('わたしはきのう英語を勉強しました。' + wline('I studied English yesterday.'),
      '<span class="en">studyed</span> と書かない。'),
     ('わたしたちは先週、昼食を食べました。' + wline('We ate lunch last week.'),
      '<span class="en">eat</span> → <span class="en">ate</span>。'),
   ]),
   'words':'<span class="en">went ／ visited ／ How was ／ were interested in ／ studied ／ ate</span>'},
  'l4':{'sub':'きのう、または先週したことを書こう',
   'cond':['一般動詞の過去形を使った文を <b>2つ以上</b>',
           '<span class="en">was</span> か <span class="en">were</span> を使った文を <b>1つ</b>',
           '「いつのことか」を表すことばを <b>1つ以上</b> 入れる'],
   'example':['I went to the park yesterday.','I played soccer with my friends.','It was really fun.'],
   'note':'これは例です。同じでなくてかまいません。「どこで」「だれと」を足すと、文がくわしくなります。',
   'check':['動詞を過去形にした','was・were と 動作のことばを重ねていない','つづりの変化（studied など）','いつのことかを書いた'],
   'review':'じぶんの文の動詞に○をつけよう。<span class="en">was</span> のうしろに動作のことばがあったら、そこがまちがい。'},
 },
}
