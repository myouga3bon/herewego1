# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox

S = {
 'id':'g2-u8-2', 'grade':2, 'unit':'8 − 2', 'unit_plain':'8-2',
 'title':'make ＋ 人 ＋ 形容詞／call A B', 'pages':'p.104〜105',
 'hero_big':'This song makes me happy.',
 'hero_jp':'この歌は わたしを うれしく させます',
 'motto':'<b><span class="en">make ＋ 人 ＋ 形容詞</span></b> ＝「（人）を～にする」。<b><span class="en">call A B</span></b> ＝「A を B とよぶ」。',
 'kana':{'make':'メイク','makes':'メイクス','made':'メイド','call':'コール','calls':'コールズ',
         'called':'コールド','nervous':'ナーバス','happy':'ハッピー','sad':'サッド',
         'angry':'アングリー','famous':'フェイマス','cat':'キャット','Momo':'モモ',
         'name':'ネイム','news':'ニューズ','song':'ソング','me':'ミー','him':'ヒム','her':'ハー'},
 'blocks':[
  ('きほんの文', [
    ('t','「この歌は わたしを <b>うれしく させる</b>」「ねこを <b>モモと よぶ</b>」のように、動詞のうしろに<b>2つことばをならべる</b>形です。'),
    ('t','使う動詞で、2つめに置くものがちがいます。'),
    ('h', gitem('❶', '<span class="en">make ＋ 人 ＋ ようすのことば</span>', '「（人）を～にする」',
                'わたしを うれしく させる', 'makes me happy',
                [('This song makes me happy.','この歌は わたしを うれしく させます。'),
                 ('That makes me nervous.','それは わたしを きんちょうさせます。')],
                '2つめは <b>ようすのことば</b>（<span class="en">happy・nervous</span>）。間に <span class="en">to</span> や <span class="en">is</span> は<b>入れません</b>。')),
    ('h', gitem('❷', '<span class="en">call ＋ A ＋ B</span>', '「A を B とよぶ」',
                'ねこを モモと よぶ', 'call our cat Momo',
                [('We call our cat Momo.','わたしたちは ねこを モモと よびます。'),
                 ('We call him Ken.','わたしたちは 彼を ケンと よびます。')],
                '2つめは <b>名前</b>。<b>よぶもの → 名前</b> の順です。', b2=True)),
    ('t','どちらも<b>うしろの2つはイコール</b>。「わたし＝うれしい」「ねこ＝モモ」という関係になっています。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜うしろの2つは <b>イコール</b>', [
    ('t','ここが今回のヤマです。動詞のうしろの <b>2つのことばは、イコールの関係</b>になります。'),
    ('h','''<div class="eqbox">
      <span class="eq">That makes</span> <span class="eq" style="color:var(--gv);">me</span> ＝ <span class="eq" style="color:var(--gv);">nervous</span><br>
      <span class="eq">We call</span> <span class="eq" style="color:var(--gv);">our cat</span> ＝ <span class="eq" style="color:var(--gv);">Momo</span>
    </div>'''),
    ('t','「わたし＝きんちょうしている」「ねこ＝モモ」。つまり<b>うしろのことばが、前のことばを説明</b>しています。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ 2つならべる<small>間に何も入れない</small></span></div>
        <div class="in"><div class="ex">That makes me happy.<br>We call him Ken.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ 余計な語を入れる<small>to・is を足す</small></span></div>
        <div class="in"><div class="ex">That makes me to happy.<br>We call him is Ken.</div></div>
      </div>
    </div>'''),
    ('t','<span class="en">to</span> も <span class="en">is</span> も入りません。<b>そのままならべる</b>だけです。'),
  ]),
  ('テストによく出ることば', [
    ('t','気持ちを表すことばと組み合わせて、よく使います。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">makes me happy</span></td><td class="k">わたしを うれしくさせる</td><td class="e">The song <u>makes me happy</u>.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">makes me sad</span></td><td class="k">わたしを 悲しくさせる</td><td class="e">The news <u>makes me sad</u>.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">call ～ …</span></td><td class="k">～を …とよぶ</td><td class="e">We <u>call</u> our cat <u>Momo</u>.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">nervous</span></td><td class="k">きんちょうした</td><td class="e">That makes me <u>nervous</u>.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">makes me happy</span> ・ <span class="en">makes me sad</span> ・ <span class="en">call ～ …</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('<span class="en">make</span> と <span class="en">call</span> のちがい', [
    ('t','うしろの2つめにくることばが、少しちがいます。'),
    ('h','''<table class="kind">
      <thead><tr><th>動詞</th><th>2つめ</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k" style="color:var(--key);font-weight:700;">make</td><td class="k">ようすのことば<br>（形容詞）</td><td class="e">That makes me <u>happy</u>.</td></tr>
        <tr><td class="k" style="color:var(--gv);font-weight:700;">call</td><td class="k">名前</td><td class="e">We call him <u>Ken</u>.</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">make</span> は<b>どんな気持ちになるか</b>、<span class="en">call</span> は<b>なんとよぶか</b>です。'),
  ]),
  ('主語が人でなくてもよい', [
    ('t','この形では、<b>主語がものやことがら</b>になることがよくあります。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">The song</span> makes me happy.（その歌が→うれしくさせる）<br>
      <span class="eq" style="color:var(--gv);">The news</span> made me sad.（そのニュースが→悲しくさせた）
    </div>'''),
    ('t','日本語では「その歌を聞くと うれしい」と言いますが、英語は<b>ものを主語にする</b>のが得意です。'),
  ]),
 ],
 'quiz':[
  ('That makes me to nervous.','That makes me nervous.','<span class="en">to</span> は<b>入りません</b>。2つならべるだけ。','それは わたしを きんちょうさせます。'),
  ('That makes I nervous.','That makes me nervous.','はさむ人は <b><span class="en">me</span></b> の形。','それは わたしを きんちょうさせます。'),
  ('That make me nervous.','That makes me nervous.','主語が <span class="en">That</span> なので <b><span class="en">makes</span></b>。','それは わたしを きんちょうさせます。'),
  ('We call Momo our cat.','We call our cat Momo.','<b>よぶもの → 名前</b>の順。','わたしたちは ねこを モモと よびます。'),
  ('We call our cat is Momo.','We call our cat Momo.','<span class="en">is</span> は<b>入りません</b>。','わたしたちは ねこを モモと よびます。'),
  ('The news made me to sad.','The news made me sad.','<span class="en">to</span> を入れません。<span class="en">made</span> は <span class="en">make</span> の過去形。','そのニュースは わたしを 悲しくさせました。'),
 ],
 'summary':[
  '<b><span class="en">make ＋ 人 ＋ ようすのことば</span></b> ＝「（人）を～にする」。',
  '<b><span class="en">call ＋ A ＋ B</span></b> ＝「A を B とよぶ」。',
  'うしろの<b>2つはイコール</b>。<span class="en">to</span> や <span class="en">is</span> は入れない。',
  'はさむ人は <b><span class="en">me・him・her</span></b> の形。主語はものでもよい。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「（人）を～にする」は、<span class="en">make</span> ＋ 人 ＋%sのことば で表す。' % bl('ようす'),
     '「A を B とよぶ」は、<span class="en">call</span> ＋ A ＋%sで表す。' % bl('B'),
     '動詞のうしろの2つは、%sの関係になっている。' % bl('イコール'),
     '2つの間に <span class="en">to</span> や%sは入れない。' % bl('is'),
     'はさむ人は <span class="en">I</span> ではなく%sの形を使う。' % bl('me'),
   ]),
   'words':'語群：ようす ／ <span class="en">B</span> ／ イコール ／ <span class="en">is</span> ／ <span class="en">me</span>',
   'exp':'<b>なぜ？</b>　<span class="en">That makes me</span> だけでは「それがわたしを作る」になってしまいます。<br>'
         'そこに <span class="en">nervous</span> を足して「<b>どんなわたしになるか</b>」を説明しているのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　（　）に1語ずつ書こう<em>イコールの関係に注意</em></h3>',
   'hint':'ここが<b>かなり大事</b>。間に <span class="en">to</span> や <span class="en">is</span> を<b>入れません</b>。',
   'body':grid2([
     '1. <span class="en">That%sme nervous.</span>（きんちょうさせる）' % bl('makes'),
     '2. <span class="en">The song makes%shappy.</span>（わたしを）' % bl('me'),
     '3. <span class="en">The news made me%s.</span>（悲しい）' % bl('sad'),
     '4. <span class="en">We%sour cat Momo.</span>（よぶ）' % bl('call'),
     '5. <span class="en">We call%sKen.</span>（彼を）' % bl('him'),
     '6. <span class="en">That makes%sangry.</span>（彼女を）' % bl('her'),
     '7. <span class="en">The song%sme happy.</span>（主語は The song）' % bl('makes'),
     '8. <span class="en">They%shim Bob.</span>（よぶ）' % bl('call'),
     '9. <span class="en">The news%sme sad.</span>（過去の文）' % bl('made'),
     '10. <span class="en">That makes me%s.</span>（きんちょうした）' % bl('nervous', False),
   ]),
   'exp':'<b>かくにん</b>　1・7 は主語が 3人ざきの単数なので <span class="en">makes</span>。<br>'
         '9 は過去なので <span class="en">made</span>。2・5・6 は <span class="en">me・him・her</span> の形です。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. That makes me nervous.','○'), ('2. That makes me to nervous.','✕'),
     ('3. We call our cat Momo.','○'), ('4. We call our cat is Momo.','✕'),
     ('5. The song makes me happy.','○'), ('6. That make me nervous.','✕'),
     ('7. The news made me sad.','○'), ('8. That makes I nervous.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">to</span> を取る　4 → <span class="en">is</span> を取る<br>'
         '6 → <span class="en">makes</span>　8 → <span class="en">me</span>'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'<span class="en">make</span> は<b>ようす</b>、<span class="en">call</span> は<b>名前</b>がうしろにきます。',
   'body':grid2([
     '1. <span class="en">That makes me （ア nervous ／イ to nervous）.</span>%s' % bl('ア'),
     '2. <span class="en">We call （ア Momo our cat ／イ our cat Momo）.</span>%s' % bl('イ'),
     '3. <span class="en">That （ア makes ／イ make） me happy.</span>%s' % bl('ア'),
     '4. <span class="en">That makes （ア I ／イ me） sad.</span>%s' % bl('イ'),
     '5. <span class="en">The news （ア made ／イ make） me sad.</span>（過去）%s' % bl('ア'),
     '6. <span class="en">We call him （ア is Ken ／イ Ken）.</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　2 は「ねこ→モモ」の順。6 は <span class="en">is</span> を入れません。<br>'
         '1 も <span class="en">to</span> なしです。どれも<b>そのままならべる</b>のがポイント。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　動詞 → 人 → ようす（または名前）の順に、そのままならべる。',
   'body':ol([
     ('<span class="jp-cue">それはわたしをきんちょうさせます。</span>　<span class="en">That%sme nervous.</span>' % bl('makes'),
      '主語は <span class="en">That</span>。'),
     ('<span class="jp-cue">その歌はわたしをうれしくさせます。</span>　<span class="en">The song makes%shappy.</span>' % bl('me'),
      '<span class="en">I</span> にしない。'),
     ('<span class="jp-cue">そのニュースはわたしを悲しくさせました。</span>　<span class="en">The news%sme sad.</span>' % bl('made'),
      '過去の形。'),
     ('<span class="jp-cue">わたしたちはねこをモモとよびます。</span>　<span class="en">We%sour cat Momo.</span>' % bl('call'),
      'よぶもの → 名前。'),
     ('<span class="jp-cue">わたしたちは彼をケンとよびます。</span>　<span class="en">We call%sKen.</span>' % bl('him'),
      '<span class="en">he</span> にしない。'),
     ('<span class="jp-cue">それは彼女をおこらせます。</span>　<span class="en">That makes%sangry.</span>' % bl('her'),
      '<span class="en">she</span> にしない。'),
     ('<span class="jp-cue">それはわたしをきんちょうさせます。</span>　<span class="en">That makes me%s.</span>' % bl('nervous', False),
      '<span class="en">to</span> はいらない。'),
     ('<span class="jp-cue">彼らは彼をボブとよびます。</span>　<span class="en">They%shim%s.</span>' % (bl('call'), bl('Bob')),
      '（　）が2つ。'),
     ('<span class="jp-cue">その歌は彼をうれしくさせます。</span>　<span class="en">The song%shim happy.</span>' % bl('makes'),
      '<span class="en">s</span> を忘れない。'),
     ('<span class="jp-cue">そのニュースは彼女を悲しくさせました。</span>　<span class="en">The news made%ssad.</span>' % bl('her'),
      '人の形。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　主語 → 動詞 → 人 → ようす（名前）。間に余計な語を入れない。',
   'body':ol([
     ('<span class="jp-cue">それはわたしをきんちょうさせます。</span>　<span class="paren en">（ nervous / That makes / me ）</span>' + line('That makes me nervous.'),
      'そのままならべる。'),
     ('<span class="jp-cue">その歌はわたしをうれしくさせます。</span>　<span class="paren en">（ happy / me / The song makes ）</span>' + line('The song makes me happy.'),
      '人 → ようす。'),
     ('<span class="jp-cue">わたしたちはねこをモモとよびます。</span>　<span class="paren en">（ Momo / our cat / We call ）</span>' + line('We call our cat Momo.'),
      'よぶもの → 名前。'),
     ('<span class="jp-cue">そのニュースはわたしを悲しくさせました。</span>　<span class="paren en">（ sad / The news made / me ）</span>' + line('The news made me sad.'),
      '<span class="en">made</span> は過去形。'),
     ('<span class="jp-cue">わたしたちは彼をケンとよびます。</span>　<span class="paren en">（ Ken / We call / him ）</span>' + line('We call him Ken.'),
      '<span class="en">him</span> の形。'),
     ('<span class="jp-cue">それは彼女をおこらせます。</span>　<span class="paren en">（ angry / her / That makes ）</span>' + line('That makes her angry.'),
      '<span class="en">her</span> の形。'),
     ('<span class="jp-cue">その歌は彼をうれしくさせます。</span>　<span class="paren en">（ happy / him / The song makes ）</span>' + line('The song makes him happy.'),
      '<span class="en">makes</span> の <span class="en">s</span>。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('それはわたしをきんちょうさせます。' + wline('That makes me nervous.'),
      '<span class="en">to</span> を入れない。'),
     ('その歌はわたしをうれしくさせます。' + wline('The song makes me happy.'),
      '<span class="en">makes</span> の <span class="en">s</span>。'),
     ('わたしたちはねこをモモとよびます。' + wline('We call our cat Momo.'),
      'よぶもの → 名前。'),
     ('そのニュースはわたしを悲しくさせました。' + wline('The news made me sad.'),
      '過去形は <span class="en">made</span>。'),
     ('わたしたちは彼をケンとよびます。' + wline('We call him Ken.'),
      '<span class="en">he</span> にしない。'),
     ('それは彼女をおこらせます。' + wline('That makes her angry.'),
      '<span class="en">she</span> にしない。'),
   ]),
   'words':'<span class="en">makes me nervous ／ makes me happy ／ call our cat Momo ／ made me sad ／ call him Ken ／ makes her angry</span>'},
  'l4':{'sub':'気持ちが動くことを書こう',
   'cond':['<span class="en">make ＋ 人 ＋ ようすのことば</span> の文を <b>2つ以上</b>',
           '<span class="en">call A B</span> の文を <b>1つ</b>',
           'ようすのことばを <b>2種類以上</b>（<span class="en">happy・sad・nervous・angry</span> など）'],
   'example':['Music makes me happy.','Tests make me nervous.','My friends call me Micchan.'],
   'note':'これは例です。同じでなくてかまいません。すきなもの・にがてなものを思い出すと書きやすいです。',
   'check':['2つならべた','to や is を入れていない','人は me・him・her の形','主語が単数なら makes'],
   'review':'じぶんの文の動詞のうしろ2つを○でかこみ、イコールになっているか見よう。'},
 },
}
