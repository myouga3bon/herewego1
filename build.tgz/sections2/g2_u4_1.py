# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'g2-u4-1', 'grade':2, 'unit':'4 − 1', 'unit_plain':'4-1',
 'title':'There is ／ There are', 'pages':'p.50〜51',
 'hero_big':'There is a book on the desk.',
 'hero_jp':'机の上に 本が あります',
 'motto':'<span class="en">There is / are</span> は <b>「ある・いる」</b>。be動詞は <b>うしろの名前の数</b>で決まる。',
 'kana':{'there':'ゼア','garden':'ガーデン','near':'ニア','several':'セヴラル',
         'books':'ブックス','big':'ビッグ','park':'パーク','cat':'キャット',
         'cats':'キャッツ','book':'ブック','books':'ブックス','desk':'デスク',
         'room':'ルーム','many':'メニィ','some':'サム','any':'エニィ',
         'is':'イズ','are':'アー','was':'ワズ','were':'ワー'},
 'blocks':[
  ('きほんの文', [
    ('t','「～が ある・いる」と、<b>はじめて話に出すもの</b>を紹介するときの形です。<span class="en">There</span> は「そこに」とは訳しません。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">There is a book on the desk.</span><span class="t">机の上に 本が あります。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Is there a book on the desk?</span><span class="t">机の上に 本が ありますか。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">— Yes, there is. ／ No, there isn&#39;t.</span><span class="t">— はい、あります。／ いいえ、ありません。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">There are two books on the desk.</span><span class="t">机の上に 本が 2さつ あります。</span></div>
    </div>'''),
    ('t','1つなら <span class="en">There is</span>、2つ以上なら <span class="en">There are</span> です。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜be動詞は<b>うしろ</b>の数で決まる', [
    ('t','ここが今回のヤマです。ふつうの文は<b>前の主語</b>で be動詞が決まりますが、この文だけは<b>うしろの名前</b>で決まります。'),
    ('h','''<div class="eqbox">
      There <span class="eq" style="color:var(--key);">is</span> <span class="eq">a big garden</span>.（1つ → <span class="en">is</span>）<br>
      There <span class="eq" style="color:var(--key);">are</span> <span class="eq">three books</span>.（2つ以上 → <span class="en">are</span>）
    </div>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ うしろを見る<small>a garden / three books</small></span></div>
        <div class="in"><div class="ex">There is a garden.<br>There are two cats.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ There を主語あつかい<small>いつも is にしてしまう</small></span></div>
        <div class="in"><div class="ex">There is two cats.<br>There are a garden.</div></div>
      </div>
    </div>'''),
    ('t','<span class="en">There</span> は<b>場所ではなく、合図のことば</b>です。だから数の判断には使いません。'),
  ]),
  ('テストによく出ることば', [
    ('t','4つの形をセットでおぼえましょう。<b>たずねる文は <span class="en">Is</span> を前に出すだけ</b>です。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>使うとき</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">There is</span></td><td class="k">1つあるとき</td><td class="e"><u>There is</u> a garden.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">There are</span></td><td class="k">2つ以上あるとき</td><td class="e"><u>There are</u> two cats.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">Is there</span></td><td class="k">たずねる文</td><td class="e"><u>Is there</u> a garden?</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">There isn&#39;t</span></td><td class="k">打ち消し</td><td class="e"><u>There isn&#39;t</u> a garden.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">There is</span> ・ <span class="en">There are</span> ・ <span class="en">Is there</span> ・ <span class="en">There isn&#39;t</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('たずねる文・打ち消し・答え方', [
    ('t','be動詞の文なので、<b>1年生のルールがそのまま使えます</b>。答えにも <span class="en">there</span> を入れるのがポイントです。'),
    ('h','''<table class="kind">
      <thead><tr><th>作る文</th><th>やり方</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k">たずねる文</td><td class="k" style="color:var(--ng);font-weight:700;">be動詞を前に出す</td><td class="e"><u>Is there</u> a garden?</td></tr>
        <tr><td class="k">打ち消し</td><td class="k" style="color:var(--ng);font-weight:700;">be動詞のうしろに not</td><td class="e">There <u>isn&#39;t</u> a garden.</td></tr>
        <tr><td class="k">答え方</td><td class="k">there を入れて返す</td><td class="e">— Yes, <u>there is</u>. ／ No, <u>there isn&#39;t</u>.</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">Yes, it is.</span> とは答えません。<b><span class="en">Yes, there is.</span></b> です。'),
  ]),
  ('過去のことを言うとき', [
    ('t','過去にするときは、be動詞を <span class="en">was・were</span> に変えるだけです。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">There was a garden.</span>（庭が ありました）<br>
      <span class="eq" style="color:var(--gv);">There were two cats.</span>（ねこが 2ひき いました）
    </div>'''),
    ('t','数の決め方は同じです。<b>1つなら <span class="en">was</span>、2つ以上なら <span class="en">were</span></b>。'),
  ]),
 ],
 'quiz':[
  ('There is two cats.','There are two cats.','うしろが <span class="en">two cats</span>（2ひき）なので <b><span class="en">are</span></b>。','ねこが 2ひき います。'),
  ('There are a garden.','There is a garden.','うしろが <span class="en">a garden</span>（1つ）なので <b><span class="en">is</span></b>。','庭が あります。'),
  ('Is there a garden? — Yes, it is.','Is there a garden? — Yes, there is.','答えにも <b><span class="en">there</span></b> を入れます。','庭が ありますか。— はい、あります。'),
  ('Do you have there a garden?','Is there a garden?','be動詞の文なので <b><span class="en">Is</span> を前に出す</b>だけです。','庭が ありますか。'),
  ('There have a garden.','There is a garden.','<span class="en">have</span> は使いません。<b>be動詞</b>を使います。','庭が あります。'),
  ('There were a garden.','There was a garden.','うしろが1つなので <b><span class="en">was</span></b>。','庭が ありました。'),
 ],
 'summary':[
  '<b><span class="en">There is / are ～.</span></b> ＝「～が ある・いる」。はじめて出すものを紹介する言い方。',
  'be動詞は <b>うしろの名前の数</b>で決まる。1つ → <span class="en">is</span>、2つ以上 → <span class="en">are</span>。',
  'たずねる文は <b><span class="en">Is there ～?</span></b>。答えも <b><span class="en">Yes, there is.</span></b> と <span class="en">there</span> を入れる。',
  '過去は <b><span class="en">There was / were</span></b>。数の決め方は同じ。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～がある・いる」は <span class="en">There</span>%s～. の形で表す。' % bl('is / are', False),
     'be動詞は、<span class="en">There</span> ではなく%sの名前の数で決める。' % bl('うしろ'),
     '2つ以上あるときは%sを使う。' % bl('are'),
     'たずねる文は、be動詞を%sに出す。' % bl('前'),
     '答えるときも、<span class="en">Yes,</span>%s<span class="en">is.</span> のように入れる。' % bl('there'),
   ]),
   'words':'語群：<span class="en">is / are</span> ／ うしろ ／ <span class="en">are</span> ／ 前 ／ <span class="en">there</span>',
   'exp':'<b>なぜ？</b>　この <span class="en">There</span> は「ほら、あるよ」と<b>合図を送るだけのことば</b>です。中身がありません。<br>'
         'だから文のほんとうの主役は<b>うしろの名前</b>。be動詞はその数に合わせるのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">is</span>？ それとも <span class="en">are</span>？<em>（　）に入るものを書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>うしろの名前の数</b>だけを見ましょう。',
   'body':grid2([
     '1. <span class="en">There%sa big garden.</span>' % bl('is'),
     '2. <span class="en">There%sthree books.</span>' % bl('are'),
     '3. <span class="en">There%stwo cats.</span>' % bl('are'),
     '4. <span class="en">There%sa book on the desk.</span>' % bl('is'),
     '5. <span class="en">There%smany people.</span>' % bl('are'),
     '6. <span class="en">There%sa park near here.</span>' % bl('is'),
     '7. <span class="en">There%sthree books.</span>' % bl('are'),
     '8. <span class="en">There%sa cat in the room.</span>' % bl('is'),
     '9. <span class="en">%sthere a garden?</span>' % bl('Is'),
     '10. <span class="en">%sthere any books?</span>' % bl('Are'),
   ]),
   'exp':'<b>見分け方</b>　<span class="en">a ～</span>（1つ）→ <span class="en">is</span>（1・4・6・8・9）<br>'
         '<span class="en">two・three・several・many</span> や <span class="en">s</span> のついた名前（2つ以上）→ <span class="en">are</span>（2・3・5・7・10）<br>'
         '<span class="en">a</span> が見えたら <span class="en">is</span>、と覚えると速いです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. There is a big garden.','○'), ('2. There are a big garden.','✕'),
     ('3. There are two cats.','○'), ('4. There is two cats.','✕'),
     ('5. Is there a garden?','○'), ('6. Do there a garden?','✕'),
     ('7. Yes, there is.','○'), ('8. Yes, it is.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">There is a big garden.</span>　4 → <span class="en">There are two cats.</span><br>'
         '6 → <span class="en">Is there a garden?</span>（be動詞の文）　8 → <span class="en">Yes, there is.</span>（<span class="en">there</span> を入れる）'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'うしろの名前に <span class="en">a</span> があるか、<span class="en">s</span> がついているかを見よう。',
   'body':grid2([
     '1. <span class="en">There （ア is ／イ are） a big garden.</span>%s' % bl('ア'),
     '2. <span class="en">There （ア is ／イ are） three books.</span>%s' % bl('イ'),
     '3. <span class="en">（ア Do ／イ Is） there a garden?</span>%s' % bl('イ'),
     '4. <span class="en">Is there a cat? — Yes, （ア it is ／イ there is）.</span>%s' % bl('イ'),
     '5. <span class="en">There （ア was ／イ were） two cats.</span>%s' % bl('イ'),
     '6. <span class="en">There （ア isn&#39;t ／イ don&#39;t） a park near here.</span>%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　1・2・5 はうしろの数。3・6 は be動詞の文に <span class="en">do</span> を混ぜないこと。<br>'
         '4 は答え方です。<span class="en">Yes, it is.</span> と言いたくなりますが、<span class="en">there</span> を使います。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　<span class="en">There</span> の<b>うしろ</b>を先に見て、1つか2つ以上かを決めよう。',
   'body':ol([
     ('<span class="jp-cue">その近くに大きな庭があります。</span>　<span class="en">There%sa big garden near there.</span>' % bl('is'),
      '<span class="en">a garden</span> は1つ。'),
     ('<span class="jp-cue">本が3さつあります。</span>　<span class="en">There%sthree books.</span>' % bl('are'),
      '<span class="en">several</span> は「いくつかの」。'),
     ('<span class="jp-cue">その近くに大きな庭がありますか。</span>　<span class="en">%sthere a big garden near there?</span>' % bl('Is'),
      'be動詞を前に出す。'),
     ('<span class="jp-cue">はい、あります。</span>　<span class="en">Yes,%sis.</span>' % bl('there'),
      '<span class="en">it</span> ではなく <span class="en">there</span>。'),
     ('<span class="jp-cue">いいえ、ありません。</span>　<span class="en">No, there%s.</span>' % bl("isn't"),
      '打ち消しの短い形。'),
     ('<span class="jp-cue">部屋にねこが2ひきいます。</span>　<span class="en">There%stwo cats in the room.</span>' % bl('are'),
      '<span class="en">two cats</span> は2ひき。'),
     ('<span class="jp-cue">机の上に本が1冊あります。</span>　<span class="en">There is%sbook on the desk.</span>' % bl('a'),
      '1冊なので <span class="en">a</span>。'),
     ('<span class="jp-cue">以前そこに庭がありました。</span>　<span class="en">There%sa garden there before.</span>' % bl('was'),
      '過去で1つなので <span class="en">was</span>。'),
     ('<span class="jp-cue">そこにねこが2ひきいました。</span>　<span class="en">There%stwo cats there.</span>' % bl('were'),
      '過去で2ひきなので <span class="en">were</span>。'),
     ('<span class="jp-cue">この近くに公園はありません。</span>　<span class="en">There%sa park near here.</span>' % bl("isn't"),
      '1つのものを打ち消す。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　<span class="en">There</span> → be動詞 → 名前 → 場所、の順。',
   'body':ol([
     ('<span class="jp-cue">その近くに大きな庭があります。</span>　<span class="paren en">（ a big garden / There is / near there ）</span>' + line('There is a big garden near there.'),
      '場所はいちばん後ろ。'),
     ('<span class="jp-cue">本が3さつあります。</span>　<span class="paren en">（ three books / There / are ）</span>' + line('There are three books.'),
      '<span class="en">are</span> を選ぶ。'),
     ('<span class="jp-cue">その近くに大きな庭がありますか。</span>　<span class="paren en">（ near there / a big garden / Is there ）</span>' + line('Is there a big garden near there?'),
      '<span class="en">Is there</span> が先頭。'),
     ('<span class="jp-cue">部屋にねこが2ひきいます。</span>　<span class="paren en">（ in the room / two cats / There are ）</span>' + line('There are two cats in the room.'),
      '「どこに」は後ろ。'),
     ('<span class="jp-cue">机の上に本が1冊あります。</span>　<span class="paren en">（ on the desk / There is / a book ）</span>' + line('There is a book on the desk.'),
      '<span class="en">a book</span> は1冊。'),
     ('<span class="jp-cue">以前そこに庭がありました。</span>　<span class="paren en">（ a garden / There was / there before ）</span>' + line('There was a garden there before.'),
      '過去形の <span class="en">was</span>。'),
     ('<span class="jp-cue">この近くに公園はありません。</span>　<span class="paren en">（ near here / a park / There isn&#39;t ）</span>' + line('There isn&#39;t a park near here.'),
      '打ち消しの形。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('その近くに大きな庭があります。' + wline('There is a big garden near there.'),
      '<span class="en">a</span> があるので <span class="en">is</span>。'),
     ('本が3さつあります。' + wline('There are three books.'),
      '2つ以上なので <span class="en">are</span>。'),
     ('その近くに大きな庭がありますか。' + wline('Is there a big garden near there?'),
      '<span class="en">Do</span> を使わない。'),
     ('部屋にねこが2ひきいます。' + wline('There are two cats in the room.'),
      '<span class="en">cats</span> の <span class="en">s</span> も忘れずに。'),
     ('以前そこに庭がありました。' + wline('There was a garden there before.'),
      '過去は <span class="en">was</span>。'),
     ('この近くに公園はありません。' + wline('There isn&#39;t a park near here.'),
      '<span class="en">There is not</span> でも正解。'),
   ]),
   'words':'<span class="en">There is ／ There are ／ Is there ／ two cats ／ There was ／ There isn&#39;t</span>'},
  'l4':{'sub':'自分の部屋や教室に何があるかを書こう',
   'cond':['<span class="en">There is ～.</span> の文を <b>1つ以上</b>',
           '<span class="en">There are ～.</span> の文を <b>1つ以上</b>',
           '「どこに」を表すことば（<span class="en">in・on・near</span>）を <b>1つ以上</b> 入れる'],
   'example':['There is a big desk in my room.','There are many books on the desk.','There isn&#39;t a TV in my room.'],
   'note':'これは例です。同じでなくてかまいません。1年生でならった <span class="en">in・on・under・near</span> が使えます。',
   'check':['うしろの数で is / are を決めた','a があるときは is','2つ以上は名前にも s','どこにあるかを書いた'],
   'review':'じぶんの文の <span class="en">There</span> のうしろに○をつけよう。<span class="en">a</span> があるのに <span class="en">are</span> なら、そこがまちがい。'},
 },
}
