# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox, gmap

S = {
 'id':'g2-u5-3', 'grade':2, 'unit':'5 − 3', 'unit_plain':'5-3',
 'title':'It&#39;s … to ～.（形式主語の It）', 'pages':'p.64〜65',
 'hero_big':'It is fun to play soccer.',
 'hero_jp':'サッカーを することは 楽しいです',
 'motto':'<span class="en">It</span> は <b>中身のない仮の主語</b>。ほんとうの主語は うしろの <span class="en">to ～</span>。',
 'kana':{'important':'インポータント','prepare':'プリペア','emergencies':'イマーヂェンスィーズ',
         'easy':'イーズィ','difficult':'ディフィカルト','hard':'ハード','fun':'ファン',
         'necessary':'ネセサリィ','interesting':'インタレスティング','for':'フォー',
         'me':'ミー','us':'アス','him':'ヒム','study':'スタディ','swim':'スウィム',
         'get':'ゲット','up':'アップ','early':'アーリィ','it':'イット'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>サッカーを することは 楽しい</b>」のように、「<b>～することは …だ</b>」と言うときの形です。'),
    ('t','英語では<b>長い主語をきらう</b>ので、先に <span class="en">It</span> を置いて、中身をあとから言います。'),
    ('h', gmap('サッカーを<b>することは</b> 楽しい', 'It is fun <b>to play soccer</b>.',
               '先頭の <b>It</b> は「それ」と<b>訳しません</b>。中身は うしろの <b>to play soccer</b> です。')),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">It is fun to play soccer.</span><span class="t">サッカーを することは 楽しいです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">It is easy to swim.</span><span class="t">泳ぐことは かんたんです。</span></div>
    </div>'''),
    ('t','「<b>だれにとって</b>」を言いたいときは <span class="en">for me</span> を足します（<span class="en">It is easy for me to swim.</span>）。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜<span class="en">It</span> は「仮の主語」', [
    ('t','ここが今回のヤマです。<b>ほんとうの主語は うしろの <span class="en">to ～</span></b>。長いので、先に <span class="en">It</span> を置いているだけです。'),
    ('h','''<div class="eqbox">
      <span class="eq" style="color:var(--gv);">To prepare well</span> <span class="eq">is important.</span>　← これでも正しいが、頭が重い<br>
      <span class="eq" style="color:var(--key);">It</span> <span class="eq">is important</span> <span class="eq" style="color:var(--gv);">to prepare well.</span>　← <span class="en">It</span> を置いて、長い主語をうしろへ
    </div>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ It ＋ ようす ＋ to ～<small>順番が決まっている</small></span></div>
        <div class="in"><div class="ex">It&#39;s easy to swim.<br>It&#39;s important to study.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ to ～ を忘れる<small>何のことか分からない</small></span></div>
        <div class="in"><div class="ex">It&#39;s easy swim.<br>It&#39;s important study.</div></div>
      </div>
    </div>'''),
    ('t','<span class="en">to</span> を忘れると、<b>何がかんたんなのか</b>が分からない文になってしまいます。'),
  ]),
  ('テストによく出ることば', [
    ('t','<span class="en">It&#39;s</span> ＋ ようすのことば ＋ <span class="en">to</span> の<b>3点セット</b>でおぼえましょう。'),
    ('h''','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">It&#39;s important to</span></td><td class="k">～することは大切だ</td><td class="e"><u>It&#39;s important to</u> study.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">It&#39;s easy to</span></td><td class="k">～することはかんたんだ</td><td class="e"><u>It&#39;s easy to</u> swim.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">It&#39;s difficult to</span></td><td class="k">～することはむずかしい</td><td class="e"><u>It&#39;s difficult to</u> get up early.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">for me</span></td><td class="k">わたしにとって</td><td class="e">It&#39;s easy <u>for me</u> to swim.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">It&#39;s important to</span> ・ <span class="en">It&#39;s easy to</span> ・ <span class="en">for me</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('「だれにとって」を言うとき', [
    ('t','「わたしにとって」のように、<b>だれにとってなのか</b>を言いたいときは <span class="en">for ～</span> を入れます。'),
    ('h','''<table class="kind">
      <thead><tr><th>入れる場所</th><th>形</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k">ようすのことばのうしろ</td><td class="k" style="color:var(--gv);font-weight:700;">for ＋ me / him / her</td><td class="e">It&#39;s easy <u>for me</u> to swim.</td></tr>
        <tr><td class="k">入れないとき</td><td class="k">だれにでもあてはまる</td><td class="e">It&#39;s easy to swim.</td></tr>
      </tbody>
    </table>'''),
    ('t'," <span class=\"en\">for</span> のうしろは、4-2 でならった <span class=\"en\">me・him・her・us・them</span> の形です。<span class=\"en\">I</span> ではありません。"),
  ]),
  ('<span class="en">to ～</span> のうしろは 原形（もとの形）', [
    ('t','2-2・4-3 と同じく、<span class="en">to</span> のうしろは<b>かざりのない形</b>です。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      ◯ <span class="eq" style="color:var(--gv);">It&#39;s easy to swim.</span>　✕ <span class="eq">It&#39;s easy to swimming.</span>　✕ <span class="eq">It&#39;s easy to swims.</span>
    </div>'''),
    ('t','<span class="en">to</span> を見たら<b>原形（もとの形）</b>、と手が勝手に動くまで練習しましょう。'),
  ]),
 ],
 'quiz':[
  ('It&#39;s important study every day.','It&#39;s important to study every day.','<b><span class="en">to</span> が抜けています</b>。<span class="en">It&#39;s ～ to ～</span> はセットです。','毎日 勉強することは 大切です。'),
  ('It&#39;s easy to swimming.','It&#39;s easy to swim.','<span class="en">to</span> のうしろは<b>原形（もとの形）</b>。','泳ぐことは かんたんです。'),
  ('It&#39;s easy for I to swim.','It&#39;s easy for me to swim.','<span class="en">for</span> のうしろは <b><span class="en">me</span></b> の形。','わたしにとって 泳ぐことは かんたんです。'),
  ('It&#39;s important to studies every day.','It&#39;s important to study every day.','<span class="en">to</span> のうしろに <span class="en">s</span> はつけません。','毎日 勉強することは 大切です。'),
  ('It easy to swim.','It&#39;s easy to swim.','<b>be動詞が抜けています</b>。<span class="en">It is</span> が必要です。','泳ぐことは かんたんです。'),
  ('Is easy to swim.','It&#39;s easy to swim.','<b>主語の <span class="en">It</span> が抜けています</b>。英語は主語を省けません。','泳ぐことは かんたんです。'),
 ],
 'summary':[
  '<b><span class="en">It&#39;s ＋ ようすのことば ＋ to ＋ 原形（もとの形）</span></b> ＝「～することは…です」。',
  'この <span class="en">It</span> は <b>仮の主語</b>。「それ」とは訳さない。',
  'ほんとうの主語は <b>うしろの <span class="en">to ～</span></b>。',
  '「だれにとって」は <b><span class="en">for me</span></b> のように、ようすのことばのうしろに入れる。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～することは…です」は、%sから始める形で表す。' % bl('It'),
     'この <span class="en">It</span> は%sの主語で、「それ」とは訳さない。' % bl('仮'),
     'ほんとうの主語は、うしろの%s～ の部分である。' % bl('to'),
     '<span class="en">to</span> のうしろは、動詞の%sの形にする。' % bl('もと'),
     '「わたしにとって」は%sを ようすのことばのうしろに入れる。' % bl('for me', False),
   ]),
   'words':'語群：<span class="en">It</span> ／ 仮 ／ <span class="en">to</span> ／ もと ／ <span class="en">for me</span>',
   'exp':'<b>なぜ？</b>　英語は<b>主語が長くなるのをきらいます</b>。<br>'
         '「よく準備すること」のような長い主語を先頭に置くと読みにくいので、<span class="en">It</span> で場所だけ取っておいて、中身はうしろで言うのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　（　）に入るものを書こう<em>1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b><span class="en">It&#39;s</span> ＋ ようす ＋ <span class="en">to</span></b> の3点セットです。',
   'body':grid2([
     '1. <span class="en">%simportant to prepare well.</span>' % bl("It's"),
     '2. <span class="en">It&#39;s easy%sswim.</span>' % bl('to'),
     '3. <span class="en">It&#39;s difficult to%sup early.</span>' % bl('get'),
     '4. <span class="en">It&#39;s easy%sme to swim.</span>' % bl('for'),
     '5. <span class="en">It&#39;s easy for%sto swim.</span>（彼にとって）' % bl('him'),
     '6. <span class="en">It&#39;s fun%splay soccer.</span>' % bl('to'),
     '7. <span class="en">It&#39;s important to%sEnglish.</span>' % bl('study'),
     '8. <span class="en">%sis difficult to read this.</span>' % bl('It'),
     '9. <span class="en">It&#39;s hard for%sto wake up.</span>（わたしたちにとって）' % bl('us'),
     '10. <span class="en">It&#39;s necessary to%swater.</span>' % bl('drink'),
   ]),
   'exp':'<b>かくにん</b>　<span class="en">to</span> のうしろはすべて<b>原形（もとの形）</b>（3・7・10）。<br>'
         '<span class="en">for</span> のうしろは <span class="en">me・him・us</span> の形（4・5・9）。<span class="en">I・he・we</span> にしません。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. It&#39;s easy to swim.','○'), ('2. It&#39;s easy swim.','✕'),
     ('3. It&#39;s easy for me to swim.','○'), ('4. It&#39;s easy for I to swim.','✕'),
     ('5. It&#39;s important to study.','○'), ('6. It&#39;s important to studying.','✕'),
     ('7. It is difficult to get up early.','○'), ('8. Is difficult to get up early.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">to</span> を入れる　4 → <span class="en">for me</span><br>'
         '6 → <span class="en">to study</span>　8 → <span class="en">It</span> を入れる（主語は省けない）'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'<span class="en">It&#39;s</span> ・ <span class="en">to</span> ・ <span class="en">for ～</span> の3つがそろっているか見よう。',
   'body':grid2([
     '1. <span class="en">It&#39;s easy （ア to swim ／イ swim）.</span>%s' % bl('ア'),
     '2. <span class="en">It&#39;s easy for （ア I ／イ me） to swim.</span>%s' % bl('イ'),
     '3. <span class="en">It&#39;s important to （ア study ／イ studying）.</span>%s' % bl('ア'),
     '4. <span class="en">（ア It is ／イ Is） difficult to read this.</span>%s' % bl('ア'),
     '5. <span class="en">It&#39;s hard for （ア we ／イ us） to wake up.</span>%s' % bl('イ'),
     '6. <span class="en">It&#39;s fun to （ア plays ／イ play） soccer.</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　1・3・6 は <span class="en">to</span> とそのうしろの形。2・5 は <span class="en">for</span> のうしろの形です。<br>'
         '4 は<b>主語を省けない</b>という英語のきまりです。日本語では「むずかしいです」と主語なしで言えますが、英語では <span class="en">It</span> が必要です。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　<span class="en">It&#39;s</span> → ようすのことば →（<span class="en">for ～</span>）→ <span class="en">to</span> → 原形（もとの形）。',
   'body':ol([
     ('<span class="jp-cue">よく準備することは大切です。</span>　<span class="en">It&#39;s important%sprepare well.</span>' % bl('to'),
      '<span class="en">to</span> を忘れない。'),
     ('<span class="jp-cue">泳ぐことはかんたんです。</span>　<span class="en">It&#39;s%sto swim.</span>' % bl('easy'),
      '「かんたん」は <span class="en">easy</span>。'),
     ('<span class="jp-cue">早起きすることはむずかしいです。</span>　<span class="en">It&#39;s difficult to%sup early.</span>' % bl('get'),
      '<span class="en">get up</span> で「起きる」。'),
     ('<span class="jp-cue">わたしにとって泳ぐことはかんたんです。</span>　<span class="en">It&#39;s easy%sme to swim.</span>' % bl('for'),
      '「～にとって」は <span class="en">for</span>。'),
     ('<span class="jp-cue">彼にとって泳ぐことはかんたんです。</span>　<span class="en">It&#39;s easy for%sto swim.</span>' % bl('him'),
      '<span class="en">he</span> → <span class="en">him</span>。'),
     ('<span class="jp-cue">サッカーをすることは楽しいです。</span>　<span class="en">It&#39;s%sto play soccer.</span>' % bl('fun'),
      '「楽しい」は <span class="en">fun</span>。'),
     ('<span class="jp-cue">英語を勉強することは大切です。</span>　<span class="en">%simportant to study English.</span>' % bl("It's"),
      '文のはじめは <span class="en">It&#39;s</span>。'),
     ('<span class="jp-cue">わたしたちにとって早起きはたいへんです。</span>　<span class="en">It&#39;s hard for%s%sget up early.</span>' % (bl('us'), bl('to')),
      '（　）が2つ。<span class="en">for us to</span>。'),
     ('<span class="jp-cue">水を飲むことは必要です。</span>　<span class="en">It&#39;s necessary to%swater.</span>' % bl('drink'),
      '<span class="en">drinking</span> にしない。'),
     ('<span class="jp-cue">これを読むことはむずかしいです。</span>　<span class="en">%sis difficult to read this.</span>' % bl('It'),
      '主語の <span class="en">It</span> を忘れない。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　<span class="en">It&#39;s</span> → ようす →（<span class="en">for ～</span>）→ <span class="en">to ～</span> の順にならべよう。',
   'body':ol([
     ('<span class="jp-cue">よく準備することは大切です。</span>　<span class="paren en">（ to prepare well / It&#39;s / important ）</span>' + line('It&#39;s important to prepare well.'),
      '<span class="en">to ～</span> はいちばん後ろ。'),
     ('<span class="jp-cue">泳ぐことはかんたんです。</span>　<span class="paren en">（ to swim / easy / It&#39;s ）</span>' + line('It&#39;s easy to swim.'),
      '3つのかたまりの順。'),
     ('<span class="jp-cue">わたしにとって泳ぐことはかんたんです。</span>　<span class="paren en">（ to swim / for me / It&#39;s easy ）</span>' + line('It&#39;s easy for me to swim.'),
      '<span class="en">for me</span> は <span class="en">to</span> の前。'),
     ('<span class="jp-cue">早起きすることはむずかしいです。</span>　<span class="paren en">（ to get up early / difficult / It&#39;s ）</span>' + line('It&#39;s difficult to get up early.'),
      '<span class="en">get up early</span> でひとかたまり。'),
     ('<span class="jp-cue">サッカーをすることは楽しいです。</span>　<span class="paren en">（ fun / to play soccer / It&#39;s ）</span>' + line('It&#39;s fun to play soccer.'),
      '<span class="en">fun</span> がようすのことば。'),
     ('<span class="jp-cue">彼にとって泳ぐことはかんたんです。</span>　<span class="paren en">（ for him / It&#39;s easy / to swim ）</span>' + line('It&#39;s easy for him to swim.'),
      '<span class="en">for him</span> の位置に注意。'),
     ('<span class="jp-cue">英語を勉強することは大切です。</span>　<span class="paren en">（ to study English / important / It&#39;s ）</span>' + line('It&#39;s important to study English.'),
      'いちばん出やすい形。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('よく準備することは大切です。' + wline('It&#39;s important to prepare well.'),
      '<span class="en">It is</span> でも正解。'),
     ('泳ぐことはかんたんです。' + wline('It&#39;s easy to swim.'),
      '<span class="en">to</span> を忘れない。'),
     ('わたしにとって泳ぐことはかんたんです。' + wline('It&#39;s easy for me to swim.'),
      '<span class="en">for I</span> にしない。'),
     ('早起きすることはむずかしいです。' + wline('It&#39;s difficult to get up early.'),
      '<span class="en">hard</span> でも正解。'),
     ('サッカーをすることは楽しいです。' + wline('It&#39;s fun to play soccer.'),
      '<span class="en">to playing</span> にしない。'),
     ('英語を勉強することは大切です。' + wline('It&#39;s important to study English.'),
      '<span class="en">It</span> を忘れない。'),
   ]),
   'words':'<span class="en">It&#39;s important to ／ It&#39;s easy to ／ for me ／ get up early ／ It&#39;s fun to ／ study English</span>'},
  'l4':{'sub':'自分にとってかんたんなこと・むずかしいことを書こう',
   'cond':['<span class="en">It&#39;s ～ to ～.</span> の文を <b>2つ以上</b>',
           '<span class="en">for me</span> を使った文を <b>1つ以上</b>',
           'ようすのことばを <b>2種類以上</b> 使う（<span class="en">easy・difficult・important・fun</span> など）'],
   'example':['It&#39;s easy for me to run fast.','It&#39;s difficult for me to get up early.','It&#39;s important to practice every day.'],
   'note':'これは例です。同じでなくてかまいません。勉強・部活・家の手伝いなどで書くと書きやすいです。',
   'check':['It&#39;s から始めた','to を入れた','to のうしろは原形（もとの形）','for のうしろは me・him の形'],
   'review':'じぶんの文の <span class="en">to</span> に○をつけよう。<span class="en">to</span> がなければ、そこがまちがい。'},
 },
}
