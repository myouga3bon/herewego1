# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'g2-u2-2', 'grade':2, 'unit':'2 − 2', 'unit_plain':'2-2',
 'title':'不定詞（名詞的用法）', 'pages':'p.22〜23',
 'hero_big':'I want to be a teacher.',
 'hero_jp':'わたしは 先生に なりたいです',
 'motto':'<span class="en">to ＋ 動詞の原形（もとの形）</span> で <b>「～すること」</b>。<span class="en">to</span> のうしろは かざりなしの形。',
 'kana':{'wants':'ワンツ','want':'ワント','soccer':'サッカー','pass':'パス',
         'important':'インポータント','thing':'スィング','need':'ニード','needs':'ニーヅ',
         'try':'トライ','hope':'ホウプ','decided':'ディサイディド','start':'スタート',
         'began':'ビギャン','swim':'スウィム','study':'スタディ','read':'リード',
         'books':'ブックス','doctor':'ダクター','be':'ビー','to':'トゥー'},
 'blocks':[
  ('きほんの文', [
    ('t','「～すること」の言い方は、じつは<b>2つ</b>あります。前回の <span class="en">動詞ing</span> と、今回の <span class="en">to ＋ 動詞の原形（もとの形）</span> です。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I want to be a teacher.</span><span class="t">わたしは 先生に なりたいです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I like to play soccer.</span><span class="t">わたしは サッカーを するのが 好きです。</span></div>
    </div>'''),
    ('t','1年生でならった <span class="en">I want to ～.</span>（～したい）が、この形の代表です。今回はそれを広げて使います。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜<span class="en">to</span> のうしろは「原形（もとの形）」', [
    ('t','ここが今回のヤマです。<span class="en">to</span> のうしろは、<b>かざりのついていない形</b>です。<span class="en">s</span> も <span class="en">ing</span> も <span class="en">ed</span> もつけません。'),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ 原形（もとの形）<small>to ＋ shoot</small></span></div>
        <div class="in"><div class="ex">Ken wants to play soccer.<br>He wants to play soccer.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ かざりつき<small>to ＋ shoots / shooting</small></span></div>
        <div class="in"><div class="ex">Ken wants to plays soccer.<br>He wants to playing soccer.</div></div>
      </div>
    </div>'''),
    ('t','主語が <span class="en">Ken</span> なので <span class="en">wants</span> には <span class="en">s</span> がつきます。でも <span class="en">to</span> のうしろの <span class="en">shoot</span> には<b>つきません</b>。<span class="en">s</span> は1つの文に1回だけです。'),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：<span class="en">to</span> のうしろは かざりのない「原形（もとの形）」</div>
        <p>1年生でならった <b class="cp"><span class="en">can</span>・<span class="en">Do</span>・命令文</b> のうしろと、まったく同じルールです。<br>
        <span class="xm">✕ He wants to shoots ✕</span></p>
      </div>
    </div>'''),
  ]),
  ('テストによく出ることば', [
    ('t','<span class="en">to</span> といっしょによく使う動詞です。<b>2語セット</b>でおぼえましょう。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">want to</span></td><td class="k">～したい</td><td class="e">I <u>want to</u> shoot.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">wants to</span></td><td class="k">he・she のとき</td><td class="e">Ken <u>wants to</u> shoot.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">need to</span></td><td class="k">～する必要がある</td><td class="e">I <u>need to</u> study.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">to be</span></td><td class="k">～になること</td><td class="e">I want <u>to be</u> a doctor.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">want to</span> ・ <span class="en">wants to</span> ・ <span class="en">need to</span> ・ <span class="en">to be</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('<span class="en">動詞ing</span> とのちがい', [
    ('t','どちらも「～すること」ですが、<b>うしろに置ける動詞がちがいます</b>。'),
    ('h','''<table class="kind">
      <thead><tr><th>うしろに置く形</th><th>よく使う動詞</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k" style="color:var(--gv);font-weight:700;">動詞ing だけ</td><td class="k">enjoy・finish</td><td class="e">I <u>enjoy playing</u> soccer.</td></tr>
        <tr><td class="k" style="color:var(--key);font-weight:700;">to ＋ 原形（もとの形）だけ</td><td class="k">want・need・hope</td><td class="e">I <u>want to play</u> soccer.</td></tr>
        <tr><td class="k">どちらでもよい</td><td class="k">like・start</td><td class="e">I <u>like playing</u> ／ <u>like to play</u></td></tr>
      </tbody>
    </table>'''),
    ('t','まずは <b><span class="en">want to</span> はセット、<span class="en">enjoy ～ing</span> もセット</b>とおぼえれば大丈夫です。'),
  ]),
  ('主語や「～です」のうしろにも置ける', [
    ('t','<span class="en">to ～</span> のかたまりも、<b>名前のなかま</b>です。だから <span class="en">is</span> のうしろにも置けます。'),
    ('h','''<div class="eqbox">
      <span class="eq">The important thing</span> <span class="eq" style="color:var(--key);">is</span> <span class="eq" style="color:var(--gv);">to pass the ball</span>.<br>
      大事なこと　＝　ボールをパスすること
    </div>'''),
    ('t','<span class="en">is</span> が「＝」のしるしだという1年生の考え方が、ここでもそのまま使えます。'),
  ]),
 ],
 'quiz':[
  ('He wants to plays soccer.','He wants to play soccer.','<span class="en">to</span> のうしろは<b>原形（もとの形）</b>。<span class="en">s</span> はつけません。','彼は サッカーを したがって います。'),
  ('He want to play soccer.','He wants to play soccer.','主語が <span class="en">He</span> なので <b><span class="en">wants</span></b>。','彼は サッカーを したがって います。'),
  ('I want to swimming.','I want to swim.','<span class="en">to</span> と <span class="en">ing</span> を<b>両方つけません</b>。','わたしは 泳ぎたいです。'),
  ('I want be a doctor.','I want to be a doctor.','<b><span class="en">to</span> が抜けています</b>。<span class="en">want to</span> はセットです。','わたしは 医者に なりたいです。'),
  ('I want to am a doctor.','I want to be a doctor.','<span class="en">am・is・are</span> の原形（もとの形）は <b><span class="en">be</span></b>。','わたしは 医者に なりたいです。'),
  ('My dream is be a teacher.','My dream is to be a teacher.','<span class="en">is</span> と <span class="en">be</span> で<b>心臓が2つ</b>。<span class="en">to</span> をつけて名前のなかまにします。','わたしの 夢は 先生に なることです。'),
 ],
 'summary':[
  '<b><span class="en">to ＋ 動詞の原形（もとの形）</span> ＝「～すること」</b>。',
  '<span class="en">to</span> のうしろは <b>かざりのない形</b>。<span class="en">s</span>・<span class="en">ing</span>・<span class="en">ed</span> をつけない。',
  '<span class="en">want to</span>・<span class="en">need to</span>・<span class="en">hope to</span> はセットでおぼえる。',
  '「～になる」は <b><span class="en">to be</span></b>。<span class="en">to am</span> とは書かない。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～すること」は、%s＋ 動詞の原形（もとの形） で表せる。' % bl('to'),
     '<span class="en">to</span> のうしろの動詞には、%sも <span class="en">ing</span> もつけない。' % bl('s'),
     '主語が <span class="en">he・she</span> のとき、<span class="en">s</span> がつくのは%sのほうだけ。' % bl('want', False),
     '「～になる」は <span class="en">to</span>%sと書く。' % bl('be'),
     '<span class="en">enjoy</span> のうしろは <span class="en">to</span> ではなく%sの形にする。' % bl('ing'),
   ]),
   'words':'語群：<span class="en">to</span> ／ <span class="en">s</span> ／ <span class="en">want</span> ／ <span class="en">be</span> ／ <span class="en">ing</span>',
   'exp':'<b>なぜ？</b>　<span class="en">to</span> はもともと「→（そっちへ向かう）」というしるしです。<br>'
         'これから向かう先なので、まだ起きていません。だから<b>かざりのつかない、まっさらな形</b>を置くのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">to</span> のうしろの形を書こう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>かざりを全部とった形</b>にしましょう。',
   'body':grid2([
     '1. <span class="en">He wants to%s.</span>' % bl('shoot'),
     '2. <span class="en">I want to%sa doctor.</span>' % bl('be'),
     '3. <span class="en">She needs to%s.</span>' % bl('study'),
     '4. <span class="en">I hope to%syou.</span>' % bl('see'),
     '5. <span class="en">He wants to%ssoccer.</span>' % bl('play'),
     '6. <span class="en">I want to%sbooks.</span>' % bl('read'),
     '7. <span class="en">She wants to%s.</span>' % bl('swim'),
     '8. <span class="en">I need to%shome.</span>' % bl('go'),
     '9. <span class="en">He hopes to%sa teacher.</span>' % bl('be'),
     '10. <span class="en">I want to%slunch.</span>' % bl('eat'),
   ]),
   'exp':'<b>かくにん</b>　どれも<b>原形（もとの形）</b>のままです。<span class="en">shoots・studies・playing・went</span> などにはしません。<br>'
         '2・9 の「～になる」は <span class="en">to be</span>。<span class="en">am・is・are</span> の原形（もとの形）が <span class="en">be</span> です。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. Ken wants to play soccer.','○'), ('2. Ken wants to plays soccer.','✕'),
     ('3. I want to be a doctor.','○'), ('4. I want to am a doctor.','✕'),
     ('5. I need to study English.','○'), ('6. I need study English.','✕'),
     ('7. I enjoy playing soccer.','○'), ('8. I enjoy to play soccer.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">shoot</span>（<span class="en">s</span> をとる）　4 → <span class="en">to be</span><br>'
         '6 → <span class="en">need to study</span>（<span class="en">to</span> を入れる）　8 → <span class="en">enjoy playing</span>（<span class="en">enjoy</span> は <span class="en">ing</span>）'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'<span class="en">want・need・hope</span> なら <span class="en">to</span>。<span class="en">enjoy・finish</span> なら <span class="en">ing</span>。',
   'body':grid2([
     '1. <span class="en">Ken wants to （ア shoot ／イ shoots）.</span>%s' % bl('ア'),
     '2. <span class="en">I enjoy （ア to play ／イ playing） soccer.</span>%s' % bl('イ'),
     '3. <span class="en">I want to （ア be ／イ am） a doctor.</span>%s' % bl('ア'),
     '4. <span class="en">She （ア need ／イ needs） to study.</span>%s' % bl('イ'),
     '5. <span class="en">The important thing is （ア to pass ／イ pass） the ball.</span>%s' % bl('ア'),
     '6. <span class="en">I finished （ア to read ／イ reading） the book.</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　1・3・5 は <span class="en">to</span> のうしろの形。2・6 は <span class="en">enjoy・finish</span> なので <span class="en">ing</span>。<br>'
         '4 は主語が <span class="en">She</span> なので <span class="en">needs</span>。<span class="en">s</span> がつくのは<b>前の動詞だけ</b>です。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　<span class="en">to</span> を書いたら、そのうしろは<b>何もつけない形</b>にしよう。',
   'body':ol([
     ('<span class="jp-cue">ケンはサッカーをしたがっています。</span>　<span class="en">Ken%sto play soccer.</span>' % bl('wants'),
      '主語が <span class="en">Ken</span> なので <span class="en">s</span>。'),
     ('<span class="jp-cue">大事なことはボールをパスすることです。</span>　<span class="en">The important thing is%spass the ball.</span>' % bl('to'),
      '<span class="en">is</span> のうしろにも <span class="en">to</span> で置ける。'),
     ('<span class="jp-cue">わたしは医者になりたいです。</span>　<span class="en">I want to%sa doctor.</span>' % bl('be'),
      '「～になる」は <b><span class="en">to be</span></b>。'),
     ('<span class="jp-cue">わたしは英語を勉強する必要があります。</span>　<span class="en">I%sto study English.</span>' % bl('need'),
      '「必要がある」は <span class="en">need to</span>。'),
     ('<span class="jp-cue">彼女は泳ぎたがっています。</span>　<span class="en">She wants to%s.</span>' % bl('swim'),
      '<span class="en">to</span> のうしろは原形（もとの形）。'),
     ('<span class="jp-cue">わたしはサッカーをして楽しみます。</span>　<span class="en">I enjoy%ssoccer.</span>' % bl('playing', False),
      '<span class="en">enjoy</span> のうしろは <span class="en">ing</span>。'),
     ('<span class="jp-cue">彼は先生になりたがっています。</span>　<span class="en">He%sto be a teacher.</span>' % bl('wants'),
      '<span class="en">He</span> なので <span class="en">wants</span>。'),
     ('<span class="jp-cue">わたしはあなたに会いたいです。</span>　<span class="en">I%s%ssee you.</span>' % (bl('want'), bl('to')),
      '（　）が2つ。<span class="en">want to</span> はセット。'),
     ('<span class="jp-cue">わたしは本を読み終えました。</span>　<span class="en">I finished%sthe book.</span>' % bl('reading', False),
      '<span class="en">finish</span> のうしろは <span class="en">ing</span>。'),
     ('<span class="jp-cue">わたしは家に帰る必要があります。</span>　<span class="en">I need to%shome.</span>' % bl('go'),
      '<span class="en">went</span> にしない。原形（もとの形）。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　<span class="en">to ～</span> のかたまりを先に作ってから、前にくっつけよう。',
   'body':ol([
     ('<span class="jp-cue">ケンはサッカーをしたがっています。</span>　<span class="paren en">（ to play soccer / Ken / wants ）</span>' + line('Ken wants to play soccer.'),
      '<span class="en">wants</span> の <span class="en">s</span> に注意。'),
     ('<span class="jp-cue">わたしは医者になりたいです。</span>　<span class="paren en">（ a doctor / want / to be / I ）</span>' + line('I want to be a doctor.'),
      '<span class="en">to be</span> でひとかたまり。'),
     ('<span class="jp-cue">大事なことはボールをパスすることです。</span>　<span class="paren en">（ to pass the ball / The important thing / is ）</span>' + line('The important thing is to pass the ball.'),
      '<span class="en">is</span> が「＝」。'),
     ('<span class="jp-cue">わたしは英語を勉強する必要があります。</span>　<span class="paren en">（ English / to study / I / need ）</span>' + line('I need to study English.'),
      '<span class="en">need to</span> はセット。'),
     ('<span class="jp-cue">彼は先生になりたがっています。</span>　<span class="paren en">（ a teacher / He / to be / wants ）</span>' + line('He wants to be a teacher.'),
      '<span class="en">wants</span> と <span class="en">be</span>、<span class="en">s</span> は前だけ。'),
     ('<span class="jp-cue">わたしはサッカーをして楽しみます。</span>　<span class="paren en">（ soccer / enjoy / I / playing ）</span>' + line('I enjoy playing soccer.'),
      '<span class="en">enjoy</span> は <span class="en">ing</span>。<span class="en">to</span> は入らない。'),
     ('<span class="jp-cue">わたしはあなたに会いたいです。</span>　<span class="paren en">（ you / I / to see / want ）</span>' + line('I want to see you.'),
      '語順は 主語 → <span class="en">want</span> → <span class="en">to</span>。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('ケンはサッカーをしたがっています。' + wline('Ken wants to play soccer.'),
      '<span class="en">to shoots</span> にしない。'),
     ('わたしは医者になりたいです。' + wline('I want to be a doctor.'),
      '<span class="en">to am</span> にしない。'),
     ('大事なことはボールをパスすることです。' + wline('The important thing is to pass the ball.'),
      '<span class="en">to</span> を忘れない。'),
     ('わたしは英語を勉強する必要があります。' + wline('I need to study English.'),
      '<span class="en">need study</span> にしない。'),
     ('彼は先生になりたがっています。' + wline('He wants to be a teacher.'),
      '<span class="en">s</span> は <span class="en">wants</span> だけ。'),
     ('わたしはサッカーをして楽しみます。' + wline('I enjoy playing soccer.'),
      '<span class="en">enjoy to play</span> にしない。'),
   ]),
   'words':'<span class="en">wants to shoot ／ to be a doctor ／ is to pass ／ need to study ／ wants to be ／ enjoy playing</span>'},
  'l4':{'sub':'自分がしたいこと・なりたいものを書こう',
   'cond':['<span class="en">I want to ～.</span> を使った文を <b>1つ以上</b>',
           '<span class="en">I want to be ～.</span>（～になりたい）の文を <b>1つ</b>',
           '<span class="en">need to</span> を使った文も <b>1つ</b> 入れる'],
   'example':['I want to go to Australia.','I want to be a nurse.','I need to study English every day.'],
   'note':'これは例です。同じでなくてかまいません。「そのために何が必要か」まで書くと、文がつながります。',
   'check':['to のうしろは原形（もとの形）','「～になる」は to be','want に s をつけたか（he・she のとき）','to と ing を重ねていない'],
   'review':'じぶんの文の <span class="en">to</span> のうしろに○をつけよう。<span class="en">s</span> や <span class="en">ing</span> がついていたら、そこがまちがい。'},
 },
}
