# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'g2-u8-1', 'grade':2, 'unit':'8 − 1', 'unit_plain':'8-1',
 'title':'want ＋ 人 ＋ 不定詞', 'pages':'p.102〜103',
 'hero_big':'I want you to help me.',
 'hero_jp':'わたしは あなたに 手伝って ほしいです',
 'motto':'<b><span class="en">want ＋ 人 ＋ to ～</span></b> ＝「（人）に～してほしい」。人は <span class="en">me・you・him</span> の形。',
 'kana':{'want':'ワント','wants':'ワンツ','help':'ヘルプ','tell':'テル','ask':'アスク',
         'come':'カム','study':'スタディ','clean':'クリーン','wash':'ウォッシュ',
         'dishes':'ディッシィズ','room':'ルーム','me':'ミー','you':'ユー','him':'ヒム',
         'her':'ハー','them':'ゼム','us':'アス','to':'トゥー'},
 'blocks':[
  ('きほんの文', [
    ('t','2-2 でならった <span class="en">want to ～</span>（～したい）に、<b>人</b>をはさんだ形です。「<b>だれに</b>してほしいか」を言えます。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I want you to help me.</span><span class="t">わたしは あなたに 手伝って ほしいです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I want to help you.</span><span class="t">わたしは あなたを 手伝いたいです。</span></div>
    </div>'''),
    ('t','上は<b>あなたが手伝う</b>、下は<b>わたしが手伝う</b>。人を1つ入れるだけで、<b>する人が変わります</b>。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜<span class="en">to ～</span> をするのは<b>はさんだ人</b>', [
    ('t','ここが今回のヤマです。<span class="en">to</span> のうしろの動作をするのは、<b>主語ではなく、はさんだ人</b>です。'),
    ('h','''<div class="eqbox">
      <span class="eq">I want</span> <span class="eq" style="color:var(--gv);">you</span> <span class="eq">to help me.</span><br>
      「ほしい」のは <b>わたし</b>、「手伝う」のは <b style="color:var(--gv);">あなた</b>
    </div>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ 人 ＋ to ～<small>me・you・him の形</small></span></div>
        <div class="in"><div class="ex">I want you to help me.<br>I want him to come.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ 主語の形<small>he・she を入れる</small></span></div>
        <div class="in"><div class="ex">I want he to come.<br>I want she to help me.</div></div>
      </div>
    </div>'''),
    ('t','はさむ人の形は、4-2 でならった <span class="en">me・you・him・her・us・them</span> です。'),
  ]),
  ('テストによく出ることば', [
    ('t','よく使う形です。<b><span class="en">to</span> のうしろは原形（もとの形）</b>という決まりも変わりません。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">want you to</span></td><td class="k">あなたに～してほしい</td><td class="e">I <u>want you to</u> help me.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">want him to</span></td><td class="k">彼に～してほしい</td><td class="e">I <u>want him to</u> come.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">tell ～ to</span></td><td class="k">～に…するように言う</td><td class="e">I <u>told him to</u> wait.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">ask ～ to</span></td><td class="k">～に…するようにたのむ</td><td class="e">I <u>asked her to</u> help.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">want you to</span> ・ <span class="en">want him to</span> ・ <span class="en">tell ～ to</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('人を入れるかどうかで意味が変わる', [
    ('t','<b>人をはさむかどうか</b>で、だれがするのかが変わります。ここをよく見ましょう。'),
    ('h','''<table class="kind">
      <thead><tr><th>形</th><th>するのはだれ</th><th>意味</th></tr></thead>
      <tbody>
        <tr><td class="e">I want <u>to help</u> you.</td><td class="k" style="color:var(--key);font-weight:700;">わたし</td><td class="k">あなたを手伝いたい</td></tr>
        <tr><td class="e">I want <u>you to help</u> me.</td><td class="k" style="color:var(--gv);font-weight:700;">あなた</td><td class="k">あなたに手伝ってほしい</td></tr>
      </tbody>
    </table>'''),
    ('t','日本語の「～してほしい」が出てきたら、<b>人をはさむ形</b>だと見分けられます。'),
  ]),
  ('仲間の動詞', [
    ('t','<span class="en">want</span> のほかにも、同じ形をとる動詞があります。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">tell ＋ 人 ＋ to ～</span>（～に…するように言う）<br>
      <span class="eq" style="color:var(--gv);">ask ＋ 人 ＋ to ～</span>（～に…するようにたのむ）
    </div>'''),
    ('t','<span class="en">I told him to wait.</span>（彼に待つように言った）のように使います。作りは <span class="en">want</span> と同じです。'),
  ]),
 ],
 'quiz':[
  ('I want he to help me.','I want him to help me.','はさむ人は <b><span class="en">him</span></b> の形。<span class="en">he</span> は主語のときの形です。','わたしは 彼に 手伝って ほしいです。'),
  ('I want you help me.','I want you to help me.','<b><span class="en">to</span> が抜けています</b>。','わたしは あなたに 手伝って ほしいです。'),
  ('I want you to helps me.','I want you to help me.','<span class="en">to</span> のうしろは<b>原形（もとの形）</b>。','わたしは あなたに 手伝って ほしいです。'),
  ('I want you to helping me.','I want you to help me.','<span class="en">to</span> と <span class="en">ing</span> を<b>両方つけません</b>。','わたしは あなたに 手伝って ほしいです。'),
  ('I want that you help me.','I want you to help me.','<span class="en">that</span> は使いません。<b>人 ＋ <span class="en">to</span></b> の形です。','わたしは あなたに 手伝って ほしいです。'),
  ('She want me to help her.','She wants me to help her.','主語が <span class="en">She</span> なので <b><span class="en">wants</span></b>。','彼女は わたしに 手伝って ほしがって います。'),
 ],
 'summary':[
  '<b><span class="en">want ＋ 人 ＋ to ＋ 原形（もとの形）</span></b> ＝「（人）に～してほしい」。',
  '<span class="en">to ～</span> を<b>するのは、はさんだ人</b>。主語ではない。',
  'はさむ人は <b><span class="en">me・you・him・her・us・them</span></b> の形。',
  '<span class="en">tell ＋ 人 ＋ to ～</span>、<span class="en">ask ＋ 人 ＋ to ～</span> も同じ作り。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「（人）に～してほしい」は、<span class="en">want</span> ＋ 人 ＋%s＋ 原形（もとの形） で表す。' % bl('to'),
     '<span class="en">to</span> のうしろの動作をするのは、主語ではなく%sである。' % bl('人'),
     'はさむ人は、<span class="en">he</span> ではなく%sの形を使う。' % bl('him'),
     '<span class="en">to</span> のうしろは動詞の%sの形にする。' % bl('もと'),
     '<span class="en">tell</span> や%sも、同じ形をとる。' % bl('ask'),
   ]),
   'words':'語群：<span class="en">to</span> ／ 人 ／ <span class="en">him</span> ／ もと ／ <span class="en">ask</span>',
   'exp':'<b>なぜ？</b>　<span class="en">I want you</span> で「あなたがほしい」と切れてしまわないよう、<br>'
         'そのうしろに <span class="en">to help me</span> と足して、「あなたに<b>してほしいこと</b>」を説明しているのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　はさむ人の形を書こう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>主語に使う形とはちがう</b>ことに注意しましょう。',
   'body':grid2([
     '1. <span class="en">I want%sto help me.</span>（あなたに）' % bl('you'),
     '2. <span class="en">I want%sto come.</span>（彼に）' % bl('him'),
     '3. <span class="en">I want%sto help me.</span>（彼女に）' % bl('her'),
     '4. <span class="en">She wants%sto study.</span>（わたしに）' % bl('me'),
     '5. <span class="en">I want%sto come.</span>（彼らに）' % bl('them'),
     '6. <span class="en">He wants%sto help him.</span>（わたしたちに）' % bl('us'),
     '7. <span class="en">I told%sto wait.</span>（彼に）' % bl('him'),
     '8. <span class="en">I asked%sto help me.</span>（彼女に）' % bl('her'),
     '9. <span class="en">She%sme to clean my room.</span>' % bl('wants'),
     '10. <span class="en">I want you to%syour room.</span>' % bl('clean'),
   ]),
   'exp':'<b>かくにん</b>　主語とちがう形になるのは <span class="en">I→me、he→him、she→her、we→us、they→them</span>。<br>'
         '9 は主語が <span class="en">She</span> なので <span class="en">wants</span>。10 は <span class="en">to</span> のうしろなので<b>原形（もとの形）</b>です。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. I want you to help me.','○'), ('2. I want you help me.','✕'),
     ('3. I want him to come.','○'), ('4. I want he to come.','✕'),
     ('5. She wants me to study.','○'), ('6. She want me to study.','✕'),
     ('7. I told him to wait.','○'), ('8. I want you to helping me.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">to</span> を入れる　4 → <span class="en">him</span><br>'
         '6 → <span class="en">wants</span>　8 → <span class="en">to help</span>'},
  {'h':'<h3 class="sec sec2">D　するのはだれ？<em>正しいほうを選ぼう</em></h3>',
   'hint':'人がはさまっていれば、<b>その人</b>がします。',
   'body':grid2([
     '1. <span class="en">I want to help you.</span>　手伝うのは（ア わたし ／イ あなた）%s' % bl('ア'),
     '2. <span class="en">I want you to help me.</span>　手伝うのは（ア わたし ／イ あなた）%s' % bl('イ'),
     '3. <span class="en">I want （ア he ／イ him） to come.</span>%s' % bl('イ'),
     '4. <span class="en">She （ア wants ／イ want） me to study.</span>%s' % bl('ア'),
     '5. あなたに来てほしい。<span class="en">I want （ア to come ／イ you to come）.</span>%s' % bl('イ'),
     '6. <span class="en">I want you to （ア clean ／イ cleans） your room.</span>%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　1・2 は<b>人がはさまっているか</b>で、する人が変わります。<br>'
         '5 は「あなたに」とあるので、人をはさむ形です。3・4・6 は形のルールです。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　「だれに」を <span class="en">want</span> のすぐうしろに置き、そのあと <span class="en">to</span>。',
   'body':ol([
     ('<span class="jp-cue">わたしはあなたに手伝ってほしいです。</span>　<span class="en">I want%sto help me.</span>' % bl('you'),
      '人をはさむ。'),
     ('<span class="jp-cue">わたしは彼に来てほしいです。</span>　<span class="en">I want him%scome.</span>' % bl('to'),
      '<span class="en">to</span> を忘れない。'),
     ('<span class="jp-cue">わたしは彼女に手伝ってほしいです。</span>　<span class="en">I want%sto help me.</span>' % bl('her'),
      '<span class="en">she</span> にしない。'),
     ('<span class="jp-cue">彼女はわたしに勉強してほしいです。</span>　<span class="en">She%sme to study.</span>' % bl('wants'),
      '主語が <span class="en">She</span>。'),
     ('<span class="jp-cue">わたしは彼に待つように言いました。</span>　<span class="en">I%shim to wait.</span>' % bl('told'),
      '「言った」は <span class="en">told</span>。'),
     ('<span class="jp-cue">わたしは彼女に手伝うようたのみました。</span>　<span class="en">I%sher to help me.</span>' % bl('asked', False),
      '「たのんだ」は <span class="en">asked</span>。'),
     ('<span class="jp-cue">わたしはあなたに部屋をそうじしてほしいです。</span>　<span class="en">I want you to%syour room.</span>' % bl('clean'),
      '<span class="en">cleans</span> にしない。'),
     ('<span class="jp-cue">わたしは彼らに来てほしいです。</span>　<span class="en">I want%s%scome.</span>' % (bl('them'), bl('to')),
      '（　）が2つ。'),
     ('<span class="jp-cue">わたしはあなたを手伝いたいです。</span>　<span class="en">I want%shelp you.</span>' % bl('to'),
      '人をはさまない形。'),
     ('<span class="jp-cue">彼はわたしたちに手伝ってほしいです。</span>　<span class="en">He wants%sto help him.</span>' % bl('us'),
      '<span class="en">we</span> にしない。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　主語 → <span class="en">want</span> → 人 → <span class="en">to</span> → 原形（もとの形）、の順。',
   'body':ol([
     ('<span class="jp-cue">わたしはあなたに手伝ってほしいです。</span>　<span class="paren en">（ to help me / I want / you ）</span>' + line('I want you to help me.'),
      '人が <span class="en">want</span> のすぐうしろ。'),
     ('<span class="jp-cue">わたしは彼に来てほしいです。</span>　<span class="paren en">（ to come / him / I want ）</span>' + line('I want him to come.'),
      '<span class="en">him</span> の形。'),
     ('<span class="jp-cue">彼女はわたしに勉強してほしいです。</span>　<span class="paren en">（ to study / She wants / me ）</span>' + line('She wants me to study.'),
      '<span class="en">wants</span> の <span class="en">s</span>。'),
     ('<span class="jp-cue">わたしは彼に待つように言いました。</span>　<span class="paren en">（ to wait / I told / him ）</span>' + line('I told him to wait.'),
      '<span class="en">tell</span> も同じ作り。'),
     ('<span class="jp-cue">わたしはあなたに部屋をそうじしてほしいです。</span>　<span class="paren en">（ to clean your room / you / I want ）</span>' + line('I want you to clean your room.'),
      '長くても作りは同じ。'),
     ('<span class="jp-cue">わたしはあなたを手伝いたいです。</span>　<span class="paren en">（ you / to help / I want ）</span>' + line('I want to help you.'),
      '人をはさまない形。'),
     ('<span class="jp-cue">彼はわたしたちに手伝ってほしいです。</span>　<span class="paren en">（ to help him / us / He wants ）</span>' + line('He wants us to help him.'),
      '<span class="en">us</span> の形。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしはあなたに手伝ってほしいです。' + wline('I want you to help me.'),
      '<span class="en">to</span> を忘れない。'),
     ('わたしは彼に来てほしいです。' + wline('I want him to come.'),
      '<span class="en">he</span> にしない。'),
     ('彼女はわたしに勉強してほしいです。' + wline('She wants me to study.'),
      '<span class="en">wants</span> の <span class="en">s</span>。'),
     ('わたしは彼に待つように言いました。' + wline('I told him to wait.'),
      '<span class="en">told</span> は過去形。'),
     ('わたしはあなたに部屋をそうじしてほしいです。' + wline('I want you to clean your room.'),
      '<span class="en">cleans</span> にしない。'),
     ('わたしはあなたを手伝いたいです。' + wline('I want to help you.'),
      '人をはさまない。'),
   ]),
   'words':'<span class="en">want you to help ／ want him to come ／ wants me to study ／ told him to wait ／ clean your room ／ want to help</span>'},
  'l4':{'sub':'だれかにしてほしいことを書こう',
   'cond':['<span class="en">want ＋ 人 ＋ to ～</span> を使った文を <b>2つ以上</b>',
           'はさむ人を <b>2種類以上</b> 使う（<span class="en">you・him・her</span> など）',
           '<span class="en">I want to ～.</span>（自分がしたいこと）の文も <b>1つ</b>'],
   'example':['I want my brother to clean our room.','I want you to come to my birthday party.','I want to be a good player.'],
   'note':'これは例です。同じでなくてかまいません。家族・友だち・先生にしてほしいことで書きやすいです。',
   'check':['人をはさんだ','人は me・him・her の形','to を入れた','to のうしろは原形（もとの形）'],
   'review':'じぶんの文の <span class="en">to</span> の前の人に○をつけよう。<span class="en">he・she</span> になっていたら、そこがまちがい。'},
 },
}
