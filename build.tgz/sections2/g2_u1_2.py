# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox

S = {
 'id':'g2-u1-2', 'grade':2, 'unit':'1 − 2', 'unit_plain':'1-2',
 'title':'接続詞 when', 'pages':'p.12〜13',
 'hero_big':'When I am free, I read books.',
 'hero_jp':'ひまなとき、わたしは 本を 読みます',
 'motto':'<span class="en">when</span> は <b>2つの文をくっつける</b>のり。<b>前に置いたらコンマ</b>、うしろならコンマなし。',
 'kana':{'when':'ウェン','free':'フリー','time':'タイム','study':'スタディ',
         'japanese':'ジャパニーズ','young':'ヤング','busy':'ビズィ','tired':'タイアド',
         'hungry':'ハングリィ','have':'ハヴ','happy':'ハピィ','home':'ホウム',
         'get':'ゲット','rain':'レイン','rains':'レインズ','read':'リード','books':'ブックス',
         'was':'ワズ','liked':'ライクト','soccer':'サッカー','music':'ミューズィック'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>ひまなとき</b>、本を読みます」のように、<b>2つの文をくっつけて</b>「～するとき」と言う形です。'),
    ('t','くっつけるのは <span class="en">when</span>。置く場所は<b>前でも うしろでもよい</b>ので、2つの形をならいます。'),
    ('h', gitem('❶', '<span class="en">when</span> のまとまりを<b>前</b>に置く', 'コンマで区切る',
                'ひまなとき、本を読みます', 'When I am free, I read books.',
                [('When I am free, I read books.','ひまなとき、わたしは 本を 読みます。'),
                 ('When I was ten, I lived in Tokyo.','10才のとき、わたしは 東京に 住んで いました。')],
                '前に置いたときは、区切りに <b>コンマ（, ）</b>を入れます。')),
    ('h', gitem('❷', '<span class="en">when</span> のまとまりを<b>うしろ</b>に置く', 'コンマはいらない',
                '本を読みます、ひまなときに', 'I read books when I am free.',
                [('I read books when I am free.','わたしは ひまなとき 本を 読みます。'),
                 ('I was happy when I got a letter.','手紙を もらったとき、わたしは うれしかったです。')],
                'うしろに置いたときは、<b>コンマはいりません</b>。意味は ❶ とまったく同じです。', b2=True)),
    ('t','大事なのは、<span class="en">when</span> のうしろは<b>ふつうの文の形</b>だということ。疑問文の形にはしません。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜文が2つ。だから動詞も2つ', [
    ('t','ここが今回のヤマです。<span class="en">when</span> の文は、<b>ふつうの文が2つ</b>くっついたものです。だから<b>動詞も2つ</b>あります。'),
    ('h','''<div class="eqbox">
      <span class="eq">I have free time.</span>（ひまな時間がある）　＋　<span class="eq">I study Japanese.</span>（日本語を勉強する）<br>
      → <span class="eq" style="color:var(--gv);">When</span> <span class="eq">I have free time, I study Japanese.</span>
    </div>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ まとまり ＋ 文<small>2つでひとつの文になる</small></span></div>
        <div class="in"><div class="ex">When I have free time,<br>I study Japanese.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ まとまりだけ<small>これでは文が終わらない</small></span></div>
        <div class="in"><div class="ex">When I have free time.</div></div>
      </div>
    </div>'''),
    ('t','<span class="en">When I have free time.</span> だけでは、「ひまなとき……で、何なの？」と宙に浮いてしまいます。<b>かならずもう1つ文が必要</b>です。'),
  ]),
  ('テストによく出ることば', [
    ('t','この3つを形でおぼえましょう。<b>コンマを打つかどうか</b>が、いちばんまちがえるところです。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味・やくわり</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">when</span></td><td class="k">～するとき</td><td class="e">I read books <u>when</u> it rains.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">When ～,</span></td><td class="k">前に置いたらコンマ</td><td class="e"><u>When I was young,</u> I liked soccer.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">～ when ～</span></td><td class="k">うしろならコンマなし</td><td class="e">I liked soccer <u>when I was young</u>.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">When I have free time,</span> と <span class="en">when I have free time</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('前に置くか、うしろに置くか', [
    ('t','<span class="en">when</span> のまとまりは、<b>前にも うしろにも</b>置けます。意味は変わりません。'),
    ('h','''<table class="kind">
      <thead><tr><th>置く場所</th><th>コンマ</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k">前に置く</td><td class="k" style="color:var(--ng);font-weight:700;">いる</td><td class="e">When I get home<u>,</u> I eat lunch.</td></tr>
        <tr><td class="k">うしろに置く</td><td class="k" style="color:var(--key);font-weight:700;">いらない</td><td class="e">I eat lunch when I get home.</td></tr>
      </tbody>
    </table>'''),
    ('t','おぼえ方は<b>「前に出したら、コンマで区切る」</b>。日本語でも「家に帰ったら、昼食を食べます」と読点を打つのと同じ感覚です。'),
  ]),
  ('たずねる <span class="en">When</span> とのちがい', [
    ('t','1年生でならった <span class="en">When is your birthday?</span>（いつ？）の <span class="en">When</span> とは<b>別のはたらき</b>です。'),
    ('h','''<table class="kind">
      <thead><tr><th>はたらき</th><th>うしろの形</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k">たずねる「いつ」</td><td class="k">たずねる文の形</td><td class="e">When <u>is</u> your birthday?</td></tr>
        <tr><td class="k">くっつける「～するとき」</td><td class="k" style="color:var(--gv);font-weight:700;">ふつうの文の形</td><td class="e">When I <u>have</u> free time, ～</td></tr>
      </tbody>
    </table>'''),
    ('t','くっつける <span class="en">when</span> のうしろは、<b>主語 → 動詞</b> のふつうの順です。<span class="en">When do I ～</span> のようにひっくり返しません。'),
  ]),
 ],
 'quiz':[
  ('When I am free.','When I am free, I read books.','<span class="en">when</span> のまとまりだけでは文になりません。<b>もう1つ文が必要</b>です。','ひまなとき、わたしは 本を 読みます。'),
  ('When I am free I read books.','When I am free, I read books.','<span class="en">when</span> を<b>前に置いたらコンマ</b>で区切ります。','ひまなとき、わたしは 本を 読みます。'),
  ('I read books, when I am free.','I read books when I am free.','<b>うしろに置くときはコンマなし</b>。','わたしは ひまなとき 本を 読みます。'),
  ('When I am free, I am read books.','When I am free, I read books.','<span class="en">am</span> と <span class="en">read</span> で<b>心臓が2つ</b>。<span class="en">am</span> はいりません。','ひまなとき、わたしは 本を 読みます。'),
  ('When am I free, I read books.','When I am free, I read books.','くっつける <span class="en">when</span> のうしろは<b>ふつうの文の形</b>。疑問文の形にはしません。','ひまなとき、わたしは 本を 読みます。'),
  ('When I was young, I like soccer.','When I was young, I liked soccer.','前が過去（<span class="en">was</span>）なら、うしろも<b>過去形</b>にそろえます。','若かったとき、わたしは サッカーが 好きでした。'),
 ],
 'summary':[
  '<b><span class="en">when</span> ＝ ～するとき</b>。ふつうの文を2つくっつけることば。',
  '<b>前に置いたらコンマ</b>（<span class="en">When ～, ～.</span>）、<b>うしろならコンマなし</b>（<span class="en">～ when ～.</span>）。',
  '<span class="en">when</span> のうしろは <b>主語 → 動詞</b> のふつうの順。たずねる文の形にしない。',
  '<span class="en">when</span> のまとまり<b>だけでは文にならない</b>。もう1つ文を書く。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～するとき」は%sを使って、文を2つくっつける。' % bl('when'),
     '<span class="en">when</span> のまとまりを<b>前</b>に置いたら、うしろに%sを打つ。' % bl('コンマ'),
     '<span class="en">when</span> のまとまりを<b>うしろ</b>に置いたら、コンマは%s。' % bl('いらない'),
     '<span class="en">when</span> のうしろは、主語 → %s のふつうの順にする。' % bl('動詞'),
     '文が2つくっつくので、1つの文に動詞が%sある。' % bl('2つ'),
   ]),
   'words':'語群：<span class="en">when</span> ／ コンマ ／ いらない ／ 動詞 ／ 2つ',
   'exp':'<b>なぜ？</b>　日本語の「～するとき」は文のはじめに来ますが、英語は<b>どちらでもよい</b>のが大きなちがいです。<br>'
         'ただし前に出したときだけ、どこまでが「まとまり」かが分かりにくいので、<b>コンマで切れ目を見せます</b>。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　コンマがいる？ いらない？<em>いるなら ✓、いらないなら ✕ を書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<span class="en">when</span> が<b>文のはじめにあるか</b>だけを見ましょう。',
   'body':tf([
     ('1. When I get home ( ) I eat lunch.','✓'), ('2. I eat lunch ( ) when I get home.','✕'),
     ('3. When it rains ( ) I read books.','✓'), ('4. I read books ( ) when it rains.','✕'),
     ('5. When I was young ( ) I liked soccer.','✓'), ('6. I liked soccer ( ) when I was young.','✕'),
     ('7. When I am tired ( ) I listen to music.','✓'), ('8. I listen to music ( ) when I am tired.','✕'),
   ]),
   'exp':'<b>見つけ方</b>　文の<b>いちばん前が <span class="en">When</span></b> → コンマがいる（1・3・5・7）<br>'
         '文の<b>とちゅうに <span class="en">when</span></b> → コンマはいらない（2・4・6・8）<br>'
         '1と2、3と4のように、同じ意味の文が2つの形で書けることを確かめよう。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. When I have free time, I study.','○'), ('2. When I have free time.','✕'),
     ('3. I study when I have free time.','○'), ('4. I study, when I have free time.','✕'),
     ('5. When it rains, I read books.','○'), ('6. When do it rains, I read books.','✕'),
     ('7. When I was young, I liked soccer.','○'), ('8. When I was young, I like soccer.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → うしろに文を足す（<span class="en">…, I study Japanese.</span>）<br>'
         '4 → コンマをとる　6 → <span class="en">When it rains,</span>（<span class="en">do</span> を使わない）<br>'
         '8 → <span class="en">I liked soccer.</span>（前が過去なら うしろも過去）'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'<span class="en">when</span> の位置と、動詞の形に注目しよう。',
   'body':grid2([
     '1. <span class="en">（ア When I get home, I ／イ When I get home I） eat lunch.</span>%s' % bl('ア'),
     '2. <span class="en">I read books （ア , when ／イ when） it rains.</span>%s' % bl('イ'),
     '3. <span class="en">When I （ア am ／イ have） free time, I study.</span>%s' % bl('イ'),
     '4. <span class="en">When I was young, I （ア liked ／イ like） soccer.</span>%s' % bl('ア'),
     '5. <span class="en">When （ア do it rains ／イ it rains）, I read books.</span>%s' % bl('イ'),
     '6. <span class="en">When I am tired, I （ア listen ／イ am listen） to music.</span>%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　1・2 はコンマ。前に出したときだけ打ちます。<br>'
         '3 は「ひまな時間が<b>ある</b>」なので <span class="en">have</span>。4 は前後の時をそろえます。<br>'
         '5 は <span class="en">do</span> を使わない。6 は <span class="en">am</span> と <span class="en">listen</span> で心臓が2つになります。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　<span class="en">when</span> のまとまりがどこからどこまでかを、指でなぞってみよう。',
   'body':ol([
     ('<span class="jp-cue">ひまな時間があるとき、わたしは日本語を勉強します。</span>　<span class="en">%sI have free time, I study Japanese.</span>' % bl('When'),
      '文のはじめなので<b>大文字</b>。'),
     ('<span class="jp-cue">わたしは家に帰ったら昼食を食べます。</span>　<span class="en">I eat lunch%sI get home.</span>' % bl('when'),
      'とちゅうなので<b>小文字</b>。コンマもなし。'),
     ('<span class="jp-cue">雨がふるとき、わたしは本を読みます。</span>　<span class="en">When it rains%sI read books.</span>' % bl('，'),
      '前に置いたので<b>コンマ</b>が必要。'),
     ('<span class="jp-cue">わたしは若いとき、サッカーが好きでした。</span>　<span class="en">When I%syoung, I liked soccer.</span>' % bl('was'),
      '「若かった」なので <b><span class="en">was</span></b>。'),
     ('<span class="jp-cue">わたしは若いとき、サッカーが好きでした。</span>　<span class="en">When I was young, I%ssoccer.</span>' % bl('liked'),
      '前が過去なので、うしろも<b>過去形</b>。'),
     ('<span class="jp-cue">つかれているとき、わたしは音楽を聞きます。</span>　<span class="en">When I%stired, I listen to music.</span>' % bl('am'),
      '主語が <span class="en">I</span> なので <b><span class="en">am</span></b>。'),
     ('<span class="jp-cue">わたしはおなかがすいたとき、パンを食べます。</span>　<span class="en">I eat bread%sI%shungry.</span>' % (bl('when'), bl('am')),
      '（　）が2つ。うしろに置くので小文字の <span class="en">when</span>。'),
     ('<span class="jp-cue">彼が家に帰ったとき、わたしは本を読んでいました。</span>　<span class="en">%she got home, I read a book.</span>' % bl('When'),
      '主語が <span class="en">he</span> でも、形は同じ。'),
     ('<span class="jp-cue">わたしはひまなとき、テレビを見ます。</span>　<span class="en">I watch TV when I%sfree time.</span>' % bl('have'),
      '「ひまな時間が<b>ある</b>」なので <span class="en">have</span>。'),
     ('<span class="jp-cue">忙しいとき、わたしは昼食を食べません。</span>　<span class="en">When I am busy, I%seat lunch.</span>' % bl("don't"),
      'うしろの文は<b>ふつうの打ち消し</b>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　まず2つの文に分けて、それから <span class="en">when</span> でくっつけよう。',
   'body':ol([
     ('<span class="jp-cue">ひまな時間があるとき、わたしは日本語を勉強します。</span>　<span class="paren en">（ I study Japanese / free time / When I have ）</span>' + line('When I have free time, I study Japanese.'),
      '前に置いたので<b>コンマ</b>を入れる。'),
     ('<span class="jp-cue">わたしはひまな時間があるとき日本語を勉強します。</span>　<span class="paren en">（ when I have free time / Japanese / I study ）</span>' + line('I study Japanese when I have free time.'),
      'うしろに置いたので<b>コンマなし</b>。'),
     ('<span class="jp-cue">雨がふるとき、わたしは本を読みます。</span>　<span class="paren en">（ I read books / it rains / When ）</span>' + line('When it rains, I read books.'),
      '<span class="en">When</span> → <span class="en">it rains</span> → コンマ の順。'),
     ('<span class="jp-cue">わたしは家に帰ったら昼食を食べます。</span>　<span class="paren en">（ I get home / lunch / when / I eat ）</span>' + line('I eat lunch when I get home.'),
      '<span class="en">I eat lunch</span> が中心の文。'),
     ('<span class="jp-cue">わたしは若いとき、サッカーが好きでした。</span>　<span class="paren en">（ I liked soccer / I was young / When ）</span>' + line('When I was young, I liked soccer.'),
      '前も うしろも<b>過去形</b>。'),
     ('<span class="jp-cue">つかれているとき、わたしは音楽を聞きます。</span>　<span class="paren en">（ to music / When I am tired / I listen ）</span>' + line('When I am tired, I listen to music.'),
      '<span class="en">listen to ～</span> でひとかたまり。'),
     ('<span class="jp-cue">わたしは忙しいとき、テレビを見ません。</span>　<span class="paren en">（ when I am busy / watch TV / I / don&#39;t ）</span>' + line('I don&#39;t watch TV when I am busy.'),
      '中心の文を打ち消しにする。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('ひまな時間があるとき、わたしは日本語を勉強します。' + wline('When I have free time, I study Japanese.'),
      'コンマを忘れないこと。'),
     ('わたしは家に帰ったら昼食を食べます。' + wline('I eat lunch when I get home.'),
      'うしろに置くのでコンマなし。'),
     ('雨がふるとき、わたしは本を読みます。' + wline('When it rains, I read books.'),
      '<span class="en">it rains</span> の <span class="en">s</span> を忘れない。'),
     ('わたしは若いとき、サッカーが好きでした。' + wline('When I was young, I liked soccer.'),
      '前後とも過去形にそろえる。'),
     ('つかれているとき、わたしは音楽を聞きます。' + wline('When I am tired, I listen to music.'),
      '<span class="en">listen to</span> の <span class="en">to</span> を忘れない。'),
     ('わたしは忙しいときテレビを見ません。' + wline('I don&#39;t watch TV when I am busy.'),
      '打ち消すのは<b>中心の文</b>のほう。'),
   ]),
   'words':'<span class="en">When I have free time ／ when I get home ／ When it rains ／ When I was young ／ When I am tired ／ when I am busy</span>'},
  'l4':{'sub':'「～するとき、わたしは…します」を自分のことで書こう',
   'cond':['<span class="en">When ～,</span> を<b>前</b>に置いた文を <b>1つ以上</b>',
           '<span class="en">～ when ～.</span> と<b>うしろ</b>に置いた文も <b>1つ</b>',
           '過去のことを言う文を <b>1つ</b> 入れる（前後とも過去形に）'],
   'example':['When I have free time, I play the guitar.','I drink hot tea when I am cold.','When I was in elementary school, I liked swimming.'],
   'note':'これは例です。同じでなくてかまいません。「朝おきたとき」「テストの前」など、自分の場面で書いてみよう。',
   'check':['前に置いたらコンマ','うしろならコンマなし','when のうしろは 主語 → 動詞','動詞が2つある'],
   'review':'じぶんの文の動詞2つに○をつけよう。1つしかなければ、文が足りていません。'},
 },
}
