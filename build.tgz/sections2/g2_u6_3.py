# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'g2-u6-3', 'grade':2, 'unit':'6 − 3', 'unit_plain':'6-3',
 'title':'不定詞（副詞的用法・原因）', 'pages':'p.76〜77',
 'hero_big':'I am happy to hear that.',
 'hero_jp':'わたしは それを 聞いて うれしいです',
 'motto':'<b>気もちのことば ＋ <span class="en">to ～</span></b> で「～して…だ」。気もちの<b>原因</b>を表す。',
 'kana':{'glad':'グラッド','happy':'ハピィ','sad':'サッド','sorry':'ソリィ',
         'surprised':'サプライズド','hear':'ヒア','heard':'ハード','see':'スィー',
         'meet':'ミート','know':'ノウ','that':'ザット','news':'ニューズ',
         'you':'ユー','again':'アゲン','win':'ウィン','won':'ワン'},
 'blocks':[
  ('きほんの文', [
    ('t','<span class="en">to ＋ 原形（もとの形）</span> の3つめの使い方です。今回は<b>気もちの原因</b>を表します。「～して…だ」と訳します。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I am happy to hear that.</span><span class="t">わたしは それを 聞いて うれしいです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I am glad to see you.</span><span class="t">わたしは あなたに 会えて うれしいです。</span></div>
    </div>'''),
    ('t','<b>気もちのことばのうしろ</b>に <span class="en">to ～</span> をつけて、「なぜその気もちになったか」を言います。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜前が<b>気もちのことば</b>', [
    ('t','ここが今回のヤマです。6-1 の「～するために」とまぎらわしいですが、<b><span class="en">to</span> の前が気もちのことばなら「～して」</b>です。'),
    ('h','''<table class="kind">
      <thead><tr><th>to の前</th><th>意味</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k" style="color:var(--gv);font-weight:700;">気もちのことば</td><td class="k">～して…だ（原因）</td><td class="e">I&#39;m <u>glad</u> to hear that.</td></tr>
        <tr><td class="k" style="color:var(--key);font-weight:700;">ふつうの文</td><td class="k">～するために（目的）</td><td class="e"><u>I went there</u> to see him.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ 気もち ＋ to ～<small>glad / happy / sorry</small></span></div>
        <div class="in"><div class="ex">I&#39;m glad to hear that.<br>I&#39;m sorry to hear that.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ be動詞を忘れる<small>I glad to ～</small></span></div>
        <div class="in"><div class="ex">I glad to hear that.<br>He happy to see you.</div></div>
      </div>
    </div>'''),
    ('t','<span class="en">glad・happy</span> は<b>ようすのことば</b>なので、前に be動詞が必要です。<span class="en">I&#39;m</span> を忘れないようにしましょう。'),
  ]),
  ('テストによく出ることば', [
    ('t','よく使う気もちのことばです。<b><span class="en">be動詞 ＋ 気もち ＋ to</span></b> の3点セットでおぼえましょう。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">glad to</span></td><td class="k">～してうれしい</td><td class="e">I&#39;m <u>glad to</u> hear that.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">happy to</span></td><td class="k">～してうれしい</td><td class="e">I&#39;m <u>happy to</u> see you.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">sorry to</span></td><td class="k">～して残念だ</td><td class="e">I&#39;m <u>sorry to</u> hear that.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">surprised to</span></td><td class="k">～しておどろいた</td><td class="e">I was <u>surprised to</u> hear it.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">glad to</span> ・ <span class="en">happy to</span> ・ <span class="en">sorry to</span> ・ <span class="en">surprised to</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('会話でそのまま使える形', [
    ('t','あいさつや返事で、そのまま使える形がいくつかあります。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">Nice to meet you.</span>（お会いできてうれしいです）<br>
      <span class="eq" style="color:var(--gv);">I&#39;m glad to hear that.</span>（それを聞いてうれしいです）<br>
      <span class="eq" style="color:var(--gv);">I&#39;m sorry to hear that.</span>（それを聞いて残念です）
    </div>'''),
    ('t','よい知らせには <span class="en">glad</span>、悪い知らせには <span class="en">sorry</span> と使い分けます。'),
  ]),
  ('4つの <span class="en">to</span> の整理', [
    ('t','これで <span class="en">to ＋ 原形（もとの形）</span> の使い方がそろいました。<b><span class="en">to</span> のすぐ前</b>を見れば見分けられます。'),
    ('h','''<table class="kind">
      <thead><tr><th>to の前</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k">動詞（want・need）</td><td class="k">～すること</td><td class="e">I want <u>to go</u>.</td></tr>
        <tr><td class="k">名前（something・time）</td><td class="k">～するための</td><td class="e">time <u>to go</u></td></tr>
        <tr><td class="k">完成した文</td><td class="k">～するために</td><td class="e">I came here <u>to see</u> you.</td></tr>
        <tr><td class="k" style="color:var(--gv);font-weight:700;">気もちのことば</td><td class="k" style="color:var(--gv);font-weight:700;">～して…だ</td><td class="e">I&#39;m glad <u>to see</u> you.</td></tr>
      </tbody>
    </table>'''),
    ('t','どの使い方でも、<span class="en">to</span> のうしろは<b>原形（もとの形）</b>です。そこは変わりません。'),
  ]),
 ],
 'quiz':[
  ('I glad to hear that.','I&#39;m glad to hear that.','<b>be動詞が抜けています</b>。<span class="en">glad</span> はようすのことばです。','わたしは それを 聞いて うれしいです。'),
  ('I&#39;m glad to hearing that.','I&#39;m glad to hear that.','<span class="en">to</span> のうしろは<b>原形（もとの形）</b>。','わたしは それを 聞いて うれしいです。'),
  ('I&#39;m glad hear that.','I&#39;m glad to hear that.','<b><span class="en">to</span> が抜けています</b>。','わたしは それを 聞いて うれしいです。'),
  ('I&#39;m glad for hear that.','I&#39;m glad to hear that.','「～して」は <b><span class="en">to</span></b> を使います。','わたしは それを 聞いて うれしいです。'),
  ('He happy to see you.','He is happy to see you.','主語が <span class="en">He</span> なので <b><span class="en">is</span></b> が必要です。','彼は あなたに 会えて うれしいです。'),
  ('I was surprised to heard it.','I was surprised to hear it.','<span class="en">to</span> のうしろは過去形にしません。','わたしは それを 聞いて おどろきました。'),
 ],
 'summary':[
  '<b>気もちのことば ＋ <span class="en">to ＋ 原形（もとの形）</span></b> ＝「～して…だ」（原因）。',
  '<span class="en">glad・happy・sorry・surprised</span> はようすのことば。<b>前に be動詞</b>が必要。',
  '<span class="en">to</span> の<b>すぐ前が気もちのことば</b>なら、この使い方。',
  '<span class="en">Nice to meet you.</span>・<span class="en">I&#39;m sorry to hear that.</span> はそのまま使える。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～して…だ」は、気もちのことばのうしろに%s＋ 原形（もとの形） を置く。' % bl('to'),
     '<span class="en">glad・happy</span> は%sのことばなので、前に be動詞がいる。' % bl('ようす'),
     'よい知らせには%s、悪い知らせには <span class="en">sorry</span> を使う。' % bl('glad'),
     '<span class="en">to</span> のすぐ前が%sのことばなら、この使い方である。' % bl('気もち'),
     '<span class="en">to</span> のうしろは、どの使い方でも%sの形にする。' % bl('もと'),
   ]),
   'words':'語群：<span class="en">to</span> ／ ようす ／ <span class="en">glad</span> ／ 気もち ／ もと',
   'exp':'<b>なぜ？</b>　<span class="en">I&#39;m glad.</span>（うれしい）だけでは、<b>なぜうれしいのか</b>が分かりません。<br>'
         'そこに <span class="en">to hear that</span> を足して、「それを聞いて」と<b>きっかけ</b>を説明しているのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　（　）に入るものを書こう<em>1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>be動詞</b>と <b><span class="en">to</span></b> の両方がいります。',
   'body':grid2([
     '1. <span class="en">I%sglad to hear that.</span>' % bl('am'),
     '2. <span class="en">I&#39;m glad%shear that.</span>' % bl('to'),
     '3. <span class="en">I&#39;m happy to%syou.</span>' % bl('see'),
     '4. <span class="en">He%shappy to see you.</span>' % bl('is'),
     '5. <span class="en">I&#39;m%sto hear that.</span>（残念だ）' % bl('sorry'),
     '6. <span class="en">I%ssurprised to hear it.</span>（おどろいた・過去）' % bl('was'),
     '7. <span class="en">Nice%smeet you.</span>' % bl('to'),
     '8. <span class="en">They%sglad to win.</span>' % bl('are'),
     '9. <span class="en">I&#39;m glad to%syou again.</span>' % bl('meet'),
     '10. <span class="en">She%sglad to hear the news.</span>' % bl('is'),
   ]),
   'exp':'<b>かくにん</b>　be動詞は主語に合わせます（1・4・8・10）。過去なら <span class="en">was</span>（6）。<br>'
         '<span class="en">to</span> のうしろは原形（もとの形）（3・9）。<span class="en">saw・meeting</span> にしません。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. I&#39;m glad to hear that.','○'), ('2. I glad to hear that.','✕'),
     ('3. I&#39;m happy to see you.','○'), ('4. I&#39;m happy see you.','✕'),
     ('5. He is glad to hear that.','○'), ('6. He glad to hear that.','✕'),
     ('7. I was surprised to hear it.','○'), ('8. I was surprised to heard it.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">I&#39;m</span>　4 → <span class="en">to</span> を入れる<br>'
         '6 → <span class="en">He is</span>　8 → <span class="en">to hear</span>（原形（もとの形））'},
  {'h':'<h3 class="sec sec2">D　<span class="en">to</span> の意味はどれ？<em>正しいほうを選ぼう</em></h3>',
   'hint':'<span class="en">to</span> の<b>すぐ前</b>を見よう。気もちのことばか、完成した文か。',
   'body':grid2([
     '1. <span class="en">I&#39;m glad to see you.</span>（ア ～して ／イ ～するために）%s' % bl('ア'),
     '2. <span class="en">I came here to see you.</span>（ア ～して ／イ ～するために）%s' % bl('イ'),
     '3. <span class="en">I&#39;m happy to hear that.</span>（ア ～して ／イ ～するための）%s' % bl('ア'),
     '4. <span class="en">I have time to study.</span>（ア ～して ／イ ～するための）%s' % bl('イ'),
     '5. <span class="en">I&#39;m sorry to hear that.</span>（ア ～して ／イ ～すること）%s' % bl('ア'),
     '6. <span class="en">I want to see you.</span>（ア ～して ／イ ～すること）%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　1・3・5 は <span class="en">glad・happy・sorry</span>（気もち）の直後 → 「～して」。<br>'
         '2 は文が完成 → 「～するために」。4 は <span class="en">time</span>（名前）の直後 → 「～するための」。6 は <span class="en">want</span>（動詞）の直後 → 「～すること」。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　主語 ＋ be動詞 ＋ 気もちのことば ＋ <span class="en">to</span> ＋ 原形（もとの形）。',
   'body':ol([
     ('<span class="jp-cue">わたしはそれを聞いてうれしいです。</span>　<span class="en">I&#39;m%sto hear that.</span>' % bl('glad'),
      '「うれしい」は <span class="en">glad</span>。'),
     ('<span class="jp-cue">わたしはあなたに会えてうれしいです。</span>　<span class="en">I&#39;m happy%ssee you.</span>' % bl('to'),
      '<span class="en">to</span> を忘れない。'),
     ('<span class="jp-cue">わたしはそれを聞いて残念です。</span>　<span class="en">I&#39;m%sto hear that.</span>' % bl('sorry'),
      '悪い知らせには <span class="en">sorry</span>。'),
     ('<span class="jp-cue">彼はあなたに会えてうれしいです。</span>　<span class="en">He%shappy to see you.</span>' % bl('is'),
      '<span class="en">He</span> なので <span class="en">is</span>。'),
     ('<span class="jp-cue">わたしはそれを聞いておどろきました。</span>　<span class="en">I%ssurprised to hear it.</span>' % bl('was'),
      '過去なので <span class="en">was</span>。'),
     ('<span class="jp-cue">お会いできてうれしいです。</span>　<span class="en">Nice to%syou.</span>' % bl('meet'),
      'あいさつの定型。'),
     ('<span class="jp-cue">わたしはまたあなたに会えてうれしいです。</span>　<span class="en">I&#39;m glad to meet you%s.</span>' % bl('again'),
      '「また」は <span class="en">again</span>。'),
     ('<span class="jp-cue">彼らは勝ってうれしいです。</span>　<span class="en">They%sglad%swin.</span>' % (bl('are'), bl('to')),
      '（　）が2つ。<span class="en">They</span> は <span class="en">are</span>。'),
     ('<span class="jp-cue">彼女はその知らせを聞いてうれしいです。</span>　<span class="en">She is glad to%sthe news.</span>' % bl('hear'),
      '<span class="en">heard</span> にしない。'),
     ('<span class="jp-cue">わたしはそれを知って悲しいです。</span>　<span class="en">I&#39;m%sto know that.</span>' % bl('sad'),
      '「悲しい」は <span class="en">sad</span>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　気もちのことばまでを先に書き、そのうしろに <span class="en">to ～</span> を足そう。',
   'body':ol([
     ('<span class="jp-cue">わたしはそれを聞いてうれしいです。</span>　<span class="paren en">（ to hear that / I&#39;m / glad ）</span>' + line('I&#39;m glad to hear that.'),
      '<span class="en">I&#39;m glad</span> が先。'),
     ('<span class="jp-cue">わたしはあなたに会えてうれしいです。</span>　<span class="paren en">（ happy / to see you / I&#39;m ）</span>' + line('I&#39;m happy to see you.'),
      '3つのかたまりの順。'),
     ('<span class="jp-cue">わたしはそれを聞いて残念です。</span>　<span class="paren en">（ sorry / I&#39;m / to hear that ）</span>' + line('I&#39;m sorry to hear that.'),
      '<span class="en">sorry</span> を選ぶ。'),
     ('<span class="jp-cue">彼はあなたに会えてうれしいです。</span>　<span class="paren en">（ to see you / He is / happy ）</span>' + line('He is happy to see you.'),
      '<span class="en">He is</span> が先。'),
     ('<span class="jp-cue">わたしはそれを聞いておどろきました。</span>　<span class="paren en">（ surprised / to hear it / I was ）</span>' + line('I was surprised to hear it.'),
      '過去形の <span class="en">was</span>。'),
     ('<span class="jp-cue">彼らは勝ってうれしいです。</span>　<span class="paren en">（ to win / They are / glad ）</span>' + line('They are glad to win.'),
      '<span class="en">They are</span> が先。'),
     ('<span class="jp-cue">わたしはそれを知って悲しいです。</span>　<span class="paren en">（ sad / to know that / I&#39;m ）</span>' + line('I&#39;m sad to know that.'),
      '<span class="en">sad</span> も気もちのことば。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしはそれを聞いてうれしいです。' + wline('I&#39;m glad to hear that.'),
      '<span class="en">I am glad</span> でも正解。'),
     ('わたしはあなたに会えてうれしいです。' + wline('I&#39;m happy to see you.'),
      '<span class="en">to</span> を忘れない。'),
     ('わたしはそれを聞いて残念です。' + wline('I&#39;m sorry to hear that.'),
      '会話でよく使う形。'),
     ('彼はあなたに会えてうれしいです。' + wline('He is happy to see you.'),
      '<span class="en">He</span> は <span class="en">is</span>。'),
     ('わたしはそれを聞いておどろきました。' + wline('I was surprised to hear it.'),
      '過去は <span class="en">was</span>。'),
     ('お会いできてうれしいです。' + wline('Nice to meet you.'),
      'あいさつの定型。'),
   ]),
   'words':'<span class="en">glad to hear ／ happy to see ／ sorry to hear ／ He is happy ／ was surprised ／ Nice to meet you</span>'},
  'l4':{'sub':'うれしかったこと・残念だったことを、理由とともに書こう',
   'cond':['<span class="en">glad・happy・sorry・surprised</span> のうち <b>2つ以上</b>を使う',
           '<span class="en">to ～</span> を使った文を <b>2つ以上</b>',
           '過去のことを言う文を <b>1つ</b> 入れる'],
   'example':['I&#39;m glad to see my friends every day.','I was happy to win the game last week.','I&#39;m sorry to hear about your dog.'],
   'note':'これは例です。同じでなくてかまいません。部活の結果・友だちとの出来事などで書きやすいです。',
   'check':['be動詞を書いた','to を入れた','to のうしろは原形（もとの形）','過去なら was / were'],
   'review':'じぶんの文の <span class="en">to</span> のすぐ前に○をつけよう。そこが<b>気もちのことば</b>なら正解です。'},
 },
}
