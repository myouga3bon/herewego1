# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'g2-u4-3', 'grade':2, 'unit':'4 − 3', 'unit_plain':'4-3',
 'title':'不定詞（形容詞的用法）', 'pages':'p.54〜55',
 'hero_big':'I want something to drink.',
 'hero_jp':'わたしは 飲むものが ほしいです',
 'motto':'<b>名前のうしろ</b>に <span class="en">to ＋ 原形（もとの形）</span>。「～するための」と、前の名前を<b>説明する</b>。',
 'kana':{'something':'サムスィング','anything':'エニスィング','nothing':'ナスィング',
         'wear':'ウェア','drink':'ドリンク','eat':'イート',
         'read':'リード','do':'ドゥー','time':'タイム','homework':'ホウムワーク',
         'water':'ウォーター','book':'ブック','books':'ブックス','need':'ニード',
         'want':'ワント','lot':'ロット','many':'メニィ','things':'スィングズ'},
 'blocks':[
  ('きほんの文', [
    ('t','2-2 でならった <span class="en">to ＋ 原形（もとの形）</span> が、今回は<b>名前のうしろ</b>について、その名前を説明します。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I want something to drink.</span><span class="t">わたしは 飲むものが ほしいです。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">I have a lot of homework to do.</span><span class="t">わたしは する宿題が たくさん あります。</span></div>
    </div>'''),
    ('t','<span class="en">something</span>（何か）だけでは何のことか分かりません。そこに <span class="en">to drink</span> をつけて<b>「飲むための何か」＝飲み物</b>と説明しています。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜<span class="en">to ～</span> は<b>うしろ</b>から説明する', [
    ('t','ここが今回のヤマです。日本語は<b>前から</b>、英語は<b>うしろから</b>説明します。語順がぎゃくになります。'),
    ('h','''<div class="eqbox">
      日本語：<b>飲む</b> ＋ もの　　（説明が前）<br>
      英語：<span class="eq">something</span> ＋ <span class="eq" style="color:var(--gv);">to drink</span>　（説明がうしろ）
    </div>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ 名前 → to ～<small>うしろから説明</small></span></div>
        <div class="in"><div class="ex">something to drink<br>time to study</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ to ～ → 名前<small>日本語の順のまま</small></span></div>
        <div class="in"><div class="ex">to drink something<br>to study time</div></div>
      </div>
    </div>'''),
    ('t','<span class="en">to drink something</span> だと「何かを飲むこと」という別の意味になります。<b>説明したい名前を先に書く</b>のがコツです。'),
  ]),
  ('テストによく出ることば', [
    ('t','この形でよく出る組み合わせです。<b>2語セット</b>でおぼえると速いです。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">something to drink</span></td><td class="k">飲むもの</td><td class="e">I want <u>something to drink</u>.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">something to eat</span></td><td class="k">食べるもの</td><td class="e">I want <u>something to eat</u>.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">time to ～</span></td><td class="k">～する時間</td><td class="e">I have no <u>time to study</u>.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">things to do</span></td><td class="k">するべきこと</td><td class="e">I have many <u>things to do</u>.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">something to drink</span> ・ <span class="en">time to study</span> ・ <span class="en">things to do</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('2-2 の形とのちがい', [
    ('t','形はまったく同じ <span class="en">to ＋ 原形（もとの形）</span> ですが、<b>前に何があるか</b>でやくわりが変わります。'),
    ('h','''<table class="kind">
      <thead><tr><th>前にあるもの</th><th>やくわり</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k">動詞（<span class="en">want・need</span>）</td><td class="k" style="color:var(--key);font-weight:700;">～すること</td><td class="e">I want <u>to drink</u> water.</td></tr>
        <tr><td class="k">名前（<span class="en">something・time</span>）</td><td class="k" style="color:var(--gv);font-weight:700;">～するための</td><td class="e">I want something <u>to drink</u>.</td></tr>
      </tbody>
    </table>'''),
    ('t','<b>すぐ前が名前なら「～するための」</b>、と見分けます。どちらも <span class="en">to</span> のうしろは<b>原形（もとの形）</b>です。'),
  ]),
  ('よく使う名前', [
    ('t','<span class="en">to ～</span> で説明されることが多い名前です。これが見えたら、うしろを探しましょう。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">something</span>（何か）　<span class="eq" style="color:var(--gv);">anything</span>（何か・何も）　<span class="eq" style="color:var(--gv);">time</span>（時間）<br>
      <span class="eq" style="color:var(--gv);">things</span>（こと）　<span class="eq" style="color:var(--gv);">a book</span>（本）　<span class="eq" style="color:var(--gv);">homework</span>（宿題）
    </div>'''),
    ('t','たずねる文や打ち消しの文では、<span class="en">something</span> が <span class="en">anything</span> に変わります。'),
  ]),
 ],
 'quiz':[
  ('I want to drink something.','I want something to drink.','「飲むもの」は <b>名前 → <span class="en">to</span></b> の順。うしろから説明します。','わたしは 飲むものが ほしいです。'),
  ('I need to eat something.','I need something to eat.','説明したい名前（<span class="en">something</span>）を<b>先</b>に書きます。','わたしは 食べるものが 必要です。'),
  ('I want something to drinking.','I want something to drink.','<span class="en">to</span> のうしろは<b>原形（もとの形）</b>。<span class="en">ing</span> はつけません。','わたしは 飲むものが ほしいです。'),
  ('I have no time study.','I have no time to study.','<b><span class="en">to</span> が抜けています</b>。名前を説明するには <span class="en">to</span> が必要です。','わたしは 勉強する 時間が ありません。'),
  ('I have many things to doing.','I have many things to do.','<span class="en">to do</span> が原形（もとの形）。','わたしは することが たくさん あります。'),
  ('I want something to drinks.','I want something to drink.','<span class="en">to</span> のうしろに <span class="en">s</span> はつけません。','わたしは 飲むものが ほしいです。'),
 ],
 'summary':[
  '<b>名前 ＋ <span class="en">to ＋ 原形（もとの形）</span></b> ＝「～するための○○」。',
  '日本語は前から、<b>英語はうしろから</b>説明する。語順がぎゃく。',
  '<span class="en">something to drink</span>（飲むもの）、<span class="en">time to study</span>（勉強する時間）。',
  '<span class="en">to</span> のうしろは <b>原形（もとの形）</b>。<span class="en">s</span>・<span class="en">ing</span> をつけない。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～するための○○」は、名前の%sに <span class="en">to</span> ＋ 原形（もとの形） を置く。' % bl('うしろ'),
     '日本語とは語順が%sになる。' % bl('ぎゃく'),
     '説明したい%sを先に書くのがコツ。' % bl('名前'),
     '<span class="en">to</span> のうしろは、動詞の%sの形にする。' % bl('もと'),
     'すぐ前が名前なら「～するための」、前が動詞なら%sの意味になる。' % bl('～すること', False),
   ]),
   'words':'語群：うしろ ／ ぎゃく ／ 名前 ／ もと ／ ～すること',
   'exp':'<b>なぜ？</b>　英語は<b>大事なことを先に言う</b>ことばです。<br>'
         '「飲みもの」なら、まず「もの（<span class="en">something</span>）」と言ってから、「どんな？ 飲むための」と<b>あとから足していく</b>のです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">to</span> のうしろの形を書こう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>かざりを全部とった形</b>にしましょう。',
   'body':grid2([
     '1. <span class="en">something to%s</span>（飲むもの）' % bl('drink'),
     '2. <span class="en">something to%s</span>（食べるもの）' % bl('eat'),
     '3. <span class="en">time to%s</span>（勉強する時間）' % bl('study'),
     '4. <span class="en">things to%s</span>（するべきこと）' % bl('do'),
     '5. <span class="en">a book to%s</span>（読む本）' % bl('read'),
     '6. <span class="en">something to%s</span>（着るもの）' % bl('wear'),
     '7. <span class="en">time to%s</span>（出発する時間）' % bl('go'),
     '8. <span class="en">a friend to%swith</span>（いっしょに遊ぶ友だち）' % bl('play'),
     '9. <span class="en">homework to%s</span>（やるべき宿題）' % bl('do'),
     '10. <span class="en">something to%s</span>（着るもの）' % bl('wear'),
   ]),
   'exp':'<b>かくにん</b>　どれも<b>原形（もとの形）</b>のままです。<span class="en">drinking・studies・went</span> などにはしません。<br>'
         '8 の <span class="en">play with</span> のように、2語でひとかたまりになるものもあります。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. I want something to drink.','○'), ('2. I want to drink something.','✕'),
     ('3. I have no time to study.','○'), ('4. I have no time study.','✕'),
     ('5. I have many things to do.','○'), ('6. I have many things to doing.','✕'),
     ('7. a book to read','○'), ('8. to read a book（読む本）','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → 「飲むもの」なら <span class="en">something to drink</span>（2は「何かを飲みたい」の意味になる）<br>'
         '4 → <span class="en">to</span> を入れる　6 → <span class="en">to do</span>　8 → <span class="en">a book to read</span>'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'日本語の意味をよく読んで、<b>説明される名前</b>を見つけよう。',
   'body':grid2([
     '1. 飲むもの　<span class="en">（ア something to drink ／イ to drink something）</span>%s' % bl('ア'),
     '2. 勉強する時間　<span class="en">（ア to study time ／イ time to study）</span>%s' % bl('イ'),
     '3. <span class="en">I want something to （ア eat ／イ eating）.</span>%s' % bl('ア'),
     '4. するべきこと　<span class="en">（ア to do things ／イ things to do）</span>%s' % bl('イ'),
     '5. <span class="en">I have no time to （ア goes ／イ go）.</span>%s' % bl('イ'),
     '6. 読む本　<span class="en">（ア a book to read ／イ to read a book）</span>%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　1・2・4・6 は<b>語順</b>です。説明される名前が先、<span class="en">to ～</span> があとです。<br>'
         '3・5 は <span class="en">to</span> のうしろの形。かざりをつけません。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　まず名前を書き、そのうしろに <span class="en">to ＋ 原形（もとの形）</span> を足そう。',
   'body':ol([
     ('<span class="jp-cue">あなたは着るものが必要です。</span>　<span class="en">You need something%swear.</span>' % bl('to'),
      '<span class="en">something</span> のうしろに <span class="en">to</span>。'),
     ('<span class="jp-cue">わたしは飲むものがほしいです。</span>　<span class="en">I want%sto drink.</span>' % bl('something', False),
      '説明される名前が先。'),
     ('<span class="jp-cue">わたしは食べるものがほしいです。</span>　<span class="en">I want something to%s.</span>' % bl('eat'),
      '<span class="en">to</span> のうしろは原形（もとの形）。'),
     ('<span class="jp-cue">わたしには勉強する時間がありません。</span>　<span class="en">I have no%sto study.</span>' % bl('time'),
      '「時間」は <span class="en">time</span>。'),
     ('<span class="jp-cue">わたしにはするべきことがたくさんあります。</span>　<span class="en">I have many things to%s.</span>' % bl('do'),
      '「する」は <span class="en">do</span>。'),
     ('<span class="jp-cue">わたしは読む本がほしいです。</span>　<span class="en">I want a book to%s.</span>' % bl('read'),
      '<span class="en">reading</span> にしない。'),
     ('<span class="jp-cue">何か飲むものはありますか。</span>　<span class="en">Do you have%sto drink?</span>' % bl('anything', False),
      'たずねる文では <span class="en">anything</span>。'),
     ('<span class="jp-cue">わたしにはやるべき宿題があります。</span>　<span class="en">I have%s%sdo.</span>' % (bl('homework', False), bl('to')),
      '（　）が2つ。名前 → <span class="en">to</span>。'),
     ('<span class="jp-cue">もう行く時間です。</span>　<span class="en">It&#39;s time%sgo.</span>' % bl('to'),
      '<span class="en">It&#39;s time to ～</span> でひとかたまり。'),
     ('<span class="jp-cue">わたしには一緒に遊ぶ友だちがいます。</span>　<span class="en">I have a friend to play%s.</span>' % bl('with'),
      '<span class="en">play with</span> で「いっしょに遊ぶ」。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　「○○するための△△」は、△△ → <span class="en">to</span> → ○○ の順にならべよう。',
   'body':ol([
     ('<span class="jp-cue">あなたは着るものが必要です。</span>　<span class="paren en">（ to wear / You need / something ）</span>' + line('You need something to wear.'),
      '<span class="en">something</span> が先。'),
     ('<span class="jp-cue">わたしは飲むものがほしいです。</span>　<span class="paren en">（ to drink / I want / something ）</span>' + line('I want something to drink.'),
      '3つのかたまりの順に注意。'),
     ('<span class="jp-cue">わたしには勉強する時間がありません。</span>　<span class="paren en">（ to study / no time / I have ）</span>' + line('I have no time to study.'),
      '<span class="en">no time</span> でひとかたまり。'),
     ('<span class="jp-cue">わたしにはするべきことがたくさんあります。</span>　<span class="paren en">（ to do / many things / I have ）</span>' + line('I have many things to do.'),
      '<span class="en">many things</span> が説明される名前。'),
     ('<span class="jp-cue">わたしは読む本がほしいです。</span>　<span class="paren en">（ a book / I want / to read ）</span>' + line('I want a book to read.'),
      '<span class="en">a book</span> → <span class="en">to read</span>。'),
     ('<span class="jp-cue">何か食べるものはありますか。</span>　<span class="paren en">（ to eat / anything / Do you have ）</span>' + line('Do you have anything to eat?'),
      'たずねる文は <span class="en">anything</span>。'),
     ('<span class="jp-cue">もう行く時間です。</span>　<span class="paren en">（ to go / It&#39;s / time ）</span>' + line('It&#39;s time to go.'),
      '<span class="en">It&#39;s time to ～</span>。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('あなたは着るものが必要です。' + wline('You need something to wear.'),
      '<span class="en">something</span> が先。'),
     ('わたしは飲むものがほしいです。' + wline('I want something to drink.'),
      '<span class="en">to drink something</span> にしない。'),
     ('わたしには勉強する時間がありません。' + wline('I have no time to study.'),
      '<span class="en">to</span> を忘れない。'),
     ('わたしにはするべきことがたくさんあります。' + wline('I have many things to do.'),
      '<span class="en">to doing</span> にしない。'),
     ('何か食べるものはありますか。' + wline('Do you have anything to eat?'),
      'たずねる文は <span class="en">anything</span>。'),
     ('もう行く時間です。' + wline('It&#39;s time to go.'),
      '<span class="en">It is time to go.</span> でも正解。'),
   ]),
   'words':'<span class="en">something to cover ／ something to drink ／ no time to study ／ things to do ／ anything to eat ／ time to go</span>'},
  'l4':{'sub':'いま必要なもの・したいことを書こう',
   'cond':['<span class="en">something to ～</span> を使った文を <b>1つ以上</b>',
           '<span class="en">time to ～</span> か <span class="en">things to ～</span> を使った文を <b>1つ</b>',
           '名前のうしろに <span class="en">to</span> を置く形を <b>3つ以上</b> 使う'],
   'example':['I want something to drink after practice.','I have many things to do today.','I don&#39;t have time to watch TV.'],
   'note':'これは例です。同じでなくてかまいません。「～するための○○」と日本語で考えてから、ぎゃくにならべると書けます。',
   'check':['名前 → to ～ の順になっている','to のうしろは原形（もとの形）','to を忘れていない','日本語の順のままになっていない'],
   'review':'じぶんの文の <span class="en">to</span> のすぐ前に○をつけよう。そこが<b>名前</b>なら正解です。'},
 },
}
