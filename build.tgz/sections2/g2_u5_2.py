# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox

S = {
 'id':'g2-u5-2', 'grade':2, 'unit':'5 − 2', 'unit_plain':'5-2',
 'title':'have to', 'pages':'p.62〜63',
 'hero_big':'I have to study today.',
 'hero_jp':'わたしは きょう 勉強しなければ なりません',
 'motto':'<span class="en">have to</span> ＝「～しなければならない」。<b><span class="en">don&#39;t have to</span> は「～しなくてよい」</b>。<span class="en">must not</span> と まったくちがう。',
 'kana':{'have':'ハヴ','has':'ハズ','had':'ハッド','clean':'プロテクト',
         'room':'ルーム','clean':'クリーン','come':'カム','wait':'ウェイト',
         'hurry':'ハリィ','worry':'ワリィ','leave':'リーヴ','early':'アーリィ',
         'today':'トゥデイ','work':'ワーク','clean':'クリーン','room':'ルーム',
         "don't":'ドウント',"doesn't":'ダズント','to':'トゥー'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>勉強しなければ ならない</b>」は <span class="en">must</span> でも言えますが、会話では <span class="en">have to</span> のほうがよく使われます。'),
    ('t','大事なのは、<b>打ち消すと意味が変わる</b>こと。<span class="en">must not</span> とは<b>まったくちがう</b>意味になります。'),
    ('h', gitem('❶', '「～しなければ ならない」', 'must よりやわらかい',
                'きょう 勉強しなければ ならない', 'have to study today',
                [('I have to study today.','わたしは きょう 勉強しなければ なりません。'),
                 ('He has to go now.','彼は 今 行かなければ なりません。')],
                '<b><span class="en">have to</span> ＋ 原形（もとの形）</b>。主語が <span class="en">he・she</span> なら <b><span class="en">has to</span></b> に変わります。')),
    ('h', gitem('❷', '「～しなくても よい」', '禁止ではない！',
                '来なくても よい', 'don&#39;t have to come',
                [('You don&#39;t have to come.','あなたは 来なくても よいです。'),
                 ('He doesn&#39;t have to go.','彼は 行かなくても よいです。')],
                '<b><span class="en">don&#39;t have to</span></b> は「<b>しなくていい</b>」。<span class="en">must not</span>（してはいけない）と<b>反対の意味</b>なので要注意。', b2=True)),
    ('t','<span class="en">have</span> はふつうの動詞なので、打ち消すときは <b><span class="en">don&#39;t ／ doesn&#39;t</span></b> を使います。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜打ち消すと意味が正反対', [
    ('t','ここが今回のヤマです。<span class="en">must not</span> と <span class="en">don&#39;t have to</span> は、<b>意味がまったくちがいます</b>。'),
    ('h','''<div class="judge">
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>must not ＝ 禁止<small>してはいけない</small></span></div>
        <div class="in"><div class="ex">You must not come.<br>＝ 来てはいけない</div></div>
      </div>
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>don&#39;t have to ＝ 不要<small>しなくてよい</small></span></div>
        <div class="in"><div class="ex">You don&#39;t have to come.<br>＝ 来なくてよい</div></div>
      </div>
    </div>'''),
    ('t','「しなければならない」の打ち消しなので「しなくてよい」になります。<b>禁止ではありません</b>。ここを取りちがえると、意味が逆になってしまいます。'),
    ('h','''<div class="heart">
      <div class="hearts">
        <svg class="hb beat"><use href="#i-heart"/></svg>
        <span class="or">か</span>
        <svg class="hp beat"><use href="#i-heart"/></svg>
      </div>
      <div class="txt">
        <div class="h">合言葉：<span class="en">must not</span> は「ダメ」、<span class="en">don&#39;t have to</span> は「しなくていい」</div>
        <p>どちらも「～ない」と訳せますが、<b>中身は正反対</b>です。<br>
        <span class="xm">✕ You don&#39;t have to run here.（走ってはいけない、の意味で使う）✕</span></p>
      </div>
    </div>'''),
  ]),
  ('テストによく出ることば', [
    ('t','<span class="en">have to</span> は<b>ふつうの動詞</b>なので、主語によって形が変わります。ここが <span class="en">must</span> とちがうところです。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>使うとき</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">have to</span></td><td class="k">I・you・they・we</td><td class="e">We <u>have to</u> go.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">has to</span></td><td class="k">he・she・it</td><td class="e">He <u>has to</u> go.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">don&#39;t have to</span></td><td class="k">～しなくてよい</td><td class="e">You <u>don&#39;t have to</u> go.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">doesn&#39;t have to</span></td><td class="k">he・she のとき</td><td class="e">He <u>doesn&#39;t have to</u> go.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">have to</span> ・ <span class="en">has to</span> ・ <span class="en">don&#39;t have to</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('<span class="en">must</span> とのちがい', [
    ('t','<span class="en">must</span> は助動詞、<span class="en">have to</span> はふつうの動詞です。だから<b>形の変わり方がちがいます</b>。'),
    ('h','''<table class="kind">
      <thead><tr><th>くらべること</th><th><span class="en">must</span></th><th><span class="en">have to</span></th></tr></thead>
      <tbody>
        <tr><td class="k">主語が he のとき</td><td class="e">He <u>must</u> go.</td><td class="e">He <u>has to</u> go.</td></tr>
        <tr><td class="k">打ち消し</td><td class="e">He <u>must not</u> go.（禁止）</td><td class="e">He <u>doesn&#39;t have to</u> go.（不要）</td></tr>
        <tr><td class="k">たずねる文</td><td class="e"><u>Must</u> he go?</td><td class="e"><u>Does</u> he <u>have to</u> go?</td></tr>
      </tbody>
    </table>'''),
    ('t','たずねる文も、<span class="en">have to</span> のほうは <span class="en">Do / Does</span> を使います。ふつうの動詞と同じ作り方です。'),
  ]),
  ('過去のことを言うとき', [
    ('t','<span class="en">must</span> には過去形がありません。<b>過去のことは <span class="en">had to</span> で言います</b>。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">I had to go home early.</span>（早く家に帰らなければならなかった）<br>
      <span class="eq" style="color:var(--gv);">I didn&#39;t have to go.</span>（行かなくてよかった）
    </div>'''),
    ('t','ここでも <span class="en">to</span> のうしろは<b>原形（もとの形）</b>のままです。'),
  ]),
 ],
 'quiz':[
  ('He have to go now.','He has to go now.','主語が <span class="en">He</span> なので <b><span class="en">has to</span></b>。','彼は 今 行かなければ なりません。'),
  ('We have to cleaning our room.','We have to clean our room.','<span class="en">to</span> のうしろは<b>原形（もとの形）</b>。','わたしたちは 部屋を そうじしなければ なりません。'),
  ('You haven&#39;t to come.','You don&#39;t have to come.','打ち消しは <b><span class="en">don&#39;t have to</span></b>。<span class="en">have</span> はふつうの動詞です。','あなたは 来なくても よいです。'),
  ('He doesn&#39;t has to go.','He doesn&#39;t have to go.','<span class="en">doesn&#39;t</span> のうしろは<b>原形（もとの形）</b>。<span class="en">has</span> にしません。','彼は 行かなくても よいです。'),
  ('Do he have to go?','Does he have to go?','主語が <span class="en">he</span> なので <b><span class="en">Does</span></b>。','彼は 行かなければ なりませんか。'),
  ('I must to go home.','I have to go home.','<span class="en">must</span> に <span class="en">to</span> はつきません。<span class="en">have to</span> にするか <span class="en">must go</span> にします。','わたしは 家に 帰らなければ なりません。'),
 ],
 'summary':[
  '<b><span class="en">have to ＋ 原形（もとの形）</span></b> ＝「～しなければならない」。<span class="en">must</span> よりやわらかい。',
  '主語が <span class="en">he・she</span> なら <b><span class="en">has to</span></b>。ふつうの動詞と同じ。',
  '<b><span class="en">don&#39;t have to</span> ＝「～しなくてよい」</b>。<span class="en">must not</span>（禁止）とは正反対。',
  'たずねる文は <b><span class="en">Do / Does ～ have to ～?</span></b>。過去は <b><span class="en">had to</span></b>。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～しなければならない」は、<span class="en">have</span>%s＋ 原形（もとの形） で表す。' % bl('to'),
     '主語が <span class="en">he・she</span> のときは%sになる。' % bl('has to', False),
     '打ち消しは%s＋ <span class="en">have to</span> の形にする。' % bl("don't", False),
     '<span class="en">don&#39;t have to</span> は「～し%s」という意味になる。' % bl('なくてよい', False),
     '過去のことを言うときは%sを使う。' % bl('had to', False),
   ]),
   'words':'語群：<span class="en">to</span> ／ <span class="en">has to</span> ／ <span class="en">don&#39;t</span> ／ なくてよい ／ <span class="en">had to</span>',
   'exp':'<b>なぜ？</b>　<span class="en">have to</span> は「～することを持っている」＝「やることになっている」というイメージです。<br>'
         'それを打ち消すと「やることになっていない」＝<b>しなくてよい</b>。禁止ではないのはこのためです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　正しい形を書こう<em>（　）に入るものを書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>主語</b>を見て形を決めましょう。',
   'body':grid2([
     '1. <span class="en">We%sclean our room.</span>' % bl('have to', False),
     '2. <span class="en">He%sgo now.</span>' % bl('has to', False),
     '3. <span class="en">She%sstudy English.</span>' % bl('has to', False),
     '4. <span class="en">They%swait.</span>' % bl('have to', False),
     '5. <span class="en">You%scome.</span>（しなくてよい）' % bl("don't have to", False),
     '6. <span class="en">He%sgo.</span>（しなくてよい）' % bl("doesn't have to", False),
     '7. <span class="en">%syou have to go?</span>' % bl('Do'),
     '8. <span class="en">%she have to go?</span>' % bl('Does'),
     '9. <span class="en">I%sgo home early.</span>（過去）' % bl('had to', False),
     '10. <span class="en">He has to%shis room.</span>' % bl('clean'),
   ]),
   'exp':'<b>見分け方</b>　<span class="en">he・she・it</span> → <span class="en">has to / doesn&#39;t have to / Does</span>（2・3・6・8）<br>'
         'そのほか → <span class="en">have to / don&#39;t have to / Do</span>（1・4・5・7）<br>'
         '過去はどの主語でも <span class="en">had to</span>（9）。10 は <span class="en">to</span> のうしろなので<b>原形（もとの形）</b>。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. He has to go now.','○'), ('2. He have to go now.','✕'),
     ('3. You don&#39;t have to come.','○'), ('4. You haven&#39;t to come.','✕'),
     ('5. Does he have to go?','○'), ('6. Do he have to go?','✕'),
     ('7. He doesn&#39;t have to go.','○'), ('8. He doesn&#39;t has to go.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">has to</span>　4 → <span class="en">don&#39;t have to</span><br>'
         '6 → <span class="en">Does</span>　8 → <span class="en">have to</span>（<span class="en">doesn&#39;t</span> のうしろは原形（もとの形））'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'日本語の意味が<b>「ダメ」</b>か<b>「しなくていい」</b>かを、よく読み取ろう。',
   'body':grid2([
     '1. 来なくてよいです。<span class="en">You （ア must not ／イ don&#39;t have to） come.</span>%s' % bl('イ'),
     '2. ここで走ってはいけません。<span class="en">You （ア must not ／イ don&#39;t have to） run here.</span>%s' % bl('ア'),
     '3. <span class="en">He （ア have ／イ has） to go now.</span>%s' % bl('イ'),
     '4. <span class="en">（ア Do ／イ Does） he have to go?</span>%s' % bl('イ'),
     '5. <span class="en">We have to （ア clean ／イ cleaning） our room.</span>%s' % bl('ア'),
     '6. 行かなくてよかったです。<span class="en">I （ア didn&#39;t have to ／イ must not） go.</span>%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　1・2・6 は<b>意味</b>で選びます。「ダメ」なら <span class="en">must not</span>、「しなくていい」なら <span class="en">don&#39;t have to</span>。<br>'
         '3・4 は主語、5 は <span class="en">to</span> のうしろの形です。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　主語を見て <span class="en">have</span> か <span class="en">has</span> かを決め、<span class="en">to</span> のうしろは原形（もとの形）。',
   'body':ol([
     ('<span class="jp-cue">わたしたちは部屋をそうじしなければなりません。</span>　<span class="en">We%sto clean our room.</span>' % bl('have'),
      '<span class="en">We</span> なので <span class="en">have</span>。'),
     ('<span class="jp-cue">あなたは来なくてもよいです。</span>　<span class="en">You%shave to come.</span>' % bl("don't"),
      '「しなくてよい」は <span class="en">don&#39;t have to</span>。'),
     ('<span class="jp-cue">彼は今、行かなければなりません。</span>　<span class="en">He%sto go now.</span>' % bl('has'),
      '<span class="en">He</span> なので <span class="en">has</span>。'),
     ('<span class="jp-cue">彼女は英語を勉強しなければなりません。</span>　<span class="en">She has%sstudy English.</span>' % bl('to'),
      '<span class="en">has to</span> はセット。'),
     ('<span class="jp-cue">彼は行かなくてもよいです。</span>　<span class="en">He%shave to go.</span>' % bl("doesn't"),
      '<span class="en">He</span> なので <span class="en">doesn&#39;t</span>。'),
     ('<span class="jp-cue">あなたは行かなければなりませんか。</span>　<span class="en">%syou have to go?</span>' % bl('Do'),
      '<span class="en">you</span> なので <span class="en">Do</span>。'),
     ('<span class="jp-cue">彼は行かなければなりませんか。</span>　<span class="en">%she have to go?</span>' % bl('Does'),
      '<span class="en">he</span> なので <span class="en">Does</span>。'),
     ('<span class="jp-cue">わたしは早く家に帰らなければなりませんでした。</span>　<span class="en">I%sto go home early.</span>' % bl('had'),
      '過去は <span class="en">had to</span>。'),
     ('<span class="jp-cue">彼は部屋をそうじしなければなりません。</span>　<span class="en">He has to%shis room.</span>' % bl('clean'),
      '<span class="en">cleans</span> にしない。'),
     ('<span class="jp-cue">わたしたちは待たなければなりません。</span>　<span class="en">We%s%swait.</span>' % (bl('have'), bl('to')),
      '（　）が2つ。<span class="en">have to</span>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　主語 → <span class="en">have / has to</span> → 原形（もとの形）、の順。',
   'body':ol([
     ('<span class="jp-cue">わたしたちは部屋をそうじしなければなりません。</span>　<span class="paren en">（ our room / have to / We / clean ）</span>' + line('We have to clean our room.'),
      '<span class="en">have to clean</span> と続ける。'),
     ('<span class="jp-cue">あなたは来なくてもよいです。</span>　<span class="paren en">（ come / don&#39;t have to / You ）</span>' + line('You don&#39;t have to come.'),
      '<span class="en">don&#39;t have to</span> でひとかたまり。'),
     ('<span class="jp-cue">彼は今、行かなければなりません。</span>　<span class="paren en">（ now / has to / He / go ）</span>' + line('He has to go now.'),
      '<span class="en">has to</span> を選ぶ。'),
     ('<span class="jp-cue">彼は行かなくてもよいです。</span>　<span class="paren en">（ go / doesn&#39;t have to / He ）</span>' + line('He doesn&#39;t have to go.'),
      '<span class="en">doesn&#39;t have to</span> の形。'),
     ('<span class="jp-cue">彼は行かなければなりませんか。</span>　<span class="paren en">（ go / he / Does / have to ）</span>' + line('Does he have to go?'),
      '<span class="en">Does</span> が先頭。'),
     ('<span class="jp-cue">わたしは早く家に帰らなければなりませんでした。</span>　<span class="paren en">（ early / had to / I / go home ）</span>' + line('I had to go home early.'),
      '過去の <span class="en">had to</span>。'),
     ('<span class="jp-cue">彼は部屋をそうじしなければなりません。</span>　<span class="paren en">（ his room / He / clean / has to ）</span>' + line('He has to clean his room.'),
      '<span class="en">clean</span> は原形（もとの形）。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしたちは部屋をそうじしなければなりません。' + wline('We have to clean our room.'),
      '<span class="en">must clean</span> でも意味は近い。'),
     ('あなたは来なくてもよいです。' + wline('You don&#39;t have to come.'),
      '<span class="en">must not</span> にしない。'),
     ('彼は今、行かなければなりません。' + wline('He has to go now.'),
      '<span class="en">have to</span> にしない。'),
     ('彼は行かなくてもよいです。' + wline('He doesn&#39;t have to go.'),
      '<span class="en">doesn&#39;t has</span> にしない。'),
     ('彼は行かなければなりませんか。' + wline('Does he have to go?'),
      '<span class="en">Do</span> にしない。'),
     ('わたしは早く家に帰らなければなりませんでした。' + wline('I had to go home early.'),
      '<span class="en">must</span> に過去形はない。'),
   ]),
   'words':'<span class="en">have to clean ／ don&#39;t have to ／ has to go ／ doesn&#39;t have to ／ Does he have to ／ had to</span>'},
  'l4':{'sub':'自分がしなければならないこと・しなくてよいことを書こう',
   'cond':['<span class="en">have to</span> か <span class="en">has to</span> を使った文を <b>2つ以上</b>',
           '<span class="en">don&#39;t have to</span> を使った文を <b>1つ</b>',
           '<span class="en">had to</span> を使った過去の文も <b>1つ</b> 入れる'],
   'example':['I have to clean my room every Sunday.','I don&#39;t have to go to school on Saturday.','I had to study hard for the test.'],
   'note':'これは例です。同じでなくてかまいません。「しなくてよい」を書くときは、<span class="en">must not</span> と混ぜないよう注意しましょう。',
   'check':['主語が he・she なら has to','to のうしろは原形（もとの形）','「しなくてよい」は don&#39;t have to','過去は had to'],
   'review':'じぶんの文を日本語に直してみよう。「ダメ」と「しなくていい」が入れかわっていないか確かめよう。'},
 },
}
