# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf

S = {
 'id':'g2-u3-2', 'grade':2, 'unit':'3 − 2', 'unit_plain':'3-2',
 'title':'助動詞 will', 'pages':'p.34〜35',
 'hero_big':'It will be sunny tomorrow.',
 'hero_jp':'あしたは 晴れるでしょう',
 'motto':'<span class="en">will</span> のうしろは <b>かざりのない「原形（もとの形）」</b>。<span class="en">will not ＝ won&#39;t</span>。',
 'kana':{'will':'ウィル',"won't":'ウォウント','hot':'ホット','cold':'コウルド',
         'rain':'レイン','sunny':'サニィ','cloudy':'クラウディ','tomorrow':'トゥモロウ',
         'next':'ネクスト','week':'ウィーク','be':'ビー','come':'カム','help':'ヘルプ',
         'snow':'スノウ','later':'レイター','someday':'サムデイ','probably':'プロバブリィ',
         'it':'イット','he':'ヒー','they':'ゼイ'},
 'blocks':[
  ('きほんの文', [
    ('t','<span class="en">will</span> も、これからのことを言う形です。<b>その場で思ったこと</b>や<b>予想</b>を言うときによく使います。'),
    ('h','''<div class="exbox">
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">It will be sunny tomorrow.</span><span class="t">あしたは 晴れるでしょう。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">Will it be sunny tomorrow?</span><span class="t">あしたは 晴れるでしょうか。</span></div>
      <div class="exline"><svg class="pn"><use href="#i-pen"/></svg><span class="s en">— Yes, it will. ／ No, it won&#39;t.</span><span class="t">— はい、晴れるでしょう。／ いいえ、晴れないでしょう。</span></div>
    </div>'''),
    ('t','<span class="en">will</span> は1年生でならった <span class="en">can</span> の仲間です。<b>使い方はまったく同じ</b>なので、覚え直す必要はありません。'),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div>きほんの文を3回音読して、さらに3回ずつ書き写そう</div>
    </div>'''),
  ]),
  ('かなり大事｜<span class="en">will</span> は <span class="en">can</span> と同じ仲間', [
    ('t','ここが今回のヤマです。<span class="en">will</span> は <span class="en">can</span> と<b>まったく同じルール</b>で動きます。3つおぼえれば終わりです。'),
    ('h','''<table class="kind">
      <thead><tr><th>やること</th><th><span class="en">can</span>（1年生）</th><th><span class="en">will</span>（今回）</th></tr></thead>
      <tbody>
        <tr><td class="k">うしろの形</td><td class="e">I <u>can swim</u>.</td><td class="e">It <u>will be</u> hot.</td></tr>
        <tr><td class="k">たずねる文</td><td class="e"><u>Can</u> you swim?</td><td class="e"><u>Will</u> it be hot?</td></tr>
        <tr><td class="k">打ち消し</td><td class="e">I <u>can&#39;t</u> swim.</td><td class="e">It <u>won&#39;t</u> be hot.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ 原形（もとの形）<small>will ＋ be / come</small></span></div>
        <div class="in"><div class="ex">It will be hot.<br>He will come tomorrow.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ かざりつき<small>will ＋ is / comes</small></span></div>
        <div class="in"><div class="ex">It will is hot.<br>He will comes tomorrow.</div></div>
      </div>
    </div>'''),
    ('t','主語が <span class="en">he</span> でも <span class="en">will</span> に <span class="en">s</span> はつきません。<b>助動詞は形が変わらない</b>からです。'),
  ]),
  ('テストによく出ることば', [
    ('t','<span class="en">will</span> のうしろでいちばんよく出るのが <span class="en">be</span> です。<b><span class="en">is</span> ではない</b>ことに注意しましょう。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味・使うとき</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">will be</span></td><td class="k">～になるでしょう</td><td class="e">It <u>will be</u> hot.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">will</span></td><td class="k">～するでしょう</td><td class="e">He <u>will</u> come.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">won&#39;t</span></td><td class="k">will not を短くした形</td><td class="e">It <u>won&#39;t</u> rain.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">Will you</span></td><td class="k">～してくれますか</td><td class="e"><u>Will you</u> help me?</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">will be</span> ・ <span class="en">won&#39;t</span> ・ <span class="en">Will you</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('<span class="en">be going to</span> とのちがい', [
    ('t','どちらも「これからのこと」ですが、<b>気もちがちがいます</b>。'),
    ('h','''<table class="kind">
      <thead><tr><th>形</th><th>気もち</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k" style="color:var(--key);font-weight:700;">be going to</td><td class="k">もう決めてある予定</td><td class="e">I&#39;m going to visit Okinawa.</td></tr>
        <tr><td class="k" style="color:var(--gv);font-weight:700;">will</td><td class="k">予想・その場で決めたこと</td><td class="e">It will be hot next week.</td></tr>
      </tbody>
    </table>'''),
    ('t','天気の予想のように、<b>自分では決められないこと</b>には <span class="en">will</span> を使います。'),
  ]),
  ('<span class="en">&#39;ll</span> と短くできる', [
    ('t','会話では、主語とくっつけて短く言うことがよくあります。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">I will → I&#39;ll</span>　<span class="eq" style="color:var(--gv);">he will → he&#39;ll</span>　<span class="eq" style="color:var(--gv);">it will → it&#39;ll</span>　<span class="eq" style="color:var(--gv);">will not → won&#39;t</span>
    </div>'''),
    ('t','<span class="en">won&#39;t</span> は <span class="en">will not</span> の短い形です。<span class="en">willn&#39;t</span> とは書きません。'),
  ]),
 ],
 'quiz':[
  ('It will is hot next week.','It will be hot next week.','<span class="en">will</span> のうしろは<b>原形（もとの形）</b>。<span class="en">is</span> の原形（もとの形）は <b><span class="en">be</span></b>。','来週は 暑く なるでしょう。'),
  ('He will comes tomorrow.','He will come tomorrow.','助動詞のうしろに <span class="en">s</span> はつけません。','彼は あした 来るでしょう。'),
  ('It willn&#39;t rain.','It won&#39;t rain.','<span class="en">will not</span> の短い形は <b><span class="en">won&#39;t</span></b>。','雨は ふらないでしょう。'),
  ('Do you will come tomorrow?','Will you come tomorrow?','<b><span class="en">Will</span> を前に出す</b>だけ。<span class="en">Do</span> は使いません。','あなたは あした 来ますか。'),
  ('Will it be hot? — Yes, it does.','Will it be hot? — Yes, it will.','<span class="en">Will</span> で聞かれたら <b><span class="en">will</span> で答えます</b>。','暑く なるでしょうか。— はい、なるでしょう。'),
  ('He wills come tomorrow.','He will come tomorrow.','<span class="en">will</span> は<b>形が変わりません</b>。','彼は あした 来るでしょう。'),
 ],
 'summary':[
  '<b><span class="en">will ＋ 動詞の原形（もとの形）</span></b> ＝「～するでしょう／～します」。',
  '<span class="en">will</span> は <span class="en">can</span> と同じ仲間。<b>たずねる文は前に出す、打ち消しは <span class="en">won&#39;t</span></b>。',
  '<b><span class="en">will be</span></b> に注意。<span class="en">will is</span> とは書かない。',
  '<span class="en">be going to</span>＝決めてある予定、<span class="en">will</span>＝予想・その場で決めたこと。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '<span class="en">will</span> のうしろは、動詞の%sの形にする。' % bl('もと'),
     '主語が <span class="en">he</span> でも、<span class="en">will</span> に%sはつけない。' % bl('s'),
     'たずねる文は、<span class="en">will</span> を文の%sに出す。' % bl('前'),
     '<span class="en">will not</span> を短くすると%sになる。' % bl("won't"),
     '<span class="en">is・am・are</span> の原形（もとの形）は%sである。' % bl('be'),
   ]),
   'words':'語群：もと ／ <span class="en">s</span> ／ 前 ／ <span class="en">won&#39;t</span> ／ <span class="en">be</span>',
   'exp':'<b>なぜ？</b>　<span class="en">will</span> は <span class="en">can</span> と同じ<b>助っ人のことば（助動詞）</b>です。<br>'
         '助っ人がいるあいだ、本来の動詞は<b>まっさらな形で待っている</b>と考えるとおぼえやすいです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">will</span> のうしろの形を書こう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>be動詞の原形（もとの形）は <span class="en">be</span></b> です。',
   'body':grid2([
     '1. <span class="en">It will%shot.</span>' % bl('be'),
     '2. <span class="en">He will%stomorrow.</span>' % bl('come'),
     '3. <span class="en">It will%stomorrow.</span>' % bl('rain'),
     '4. <span class="en">She will%sbusy.</span>' % bl('be'),
     '5. <span class="en">They will%ssoccer.</span>' % bl('play'),
     '6. <span class="en">I will%syou.</span>' % bl('help'),
     '7. <span class="en">It will%scold.</span>' % bl('be'),
     '8. <span class="en">He will%sEnglish.</span>' % bl('study'),
     '9. <span class="en">We will%sthere.</span>' % bl('be'),
     '10. <span class="en">It will%snext week.</span>' % bl('snow'),
   ]),
   'exp':'<b>かくにん</b>　ようすのことば・名前が続くときは <span class="en">be</span>（1・4・7・9）。<br>'
         'そのほかの動作のことばは、そのまま<b>原形（もとの形）</b>で置きます（2・3・5・6・8・10）。<br>'
         '<span class="en">comes・rains・studies</span> のように <span class="en">s</span> をつけないこと。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. It will be hot next week.','○'), ('2. It will is hot next week.','✕'),
     ('3. He will come tomorrow.','○'), ('4. He will comes tomorrow.','✕'),
     ('5. It won&#39;t rain.','○'), ('6. It willn&#39;t rain.','✕'),
     ('7. Will you help me?','○'), ('8. Do you will help me?','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">be</span>　4 → <span class="en">come</span>（<span class="en">s</span> をとる）<br>'
         '6 → <span class="en">won&#39;t</span>　8 → <span class="en">Will you help me?</span>（<span class="en">Do</span> を使わない）'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'1年生の <span class="en">can</span> と同じ形になっているかを確かめよう。',
   'body':grid2([
     '1. <span class="en">It will （ア be ／イ is） hot next week.</span>%s' % bl('ア'),
     '2. <span class="en">He will （ア comes ／イ come） tomorrow.</span>%s' % bl('イ'),
     '3. <span class="en">（ア Will ／イ Do） you help me?</span>%s' % bl('ア'),
     '4. <span class="en">It （ア willn&#39;t ／イ won&#39;t） rain.</span>%s' % bl('イ'),
     '5. <span class="en">Will it be hot? — Yes, it （ア will ／イ does）.</span>%s' % bl('ア'),
     '6. <span class="en">He （ア wills ／イ will） study English.</span>%s' % bl('イ'),
   ]),
   'exp':'<b>ここが大事</b>　2・6 は<b>助動詞に <span class="en">s</span> はつかない</b>というルール。<br>'
         '3・5 は <span class="en">do</span> を混ぜないこと。1 は <span class="en">be動詞の原形（もとの形）</span>、4 は短い形のつづりです。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　<span class="en">will</span> を書いたら、うしろは<b>何もつけない形</b>にしよう。',
   'body':ol([
     ('<span class="jp-cue">来週は暑くなるでしょう。</span>　<span class="en">It will%shot next week.</span>' % bl('be'),
      '<span class="en">is</span> ではなく <b><span class="en">be</span></b>。'),
     ('<span class="jp-cue">来週は暑くなるでしょうか。</span>　<span class="en">%sit be hot next week?</span>' % bl('Will'),
      '<span class="en">Will</span> を前に出す。'),
     ('<span class="jp-cue">はい、なるでしょう。</span>　<span class="en">Yes, it%s.</span>' % bl('will'),
      '<span class="en">will</span> で答える。'),
     ('<span class="jp-cue">いいえ、ならないでしょう。</span>　<span class="en">No, it%s.</span>' % bl("won't"),
      '短い形は <span class="en">won&#39;t</span>。'),
     ('<span class="jp-cue">彼はあした来るでしょう。</span>　<span class="en">He will%stomorrow.</span>' % bl('come'),
      '<span class="en">comes</span> にしない。'),
     ('<span class="jp-cue">あした雨はふらないでしょう。</span>　<span class="en">It%srain tomorrow.</span>' % bl("won't"),
      '打ち消しは <span class="en">won&#39;t</span>。'),
     ('<span class="jp-cue">手伝ってくれますか。</span>　<span class="en">%syou help me?</span>' % bl('Will'),
      '「～してくれますか」も <span class="en">Will you</span>。'),
     ('<span class="jp-cue">彼女は忙しいでしょう。</span>　<span class="en">She%s%sbusy.</span>' % (bl('will'), bl('be')),
      '（　）が2つ。<span class="en">will be</span>。'),
     ('<span class="jp-cue">わたしがあなたを手伝います。</span>　<span class="en">I%shelp you.</span>' % bl('will'),
      'その場で決めたことにも使う。'),
     ('<span class="jp-cue">来週は雪がふるでしょう。</span>　<span class="en">It will%snext week.</span>' % bl('snow'),
      '「雪がふる」は <span class="en">snow</span>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　主語 → <span class="en">will</span> → 原形（もとの形） → そのほか、の順。',
   'body':ol([
     ('<span class="jp-cue">来週は暑くなるでしょう。</span>　<span class="paren en">（ hot / It / next week / will be ）</span>' + line('It will be hot next week.'),
      '<span class="en">will be</span> でひとかたまり。'),
     ('<span class="jp-cue">来週は暑くなるでしょうか。</span>　<span class="paren en">（ next week / be hot / Will / it ）</span>' + line('Will it be hot next week?'),
      '<span class="en">Will</span> が先頭。終わりは <b>?</b>。'),
     ('<span class="jp-cue">彼はあした来るでしょう。</span>　<span class="paren en">（ tomorrow / come / He / will ）</span>' + line('He will come tomorrow.'),
      '<span class="en">He will come</span> の順。'),
     ('<span class="jp-cue">あした雨はふらないでしょう。</span>　<span class="paren en">（ tomorrow / rain / It / won&#39;t ）</span>' + line('It won&#39;t rain tomorrow.'),
      '<span class="en">won&#39;t</span> のうしろも原形（もとの形）。'),
     ('<span class="jp-cue">手伝ってくれますか。</span>　<span class="paren en">（ me / you / Will / help ）</span>' + line('Will you help me?'),
      '<span class="en">Will you</span> ＋ 原形（もとの形）。'),
     ('<span class="jp-cue">彼女は忙しいでしょう。</span>　<span class="paren en">（ busy / She / be / will ）</span>' + line('She will be busy.'),
      '<span class="en">will be</span> を続ける。'),
     ('<span class="jp-cue">わたしたちはそこにいるでしょう。</span>　<span class="paren en">（ there / will / We / be ）</span>' + line('We will be there.'),
      '<span class="en">be there</span> で「そこにいる」。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('来週は暑くなるでしょう。' + wline('It will be hot next week.'),
      '<span class="en">will is</span> にしない。'),
     ('来週は暑くなるでしょうか。' + wline('Will it be hot next week?'),
      '<span class="en">Will</span> を前に出す。'),
     ('彼はあした来るでしょう。' + wline('He will come tomorrow.'),
      '<span class="en">comes</span> にしない。'),
     ('あした雨はふらないでしょう。' + wline('It won&#39;t rain tomorrow.'),
      '<span class="en">will not</span> でも正解。'),
     ('手伝ってくれますか。' + wline('Will you help me?'),
      '<span class="en">Do you</span> にしない。'),
     ('彼女は忙しいでしょう。' + wline('She will be busy.'),
      '<span class="en">She&#39;ll be busy.</span> でも正解。'),
   ]),
   'words':'<span class="en">will be hot ／ Will it ／ will come ／ won&#39;t rain ／ Will you help ／ will be busy</span>'},
  'l4':{'sub':'あしたや来週がどうなると思うか、予想を書こう',
   'cond':['<span class="en">will</span> を使った文を <b>2つ以上</b>',
           '<span class="en">won&#39;t</span> を使った打ち消しの文を <b>1つ</b>',
           '<span class="en">will be</span> を使った文を <b>1つ</b> 入れる'],
   'example':['It will be sunny tomorrow.','I will study English after dinner.','It won&#39;t rain this weekend.'],
   'note':'これは例です。同じでなくてかまいません。天気・テスト・部活など、予想しやすいことで書いてみよう。',
   'check':['will のうしろは原形（もとの形）','will be に なっているか','打ち消しは won&#39;t','will に s をつけていない'],
   'review':'じぶんの文の <span class="en">will</span> のうしろに○をつけよう。<span class="en">is</span> や <span class="en">s</span> があったら、そこがまちがい。'},
 },
}
