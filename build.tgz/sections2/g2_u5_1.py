# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox

S = {
 'id':'g2-u5-1', 'grade':2, 'unit':'5 − 1', 'unit_plain':'5-1',
 'title':'助動詞 must', 'pages':'p.60〜61',
 'hero_big':'You must study hard.',
 'hero_jp':'あなたは 一生けんめい 勉強しなければ なりません',
 'motto':'<span class="en">must</span> ＝「～しなければならない」。うしろは <b>原形（もとの形）</b>。<span class="en">must not</span> は <b>「～してはいけない」</b>。',
 'kana':{'must':'マスト','study':'スタディ','hard':'ハード',
         'forget':'フォゲット','include':'インクルード','bring':'ブリング','bag':'バッグ',
         'evacuation':'イヴァキュエイション','wash':'ウォッシュ','hands':'ハンヅ',
         'run':'ラン','touch':'タッチ','study':'スタディ','hurry':'ハリィ',
         'now':'ナウ','here':'ヒア','not':'ノット'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>勉強しなければ ならない</b>」「<b>走っては いけない</b>」のように、<b>強く言う</b>ときの形です。'),
    ('t','<span class="en">must</span> は <span class="en">can・will</span> の仲間（助動詞）。<b>そのままの形</b>と<b>打ち消した形</b>で意味が大きく変わります。'),
    ('h', gitem('❶', '「～しなければ ならない」', 'しなさい、という強い言い方',
                '一生けんめい 勉強しなければ ならない', 'must study hard',
                [('You must study hard.','あなたは 一生けんめい 勉強しなければ なりません。'),
                 ('He must go now.','彼は 今 行かなければ なりません。')],
                '<b><span class="en">must</span> ＋ 動詞の原形（もとの形）</b>。主語がだれでも <span class="en">must</span> の形は<b>変わりません</b>。')),
    ('h', gitem('❷', '「～しては いけない」', '禁止する言い方',
                'ここで 走っては いけない', 'must not run here',
                [('You must not run here.','あなたは ここで 走っては いけません。'),
                 ('You must not forget your bag.','かばんを 忘れては いけません。')],
                '<b><span class="en">must not</span></b> は「しなくてよい」ではなく <b>「ぜったいにするな」</b>という強い禁止です。', b2=True)),
    ('t','うしろが <b>ようすのことば</b>のときは <span class="en">be</span> が必要です（<span class="en">You must be careful.</span>）。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜<span class="en">must not</span> は「禁止」', [
    ('t','ここが今回のヤマです。<span class="en">must</span> に <span class="en">not</span> がつくと、<b>「しなくてよい」ではなく「してはいけない」</b>になります。'),
    ('h','''<table class="kind">
      <thead><tr><th>形</th><th>意味</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k" style="color:var(--key);font-weight:700;">must</td><td class="k">～しなければならない</td><td class="e">You <u>must</u> wash your hands.</td></tr>
        <tr><td class="k" style="color:var(--ng);font-weight:700;">must not</td><td class="k">～してはいけない（禁止）</td><td class="e">You <u>must not</u> run here.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ 禁止の意味<small>してはいけない</small></span></div>
        <div class="in"><div class="ex">You must not run here.<br>＝ 走ってはいけない</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ しなくてよい<small>という意味ではない</small></span></div>
        <div class="in"><div class="ex">You must not run here.<br>≠ 走らなくてよい</div></div>
      </div>
    </div>'''),
    ('t','<span class="en">Don&#39;t run here.</span>（走るな）とほぼ同じ強さです。かなり強い言い方なので、看板や注意書きでよく使われます。'),
  ]),
  ('テストによく出ることば', [
    ('t','<span class="en">must</span> は<b>形が変わらない</b>のが特ちょうです。主語が何でも、いつのことでも同じ形です。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>意味</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">must</span></td><td class="k">～しなければならない</td><td class="e">You <u>must</u> studyt.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">must not</span></td><td class="k">～してはいけない</td><td class="e">You <u>must not</u> run.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">mustn&#39;t</span></td><td class="k">must not の短い形</td><td class="e">You <u>mustn&#39;t</u> run.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">must be</span></td><td class="k">～でなければならない</td><td class="e">You <u>must be</u> careful.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">must</span> ・ <span class="en">must not</span> ・ <span class="en">must be</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('<span class="en">can・will</span> と同じルール', [
    ('t','助動詞なので、1年生でならった <span class="en">can</span> とまったく同じように動きます。'),
    ('h','''<table class="kind">
      <thead><tr><th>やること</th><th>ルール</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k">うしろの形</td><td class="k" style="color:var(--ng);font-weight:700;">原形（もとの形）</td><td class="e">He must <u>study</u>.</td></tr>
        <tr><td class="k">主語が he でも</td><td class="k" style="color:var(--ng);font-weight:700;">s をつけない</td><td class="e">He <u>must</u> go.</td></tr>
        <tr><td class="k">たずねる文</td><td class="k">must を前に出す</td><td class="e"><u>Must</u> I go?</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">musts</span> とは書きません。<b>助動詞は形が変わらない</b>、これが共通のルールです。'),
  ]),
  ('注意書きでよく見る形', [
    ('t','災害や安全についての文では、<span class="en">must</span> と <span class="en">must not</span> がセットで出てきます。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">You must study ～.</span>（勉強しなければならない）<br>
      <span class="eq" style="color:var(--gv);">You must not forget ～.</span>（忘れてはいけない）<br>
      <span class="eq" style="color:var(--gv);">You must be careful.</span>（気をつけなければならない）
    </div>'''),
    ('t','<span class="en">must be</span> の <span class="en">be</span> を忘れる人が多いところです。「～<b>でなければならない</b>」と、ようすのことばが続くときは <span class="en">be</span> が必要です。'),
  ]),
 ],
 'quiz':[
  ('You must studies hard.','You must study hard.','助動詞のうしろは<b>原形（もとの形）</b>。<span class="en">s</span> はつけません。','あなたは 一生けんめい 勉強しなければ なりません。'),
  ('He musts go now.','He must go now.','<span class="en">must</span> は<b>形が変わりません</b>。','彼は 今 行かなければ なりません。'),
  ('You must not to run here.','You must not run here.','<span class="en">to</span> はいりません。<span class="en">must not</span> ＋ 原形（もとの形）。','あなたは ここで 走っては いけません。'),
  ('You don&#39;t must run here.','You must not run here.','打ち消しは <span class="en">must</span> のうしろに <b><span class="en">not</span></b>。','あなたは ここで 走っては いけません。'),
  ('You must careful.','You must be careful.','「気をつけ<b>なければならない</b>」のように、ようすのことばが続くときは <b><span class="en">be</span></b> が必要です。','あなたは 気をつけなければ なりません。'),
  ('You must not forget to bringing your bag.','You must not forget to bring your bag.','<span class="en">to</span> のうしろも<b>原形（もとの形）</b>です。','あなたは かばんを 持ってくるのを 忘れては いけません。'),
 ],
 'summary':[
  '<b><span class="en">must ＋ 原形（もとの形）</span></b> ＝「～しなければならない」。強い言い方。',
  '<b><span class="en">must not</span> ＝「～してはいけない」</b>（禁止）。「しなくてよい」ではない。',
  '<span class="en">must</span> は <b>形が変わらない</b>。主語が <span class="en">he</span> でも <span class="en">s</span> をつけない。',
  '「～でなければならない」でようすのことばが続くときは <b><span class="en">must be</span></b>。<span class="en">be</span> を忘れない。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '<span class="en">must</span> は「～しなければ%s」という意味である。' % bl('ならない', False),
     '<span class="en">must</span> のうしろは、動詞の%sの形にする。' % bl('もと'),
     '主語が <span class="en">he</span> でも、<span class="en">must</span> に%sはつけない。' % bl('s'),
     '<span class="en">must not</span> は「～しては%s」という禁止の意味になる。' % bl('いけない', False),
     '「～でなければならない」でようすのことばが続くときは、<span class="en">must</span> のうしろに%sを置く。' % bl('be'),
   ]),
   'words':'語群：ならない ／ もと ／ <span class="en">s</span> ／ いけない ／ <span class="en">be</span>',
   'exp':'<b>なぜ？</b>　<span class="en">not</span> は<b>すぐうしろのことば</b>を打ち消します。<br>'
         '<span class="en">must not run</span> は「走る、を しない ことが must」＝<b>走らないことが義務</b>。だから「してはいけない」になるのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">must</span> のうしろの形を書こう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>ようすのことばが続くなら <span class="en">be</span></b> です。',
   'body':grid2([
     '1. <span class="en">You must%shard.</span>' % bl('study'),
     '2. <span class="en">You must%scareful.</span>' % bl('be'),
     '3. <span class="en">He must%snow.</span>' % bl('go'),
     '4. <span class="en">You must%syour hands.</span>' % bl('wash'),
     '5. <span class="en">We must%squiet.</span>' % bl('be'),
     '6. <span class="en">She must%sEnglish.</span>' % bl('study'),
     '7. <span class="en">You must not%shere.</span>' % bl('run'),
     '8. <span class="en">You must not%sit.</span>' % bl('touch'),
     '9. <span class="en">I must%shome.</span>' % bl('go'),
     '10. <span class="en">They must%son time.</span>' % bl('be'),
   ]),
   'exp':'<b>かくにん</b>　ようすのことば・場所が続くときは <span class="en">be</span>（2・5・10）。<br>'
         'そのほかは動作のことばを<b>原形（もとの形）</b>で置きます。<span class="en">studies・goes・plays</span> にしないこと。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. You must study hard.','○'), ('2. You must studies hard.','✕'),
     ('3. He must go now.','○'), ('4. He musts go now.','✕'),
     ('5. You must not run here.','○'), ('6. You don&#39;t must run here.','✕'),
     ('7. You must be careful.','○'), ('8. You must careful.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">study</span>　4 → <span class="en">must</span>（<span class="en">s</span> をとる）<br>'
         '6 → <span class="en">You must not run here.</span>　8 → <span class="en">be</span> を入れる'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'日本語の意味をよく読んで、<b>禁止</b>かどうかを見分けよう。',
   'body':grid2([
     '1. <span class="en">You must （ア study ／イ studies） hard.</span>%s' % bl('ア'),
     '2. ここで走ってはいけない。<span class="en">You （ア must not ／イ don&#39;t must） run here.</span>%s' % bl('ア'),
     '3. <span class="en">He （ア musts ／イ must） go now.</span>%s' % bl('イ'),
     '4. 気をつけなければならない。<span class="en">You must （ア be ／イ 　） careful.</span>%s' % bl('ア'),
     '5. <span class="en">You must not （ア to touch ／イ touch） it.</span>%s' % bl('イ'),
     '6. 手を洗わなければならない。<span class="en">You （ア must ／イ must not） wash your hands.</span>%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　2・6 は意味で <span class="en">must</span> と <span class="en">must not</span> を選びます。<br>'
         '1・3・5 は形のルール（原形（もとの形）・<span class="en">s</span> なし・<span class="en">to</span> なし）。4 は <span class="en">be</span> の有無です。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　<span class="en">must</span> を書いたら、うしろは<b>何もつけない形</b>にしよう。',
   'body':ol([
     ('<span class="jp-cue">あなたは一生けんめい勉強しなければなりません。</span>　<span class="en">You%sstudy hard.</span>' % bl('must'),
      '「～しなければならない」は <span class="en">must</span>。'),
     ('<span class="jp-cue">かばんを持ってくるのを忘れてはいけません。</span>　<span class="en">You must%sforget to bring your bag.</span>' % bl('not'),
      '禁止は <span class="en">must not</span>。'),
     ('<span class="jp-cue">あなたは気をつけなければなりません。</span>　<span class="en">You must%scareful.</span>' % bl('be'),
      'ようすのことばの前は <span class="en">be</span>。'),
     ('<span class="jp-cue">彼は今、行かなければなりません。</span>　<span class="en">He must%snow.</span>' % bl('go'),
      '<span class="en">goes</span> にしない。'),
     ('<span class="jp-cue">ここで走ってはいけません。</span>　<span class="en">You must not%shere.</span>' % bl('run'),
      '<span class="en">must not</span> ＋ 原形（もとの形）。'),
     ('<span class="jp-cue">手を洗わなければなりません。</span>　<span class="en">You must%syour hands.</span>' % bl('wash'),
      '「洗う」は <span class="en">wash</span>。'),
     ('<span class="jp-cue">わたしたちは静かにしなければなりません。</span>　<span class="en">We%s%squiet.</span>' % (bl('must'), bl('be')),
      '（　）が2つ。<span class="en">must be</span>。'),
     ('<span class="jp-cue">それにさわってはいけません。</span>　<span class="en">You%snot touch it.</span>' % bl('must'),
      '<span class="en">must not</span> の形。'),
     ('<span class="jp-cue">彼女は英語を勉強しなければなりません。</span>　<span class="en">She must%sEnglish.</span>' % bl('study'),
      '<span class="en">studies</span> にしない。'),
     ('<span class="jp-cue">あなたは時間を守らなければなりません。</span>　<span class="en">You must be%stime.</span>' % bl('on'),
      '<span class="en">on time</span> で「時間どおりに」。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　主語 → <span class="en">must</span> →（<span class="en">not</span>）→ 原形（もとの形）、の順。',
   'body':ol([
     ('<span class="jp-cue">あなたは一生けんめい勉強しなければなりません。</span>　<span class="paren en">（ hard / must / You / study ）</span>' + line('You must study hard.'),
      '<span class="en">must study</span> の順。'),
     ('<span class="jp-cue">ここで走ってはいけません。</span>　<span class="paren en">（ here / must not / run / You ）</span>' + line('You must not run here.'),
      '<span class="en">must not</span> でひとかたまり。'),
     ('<span class="jp-cue">あなたは気をつけなければなりません。</span>　<span class="paren en">（ careful / be / You / must ）</span>' + line('You must be careful.'),
      '<span class="en">must be</span> を続ける。'),
     ('<span class="jp-cue">彼は今、行かなければなりません。</span>　<span class="paren en">（ now / go / He / must ）</span>' + line('He must go now.'),
      '<span class="en">must</span> に <span class="en">s</span> はつかない。'),
     ('<span class="jp-cue">手を洗わなければなりません。</span>　<span class="paren en">（ your hands / must / wash / You ）</span>' + line('You must wash your hands.'),
      '「何を」はうしろ。'),
     ('<span class="jp-cue">それにさわってはいけません。</span>　<span class="paren en">（ it / must not / You / touch ）</span>' + line('You must not touch it.'),
      '禁止の形。'),
     ('<span class="jp-cue">わたしたちは静かにしなければなりません。</span>　<span class="paren en">（ quiet / must / We / be ）</span>' + line('We must be quiet.'),
      '<span class="en">be quiet</span> で「静かにする」。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('あなたは一生けんめい勉強しなければなりません。' + wline('You must study hard.'),
      '<span class="en">studies</span> にしない。'),
     ('かばんを持ってくるのを忘れてはいけません。' + wline('You must not forget to bring your bag.'),
      '<span class="en">must not</span> の形。'),
     ('あなたは気をつけなければなりません。' + wline('You must be careful.'),
      '<span class="en">be</span> を忘れない。'),
     ('ここで走ってはいけません。' + wline('You must not run here.'),
      '<span class="en">mustn&#39;t</span> でも正解。'),
     ('彼は今、行かなければなりません。' + wline('He must go now.'),
      '<span class="en">musts</span> にしない。'),
     ('わたしたちは静かにしなければなりません。' + wline('We must be quiet.'),
      '<span class="en">must be</span> の形。'),
   ]),
   'words':'<span class="en">must study ／ must not forget ／ must be careful ／ must not run ／ must go ／ must be quiet</span>'},
  'l4':{'sub':'教室や家でのきまりを、<span class="en">must</span> を使って書こう',
   'cond':['<span class="en">must</span> を使った文を <b>2つ以上</b>',
           '<span class="en">must not</span> を使った文を <b>1つ以上</b>',
           '<span class="en">must be</span> を使った文も <b>1つ</b> 入れる'],
   'example':['You must do your homework every day.','You must not use your phone in class.','You must be quiet in the library.'],
   'note':'これは例です。同じでなくてかまいません。防災・教室・図書館などのきまりで書くと書きやすいです。',
   'check':['must のうしろは原形（もとの形）','must に s をつけていない','禁止は must not','ようすのことばの前は must be'],
   'review':'じぶんの文の <span class="en">must</span> のうしろに○をつけよう。<span class="en">s</span> や <span class="en">to</span> があったら、そこがまちがい。'},
 },
}
