# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox

S = {
 'id':'g2-u3-1', 'grade':2, 'unit':'3 − 1', 'unit_plain':'3-1',
 'title':'be going to', 'pages':'p.32〜33',
 'hero_big':'I am going to play tennis.',
 'hero_jp':'わたしは テニスを する 予定です',
 'motto':'<b><span class="en">be動詞 ＋ going to ＋ 原形（もとの形）</span></b> で「～する予定」。be動詞は <b>主語で決まる</b>。',
 'kana':{'going':'ゴウイング','visit':'ヴィズィット','okinawa':'オキナワ',
         'tomorrow':'トゥモロウ','next':'ネクスト','week':'ウィーク','weekend':'ウィークエンド',
         'plan':'プラン','plans':'プランズ','summer':'サマー','vacation':'ヴェイケイション',
         'study':'スタディ','play':'プレイ','watch':'ウォッチ','buy':'バイ','stay':'ステイ',
         'am':'アム','are':'アー','is':'イズ','going':'ゴウイング'},
 'blocks':[
  ('きほんの文', [
    ('t','「<b>テニスをする 予定です</b>」のように、<b>もう決めてある これからの予定</b>を言う形です。'),
    ('t','形は <b><span class="en">be</span>動詞 ＋ <span class="en">going to</span> ＋ 動詞の原形（もとの形）</b>。たずね方もいっしょにならいます。'),
    ('h', gitem('❶', '「～する 予定です」と言う', 'ふつうの文',
                'テニスを する 予定です', 'am going to play tennis',
                [('I am going to play tennis.','わたしは テニスを する 予定です。'),
                 ('He is going to study tonight.','彼は 今夜 勉強する 予定です。')],
                '<span class="en">be</span>動詞は主語で変わります（<span class="en">I→am、He→is、They→are</span>）。<b>going to のうしろは原形（もとの形）</b>。')),
    ('h', gitem('❷', '「～する 予定ですか」とたずねる', '疑問文',
                'テニスを する 予定ですか', 'Are you going to play tennis?',
                [('Are you going to play tennis?','あなたは テニスを する 予定ですか。'),
                 ('— Yes, I am. ／ No, I&#39;m not.','— はい、そうです。／ いいえ、ちがいます。')],
                '<b><span class="en">be</span>動詞を前に出す</b>だけ。答えるときも <span class="en">be</span>動詞を使います。', b2=True)),
    ('t','<span class="en">going</span> があっても「行く」という意味ではありません。<b>3語で1セット</b>とおぼえましょう。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜変えるのは be動詞だけ', [
    ('t','ここが今回のヤマです。主語が変わっても、変わるのは<b>be動詞だけ</b>。<span class="en">going to</span> から先は<b>いつも同じ</b>です。'),
    ('h','''<table class="kind">
      <thead><tr><th>主語</th><th>be動詞</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k">I（わたし）</td><td class="k" style="color:var(--key);font-weight:700;">am</td><td class="e">I <u>am</u> going to visit Okinawa.</td></tr>
        <tr><td class="k">he / she・名前</td><td class="k" style="color:var(--key);font-weight:700;">is</td><td class="e">He <u>is</u> going to visit Okinawa.</td></tr>
        <tr><td class="k">you・they・we</td><td class="k" style="color:var(--key);font-weight:700;">are</td><td class="e">They <u>are</u> going to visit Okinawa.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ be動詞を合わせる<small>うしろはいつも同じ</small></span></div>
        <div class="in"><div class="ex">He is going to visit.<br>They are going to visit.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ うしろを変える<small>s や ing をつける</small></span></div>
        <div class="in"><div class="ex">He is going to visits.<br>He is going to visiting.</div></div>
      </div>
    </div>'''),
    ('t','<span class="en">to</span> のうしろは<b>原形（もとの形）</b>。2-2 でならったルールと同じです。'),
  ]),
  ('テストによく出ることば', [
    ('t','主語ごとの<b>短い形</b>をそのままおぼえてしまうのが、いちばん早いです。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>使うとき</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">I&#39;m going to</span></td><td class="k">わたしは～する予定</td><td class="e"><u>I&#39;m going to</u> visit Okinawa.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">He&#39;s going to</span></td><td class="k">he・she・名前</td><td class="e"><u>He&#39;s going to</u> play soccer.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">Are you going to</span></td><td class="k">たずねる文</td><td class="e"><u>Are you going to</u> visit?</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">not going to</span></td><td class="k">打ち消し</td><td class="e">I&#39;m <u>not going to</u> visit.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">I&#39;m going to</span> ・ <span class="en">Are you going to</span> ・ <span class="en">not going to</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('たずねる文と打ち消しの作り方', [
    ('t','be動詞の文なので、<b>1年生でならったルールがそのまま使えます</b>。<span class="en">Do</span> は使いません。'),
    ('h','''<table class="kind">
      <thead><tr><th>作る文</th><th>やり方</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k">たずねる文</td><td class="k" style="color:var(--ng);font-weight:700;">be動詞を前に出す</td><td class="e"><u>Are</u> you going to visit?</td></tr>
        <tr><td class="k">打ち消し</td><td class="k" style="color:var(--ng);font-weight:700;">be動詞のうしろに not</td><td class="e">I&#39;m <u>not</u> going to visit.</td></tr>
        <tr><td class="k">答え方</td><td class="k">be動詞で返す</td><td class="e">— Yes, I <u>am</u>. ／ No, I&#39;m <u>not</u>.</td></tr>
      </tbody>
    </table>'''),
    ('t','<span class="en">Do you going to ～?</span> とは言いません。<b>be動詞の文には <span class="en">Do</span> を使わない</b>、これも1年生と同じです。'),
  ]),
  ('「いつのことか」を表すことば', [
    ('t','これからのことなので、<b>未来を表すことば</b>がいっしょによく出てきます。'),
    ('h','''<div class="eqbox">
      <span class="eq">tomorrow</span>（あした）　<span class="eq">next week</span>（来週）　<span class="eq">next summer</span>（来年の夏）　<span class="eq">this weekend</span>（今週末）
    </div>'''),
    ('t','1年生でならった <span class="en">last week</span>（先週）の反対が <span class="en">next week</span>（来週）です。セットでおぼえましょう。'),
  ]),
 ],
 'quiz':[
  ('I am going to visits Okinawa.','I am going to visit Okinawa.','<span class="en">to</span> のうしろは<b>原形（もとの形）</b>。<span class="en">s</span> はつけません。','わたしは 沖縄を たずねる 予定です。'),
  ('He are going to play soccer.','He is going to play soccer.','主語が <span class="en">He</span> なので <b><span class="en">is</span></b>。','彼は サッカーを する 予定です。'),
  ('I going to visit Okinawa.','I am going to visit Okinawa.','<b>be動詞が抜けています</b>。<span class="en">am</span> が必要です。','わたしは 沖縄を たずねる 予定です。'),
  ('Do you going to visit Okinawa?','Are you going to visit Okinawa?','be動詞の文なので <b><span class="en">Are</span></b> を前に出します。','あなたは 沖縄を たずねる 予定ですか。'),
  ('I am going to visiting Okinawa.','I am going to visit Okinawa.','<span class="en">to</span> と <span class="en">ing</span> を<b>両方つけません</b>。','わたしは 沖縄を たずねる 予定です。'),
  ('Are you going to visit? — Yes, I do.','Are you going to visit? — Yes, I am.','be動詞で聞かれたら <b>be動詞で答えます</b>。','たずねる 予定ですか。— はい、そうです。'),
 ],
 'summary':[
  '<b><span class="en">be動詞 ＋ going to ＋ 動詞の原形（もとの形）</span></b> ＝「～する予定です」。',
  '主語で変わるのは <b>be動詞だけ</b>（<span class="en">am・is・are</span>）。うしろはいつも同じ。',
  'たずねる文は <b>be動詞を前に出す</b>。打ち消しは <b>be動詞のうしろに <span class="en">not</span></b>。',
  '答えも <b>be動詞で返す</b>。<span class="en">Yes, I am. ／ No, I&#39;m not.</span>',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '「～する予定です」は、be動詞 ＋%s＋ 動詞の原形（もとの形） で表す。' % bl('going to', False),
     '主語によって変わるのは%sだけである。' % bl('be動詞', False),
     '<span class="en">to</span> のうしろの動詞は%sの形にする。' % bl('もと'),
     'たずねる文は、be動詞を文の%sに出す。' % bl('前'),
     '打ち消しは、be動詞のうしろに%sを置く。' % bl('not'),
   ]),
   'words':'語群：<span class="en">going to</span> ／ be動詞 ／ もと ／ 前 ／ <span class="en">not</span>',
   'exp':'<b>なぜ？</b>　<span class="en">going to</span> はもともと「～へ向かっている」という意味です。<br>'
         '気もちがもうその予定に<b>向かっている</b>ので、「決めてあること」を表します。だから思いつきには使いません。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　be動詞を書こう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>主語だけ</b>を見て決めましょう。',
   'body':grid2([
     '1. <span class="en">I%sgoing to visit Okinawa.</span>' % bl('am'),
     '2. <span class="en">He%sgoing to play soccer.</span>' % bl('is'),
     '3. <span class="en">They%sgoing to study.</span>' % bl('are'),
     '4. <span class="en">She%sgoing to buy a book.</span>' % bl('is'),
     '5. <span class="en">You%sgoing to stay home.</span>' % bl('are'),
     '6. <span class="en">We%sgoing to watch TV.</span>' % bl('are'),
     '7. <span class="en">My father%sgoing to cook.</span>' % bl('is'),
     '8. <span class="en">%syou going to visit Okinawa?</span>' % bl('Are'),
     '9. <span class="en">%she going to play soccer?</span>' % bl('Is'),
     '10. <span class="en">Tina and Kota%sgoing to sing.</span>' % bl('are'),
   ]),
   'exp':'<b>見分け方</b>　<span class="en">I</span> → <span class="en">am</span>（1）<br>'
         '<span class="en">he・she</span>・名前1人・1つのもの → <span class="en">is</span>（2・4・7・9）<br>'
         '<span class="en">you・they・we</span>・2人以上 → <span class="en">are</span>（3・5・6・8・10）'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. I am going to visit Okinawa.','○'), ('2. I going to visit Okinawa.','✕'),
     ('3. He is going to play soccer.','○'), ('4. He is going to plays soccer.','✕'),
     ('5. Are you going to study?','○'), ('6. Do you going to study?','✕'),
     ('7. I&#39;m not going to go out.','○'), ('8. I don&#39;t going to go out.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">am</span> を入れる　4 → <span class="en">play</span>（原形（もとの形））<br>'
         '6 → <span class="en">Are you going to study?</span>　8 → <span class="en">I&#39;m not going to ～</span>（be動詞の文に <span class="en">don&#39;t</span> は使わない）'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'be動詞の文です。1年生の <span class="en">Are you ～?</span> と同じルールで考えよう。',
   'body':grid2([
     '1. <span class="en">I am going to （ア visit ／イ visits） Okinawa.</span>%s' % bl('ア'),
     '2. <span class="en">He （ア are ／イ is） going to play soccer.</span>%s' % bl('イ'),
     '3. <span class="en">（ア Do ／イ Are） you going to study?</span>%s' % bl('イ'),
     '4. <span class="en">I&#39;m （ア not ／イ don&#39;t） going to go out.</span>%s' % bl('ア'),
     '5. <span class="en">Are you going to visit? — Yes, I （ア do ／イ am）.</span>%s' % bl('イ'),
     '6. <span class="en">They （ア are ／イ is） going to sing.</span>%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　3・4・5 は、<b>be動詞の文に <span class="en">do</span> を混ぜない</b>というルールです。<br>'
         '1 は <span class="en">to</span> のうしろの形、2・6 は主語に合わせた be動詞です。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　まず主語を見て be動詞を決め、そのあと <span class="en">going to</span> ＋ 原形（もとの形）。',
   'body':ol([
     ('<span class="jp-cue">わたしは沖縄をたずねる予定です。</span>　<span class="en">I%sgoing to visit Okinawa.</span>' % bl('am'),
      '<span class="en">I</span> なので <span class="en">am</span>。'),
     ('<span class="jp-cue">彼はサッカーをする予定です。</span>　<span class="en">He is going to%ssoccer.</span>' % bl('play'),
      '<span class="en">to</span> のうしろは原形（もとの形）。'),
     ('<span class="jp-cue">あなたは沖縄をたずねる予定ですか。</span>　<span class="en">%syou going to visit Okinawa?</span>' % bl('Are'),
      'be動詞を前に出す。'),
     ('<span class="jp-cue">はい、そうです。</span>　<span class="en">Yes, I%s.</span>' % bl('am'),
      'be動詞で答える。'),
     ('<span class="jp-cue">いいえ、ちがいます。</span>　<span class="en">No, I&#39;m%s.</span>' % bl('not'),
      '<span class="en">I&#39;m not</span> の形。'),
     ('<span class="jp-cue">彼らは来週、勉強する予定です。</span>　<span class="en">They%sgoing to study next week.</span>' % bl('are'),
      '<span class="en">They</span> なので <span class="en">are</span>。'),
     ('<span class="jp-cue">わたしはあした出かける予定はありません。</span>　<span class="en">I&#39;m%sgoing to go out tomorrow.</span>' % bl('not'),
      'be動詞のうしろに <span class="en">not</span>。'),
     ('<span class="jp-cue">彼女は本を買う予定です。</span>　<span class="en">She%s%sto buy a book.</span>' % (bl('is'), bl('going', False)),
      '（　）が2つ。<span class="en">is going to</span>。'),
     ('<span class="jp-cue">わたしたちは今週末、テレビを見る予定です。</span>　<span class="en">We are going to%sTV this weekend.</span>' % bl('watch'),
      '「見る」は <span class="en">watch</span>。'),
     ('<span class="jp-cue">彼は家にいる予定ですか。</span>　<span class="en">%she going to stay home?</span>' % bl('Is'),
      '主語が <span class="en">he</span> なので <span class="en">Is</span>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　主語 → be動詞 → <span class="en">going to</span> → 動詞 → そのほか、の順。',
   'body':ol([
     ('<span class="jp-cue">わたしは沖縄をたずねる予定です。</span>　<span class="paren en">（ going to / Okinawa / I&#39;m / visit ）</span>' + line('I&#39;m going to visit Okinawa.'),
      '<span class="en">I&#39;m going to</span> でひとかたまり。'),
     ('<span class="jp-cue">彼はサッカーをする予定です。</span>　<span class="paren en">（ soccer / He / play / is going to ）</span>' + line('He is going to play soccer.'),
      '<span class="en">play</span> は原形（もとの形）。'),
     ('<span class="jp-cue">あなたは沖縄をたずねる予定ですか。</span>　<span class="paren en">（ Okinawa / going to / Are you / visit ）</span>' + line('Are you going to visit Okinawa?'),
      '<span class="en">Are</span> が先頭。終わりは <b>?</b>。'),
     ('<span class="jp-cue">彼らは来週、勉強する予定です。</span>　<span class="paren en">（ next week / They / going to study / are ）</span>' + line('They are going to study next week.'),
      '「いつ」はいちばん後ろ。'),
     ('<span class="jp-cue">わたしはあした出かける予定はありません。</span>　<span class="paren en">（ tomorrow / go out / I&#39;m not / going to ）</span>' + line('I&#39;m not going to go out tomorrow.'),
      '<span class="en">not</span> は be動詞のうしろ。'),
     ('<span class="jp-cue">彼女は本を買う予定です。</span>　<span class="paren en">（ a book / going to / She is / buy ）</span>' + line('She is going to buy a book.'),
      '<span class="en">She is going to</span> の順。'),
     ('<span class="jp-cue">彼は家にいる予定ですか。</span>　<span class="paren en">（ stay home / he / going to / Is ）</span>' + line('Is he going to stay home?'),
      '<span class="en">Is</span> → 主語 → <span class="en">going to</span>。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしは沖縄をたずねる予定です。' + wline('I&#39;m going to visit Okinawa.'),
      '<span class="en">I am</span> でも正解。'),
     ('彼はサッカーをする予定です。' + wline('He is going to play soccer.'),
      '<span class="en">plays</span> にしない。'),
     ('あなたは勉強する予定ですか。' + wline('Are you going to study?'),
      '<span class="en">Do you</span> にしない。'),
     ('わたしはあした出かける予定はありません。' + wline('I&#39;m not going to go out tomorrow.'),
      '<span class="en">don&#39;t</span> を使わない。'),
     ('彼らは来週、勉強する予定です。' + wline('They are going to study next week.'),
      '<span class="en">They</span> は <span class="en">are</span>。'),
     ('彼女は本を買う予定です。' + wline('She is going to buy a book.'),
      '<span class="en">She&#39;s</span> でも正解。'),
   ]),
   'words':'<span class="en">going to visit ／ going to play ／ Are you going to ／ not going to ／ next week ／ buy a book</span>'},
  'l4':{'sub':'この週末や次の休みの予定を書こう',
   'cond':['<span class="en">be going to</span> を使った文を <b>2つ以上</b>',
           '打ち消しの文（<span class="en">not going to</span>）を <b>1つ</b>',
           '「いつのことか」を表すことばを <b>1つ以上</b> 入れる'],
   'example':['I&#39;m going to visit my grandmother next weekend.','We are going to have lunch together.','I&#39;m not going to study on Sunday.'],
   'note':'これは例です。同じでなくてかまいません。「だれと」「どこで」を足すと、文がくわしくなります。',
   'check':['be動詞が主語に合っている','to のうしろは原形（もとの形）','打ち消しは be動詞のうしろに not','いつのことかを書いた'],
   'review':'じぶんの文の be動詞に○をつけよう。<span class="en">going to</span> のうしろに <span class="en">s</span> や <span class="en">ing</span> があったら、そこがまちがい。'},
 },
}
