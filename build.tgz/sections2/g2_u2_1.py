# -*- coding: utf-8 -*-
from gen import ol, bl, line, wline, grid2, olq, tf, gitem, copybox

S = {
 'id':'g2-u2-1', 'grade':2, 'unit':'2 − 1', 'unit_plain':'2-1',
 'title':'動名詞', 'pages':'p.20〜21',
 'hero_big':'I like playing soccer.',
 'hero_jp':'わたしは サッカーを するのが 好きです',
 'motto':'<span class="en">動詞ing</span> は <b>「～すること」</b>。名前のかわりに 主語にも 目的語にもなる。',
 'kana':{'playing':'プレイング','passing':'パッスィング','swimming':'スウィミング',
         'running':'ラニング','dancing':'ダンスィング','cooking':'クッキング',
         'reading':'リーディング','singing':'スィンギング','writing':'ライティング',
         'basketball':'バスケットボール','ball':'ボール','easy':'イーズィ',
         'good':'グッド','at':'アット','like':'ライク','likes':'ライクス',
         'enjoy':'インヂョイ','finish':'フィニッシュ','start':'スタート','hobby':'ハビィ'},
 'blocks':[
  ('きほんの文', [
    ('t','動詞に <span class="en">ing</span> をつけると、「<b>～すること</b>」という意味の、<b>ものの名前のような ことば</b>になります。'),
    ('t','<span class="en">play</span>（する）→ <span class="en">playing</span>（すること）。出てくる場所が<b>3つ</b>あります。'),
    ('h', gitem('❶', '動詞の<b>うしろ</b>に置く', 'いちばん多い形',
                'サッカーを するのが 好きです', 'like playing soccer',
                [('I like playing soccer.','わたしは サッカーを するのが 好きです。'),
                 ('I enjoy playing soccer.','わたしは サッカーを して 楽しみます。')],
                '<span class="en">like・enjoy・finish</span> などのうしろに置きます。')),
    ('h', gitem('❷', '<span class="en">at・of</span> などの<b>うしろ</b>に置く', '前置詞のあと',
                'サッカーを するのが 得意です', 'good at playing soccer',
                [('I am good at playing soccer.','わたしは サッカーを するのが 得意です。'),
                 ('Thank you for helping me.','手伝って くれて ありがとう。')],
                '<span class="en">at・for・of</span> のうしろは<b>名前のなかま</b>しか置けないので、<span class="en">ing</span> の形にします。')),
    ('h', gitem('❸', '文の<b>主語</b>になる', '文の先頭',
                'サッカーを することは 楽しい', 'Playing soccer is fun.',
                [('Playing soccer is fun.','サッカーを することは 楽しいです。'),
                 ('Reading books is important.','本を 読むことは 大切です。')],
                '文の先頭に置けば<b>主語</b>になります。<span class="en">Play soccer is fun.</span> とは言えません。', b2=True)),
    ('t','どれも <span class="en">ing</span> の形ひとつで「～すること」。進行形（<span class="en">be</span>動詞＋<span class="en">ing</span>）とはちがうので注意しましょう。'),
    ('h', copybox()),
  ]),
  ('かなり大事｜<span class="en">動詞ing</span> は「名前」のなかま', [
    ('t','ここが今回のヤマです。<span class="en">動詞ing</span> は、<b>ものの名前と同じ場所</b>に置けます。だから<b>主語にもなれる</b>のです。'),
    ('h','''<table class="kind">
      <thead><tr><th>置く場所</th><th>名前のとき</th><th>動詞ing のとき</th></tr></thead>
      <tbody>
        <tr><td class="k">主語（文のはじめ）</td><td class="e">Soccer is fun.</td><td class="e"><u>Playing soccer</u> is fun.</td></tr>
        <tr><td class="k">動詞のうしろ</td><td class="e">I like soccer.</td><td class="e">I like <u>playing soccer</u>.</td></tr>
        <tr><td class="k"><span class="en">at・of</span> などのうしろ</td><td class="e">I&#39;m good at soccer.</td><td class="e">I&#39;m good at <u>playing soccer</u>.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="judge">
      <div class="col yes">
        <div class="ttl"><svg class="ic-l"><use href="#i-person"/></svg>
          <span>◯ ing のまま<small>名前のなかまとして置く</small></span></div>
        <div class="in"><div class="ex">I like playing soccer.<br>Passing the ball isn&#39;t easy.</div></div>
      </div>
      <div class="col no">
        <div class="ttl"><svg class="ic-l"><use href="#i-globe"/></svg>
          <span>✕ 原形（もとの形）のまま<small>名前にならない</small></span></div>
        <div class="in"><div class="ex">I like play soccer.<br>Pass the ball isn&#39;t easy.</div></div>
      </div>
    </div>'''),
    ('t','<span class="en">I like play soccer.</span> だと、<b>心臓（動詞）が2つ</b>になってしまいます。<span class="en">playing</span> にすれば、動詞ではなく「名前」になるので1つで済みます。'),
  ]),
  ('テストによく出ることば', [
    ('t','<span class="en">ing</span> のつけ方は3パターンです。1年生の 3-2 でならったものと同じです。'),
    ('h','''<table class="kind kw">
      <thead><tr><th>ことば</th><th>つけ方</th><th>れい</th></tr></thead>
      <tbody>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">playing</span></td><td class="k">そのまま ing</td><td class="e">I like <u>playing</u> soccer.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">passing</span></td><td class="k">e をとって ing</td><td class="e">I&#39;m good at <u>passing</u>.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">swimming</span></td><td class="k">m をかさねて ing</td><td class="e">I like <u>swimming</u>.</td></tr>
        <tr><td class="k"><svg class="pn"><use href="#i-pen"/></svg><span class="en">running</span></td><td class="k">n をかさねて ing</td><td class="e">I enjoy <u>running</u>.</td></tr>
      </tbody>
    </table>'''),
    ('h','''<div class="copy">
      <svg><use href="#i-pen"/></svg>
      <div><span class="en">playing</span> ・ <span class="en">passing</span> ・ <span class="en">swimming</span> ・ <span class="en">running</span> を3回ずつ書き写そう！</div>
    </div>'''),
  ]),
  ('進行形の <span class="en">ing</span> とのちがい', [
    ('t','形は同じ <span class="en">動詞ing</span> ですが、<b>前に be動詞があるかどうか</b>で意味が変わります。'),
    ('h','''<table class="kind">
      <thead><tr><th>形</th><th>意味</th><th>れい文</th></tr></thead>
      <tbody>
        <tr><td class="k" style="color:var(--key);font-weight:700;">be動詞 ＋ 動詞ing</td><td class="k">～しているところ（進行形）</td><td class="e">I <u>am playing</u> soccer.</td></tr>
        <tr><td class="k" style="color:var(--gv);font-weight:700;">動詞ing だけ</td><td class="k">～すること（名前のなかま）</td><td class="e">I like <u>playing</u> soccer.</td></tr>
      </tbody>
    </table>'''),
    ('t','be動詞があれば「今やっている」、なければ「～すること」。<b>be動詞を見るだけ</b>で見分けられます。'),
  ]),
  ('<span class="en">ing</span> をうしろに置く動詞', [
    ('t','「～すること」をうしろに置ける動詞は決まっています。よく出る4つをおぼえましょう。'),
    ('h','''<div class="eqbox" style="border-left-color:var(--gv);background:rgba(194,24,91,.06);">
      <span class="eq" style="color:var(--gv);">like ～ing</span>（～するのが好き）　<span class="eq" style="color:var(--gv);">enjoy ～ing</span>（～して楽しむ）<br>
      <span class="eq" style="color:var(--gv);">start ～ing</span>（～し始める）　<span class="eq" style="color:var(--gv);">finish ～ing</span>（～し終える）
    </div>'''),
    ('t','<span class="en">be good at ～ing</span>（～するのが得意）も、会話でとてもよく使います。'),
  ]),
 ],
 'quiz':[
  ('I like play basketball.','I like playing basketball.','<span class="en">like</span> のうしろは「～すること」。<b><span class="en">playing</span></b> にします。','わたしは バスケットボールを するのが 好きです。'),
  ('Play soccer isn&#39;t easy.','Playing soccer isn&#39;t easy.','主語になるので <b><span class="en">Playing</span></b>。原形（もとの形）では主語になれません。','サッカーを することは かんたんでは ありません。'),
  ('I&#39;m not good at cook.','I&#39;m not good at cooking.','<span class="en">at</span> のうしろは<b>名前のなかま</b>。<span class="en">cooking</span> にします。','わたしは 料理を するのが 得意では ありません。'),
  ('I like swiming.','I like swimming.','<b><span class="en">m</span> をかさねて</b> <span class="en">ing</span>。','わたしは 泳ぐことが 好きです。'),
  ('I am like playing soccer.','I like playing soccer.','<span class="en">am</span> と <span class="en">like</span> で<b>心臓が2つ</b>。<span class="en">am</span> はいりません。','わたしは サッカーを するのが 好きです。'),
  ('I like to playing soccer.','I like playing soccer.','<span class="en">to</span> と <span class="en">ing</span> を<b>両方つけません</b>。どちらか1つです。','わたしは サッカーを するのが 好きです。'),
 ],
 'summary':[
  '<b><span class="en">動詞ing</span> ＝「～すること」</b>。ものの名前と同じ場所に置ける。',
  '<b>主語にもなれる</b>。<span class="en">Playing soccer is fun.</span>',
  '<span class="en">like・enjoy・start・finish</span> や <span class="en">at・of</span> のうしろに置く。',
  '前に<b>be動詞があれば進行形</b>、<b>なければ「～すること」</b>。',
 ],
 'p2':[
  {'h':'<h3 class="sec">A　説明の（　）をうめよう<em>語群から選びます（同じ語を2回使ってもよい）</em></h3>',
   'body':olq([
     '動詞に%sをつけると「～すること」という意味になる。' % bl('ing'),
     'この形は、ものの%sと同じ場所に置ける。' % bl('名前'),
     'だから、文の%sになることもできる。' % bl('主語'),
     '<span class="en">at</span> や <span class="en">of</span> のうしろは、原形（もとの形）ではなく%sの形にする。' % bl('ing'),
     '前に%sがあれば、それは進行形である。' % bl('be動詞', False),
   ]),
   'words':'語群：<span class="en">ing</span> ／ 名前 ／ 主語 ／ be動詞',
   'exp':'<b>なぜ？</b>　英語では、文の主語になれるのは<b>ものの名前</b>だけです。<br>'
         '「泳ぐこと」を主語にしたいとき、<span class="en">swim</span> のままでは動詞なので置けません。<span class="en">swimming</span> にして名前のなかまに変えるのです。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">B　<span class="en">ing</span> の形にしよう<em>（　）に1語ずつ書こう</em></h3>',
   'hint':'ここが<b>かなり大事</b>。<b>つづりの変化</b>に気をつけましょう。',
   'body':grid2([
     '1. <span class="en">play → %s</span>' % bl('playing', False),
     '2. <span class="en">swim → %s</span>' % bl('swimming', False),
     '3. <span class="en">pass → %s</span>' % bl('passing', False),
     '4. <span class="en">run → %s</span>' % bl('running', False),
     '5. <span class="en">dance → %s</span>' % bl('dancing', False),
     '6. <span class="en">read → %s</span>' % bl('reading', False),
     '7. <span class="en">write → %s</span>' % bl('writing', False),
     '8. <span class="en">cook → %s</span>' % bl('cooking', False),
     '9. <span class="en">sing → %s</span>' % bl('singing', False),
     '10. <span class="en">get → %s</span>' % bl('getting', False),
   ]),
   'exp':'<b>見分け方</b>　そのまま <span class="en">ing</span> → 1・6・8・9<br>'
         '<b>e をとる</b> → 3（<span class="en">pass</span> はもともと e なし）・5・7<br>'
         '<b>字をかさねる</b> → 2・4・10<br>'
         '※ <span class="en">pass</span> はそのまま <span class="en">ing</span> をつけます。'},
  {'h':'<h3 class="sec sec2" style="border-left-color:#D98400;">C　正しい文には ○、まちがっている文には ✕ を書こう</h3>',
   'body':tf([
     ('1. I like playing soccer.','○'), ('2. I like play soccer.','✕'),
     ('3. Playing soccer is fun.','○'), ('4. Play soccer is fun.','✕'),
     ('5. I&#39;m good at swimming.','○'), ('6. I&#39;m good at swim.','✕'),
     ('7. I enjoy reading books.','○'), ('8. I am like playing soccer.','✕'),
   ]),
   'exp':'<b>直し方</b>　2 → <span class="en">playing</span>　4 → <span class="en">Playing soccer is fun.</span>（主語にするので <span class="en">ing</span>）<br>'
         '6 → <span class="en">swimming</span>（<span class="en">at</span> のうしろ）　8 → <span class="en">am</span> をとる（心臓が2つ）'},
  {'h':'<h3 class="sec sec2">D　正しいほうを選ぼう</h3>',
   'hint':'前に <span class="en">be動詞</span> があるかどうかを、まず見よう。',
   'body':grid2([
     '1. <span class="en">I like （ア play ／イ playing） basketball.</span>%s' % bl('イ'),
     '2. <span class="en">（ア Passing ／イ Pass） the ball isn&#39;t easy.</span>%s' % bl('ア'),
     '3. <span class="en">I&#39;m good at （ア pass ／イ passing） the ball.</span>%s' % bl('イ'),
     '4. <span class="en">I am （ア playing ／イ play） soccer now.</span>%s' % bl('ア'),
     '5. <span class="en">I enjoy （ア read ／イ reading） books.</span>%s' % bl('イ'),
     '6. <span class="en">（ア Swimming ／イ Swim） is fun.</span>%s' % bl('ア'),
   ]),
   'exp':'<b>ここが大事</b>　4だけが<b>進行形</b>です。前に <span class="en">am</span> があり、<span class="en">now</span> もあります。<br>'
         'ほかはすべて「～すること」。2・6 は<b>主語</b>の位置なので、原形（もとの形）では置けません。'},
 ],
 'p3':{
  'l1':{'hint':'<b>コツ</b>　「～すること」なら <span class="en">ing</span>。つづりの変化にも気をつけよう。',
   'body':ol([
     ('<span class="jp-cue">わたしはバスケットボールをするのが好きではありません。</span>　<span class="en">I don&#39;t like%sbasketball.</span>' % bl('playing', False),
      '<span class="en">like</span> のうしろは <span class="en">ing</span>。'),
     ('<span class="jp-cue">ボールをパスすることはかんたんではありません。</span>　<span class="en">%sthe ball isn&#39;t easy.</span>' % bl('Passing', False),
      '主語なので<b>大文字</b>で始める。'),
     ('<span class="jp-cue">わたしはボールをパスするのが得意ではありません。</span>　<span class="en">I&#39;m not good at%sthe ball.</span>' % bl('passing', False),
      '<span class="en">at</span> のうしろ。'),
     ('<span class="jp-cue">わたしは泳ぐのが好きです。</span>　<span class="en">I like%s.</span>' % bl('swimming', False),
      '<span class="en">m</span> をかさねる。'),
     ('<span class="jp-cue">わたしは本を読んで楽しみます。</span>　<span class="en">I%sreading books.</span>' % bl('enjoy'),
      '「楽しむ」は <span class="en">enjoy</span>。'),
     ('<span class="jp-cue">走ることは楽しいです。</span>　<span class="en">%sis fun.</span>' % bl('Running', False),
      '<span class="en">n</span> をかさねる。主語なので大文字。'),
     ('<span class="jp-cue">わたしは今サッカーをしています。</span>　<span class="en">I%splaying soccer now.</span>' % bl('am'),
      'これは<b>進行形</b>。be動詞が必要。'),
     ('<span class="jp-cue">わたしはおどるのが得意です。</span>　<span class="en">I&#39;m good%sdancing.</span>' % bl('at'),
      '「～が得意」は <span class="en">be good at</span>。'),
     ('<span class="jp-cue">わたしは料理をし終えました。</span>　<span class="en">I%scooking.</span>' % bl('finished', False),
      '「～し終える」は <span class="en">finish</span>。過去形に。'),
     ('<span class="jp-cue">歌うことはわたしの趣味です。</span>　<span class="en">%sis my hobby.</span>' % bl('Singing', False),
      '主語の位置。そのまま <span class="en">ing</span>。'),
   ], sp=True)},
  'l2':{'hint':'<b>コツ</b>　「～すること」のかたまりがどこまでかを、先に見つけよう。',
   'body':ol([
     ('<span class="jp-cue">わたしはバスケットボールをするのが好きではありません。</span>　<span class="paren en">（ playing basketball / I / like / don&#39;t ）</span>' + line('I don&#39;t like playing basketball.'),
      '<span class="en">playing basketball</span> でひとかたまり。'),
     ('<span class="jp-cue">ボールをパスすることはかんたんではありません。</span>　<span class="paren en">（ isn&#39;t easy / Passing / the ball ）</span>' + line('Passing the ball isn&#39;t easy.'),
      '<span class="en">Passing the ball</span> が主語。'),
     ('<span class="jp-cue">わたしはボールをパスするのが得意ではありません。</span>　<span class="paren en">（ passing the ball / I&#39;m / at / not good ）</span>' + line('I&#39;m not good at passing the ball.'),
      '<span class="en">be good at</span> でひとかたまり。'),
     ('<span class="jp-cue">サッカーをすることは楽しいです。</span>　<span class="paren en">（ is fun / soccer / Playing ）</span>' + line('Playing soccer is fun.'),
      '主語が2語。'),
     ('<span class="jp-cue">わたしは本を読んで楽しみます。</span>　<span class="paren en">（ books / enjoy / reading / I ）</span>' + line('I enjoy reading books.'),
      '<span class="en">enjoy</span> のうしろは <span class="en">ing</span>。'),
     ('<span class="jp-cue">わたしは今サッカーをしています。</span>　<span class="paren en">（ soccer / am / now / I / playing ）</span>' + line('I am playing soccer now.'),
      'これだけ<b>進行形</b>。<span class="en">am</span> が入る。'),
     ('<span class="jp-cue">歌うことはわたしの趣味です。</span>　<span class="paren en">（ my hobby / Singing / is ）</span>' + line('Singing is my hobby.'),
      '<span class="en">Singing</span> 1語が主語。'),
   ])},
 },
 'p4':{
  'l3':{'body':ol([
     ('わたしはバスケットボールをするのが好きではありません。' + wline('I don&#39;t like playing basketball.'),
      '<span class="en">play</span> のままにしない。'),
     ('ボールをパスすることはかんたんではありません。' + wline('Passing the ball isn&#39;t easy.'),
      '主語なので大文字で始める。'),
     ('わたしはボールをパスするのが得意ではありません。' + wline('I&#39;m not good at passing the ball.'),
      '<span class="en">at</span> のうしろは <span class="en">ing</span>。'),
     ('サッカーをすることは楽しいです。' + wline('Playing soccer is fun.'),
      '<span class="en">is</span> を忘れない。'),
     ('わたしは本を読んで楽しみます。' + wline('I enjoy reading books.'),
      '<span class="en">enjoy to read</span> とは言わない。'),
     ('歌うことはわたしの趣味です。' + wline('Singing is my hobby.'),
      '<span class="en">Sing</span> では主語になれない。'),
   ]),
   'words':'<span class="en">playing basketball ／ Passing the ball ／ good at ／ Playing soccer ／ enjoy reading ／ Singing</span>'},
  'l4':{'sub':'自分の好きなこと・得意なことを書こう',
   'cond':['<span class="en">like ～ing</span> を使った文を <b>1つ以上</b>',
           '<span class="en">be good at ～ing</span> を使った文を <b>1つ</b>',
           '<span class="en">～ing</span> を<b>主語</b>にした文も <b>1つ</b> 入れる'],
   'example':['I like playing the guitar.','I&#39;m good at cooking.','Running every morning is hard for me.'],
   'note':'これは例です。同じでなくてかまいません。「得意ではない」なら <span class="en">I&#39;m not good at ～ing.</span> と書けます。',
   'check':['ing の形になっている','つづりの変化（swimming など）','be動詞を足していない','主語の文は大文字で始めた'],
   'review':'じぶんの文に <span class="en">to</span> と <span class="en">ing</span> が両方ついていないか見直そう。どちらか1つです。'},
 },
}
