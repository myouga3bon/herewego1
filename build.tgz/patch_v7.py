# -*- coding: utf-8 -*-
"""patch_v7: 1) 間違いさがしクイズの答えを2文字ぶん右へ
             2) ヒント無しでは答えられない問題にヒントを添える
             3) 鉛筆マークをベタ塗りに"""
import re

# ---- 3) 鉛筆アイコンをベタ塗りに ------------------------------------------
PEN_OLD = ('<symbol id="i-pen" viewBox="0 0 24 24"><path d="M16.6 3.4a2 2 0 0 1 2.8 0'
           'l1.2 1.2a2 2 0 0 1 0 2.8L9.2 19.8l-4.9 1.3 1.3-4.9z" fill="none" '
           'stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></symbol>')
PEN_NEW = ('<symbol id="i-pen" viewBox="0 0 24 24"><path d="M16.6 3.4a2 2 0 0 1 2.8 0'
           'l1.2 1.2a2 2 0 0 1 0 2.8L9.2 19.8l-4.9 1.3 1.3-4.9z" fill="currentColor" '
           'stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></symbol>')

PEN_RULES = [
 '.copy svg{width:24px;height:24px;flex:none;color:%s;}',
 '.exline .pn{width:14px;height:14px;flex:none;color:%s;align-self:center;margin-right:-5px;}',
 'table.kind td.k .pn{width:13px;height:13px;color:%s;',
]

# ---- 1)+2) CSS -------------------------------------------------------------
CSS_OLD = '.qza{display:none;margin:4px 0 1px 26px;}'
CSS_NEW = ('.qza{display:none;margin:4px 0 1px 52px;}\n'
           '  .qzq .qzt{font-family:"Zen Kaku Gothic New",sans-serif;font-weight:500;\n'
           '    font-size:9pt;color:var(--mut);margin-left:8px;}\n'
           '  .qzq .qzt b{color:var(--ng);font-weight:700;}')

# ---- 2) ヒント（ファイル → ✕の文 → ヒント本文） ----------------------------
HINTS = {
 'u2-1.html': {
   '✕ Yes, you are. ✕':
     '<span class="en">Are you Ken?</span> に <b>はい</b> と答えたい場合',
 },
 'u3-1.html': {
   '✕ What do you like music? ✕':
     '<b>「何が好きですか」</b>と たずねたい場合',
   '✕ What do you like? — Yes, I do. ✕':
     '<b>「音楽が好きです」</b>と 答えたい場合',
 },
 'u4-2.html': {
   '✕ Who&#39;s that girl? — Yes, she is. ✕':
     '<b>「わたしの姉です」</b>と 答えたい場合',
 },
 'u5-2.html': {
   '✕ Where is my bag? — Yes, it is. ✕':
     '<b>「机の上にある」</b>と 答えたい場合',
 },
 'u5-3.html': {
   '✕ When is your birthday? — Yes, it is. ✕':
     '<b>「8月です」</b>と 答えたい場合',
   '✕ Where is your birthday? ✕':
     '<b>「いつ」</b>を たずねたい場合',
 },
 'u6-2.html': {
   '✕ Does he a student? ✕':
     '<b>「彼は生徒ですか」</b>と たずねたい場合',
 },
 'u4-3.html': {
   '✕ Is this your bag? — Yes, this is. ✕':
     '<b>「はい、そうです」</b>と 答えたい場合',
 },
}

def apply(src, name):
    s = src
    n_pen = s.count(PEN_OLD)
    s = s.replace(PEN_OLD, PEN_NEW)
    n_css = s.count(CSS_OLD)
    s = s.replace(CSS_OLD, CSS_NEW)
    for t in PEN_RULES:                   # 鉛筆マークだけ明るめの緑に
        s = s.replace(t % '#C88A16', t % '#35B44B')

    n_hint = 0
    for xm, note in HINTS.get(name, {}).items():
        old = '<span class="xm">%s</span>' % xm
        if old not in s:
            raise SystemExit('!! %s: 見つかりません %r' % (name, xm))
        new = old + '<span class="qzt">%s</span>' % note
        if '<span class="qzt">' not in s.split(old)[1][:40]:
            s = s.replace(old, new, 1)
            n_hint += 1
    return s, n_pen, n_css, n_hint

if __name__ == '__main__':
    import sys, glob, os
    files = sys.argv[1:] or sorted(glob.glob('/home/claude/u*.html'))
    for p in files:
        name = os.path.basename(p)
        src = open(p, encoding='utf-8').read()
        out, a, b, c = apply(src, name)
        open(p, 'w', encoding='utf-8').write(out)
        print('%-12s pen=%d qza=%d hint=%d' % (name, a, b, c))
